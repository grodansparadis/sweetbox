/*                                                                                                           
 *     usbcoce.c  --  USB-IR-Boy main module                                                           
 *                                                                                                           
 *     www.sourceforge.net/projects/usbirboy/                                                                
 *                                                                                                           
 *     Copyright (c) 2004 Ilkka Urtamo/Aapo Tamminen
 *                                                                                                           
 *                                                                                                           
 *     This program is free software; you can redistribute it and/or modify                                  
 *     it under the terms of the GNU General Public License as published by                                  
 *     the Free Software Foundation; either version 2 of the License, or                                     
 *     (at your option) any later version.                                                                   
 *                                                                                                           
 *     This program is distributed in the hope that it will be useful,                                       
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of                                        
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                         
 *     GNU General Public License for more details.                                                          
 *                                                                                                           
 *     You should have received a copy of the GNU General Public License                                     
 *     along with this program; if not, write to the Free Software                                           
 *     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.                                             
 *                                                                                                           
 *                                                                                                           
 */

#include "mc68hc908jb8.h"
#include "types.h"
#include "usbcore.h"
#include "ir.h"


void delay(void)
{
 begin_asm
    lda #240
    delay10: dbnza delay10
 end_asm
}

void main(void)
{
    uint8 a,b,ch;
    
  
#ifdef SDCC /*CW does this by default, I think*/
  _asm
    mov #33,31 // USB Reset Disable, COP Disable
    clr 10 // clear TSTOP, Prescaler=0
  _endasm;
  
#endif
      
  DDRA = 0xff; // make port A output
  PTA=0x01;
  
  usb_init(); // initialize usb subsystem
  cli(); 
  while(usb_dev_configured == FALSE); // wait until usb is initialized


  ir_init(); // initialize infrared receiving subsystem
  
  // toggle led rest of the evening
  for (;;) 
  {
      for (a=0; a<10; a++)
      {
	  for (b=0; b<255; b++)
	  {
	      delay();
	      if(usb_getc(&ch))
		  usb_putc(ch);
	  }
      }
      
      PTA^=0x01;
    }
}


/* define dummy intterrupt handlers */

#ifdef SDCC

void dummy_inth1(void) interrupt 1
{return;}
void dummy_inth3(void) interrupt 3
{return;}
void dummy_inth5(void) interrupt 5
{return;}

#else /*CW*/

interrupt void dummy_inth(void)
{return;}

#endif
