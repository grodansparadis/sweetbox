/* serial output (for debugging) */
#define SIO_TX 			1	/* serial send bit (PTA) */
#define SIO_SEND_BUFF_LEN	32	/* in bytes, must be a power of 2 */

/* USB */
#define USB_SEND_BUFF_LEN	64	/* in bytes, must be a power of 2 */
#define USB_RECEIVE_BUFF_LEN	32	/* in bytes, must be a power of 2 */

#define USB_VENDOR_ID		0xFFFE	/* manufacturer id (we use random from the end of the list) */
#define USB_PRODUCT_ID		0x0000	/* our product id */
#define USB_PRODUCT_VER		0x0030	/* our product version */

#define USB_POWERED		1	/* set to 1 if using USB power, 0 otherwise */

/* IR processing */
#define IR_FILTER		1	/* apply IR noise filter */
#define IR_DECODE 		0	/* set to 1 to send decoded keypresses, 0 to send raw IR codes */
#define IR_CONV_TIME		1	/* if 1, pulse/space lengths are in usecs (as in LIRC). Otherwise 1/3 usec */
#define IR_ENCODE_DATA		1	/* apply encoding to sent data */
#define IR_BUFF_LEN		8	/* in IR codes (4 bytes each), must be a power of 2 */

/* IR decoding (only if IR_DECODE defined) */
#define SPACE_ENC	1
#define EPS		30
#define AEPS		100
#define HEADER_PULSE	8810
#define HEADER_SPACE	4615
#define REPEAT_PULSE	8807
#define REPEAT_SPACE	2186
#define BIT_PULSE	581
#define ONE_SPACE	1687
#define ZERO_SPACE	548
#define PTRAIL		583
#define GAP		39713
#define REPEAT_GAP	95914
#define TOGGLE_BIT	0
#define PRE_DATA_BITS	16
#define PRE_DATA	0x3ec1
#define DATA_BITS	16

/* recognized keys */
#define KEY_ONE		0x29d6
#define KEY_TWO		0xa956
#define KEY_THREE	0x6996
#define KEY_FOUR	0xe916
#define KEY_FIVE	0x19e6
#define KEY_SIX		0x9966
#define KEY_SEVEN	0x59a6
#define KEY_EIGHT	0xd926
#define KEY_NINE	0x39c6
#define KEY_ZERO	0xc936
#define KEY_PLUSTEN	0xb946
#define KEY_ENTER	0x7986
#define KEY_TITLE	0x8d72
#define KEY_UP		0x2dd2
#define KEY_MENU	0x4db2
#define KEY_LEFT	0xad52
#define KEY_SELECT	0x1de2
#define KEY_RIGHT	0x6d92
#define KEY_RETURN	0xed12
#define KEY_DOWN	0xcd32
#define KEY_DISPLAY	0x659a
#define KEY_REC		0xd12e
#define KEY_REW		0x619e
#define KEY_FF		0xe11e
#define KEY_AUDIO	0xb54a
#define KEY_PAUSE	0xc13e
#define KEY_PREV	0x9d62
#define KEY_NEXT	0x5da2
#define KEY_STOP	0xa15e
#define KEY_PLAY	0x41be
#define KEY_AVPOWER	0x01fe
