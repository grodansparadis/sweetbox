#ifndef SERIAL_H
#define SERIAL_H


void sio_init(void);
void sio_send(void);
void sio_putc(unsigned char c);
void sio_sendc(unsigned char c);
void sio_puthex(unsigned char c);

#endif
