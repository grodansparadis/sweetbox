/*                                                                                                           
 *     ir.c  --  USB-IR-Boy IR receiver (TSOP 173x)
 *                                                                                                           
 *     www.sourceforge.net/projects/usbirboy/                                                                
 *                                                                                                           
 *     Copyright (c) 2004 Aapo Tamminen
 *                                                                                                           
 *                                                                                                           
 *     This program is free software; you can redistribute it and/or modify                                  
 *     it under the terms of the GNU General Public License as published by                                  
 *     the Free Software Foundation; either version 2 of the License, or                                     
 *     (at your option) any later version.                                                                   
 *                                                                                                           
 *     This program is distributed in the hope that it will be useful,                                       
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of                                        
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                         
 *     GNU General Public License for more details.                                                          
 *                                                                                                           
 *     You should have received a copy of the GNU General Public License                                     
 *     along with this program; if not, write to the Free Software                                           
 *     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.                                             
 *                                                                                                           
 *                                                                                                           
 */

#include "mc68hc908jb8.h"
#include "types.h"
#include "filter.h"


volatile uint8 ir_epoch;
volatile uint8 ir_start_epoch;
volatile uint8 ir_end_epoch;
volatile uu16 ir_start_time;
volatile uu16 ir_end_time;

void ir_init(void)
{
	TSC = TSTOP | TRST;
	TMODH = 0xff;
	TMODL = 0xff;
	TSC0 = CHIE | ELSA | ELSB;
	TSC = TOIE;
}

#ifdef SDCC
void epoch_inth(void) interrupt 6  
#else
interrupt void epoch_inth(void)
#endif
{
	uint8 u = TSC;
	uint8 new_epoch = ir_epoch + 1;
	if (new_epoch != ir_start_epoch)
		ir_epoch = new_epoch;
	TSC = u & ~TOF;
}

#ifdef SDCC
void pulse_inth(void) interrupt 4
#else
interrupt void pulse_inth(void)
#endif
{
	uint8 u = TSC0;
	uint8 pulse = ((PTE & 2) >> 1);
	
	ir_end_time.byte.high = TCH0H;
	ir_end_time.byte.low = TCH0L;
	ir_end_epoch = ir_epoch;
	
	frb_code.word.high.byte.high = 0;
	frb_code.word.high.byte.low = ir_end_epoch - ir_start_epoch;
	if (ir_end_time.word <= ir_start_time.word)
		frb_code.word.high.byte.low--;
	frb_code.word.low.word = ir_end_time.word - ir_start_time.word;

#ifndef SDCC
	frb_code.dword /= 3;
#else
	    /* divulong is broken in SDCC, must set kmod to devide it for us
	     * enable by "modprobe usbirboy sdcc=1" */
	
#endif

	
	frb_code.word.high.byte.high = pulse;
	frbwrite();
	
	ir_start_epoch = ir_end_epoch;
	ir_start_time.word = ir_end_time.word;
	
	TSC0 = u & ~CHF;
}
