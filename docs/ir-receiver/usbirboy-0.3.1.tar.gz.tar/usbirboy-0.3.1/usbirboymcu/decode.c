/*                                                                                                           
 *     ir.c  --  USB-IR-Boy IR receiver
 *                                                                                                           
 *     www.sourceforge.net/projects/usbirboy/                                                                
 *                                                                                                           
 *     Copyright (c) 2007 Aapo Tamminen
 *                                                                                                           
 *                                                                                                           
 *     This program is free software; you can redistribute it and/or modify                                  
 *     it under the terms of the GNU General Public License as published by                                  
 *     the Free Software Foundation; either version 2 of the License, or                                     
 *     (at your option) any later version.                                                                   
 *                                                                                                           
 *     This program is distributed in the hope that it will be useful,                                       
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of                                        
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the                                         
 *     GNU General Public License for more details.                                                          
 *                                                                                                           
 *     You should have received a copy of the GNU General Public License                                     
 *     along with this program; if not, write to the Free Software                                           
 *     Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.                                             
 *                                                                                                           
 *                                                                                                           
 */

#include "config.h"

#ifndef UNIT_TEST
#include "mc68hc908jb8.h"
#include "types.h"
#endif

#ifdef UNIT_TEST
typedef unsigned int uint32;
typedef unsigned short uint16;
typedef unsigned char uint8;
union
{
	uint16 word;
	struct
	{
		uint8 high;
		uint8 low;
	} byte;
} uu16;
#endif

#if 0
  bits           16
  flags SPACE_ENC
  eps            30
  aeps          100

  header       8810  4615
  one           581  1687
  zero          581   548
  ptrail        583
  repeat       8807  2186
  pre_data_bits   16
  pre_data       0x3EC1
  gap          39713
  repeat_gap   95914
  toggle_bit      0
#endif

/* states */
#define S_GAP 0
#define S_HEADER_PULSE 1
#define S_HEADER_SPACE 2
#define S_PRE_DATA_PULSE 3
#define S_PRE_DATA_SPACE 4
#define S_DATA_PULSE 5
#define S_DATA_SPACE 6
#define S_REPEAT_PULSE 7
#define S_REPEAT_SPACE 8
#define S_PTRAIL 9

#define APPROX(a,b) (b-AEPS<a && a<b+AEPS)

static uint16 pre_data;
static uu16 data;
static uint8 state = S_HEADER_PULSE;
static uint8 bit = 0;
void keypress(uu16);

/* decode "space encoded" IR codes */
static uint8 decode_space_enc(uint8 state, uint32 input)
{
	/* check type */
	if ((input>>24) != (state&1)) /* state 0 is space, pulses and spaces alternate */
		return S_HEADER_PULSE; /* lost it */
		
	/* check length */
	input &= 0x00ffffff;
	switch (state)
	{
	case S_GAP: /* looking for gap */
		if (APPROX(input, GAP)) 		return S_HEADER_PULSE;
		else if (APPROX(input, REPEAT_GAP)) 	return S_REPEAT_PULSE;
		else					return S_GAP; /* lost it */
		
	case S_HEADER_PULSE: /* looking for header (or repeat) pulse */
		if(APPROX(input, HEADER_PULSE))		return S_HEADER_SPACE; /* continue */
		else					return S_HEADER_PULSE; /* lost it */
	
	case S_HEADER_SPACE: /* looking for header space */
		if (APPROX(input, HEADER_SPACE))	{ bit=PRE_DATA_BITS; pre_data=0; return S_PRE_DATA_PULSE; } /* continue */
		else if (APPROX(input, REPEAT_SPACE))	{ keypress(data); return S_HEADER_PULSE; } /* ok, repeat code */
		else					return S_HEADER_PULSE; /* lost it */
		
	case S_PRE_DATA_PULSE: /* looking for pre data pulse */
		if(APPROX(input, BIT_PULSE))		return S_PRE_DATA_SPACE; /* continue */
		else					return S_HEADER_PULSE; /* lost it */
		
	case S_PRE_DATA_SPACE: /* looking for pre data space */
		if (APPROX(input, ONE_SPACE)) 		pre_data|=(1<<--bit); /* MSB first */
		else if (APPROX(input, ZERO_SPACE))	--bit;
		else					return S_HEADER_PULSE; /* lost it */
		
		if (bit==0) 				{ bit=DATA_BITS; data.word=0; return S_DATA_PULSE; } /* continue */
		else					return S_PRE_DATA_PULSE; /* next bit */
		
	case S_DATA_PULSE: /* looking for data pulse */
		if(APPROX(input, BIT_PULSE))		return S_DATA_SPACE; /* continue */
		else					return S_HEADER_PULSE; /* lost it */
		
	case S_DATA_SPACE: /* looking for data space */
		if (APPROX(input, ONE_SPACE)) 		data.word|=(1<<--bit); /* MSB first */
		else if (APPROX(input, ZERO_SPACE))	--bit;
		else					return S_HEADER_PULSE; /* lost it */
		
		if (bit==0) 				/*return S_PTRAIL;*/ { keypress(data); return S_HEADER_PULSE; } /* ok, new code */
		else					return S_DATA_PULSE; /* next bit */
		
	case S_REPEAT_PULSE: /* looking for repeat pulse */
		if(APPROX(input, REPEAT_PULSE))		return S_REPEAT_SPACE; /* continue */
		else					return S_HEADER_PULSE; /* lost it */
		
	case S_REPEAT_SPACE: /* looking for repeat space */
		if(APPROX(input, REPEAT_SPACE))		return S_PTRAIL; /* continue */
		else					return S_HEADER_PULSE; /* lost it */
		
	case S_PTRAIL: /* looking for trail */
		if (APPROX(input, PTRAIL))		{ if (pre_data==PRE_DATA) keypress(data); } /* ok */
		else					return S_HEADER_PULSE; /* lost it */
	}
}

#if IR_DECODE
void decode(uint32 input)
{
#if SPACE_ENC
	state = decode_space_enc(state, input);
#else
#error "unknown encoding"
#endif
}
#endif


#ifdef UNIT_TEST
#include <stdio.h>
#include <string.h>
void keypress(uu16 data)
{
	//printf("%04x %04x\n", pre_data, data);
	switch (data.word)
	{
		case KEY_ONE:		printf("one\n"); break;
		case KEY_TWO:		printf("two\n"); break;
		case KEY_THREE:		printf("three\n"); break;
		case KEY_FOUR:		printf("four\n"); break;
		case KEY_FIVE:		printf("five\n"); break;
		case KEY_SIX:		printf("six\n"); break;
		case KEY_SEVEN:		printf("seven\n"); break;
		case KEY_EIGHT:		printf("eight\n"); break;
		case KEY_NINE:		printf("nine\n"); break;
		case KEY_ZERO:		printf("zero\n"); break;
		case KEY_PLUSTEN:	printf("plusten\n"); break;
		case KEY_ENTER:		printf("enter\n"); break;
		case KEY_TITLE:		printf("title\n"); break;
		case KEY_UP:		printf("up\n"); break;
		case KEY_MENU:		printf("menu\n"); break;
		case KEY_LEFT:		printf("left\n"); break;
		case KEY_SELECT:	printf("select\n"); break;
		case KEY_RIGHT:		printf("right\n"); break;
		case KEY_RETURN:	printf("return\n"); break;
		case KEY_DOWN:		printf("down\n"); break;
		case KEY_DISPLAY:	printf("display\n"); break;
		case KEY_REC:		printf("rec\n"); break;
		case KEY_REW:		printf("rew\n"); break;
		case KEY_FF:		printf("ff\n"); break;
		case KEY_AUDIO:		printf("audio\n"); break;
		case KEY_PAUSE:		printf("pause\n"); break;
		case KEY_PREV:		printf("prev\n"); break;
		case KEY_NEXT:		printf("next\n"); break;
		case KEY_STOP:		printf("stop\n"); break;
		case KEY_PLAY:		printf("play\n"); break;
		case KEY_AVPOWER:	printf("avpower\n"); break;
	}
}

static void print_state(void)
{
	switch (state)
	{
		case S_GAP:		printf("S_GAP\n"); break;
		case S_HEADER_PULSE:	printf("S_HEADER_PULSE\n"); break;
		case S_HEADER_SPACE:	printf("S_HEADER_SPACE\n"); break;
		case S_PRE_DATA_PULSE:	printf("S_PRE_DATA_PULSE\n"); break;
		case S_PRE_DATA_SPACE:	printf("S_PRE_DATA_SPACE\n"); break;
		case S_DATA_PULSE:	printf("S_DATA_PULSE\n"); break;
		case S_DATA_SPACE:	printf("S_DATA_SPACE\n"); break;
		case S_REPEAT_PULSE:	printf("S_REPEAT_PULSE\n"); break;
		case S_REPEAT_SPACE:	printf("S_REPEAT_SPACE\n"); break;
		case S_PTRAIL:		printf("S_PTRAIL\n"); break;
	}
}

int main()
{
	uint32 input;
	char type[100];
	while (!feof(stdin))
	{	
		scanf("%s %u", type, &input); /* read mode2 output */
		input &= 0x00ffffff;
		if (0==strcmp(type, "pulse"))
			input |= 0x01000000;
		decode(input);
		//printf("%8x\n", input);
		//print_state();
	}
	return 0;
}
#endif
