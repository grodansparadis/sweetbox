/*      $Id: filter.c,v 1.7 2007/02/17 10:36:11 blckdove Exp $      */

/****************************************************************************
 ** lirc_serial.c ***********************************************************
 ****************************************************************************
 *
 * lirc_serial - Device driver that records pulse- and pause-lengths
 *               (space-lengths) between DDCD event on a serial port.
 *
 * Copyright (C) 1996,97 Ralph Metzler <rjkm@thp.uni-koeln.de>
 * Copyright (C) 1998 Trent Piepho <xyzzy@u.washington.edu>
 * Copyright (C) 1998 Ben Pfaff <blp@gnu.org>
 * Copyright (C) 1999 Christoph Bartelmus <lirc@bartelmus.de>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */

/* Steve's changes to improve transmission fidelity:
     - for systems with the rdtsc instruction and the clock counter, a 
       send_pule that times the pulses directly using the counter.
       This means that the LIRC_SERIAL_TRANSMITTER_LATENCY fudge is
       not needed. Measurement shows very stable waveform, even where
       PCI activity slows the access to the UART, which trips up other
       versions.
     - For other system, non-integer-microsecond pulse/space lengths,
       done using fixed point binary. So, much more accurate carrier
       frequency.
     - fine tuned transmitter latency, taking advantage of fractional
       microseconds in previous change
     - Fixed bug in the way transmitter latency was accounted for by
       tuning the pulse lengths down - the send_pulse routine ignored
       this overhead as it timed the overall pulse length - so the
       pulse frequency was right but overall pulse length was too
       long. Fixed by accounting for latency on each pulse/space
       iteration.

   Steve Davies <steve@daviesfam.org>  July 2001
*/

/* frbwrite() modified for usbirboy by Aapo Tamminen  September 2004 */

#include "mc68hc908jb8.h"
#include "types.h"
#include "usbcore.h"
#include "filter.h"

#define PULSE_BIT 1

static uu32 frb_pulse,frb_space;
static uint8 frb_ptr;
static uu32 frb_sendcode;
uu32 frb_code;

static void usb_send(void)
{
	usb_putc(frb_sendcode.word.low.byte.low | 0x80);
	frb_sendcode.dword <<= 1;
	usb_putc(frb_sendcode.word.low.byte.high & 0x7f);
	frb_sendcode.dword <<= 1;
	usb_putc(frb_sendcode.word.high.byte.low & 0x7f);
	frb_sendcode.dword <<= 1;
	usb_putc(frb_sendcode.word.high.byte.high & 0x7f);
}

void frbwrite(void)
{
	/* simple noise filter */
	if(frb_ptr>0 && (frb_code.word.high.byte.high&PULSE_BIT))
	{
		frb_code.word.high.byte.high = 0;
		frb_pulse.dword+=frb_code.dword;
		if(frb_pulse.dword>250)
		{
			frb_sendcode.dword=frb_space.dword;
			usb_send();
			frb_pulse.word.high.byte.high|=PULSE_BIT;
			frb_sendcode.dword=frb_pulse.dword;
			usb_send();
			frb_ptr=0;
			frb_pulse.dword=0;
		}
		return;
	}
	if(!(frb_code.word.high.byte.high&PULSE_BIT))
	{
		if(frb_ptr==0)
		{
			if(frb_code.dword>20000)
			{
				frb_space.dword=frb_code.dword;
				frb_ptr++;
				return;
			}
		}
		else
		{
			if(frb_code.dword>20000)
			{
				frb_space.dword+=frb_pulse.dword;
				if (frb_space.word.high.byte.high != 0)
				{
					frb_space.word.high.word = 0x00ff;
					frb_space.word.low.word = 0xffff;
				}
				frb_space.dword+=frb_code.dword;
				if (frb_space.word.high.byte.high != 0)
				{
					frb_space.word.high.word = 0x00ff;
					frb_space.word.low.word = 0xffff;
				}
				frb_pulse.dword=0;
				return;
			}
			frb_sendcode.dword=frb_space.dword;
			usb_send();
			frb_pulse.word.high.byte.high|=PULSE_BIT;
			frb_sendcode.dword=frb_pulse.dword;
			usb_send();
			frb_ptr=0;
			frb_pulse.dword=0;
		}
	}
	frb_sendcode.dword=frb_code.dword;
	usb_send();
}
