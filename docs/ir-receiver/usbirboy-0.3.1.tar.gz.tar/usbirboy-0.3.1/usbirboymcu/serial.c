/* HC08 software serial transmit: TX=PTA2, 19200 baud, 1 stop bit */
/* Aapo Tamminen, 2005 */
/* Added buffering: Ilkka Urtamo, 2005 */
#include "serial.h"
#include "mc68hc908jb8.h"
#include "types.h"
#define TX 1

/* edit us accordingly */
#define SIO_SEND_BUFF_LEN		32		/*in bytes, intervals of 8 (max 256 ==uint8)*/
#define SIO_SEND_BUFF_MASK (SIO_SEND_BUFF_LEN-1)
#define INC_SIOINDEX(a) do{ (a) += 1; (a) &= SIO_SEND_BUFF_MASK;}while(0)
uint8 sio_sendbuffer[SIO_SEND_BUFF_LEN];
uint8 sio_buff_head;
uint8 sio_buff_tail;
uint8 sio_hi_nible;
uint8 sio_low_nible;

const char hex[] = "0123456789ABCDEF";

void sio_puthex(unsigned char c)
{
    uint8 ch;
    
    sio_hi_nible = (c&0xF0);
    sio_hi_nible>>=4;
    sio_low_nible = (c&0x0F);
    ch = hex[sio_hi_nible];
    sio_putc(ch);
    ch = hex[sio_low_nible];
    sio_putc(ch);
    sio_putc('\r');
    sio_putc('\n');
}

void sio_putc(unsigned char c)
{
  sio_sendbuffer[sio_buff_head]=c;
  INC_SIOINDEX(sio_buff_head);
}

void sio_send(void)
{
    while((sio_buff_tail != sio_buff_head))
    {
	_asm sei _endasm; // disable int, must make this atomic
	sio_sendc(sio_sendbuffer[sio_buff_tail]);
	INC_SIOINDEX(sio_buff_tail);
	_asm cli _endasm; // enable int
    }
}

void sio_init(void)
{
    sio_buff_head = 0;
    sio_buff_tail = 0;
    PTA|=(1<<TX);
}

void sio_sendc(unsigned char c)
{
   c; // prevent unreferenced function argument
begin_asm
	pshx			 ;  3
	psha			 ;  2
	lda	#47		 ;  2	(156-(3+2+2+3+4))/3 = 47
	bclr	#TX,*_PTA	 ;  4
delay0: dbnza	delay0		 ;  3x
	pula			 ;  3
	ldx	#0x08		 ;  2
sloop:	bit	#0x01		 ;  2
	beq	zero		 ;  3
one:	bset	#TX,*_PTA	 ;  4
	bra	next		 ;  3
zero:	bclr	#TX,*_PTA	 ;  4
	bra	next		 ;  3
next:	lsra			 ;  1
	psha			 ;  3
	lda	#44		 ;  2	(156-(3+1+2+2+3+3+2+3+4))/3 = 44
delay1: dbnza   delay1		 ;  3x
	pula			 ;  3
	dbnzx	sloop		 ;  3
	lda	#2		 ;  2
delay3: dbnza	delay3		 ;  3x
	lda	#52		 ;  2	(156)/3 = 52
	bset	#TX,*_PTA	 ;  4
delay2: dbnza	delay2		 ;  3x
	pulx			 ;  3
end_asm;
}

