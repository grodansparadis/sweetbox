#ifndef FILTER_H
#define FILTER_H

#include "types.h"

void frbwrite(void);

extern uu32 frb_code;

#endif
