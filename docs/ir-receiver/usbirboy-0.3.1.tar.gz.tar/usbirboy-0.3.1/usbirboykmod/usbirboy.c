/*
 *  usbirboy.c  --  USB-IR-Boy linux driver.
 *
 *	For 2.6.x kernels www.sourceforge.net/projects/usbirboy/
 *
 * 	Copyright (c) 2006 Ilkka Urtamo 
 *	
 *	Based on kernel usb_skel and driver skeleton from Aapo Tamminen
 *	
 *	
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *
 */ 
 
 /*
  Changelog
	v 0.1
        	- Initial version
	v 0.2
	        - No such version, moved strait to 0.3
	          to sync with complete distribution version
	v 0.3
	        - Based on usbint_skel
	        - Supports device firmware with syncronized USB transfers (irboy 0.3 with NAK support)
	        - Supports writing to device
	        - Supports amd64 and big endian platforms
	        - Supports > 2.6.16 kernels
	        - Supports multible devices to be connected
	v 0.4
	        - Fixed 
	        
*/



/*****************************************************************************/

#include <linux/version.h>
#include <linux/module.h>
#include <linux/list.h>
#include <linux/vmalloc.h>
#include <linux/slab.h>
#include <linux/init.h>
#include <asm/uaccess.h>
#include <asm/atomic.h>
#include <linux/delay.h>
#include <linux/usb.h>
#include <linux/poll.h>
#include <linux/kref.h>

/*
 * Debugging
 */

#undef IRBOY_DEBUG
#undef IRBOY_INFO
#ifdef __KERNEL__
#   define IRBOY_DEBUG(fmt,args...) if(debug) printk(KERN_DEBUG "usbirboy: " fmt, ##args )
#   define IRBOY_INFO(format, arg...) printk(KERN_INFO "%s: " format "\n" , DRIVER_NAME , ## arg)
#endif
#undef IF_IRBOY_DEBUG
#undef END_IRBOY_DEBUG
#define IF_IRBOY_DEBUG if(debug) {
#define END_IRBOY_DEBUG }


/*
 * Version information
 */
#define DRIVER_VERSION			"v0.04"
#define DRIVER_AUTHOR			"Ilkka Urtamo (ilkka@urtamo.com)"
#define DRIVER_DESC				"usbirboy (c)2006"
#define DRIVER_NAME				"usbirboy"
#define DEVFS_DRIVER_NAME		"usbirboy%d"
#define MINOR_BASE				240  		/* some unassigned USB minor */

/* Strait from lirc.h adopted ioctl definitions */
/* Lets hope they dont change those*/
#define LIRC_MODE2REC(x)			((x) << 16)
#define LIRC_GET_FEATURES			_IOR('i', 0x00000000, __u32)
#define LIRC_CAN_REC_MODE2			LIRC_MODE2REC(LIRC_MODE_MODE2)
#define LIRC_GET_REC_MODE			_IOR('i', 0x00000002, __u32)
#define LIRC_MODE_MODE2				0x00000004
#define LIRC_SET_REC_MODE			_IOW('i', 0x00000012, __u32)

#define RECEIVE_BUF_SIZE			1024		/* this must be 2^n */
#define RECEIVE_BUF_MASK			(RECEIVE_BUF_SIZE-1)
#define SEND_BUF_SIZE				1024
#define SEND_BUF_MASK				(SEND_BUF_SIZE-1)
#define PULSESPACE_BIT_MASK			0x0fffffff
#define PULSESPACE_BIT				0x01000000
#define DATA_BIT_MASK				0x00ffffff

/* define debug kernel option */
static int debug = 0;
#if LINUX_VERSION_CODE < 132625
	MODULE_PARM(debug, "i");
#else
	module_param(debug, int, 0);
#endif

static int vendor_id = 0;
static int product_id = 0;

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,17)
	MODULE_PARM(vendor_id, "i");
	MODULE_PARM(product_id, "i");
#else
	module_param(vendor_id,int,0);
	module_param(product_id,int,0);
#endif

#define INC_INDEX(a) 		a += 1; a &= RECEIVE_BUF_MASK
#define IS_STARTBIT(a)		( a & STARTBYTE) == STARTBYTE 
#define REMOVE_STARTBIT(a)	a = (a ^ STARTBYTE)

#define USBIRBOY_VENDOR_ID		0xFFFE		/* MC68HC908  Motorola vendor ID */
#define USBIRBOY_PRODUCT_ID  	0x0			/* MC68HC908  USB board product ID */
#define STARTBYTE				0x80		/* defines if byte starts the 4 byte serie */

struct usbirboy {
	struct usb_device*			udev;					/* save off the usb device pointer */
	struct usb_interface*		interface;				/* the interface for this device */
	int							minor;					/* the starting minor number for this device */ /* AT changed to int */
	unsigned char*				read_buffer;			/* the buffer to store received data*/
	unsigned char*				int_in_buffer;			/* the buffer to receive data from device*/
	size_t						int_in_size;			/* the size of the receive buffer */
	__u8						int_in_endpointAddr;	/* the address of the interrupt in endpoint */
	__u8						int_in_interval;
	struct urb*					read_urb;				/* the urb used to receive data */
	unsigned char*				write_buffer;
	unsigned char*				int_out_buffer;
	size_t						int_out_buffer_size;
	__u8						int_out_endpointAddr;
	__u8						int_out_interval;
	struct urb*					write_urb;
	int		    			    wused;					/* true if module is open for writing in user space */ 
	int		    			    rused;					/* true if module is open for reading in user space */ 
	int							dev_present;			/* true if the device is connected */
	struct semaphore			sem;					/* locks this structure */
	volatile size_t				read_buff_head;
	volatile size_t				read_buff_tail;			/* head and tail indexes for read buffer*/
	volatile size_t				packet_ptr;				/* to store position in read_buffer within in current packet */
	volatile size_t				packet_size;			/* to store number of bytes already read into packet */
	volatile size_t				write_buff_head;
	volatile size_t				write_buff_tail;	   	/* head and tail indexes for write buffer*/
	volatile int				write_urb_done;   		/* flag indicating all data in current buffer is sent*/
	volatile int				write_urb_bytes;
	wait_queue_head_t			wait_rdata;    			/* object for userspace to wait more read data */
	wait_queue_head_t			wait_wdata;    			/* object for userspace to wait more write data */
	wait_queue_head_t 			wait_remove;			/* clear to unregister usb_device now */
	struct kref					kref;					/* usage count */
};



/* prevent races between open() and disconnect() */
static DECLARE_MUTEX (disconnect_sem);

static inline void usbirboy_cleanup (struct kref *kref);
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,19)
static void usbirboy_read_urb_callback (struct urb *urb, struct pt_regs *regs);
static void usbirboy_write_urb_callback (struct urb *urb, struct pt_regs *regs);
#else
static void usbirboy_read_urb_callback (struct urb *urb);
static void usbirboy_write_urb_callback (struct urb *urb);
#endif
static int usbirboy_send_write_urb(struct usbirboy *dev, int mem_flags);
static int __init usbirboy_module_init (void);
static void __exit usbirboy_module_exit (void);
static struct usb_driver usbirboy_driver;
static struct usb_class_driver usbirboy_class;

#define to_usbirboy_dev(d) container_of(d, struct usbirboy, kref)

/*talbe describing product and vendor id's we use this driver for */
static struct usb_device_id usbirboy_device_table [] = {
	{ USB_DEVICE(USBIRBOY_VENDOR_ID, USBIRBOY_PRODUCT_ID) },
    { }/* Terminating entry */
};

/*internal fuction to free memory */
static inline void usbirboy_cleanup (struct kref *kref)
{
	struct usbirboy *dev;

	dev = to_usbirboy_dev(kref);

	if(dev == NULL)
	{
		err("dev == NULL \n");
		return;
	}
	if(dev->int_in_buffer != NULL)
		kfree (dev->int_in_buffer);
	if(dev->read_buffer != NULL)
		kfree(dev->read_buffer);
	if (dev->int_out_buffer != NULL)
		kfree(dev->int_out_buffer);
	if (dev->write_buffer != NULL)
		kfree(dev->write_buffer);    


	if (dev->read_urb != NULL)
		usb_free_urb (dev->read_urb);
	if (dev->write_urb != NULL)
		kfree(dev->write_urb);

	kfree (dev);
	dev = NULL;
}


static int usbirboy_user_ioctl(struct inode *node,
			       struct file *filep,
			       unsigned int cmd,
			       unsigned long arg)
{
	int retval = 0;

	switch(cmd)
	{
		case LIRC_GET_FEATURES:
			retval = put_user(LIRC_CAN_REC_MODE2, (unsigned long *) arg);
			break;
		case LIRC_GET_REC_MODE:
			retval = put_user(LIRC_MODE_MODE2, (unsigned long *) arg);
			break;
		case LIRC_SET_REC_MODE:
			retval = put_user(LIRC_MODE_MODE2, (unsigned long *) arg);
			break;
		default:
			retval = -ENOIOCTLCMD;
	}

	return retval;
}

/*called from userspace, when userspace process is calling fopen for the device*/
int usbirboy_user_open (struct inode *inode, struct file *file)
{
	/*user space has opened this device */
	/*in this version we asume we have only one device*/
	int minor = -1;
	struct usbirboy *dev;
	struct usb_interface *intf;
	int retval = -ENODEV;

	if(file == NULL)
	{
		err("file pointer is null\n");
		return -EFAULT;  
	}

	minor = iminor(inode);

	if(minor < 0)
		return -ENODEV;

	IRBOY_DEBUG("Using minor %d\n",(int)minor);

	/*do not allow disconnecting during this function*/
	down(&disconnect_sem);

	intf = usb_find_interface(&usbirboy_driver,minor);
	if(NULL == intf)
		goto error;

	dev = usb_get_intfdata(intf);
	if(NULL == dev || NULL == dev->udev || !dev->dev_present)
		goto error;

	/*check if another user process is allready reading the device*/
	retval = -EBUSY;

	/* lock structure */
	down (&dev->sem);

	if(file->f_mode & FMODE_READ)
	{
		if(dev->rused > 0)
			goto error_already_inuse;
		else
			dev->rused = 1;
	}

	if(file->f_mode & FMODE_WRITE)
	{
		if(dev->wused > 0)
			goto error_already_inuse;
		else
			dev->wused = 1;
	}

	/*do actual opening*/
	file->f_pos=0;
	file->private_data = dev;

	up (&dev->sem);
	up(&disconnect_sem);

	IRBOY_DEBUG("dev_present = %d , wused = %d , rused = %d \n",(int)dev->dev_present,(int)dev->wused,(int)dev->rused);	  

	return 0;

error_already_inuse:
	up (&dev->sem);
error:
	up(&disconnect_sem);
	return retval;
}

/*called from userspace, when userspace process is calling flose for the device*/
int usbirboy_user_release (struct inode *inode, struct file *file)
{
	/*userspace has closed this device*/
	struct usbirboy *dev;

	if(file == NULL)
	{
		err("file pointer is null\n");
		return -EFAULT;  
	}
	dev = file->private_data;

	if(dev == NULL)
	{
		err("Error in %s : dev is null",__FUNCTION__);
		return -ENODEV;
	} 

	down(&dev->sem);

	/*we are no longer using this device*/
	if(file->f_mode & FMODE_READ)
	{
		if(dev->rused != 0)
		{
			dev->rused = 0;
		}
		else
		{
			err("Trying to close devicewith different R/W flag\n");
			return -EPERM;
		}
	}
	if(file->f_mode & FMODE_WRITE)
	{
		if(dev->wused != 0)
		{
			dev->wused = 0;
		}	
		else
		{
			err("Trying to close device with different R/W flag\n");
			return -EPERM;
		}
	}

	if(dev->wused == 0 &&
		dev->rused==0 &&
		dev->dev_present == 0)
	{
		up(&dev->sem);
		IRBOY_DEBUG("release: remove ok wakeup\n");	  
		/* device is no longer dev_present, usb_disconnect is waiting for us */
		wake_up(&dev->wait_remove);
		/*after this we cannot relay on dev to be valid anymore*/
	}
	else
	{
		up(&dev->sem);
	}

	IRBOY_DEBUG("dev_present = %d , wused = %d , rused = %d \n",(int)dev->dev_present,(int)dev->wused,(int)dev->rused);	  

	return 0;
}

ssize_t usbirboy_user_read (struct file *file, char *buffer, size_t count, loff_t *ppos)
{
	/*user space reads the device*/
	struct usbirboy *dev;
	size_t head;
	size_t len1, len2;
	size_t i;

	if(file == NULL)
	{
		err("file pointer is null\n");
		return -EFAULT;  
	}
	dev = file->private_data;

	if (*ppos)
		return -ESPIPE;

	if(!dev)
	{
		err("Error in %s : dev is null",__FUNCTION__);
		return -EIO;
	}

	if (!dev->udev)
	{
		err("Error in %s : dev->udev is null",__FUNCTION__);
		return -EIO;
	}

	if (dev->dev_present == 0) 
		return -ENODEV;    

	/* wait for data */
	while (dev->read_buff_head == dev->read_buff_tail)
	{
		if (file->f_flags & O_NONBLOCK) /*userspace program do not whant us to wait for data*/
			return -EAGAIN;

		if (wait_event_interruptible(dev->wait_rdata,
									((dev->read_buff_head != dev->read_buff_tail) 
									|| dev->dev_present==0) ))
			return -ERESTARTSYS; /* signal: tell the fs layer to handle it */

		if (dev->dev_present == 0) 
			return -ENODEV;    
	}

	/* acquire semaphore */
	down(&dev->sem);

	/* TODO what to do if head == tail at this point? */
	head = dev->read_buff_head;
	len1 = len2 = 0;

	IRBOY_DEBUG("head=%d tail=%d requested=%d\n", (int)head,(int)dev->read_buff_tail,(int)count);

	/* copy to userspace */
	if (dev->read_buff_tail < head) /* 1 part to copy */
	{
		/* from tail to head */
		len1 = head - dev->read_buff_tail;
		if (len1 > count) 
			len1 = count;
		if (copy_to_user(buffer, &dev->read_buffer[dev->read_buff_tail], len1))
			goto fault;
	}
	else /* 2 parts to copy */
	{
		/* 1st part from tail to end of buffer */
		len1 = RECEIVE_BUF_SIZE - dev->read_buff_tail;
		if (len1 > count) 
			len1 = count;
		if (copy_to_user(buffer, &dev->read_buffer[dev->read_buff_tail], len1))
			goto fault;
		count -= len1;

		/* 2nd part from beginning of buffer to head */
		len2 = head;
		if (len2 > count) 
			len2 = count;
		if (len2 > 0)
			if (copy_to_user(&buffer[len1], dev->read_buffer, len2))
				goto fault;
	}
	i = dev->read_buff_tail;

	/* update tail. dev->read_buff_head may have changed in the meantime but we don't care */
	dev->read_buff_tail = (dev->read_buff_tail + len1 + len2) & (RECEIVE_BUF_SIZE - 1);

IF_IRBOY_DEBUG
		unsigned char c;
		dbg("copied %d bytes \"", len1 + len2);
		while (i != dev->read_buff_tail)
		{
			c = dev->read_buffer[i];
			dbg("%c", c >= 32 && c < 127 ? c : '.');
			i = (i+1) & (RECEIVE_BUF_SIZE-1);
		}
		dbg("\"\n");
END_IRBOY_DEBUG   

	/* successful return - release semaphore */
	up(&dev->sem);
	return len1 + len2;

	/* segmentation fault while copying */
fault:  
	up(&dev->sem);
	return -EFAULT;
}

ssize_t usbirboy_user_write (struct file *file, const char *buffer, size_t count, loff_t *ppos)
{
	struct usbirboy *dev;
	size_t tail;
	size_t len1, len2;
	size_t i;

	if(file == NULL)
	{
		err("file pointer is null\n");
		return -EFAULT;  
	}
	dev = file->private_data;

	if (*ppos)
		return -ESPIPE;

	if(!dev)
	{
		err("Error in %s : dev is null",__FUNCTION__);
		return -EIO;
	}

	if (!dev->udev)
	{
		err("Error in %s : dev->udev is null",__FUNCTION__);
		return -EIO;
	}

	if (dev->dev_present == 0) 
		return -ENODEV;    

	/* wait for space in buffer */
	while (((dev->write_buff_head+1) & (SEND_BUF_SIZE-1)) == dev->write_buff_tail)
	{
		if (file->f_flags & O_NONBLOCK) /*userspace program do not whant us to wait */
			return -EAGAIN;

		if (wait_event_interruptible(dev->wait_wdata,(
													(((dev->write_buff_head+1) & (SEND_BUF_SIZE-1)) != dev->write_buff_tail)
													|| dev->dev_present==0)	))
			return -ERESTARTSYS; /* signal: tell the fs layer to handle it */

		if (dev->dev_present == 0) 
			return -ENODEV;    
	}

	/* acquire semaphore */
	down(&dev->sem);

	/* TODO what to do if head == tail at this point? */
	tail = (dev->write_buff_tail-1) & (SEND_BUF_SIZE-1);
	len1 = len2 = 0;

	IRBOY_DEBUG("head=%d tail=%d count=%d\n",(int) dev->write_buff_head, (int) tail, (int) count);

	/* copy to userspace */
	if (dev->write_buff_head <= tail) /* 1 part to copy */
	{
		/* from tail to head */
		len1 = tail - dev->write_buff_head;
		if (len1 > count) 
			len1 = count;
		if (copy_from_user(&dev->write_buffer[dev->write_buff_head], buffer, len1))
			goto fault;
	}
	else /* 2 parts to copy */
	{
		/* 1st part from tail to end of buffer */
		len1 = SEND_BUF_SIZE - dev->write_buff_head;
		if (len1 > count) 
			len1 = count;
		if (copy_from_user(&dev->write_buffer[dev->write_buff_head], buffer, len1))
			goto fault;
		count -= len1;

		/* 2nd part from beginning of buffer to head */
		len2 = tail;
		if (len2 > count) 
			len2 = count;
		if (len2 > 0)
			if (copy_from_user(dev->write_buffer, &buffer[len1], len2))
				goto fault;
	}
	i = dev->write_buff_head;
	dev->write_buff_head = (dev->write_buff_head + len1 + len2) & (SEND_BUF_SIZE - 1);

	if(dev->write_urb_done)
	{
		IRBOY_DEBUG("Last write done ,submit new urb\n");
		if(usbirboy_send_write_urb(dev, GFP_KERNEL) == -1)
			goto eio;
		else
			dev->write_urb_done=0;
	}

	/* successful return - release semaphore */
	up(&dev->sem);

	IRBOY_DEBUG("write done, head=%d tail=%d\n",(int) dev->write_buff_head,(int) dev->write_buff_tail);

	return len1 + len2;

	/* segmentation fault while copying */
fault:  
	up(&dev->sem);
	return -EFAULT;

eio:
	up(&dev->sem);
	return -EIO;
}

unsigned int usbirboy_user_poll(struct file * file, poll_table * wait)
{
	struct usbirboy *dev = file->private_data;
	int retval=0;
	
	poll_wait(file, &dev->wait_rdata, wait);
	poll_wait(file, &dev->wait_wdata, wait);

	if (dev->dev_present == 0) 
		return POLLERR;

	if(dev->read_buff_head != dev->read_buff_tail)
		retval |= POLLIN | POLLRDNORM;
	if(((dev->write_buff_head+1) & (SEND_BUF_SIZE-1)) != dev->write_buff_tail)
		retval |= POLLOUT | POLLWRNORM;

	return retval;
}

static inline __u32 make_32b_int(unsigned char * buffer,size_t buff_pos)
{
	/* Each byte has 7 meaninfull bits */
	/* Combine these bits to one 32b integer*/
	__u32 data = 0;
	int i=0;
	char local_buffer[4];

	/*first safely copy 32bit int to local buffer*/  
	for(i=0;i<4;i++)
	{
		local_buffer[i] = buffer[buff_pos];
		INC_INDEX(buff_pos);
	}

	/* Process each byte to make real integer */
#if defined(__LITTLE_ENDIAN)
	for(i=3;i!=0;i--)	/*Must swap endian*/
#else
	for(i=0;i!=3;i++)	/*Already in correct endian*/
#endif  
	{
		data |= local_buffer[i];
		data = data << 7;
	}
	data |= local_buffer[0];

	return data;
}

/* Process byte from device and return number  of full packets received (basically 0 or 1) */
static inline int process_irboy_packets(unsigned char received_byte,struct usbirboy *dev)
{
	int i;
	__u32 data_int=0;
	int packet_ready=0;

	if(IS_STARTBIT(received_byte) )
	{
		/*Packet starting*/
		if(dev->packet_ptr != 0)
			err("new start bit received before last packet was ready!\n");

		dev->packet_ptr = dev->read_buff_head;
		dev->packet_size = 0;
		dev->read_buffer[dev->packet_ptr] = received_byte;
		REMOVE_STARTBIT(dev->read_buffer[dev->packet_ptr]);
		IRBOY_DEBUG("Packet start byte (byte ptr=%d size=%d)\n", (int)dev->packet_ptr,(int)dev->packet_size);
	}
	else
	{
		/*Packet continue*/
		INC_INDEX(dev->packet_ptr);
		dev->packet_size++;
		if(dev->packet_size < 4 && dev->packet_size > 0)	/*just for caution*/
			dev->read_buffer[dev->packet_ptr] = received_byte;
		IRBOY_DEBUG("Packet continue byte (byte ptr=%d size=%d)\n", (int)dev->packet_ptr,(int)dev->packet_size);
	}

	/* One packet ready, process and put visible to userspace */
	if(dev->packet_size == 3)
	{
		data_int = make_32b_int(dev->read_buffer,dev->read_buff_head);
		data_int &= PULSESPACE_BIT_MASK;

IF_IRBOY_DEBUG
		if (data_int&0x01000000) 
			printk("pulse "); else printk("space ");
			printk("%d\n", data_int&DATA_BIT_MASK);	  
END_IRBOY_DEBUG

		/* Place new uint 32 into read buffer */	      		
		for(i=0;i<4;i++) 
		{
			dev->read_buffer[dev->read_buff_head] = *(((char*)&data_int)+i);
			INC_INDEX(dev->read_buff_head);
		}

		dev->packet_ptr=0;
		dev->packet_size=0;
		packet_ready++;
	}

	/*WTF, device is giving some weard packets*/
	if(dev->packet_size>3)
		err("Packet ended but data bytes still coming (ignored untill next start byte from device)\n");

	return packet_ready;
}

/* 
	NOTE: read buffer is used to store unfinished packets and userland 
	head pointer is increased only after successfull full packet received 
*/
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,19)
static void usbirboy_read_urb_callback (struct urb *urb, struct pt_regs *regs)
#else
static void usbirboy_read_urb_callback (struct urb *urb)
#endif
{
	struct usbirboy *dev = NULL;
	int packets_ready=0;
	int retval;
	int i;

	switch (urb->status) 
	{
		case 0:	/* success */
			break;
		case -ECONNRESET:
			err("ECONNRESET \n");
			return;
		case -ENOENT:
			err("ENOENT  \n");
			return;
		case -ESHUTDOWN:
			err("ESHUTDOWN \n");
			return;
		case -ESPIPE:
			err("ESPIPE \n");
		default:
			err("Unknown read urb status %d (urb pipe killed)\n",urb->status);
		return;
	}
	dev = urb->context;

	if (NULL == dev)
	{
		err("Error in %s : dev is null",__FUNCTION__);
		return;
	}
	if(!dev->dev_present) /* device no longer present */
		return;

	if (urb->actual_length > 0)
	{
		for(i=0;i<urb->actual_length;++i)
		{
			IRBOY_DEBUG("data: 0x%x\n",dev->int_in_buffer[i]);
			packets_ready += process_irboy_packets(dev->int_in_buffer[i],dev);
		}

		if(packets_ready>0)
		{
			IRBOY_DEBUG("packets=%d head=%d tail=%d\n", (int)packets_ready,(int)dev->read_buff_head,(int)dev->read_buff_tail);
			/*Announce userland changes only if full packets received */
			wake_up_interruptible(&dev->wait_rdata);
		}

	}

	/* Continue sending USB int read urbs for more data */
	retval =  usb_submit_urb(dev->read_urb,GFP_ATOMIC);
	if (retval)
	{
		err ("unable to submit urb - ret %d",retval);
		return;
	}
}
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,19)
static void usbirboy_write_urb_callback (struct urb *urb, struct pt_regs *regs)
#else
static void usbirboy_write_urb_callback (struct urb *urb)
#endif
{
	struct usbirboy *dev = NULL;

	switch (urb->status) 
	{
		case 0:	/* success */
			break;
		case -ECONNRESET:
			err("ECONNRESET \n");
			return;
		case -ENOENT:
			err("ENOENT  \n");
			return;
		case -ESHUTDOWN:
			err("ESHUTDOWN \n");
			return;
		default:    
			return;
	}
	dev = urb->context;

	if (NULL == dev)
	{
		err("Error in %s : dev is null",__FUNCTION__);
		return;
	}
	if(!dev->dev_present) /* device no longer present */
		return;

	/* Send more urbs if there is unsent bytes in write buffer*/
	if(dev->write_urb_bytes==urb->actual_length)
	{
		IRBOY_DEBUG("write urb callback with actual len %d \n",(int)urb->actual_length);
	}
	else
	{
		err("write urb callback with actual len %d differents last shipped urb %d\n",
		urb->actual_length,dev->write_urb_bytes);
	}

	if (urb->actual_length > 0)
	{
		usbirboy_send_write_urb(dev, GFP_ATOMIC);
	}
	else
	{
		IRBOY_DEBUG("Last pkg sent with len %d , all data in buffer sent\n",(int)urb->actual_length);
		dev->write_urb_done =1;
		wake_up_interruptible(&dev->wait_wdata);
	}
}

/* Copy data to urb write buffer and send urb accordingly*/
static int usbirboy_send_write_urb(struct usbirboy *dev, int mem_flags)
{
	unsigned int len;

	len = 0;
	while (len < dev->int_out_buffer_size && dev->write_buff_tail != dev->write_buff_head)
	{
		dev->int_out_buffer[len] = dev->write_buffer[dev->write_buff_tail];
		dev->write_buff_tail = (dev->write_buff_tail+1) & (SEND_BUF_SIZE-1);
		len++;
	}

	/* Set new buffer length accordingly */
	dev->write_urb->transfer_buffer_length = len;
	IRBOY_DEBUG("submit urb with %d bytes\n", len);
	dev->write_urb_bytes=len;

	if (usb_submit_urb(dev->write_urb,mem_flags))
	{
		err ("unable to submit write urb ");
		return -1;
	}

	return len;
}

/* usb-core calls this when new usb device with 
 * id number matching one in device id table is 
 * connected
*/
int usbirboy_usb_probe(struct usb_interface *interface, const struct usb_device_id *id)
{
	int retval = -ENOMEM;
	size_t buffer_size;
	int i;
	struct usb_device *udev = interface_to_usbdev(interface);
	struct usbirboy *dev = NULL;
	struct usb_host_interface *iface_desc;
	struct usb_endpoint_descriptor *endpoint;
	struct usb_device_descriptor *irdescriptor  = NULL;
	struct usb_device_id *devid;

	IRBOY_INFO( "Dev Product: 0x%x\n",udev->descriptor.idProduct);
	IRBOY_INFO( "Dev Vendod: 0x%x\n",udev->descriptor.idVendor);

	/* See if the device offered us matches what we can accept */
	devid = usbirboy_device_table;

	for (; devid->idVendor; devid++)
		if ((udev->descriptor.idVendor == devid->idVendor) &&
			(udev->descriptor.idProduct == devid->idProduct)) 
		{
			goto found_id;
		}
	err ("no dev found\n");
	return -ENODEV;

/* Proper device was found, continue */	
found_id:

	dev = kmalloc (sizeof(*dev), GFP_KERNEL);
	if (dev == NULL) 
	{
		err ("Out of memory");
		goto error;
	}
	memset (dev, 0x00, sizeof (*dev));
	/* first thing to do is to increment usecount*/
	kref_init(&dev->kref);

	dev->read_buffer =(unsigned char *) kmalloc (RECEIVE_BUF_SIZE, GFP_KERNEL);
	dev->write_buffer = (unsigned char *) kmalloc(SEND_BUF_SIZE, GFP_KERNEL);

	init_MUTEX (&dev->sem);

	dev->udev = udev;
	dev->interface = interface;
	irdescriptor  = &udev->descriptor;

	/* seach for correct endpoints and initialize them*/
	iface_desc = &interface->altsetting[0];
	IRBOY_DEBUG( "bNumEndpoints: %d\n", iface_desc->desc.bNumEndpoints);

	/*Just pick up fist 2 endpoints*/
	for(i = 0;i<iface_desc->desc.bNumEndpoints; ++i )
	{
		int maxp =0 ;
		unsigned int pipe;
		endpoint = &iface_desc->endpoint[i].desc;

		if (!dev->int_in_endpointAddr &&	
			(endpoint->bEndpointAddress & USB_DIR_IN) && // with mask == 1
			((endpoint->bmAttributes & USB_ENDPOINT_XFERTYPE_MASK)
				== USB_ENDPOINT_XFER_INT))
		{
			IRBOY_DEBUG("Using endpoint %d for reading, addr=%x attr=%x\n",
			i+1, // control endpoint 0 is not listed
			endpoint->bEndpointAddress,
			endpoint->bmAttributes);

			buffer_size = endpoint->wMaxPacketSize;
			dev->int_in_size = buffer_size;
			dev->int_in_interval = endpoint->bInterval;
			dev->int_in_endpointAddr = endpoint->bEndpointAddress;
			dev->int_in_buffer = kmalloc (buffer_size, GFP_KERNEL);

			if (!dev->int_in_buffer) 
			{
				err("Couldn't allocate int_in_buffer");
				goto error;
			}
			memset (dev->int_in_buffer, 0x00, sizeof (*dev->int_in_buffer));

			dev->read_urb = usb_alloc_urb(0, GFP_KERNEL);	
			if (!dev->read_urb)
			{
				err("No free urbs available for read_urb");
				goto error;
			}
			pipe = usb_rcvintpipe(udev, endpoint->bEndpointAddress);
			maxp = usb_maxpacket(udev, pipe, usb_pipeout(pipe));

			IRBOY_DEBUG("maxpr=%d\n",(int)buffer_size);


			usb_fill_int_urb(dev->read_urb, 
							udev,
							pipe,		/*receiving pipe*/
							dev->int_in_buffer, 
							maxp,
							usbirboy_read_urb_callback,
							dev,
							dev->int_in_interval);	
		}

		if (!dev->int_out_endpointAddr &&
			!(endpoint->bEndpointAddress & USB_DIR_IN) && // with mask == 0
			((endpoint->bmAttributes & USB_ENDPOINT_XFERTYPE_MASK)
			== USB_ENDPOINT_XFER_INT))
		{
			IRBOY_DEBUG("Using endpoint %d for writing, addr=%x attr=%x\n",
			i+1, // control endpoint 0 is not listed
			endpoint->bEndpointAddress,
			endpoint->bmAttributes);

			buffer_size = endpoint->wMaxPacketSize;
			dev->int_out_buffer_size = buffer_size;
			dev->int_out_interval = endpoint->bInterval;
			dev->int_out_endpointAddr = endpoint->bEndpointAddress;
			dev->int_out_buffer = kmalloc (buffer_size, GFP_KERNEL);

			if (!dev->int_out_buffer) 
			{
				err("Couldn't allocate int_in_buffer");
				goto error;
			}
			memset (dev->int_out_buffer, 0x00, buffer_size); // AT: fixed 

			dev->write_urb = usb_alloc_urb(0, GFP_KERNEL);	
			if (!dev->write_urb)
			{
				err("No free urbs available for write_urb");
				goto error;
			}

			pipe = usb_sndintpipe(udev, endpoint->bEndpointAddress);
			maxp = usb_maxpacket(udev, pipe,usb_pipeout(pipe));

			IRBOY_DEBUG("maxpr=%d\n",(int)buffer_size);

			usb_fill_int_urb(dev->write_urb, 
							udev,
							pipe,		/*sending pipe*/
							dev->int_out_buffer, 
							0, /*bufflen zero by default*/
							usbirboy_write_urb_callback,
							dev,
							dev->int_out_interval);	
		}
	}

	init_waitqueue_head (&dev->wait_rdata);
	init_waitqueue_head (&dev->wait_wdata);
	init_waitqueue_head (&dev->wait_remove);

	/* allow device read */
	dev->dev_present = 1;

	/*reset read buffer*/
	dev->read_buff_head = 0;
	dev->read_buff_tail = 0;
	dev->packet_ptr=0;
	dev->write_urb_done = 1;

	/*device is not used in userspace at this point*/
	dev->rused = dev->wused = 0;

	/* we can register the device now, as it is ready */
	usb_set_intfdata (interface, dev);						

	retval = usb_register_dev (interface, &usbirboy_class);

	if (retval)
	{
		/* something prevented us from registering this driver */
		err ("Not able to get a minor for this device.");
		usb_set_intfdata (interface, NULL);
		goto error;
	}

	dev->minor = interface->minor;  

	retval =  usb_submit_urb(dev->read_urb,GFP_KERNEL);  		
	if (retval)
	{
		err ("unable to submit initial read urb ");
		goto error;
	}

	IRBOY_INFO("USB-Ir-Boy device attached to with minor %d\n", dev->minor);

	return retval;

error:
	kref_put(&dev->kref,usbirboy_cleanup );
	return retval;
}

/* This is called by usb-core whenever device is disconnected */
void usbirboy_usb_disconnect(struct usb_interface *interface)
{
	struct usbirboy *usbdev = NULL;
	int minor = -1;

	/* prevent open to get thrue because we are disconnecting */
	down (&disconnect_sem);

	usbdev = usb_get_intfdata (interface);
	usb_set_intfdata (interface, NULL);

	/*lock dev structure*/
	down (&usbdev->sem);
	minor = usbdev->minor;

	/* terminate an ongoing read */
	IRBOY_DEBUG("Disconnect: unlinking urb...\n");

	/*this will end all further interrupts from device*/
	usb_unlink_urb (usbdev->read_urb);
	usb_unlink_urb (usbdev->write_urb);

	/* prevent device read  */
	usbdev->dev_present = 0;

	if(usbdev->wused == 1 || usbdev->rused == 1)
	{
		/*driver is open to user space */
		IRBOY_DEBUG("Disconnect: wused = %d , rused = %d\n",usbdev->wused,usbdev->rused);	  

		/*unlock structure to let userland read/write finish and release */
		up (&usbdev->sem); 

		/* wake up pending read */
		IRBOY_DEBUG("Disconnect: wake up wait_data\n");	  
		wake_up (&usbdev->wait_rdata);
		wake_up (&usbdev->wait_wdata);

		/*wait untill userspace releases the driver*/

		IRBOY_DEBUG("Disconnect: waiting on wait_remove\n");	  
		
		wait_event(usbdev->wait_remove, !(usbdev->wused == 0 && usbdev->rused == 0) );
	
		IRBOY_DEBUG("Disconnect: wait_remove ok\n");	  

		/*continue with locked structure*/
		down (&usbdev->sem);
	}

	/**** clean up ****/

	/* give back our minor */
	usb_deregister_dev (interface, &usbirboy_class);

	/* if device is open to userspace, release will eventually clean this up*/
	IRBOY_DEBUG("dev_present = %d , wused = %d, rused = %d\n",usbdev->dev_present,usbdev->wused,usbdev->rused);

	if(usbdev->wused == 1 || usbdev->rused == 1)
		err("Error: driver still used by userspace.. cleaning anyway");

	up (&usbdev->sem);

	/* decrement our usage count */
	kref_put(&usbdev->kref,usbirboy_cleanup );
	/*usbirboy_cleanup (usbdev);*/
	up (&disconnect_sem);

	IRBOY_INFO( "IRBOY USB device detached. Released minor: %d\n",minor);
}

/*called by usb-core during insmod or modprobe */
static int __init usbirboy_module_init (void)
{
	int result;

	IRBOY_DEBUG("Loaded with debug option, flooding...\n");

	/* Add user defined id:s to known devices */
	if(vendor_id != 0x0000) 
	{
		usbirboy_device_table[0].idVendor = vendor_id;
		usbirboy_device_table[0].idProduct = product_id;
	}

	/* register this driver with the USB subsystem */
	result = usb_register(&usbirboy_driver);			
	if (result < 0)
	{
		err("usb_register failed for the " __FILE__	" driver. Error number %d", result);
		return -1;
	}

	IRBOY_INFO("Registered : " DRIVER_DESC " " DRIVER_VERSION "\n");
	return 0;
}

/*called by usb-core during rmmod*/
static void __exit usbirboy_module_exit (void)
{
    usb_deregister (&usbirboy_driver);
    IRBOY_DEBUG( "driver deregistered...\n");
}

/*defines user space function bodies*/
static struct file_operations usbirboy_fops = {
	.owner =	THIS_MODULE,
	.read =		usbirboy_user_read,
	.open =		usbirboy_user_open,
	.release =	usbirboy_user_release,
	.ioctl = 	usbirboy_user_ioctl,
	.poll = 	usbirboy_user_poll,
	.write =	usbirboy_user_write,
};

/*descriptor for devfs */
static struct usb_class_driver usbirboy_class = {
	.name =		DEVFS_DRIVER_NAME,
	.fops =		&usbirboy_fops,
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,17)
	.mode =		S_IFCHR | S_IRUSR | S_IRGRP | S_IROTH,*/
#endif
	.minor_base =	MINOR_BASE,
};

/*driver info for kernel*/
static struct usb_driver usbirboy_driver = {
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,17)
	.owner =        THIS_MODULE,
#endif
	.name =         DRIVER_NAME,
	.id_table =     usbirboy_device_table,
	.probe =        usbirboy_usb_probe,
	.disconnect =   usbirboy_usb_disconnect,
};


/* -------------------------- Ending ------------------------------------ */

MODULE_DEVICE_TABLE (usb, usbirboy_device_table);
MODULE_AUTHOR( DRIVER_AUTHOR );
MODULE_DESCRIPTION( DRIVER_DESC );
MODULE_LICENSE("GPL");

module_init (usbirboy_module_init);
module_exit (usbirboy_module_exit);

/* --------------------------------------------------------------------- */
