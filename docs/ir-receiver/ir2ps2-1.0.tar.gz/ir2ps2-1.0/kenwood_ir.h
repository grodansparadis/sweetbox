/*  
 *  ir2ps2: A firmware for the AVR Atmega8 which converts infrared events
 *  received from a Kenwood RC-KB2 keyboard to PS/2 key events.
 *  Copyright (C) 2007  Rapha�l Ass�nat <raph@raphnet.net>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */
#ifndef _kenwood_ir_h__
#define _kenwood_ir_h__

#define KENWOOD_IR_PIN	PIND
#define KENWOOD_IR_BIT	(1<<2)

#define kenwood_pinIsHigh()	((KENWOOD_IR_PIN & KENWOOD_IR_BIT))
#define kenwood_pinIsLow()	((KENWOOD_IR_PIN & KENWOOD_IR_BIT)==0)

void kenwoodInit(void);
void kenwoodReceive(void (*keyPressCb)(unsigned char data[4]), 
						void (*keyRepeatCb)(void));
char kenwoodGetLastEvent(unsigned short *dst);

#endif

