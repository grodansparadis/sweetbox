/*  
 *  ir2ps2: A firmware for the AVR Atmega8 which converts infrared events
 *  received from a Kenwood RC-KB2 keyboard to PS/2 key events.
 *  Copyright (C) 2007  Rapha�l Ass�nat <raph@raphnet.net>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */
#ifndef _ps2_keyboard_dev_h__
#define _ps2_keyboard_dev_h__

#define PS2_KBDEV_DDR		DDRC
#define PS2_KBDEV_PORT		PORTC
#define PS2_KBDEV_PIN		PINC
#define PS2_KBDEV_CLK_BIT	(1<<4)
#define PS2_KBDEV_DAT_BIT	(1<<5)

#define PS2_CLK_DELAY	20

#define PS2_HCMD_SET_STATUS_LEDS	0xED
#define PS2_HCMD_ECHO				0xEE
#define PS2_HCMD_SET_SCAN_SET		0xF0
#define PS2_HCMD_READ_ID			0xF2
#define PS2_HCMD_SET_TYPEMATIC_RATE	0xF3
#define PS2_HCMD_KEYBOARD_ENABLE	0xF4
#define PS2_HCMD_KEYBOARD_DISABLE		0xF5
#define PS2_HCMD_SET_DEFAULT	0xF6
#define PS2_HCMD_RESEND				0xFE
#define PS2_HCMD_RESET				0xFF

#define PS2_KCMD_ACK				0xFA
#define PS2_KCMD_BAT				0xAA
#define PS2_KCMD_ECHO				0xEE
#define PS2_KCMD_RESEND				0xFE
#define PS2_KCMD_ERR_00				0x00
#define PS2_KCMD_ERR_FF				0xFF

void ps2_kbdev_init(void);
void ps2_kbdev_run(void);
void ps2_kbdev_sendByte(unsigned char b);
char ps2_kbdev_isByteSent(void);
void ps2_kbdev_byteDelay(void);

#endif // _ps2_keyboard_dev_h__

