/*  
 *  ir2ps2: A firmware for the AVR Atmega8 which converts infrared events
 *  received from a Kenwood RC-KB2 keyboard to PS/2 key events.
 *  Copyright (C) 2007  Rapha�l Ass�nat <raph@raphnet.net>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */
#include <avr/io.h>
#include <avr/interrupt.h>
#include <string.h>
#include "kenwood_ir.h"

/* -- Key press event --
 *                4.5ms
 *	----+        +----
 *      |________|
 *        9.1ms
 *      
 *         Att.
 *
 * -- Key release/repeat event --
 *              2.2ms
 * ----+         +--+ +----x
 *     |_________|  |_|
 *      9.1ms        ^
 *                 600us
 *     
 * ------------------------------------------
 *  Sample signal. Low time: 560us  High time: 1.640ms
 *
 *           -----+ +-+ +-----+ +-----+ +-+ +--
 *                |_| |_|     |_|     |_| |_|
 *
 *                    0       1       1   0
 *
 */

/* \param timeout Timeout given in steps of 100us
 * \param rise Wait for a rising edge? Otherwise falling.
 * \return The time it took before we got the transition (in 100us steps). -1 on timeout.
 */
#define MS_TO_CYCLES(m) ((m)*10) /* 1ms = 10 * 100us = 1000us */


static int waitLevel(char level, int timeout)
{
	int time_elaps=0; // 1 == 100 micro

	TCNT2 = 0;
	if (level) {
		while (kenwood_pinIsLow()) {
			if (TIFR & (1<<OCF2)) {
				TIFR |= (1<<OCF2);
				time_elaps++;
			}
			if (time_elaps >= timeout)
				return -1;
		}
	}
	else { // fall
		while (kenwood_pinIsHigh()) {
			if (TIFR & (1<<OCF2)) {
				TIFR |= (1<<OCF2);
				time_elaps++;
			}
			if (time_elaps >= timeout)
				return -1;
		}
	}

	return time_elaps;
}

void kenwoodInit(void)
{
	/* Clock is 16000000 (16mhz). Use prescaler to
	 * divide it by 8 to obtain 2000000 (2mhz). 
	 * Next, use output compare register to divide
	 * by 200, which gives use 10khz.
	 *
	 * 1khz = 1 millisecond resolution
	 * 10khz = 0.1 millisecond resolution
	 * */
	TCCR2 = (1<<WGM21) | (1<<CS01);
	OCR2 = 200;
	TCNT2 = 0;
	TIMSK = OCIE2;	/* Compare match interrupt enable */

	/* configure external INT0 for falling edge */
	MCUCR = 0x02;
	GICR = 0x40;
}

static volatile unsigned short presses[64];
static volatile int pr_head=0, pr_tail=0;

static void queueKeyPress(unsigned char data[4])
{
	if ((data[2] + data[3]) != 0xFF )
		return;	/* That's too bad, but the data is corrupted */

	presses[pr_head] = data[1]<<8 | data[2];
	pr_head++;
	if (pr_head >= 64)
		pr_head = 0;
}

static void queueKeyRepeat(void)
{
	presses[pr_head] = 0xffff;
	pr_head++;
	if (pr_head >= 64)
		pr_head = 0;
}

/* return 1 if something was returned */
char kenwoodGetLastEvent(unsigned short *dst)
{
	unsigned char sreg = SREG;

	cli();

	if (pr_head == pr_tail) {
		SREG = sreg;
		return 0;
	}

	*dst = presses[pr_tail];
	SREG = sreg;

	pr_tail++;
	if (pr_tail >= 64)
		pr_tail = 0;

	return 1;
}

SIGNAL(SIG_INTERRUPT0)
{
	kenwoodReceive(queueKeyPress, queueKeyRepeat);
}

void kenwoodReceive(void (*keyPressCb)(unsigned char data[4]), 
						void (*keyRepeatCb)(void))
{
	unsigned char bit;
	int i, t, idx;
	unsigned char buf[4];

	memset(buf, 0, 4);

	t = waitLevel(0, MS_TO_CYCLES(15));
	if (t == -1) 
		return;

	t = waitLevel(1, MS_TO_CYCLES(13));
	if (t == -1 || t < MS_TO_CYCLES(8) || t > MS_TO_CYCLES(10))
		return;


	t = waitLevel(0, MS_TO_CYCLES(6));
	if (t == -1)
		return;

	if (t >= MS_TO_CYCLES(1) && t <= MS_TO_CYCLES(3)) {
		keyRepeatCb();
		return;
	} else if (t > MS_TO_CYCLES(4) && t <= MS_TO_CYCLES(5)) {
		// start condition
	} else {
		return;
	}

	idx = 0;
	bit = 0x80;
	for (i=0; i<33; i++)
	{
		t = waitLevel(1, 8); /* 800us */
		if (t == -1 || t<4 || t>7)
			break;

		t = waitLevel(0, 20); /* 2000us */
		if (t == -1)
			break;

		if (i==32)
			return; /* we should have had a timeout! */

		if (t>=4 && t<=8) {
			/* bit pre-cleared */
		}
		else if (t>=14 && t<= 18) {
			buf[idx] |= bit;
		}
		else
			break;

		bit >>= 1;
		if (!bit) {
			idx++;
			bit = 0x80;
		}
	}
	if (i==32) {
		keyPressCb(buf);
	}
}

