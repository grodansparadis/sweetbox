/*  
 *  ir2ps2: A firmware for the AVR Atmega8 which converts infrared events
 *  received from a Kenwood RC-KB2 keyboard to PS/2 key events.
 *  Copyright (C) 2007  Rapha�l Ass�nat <raph@raphnet.net>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <stdio.h>
#include <avr/io.h>
#include <util/delay.h>

#include "ps2_keyboard_dev.h"

#define ps2_clkIsHigh()		(PS2_KBDEV_PIN & PS2_KBDEV_CLK_BIT)
#define ps2_clkIsLow()		((PS2_KBDEV_PIN & PS2_KBDEV_CLK_BIT)==0)

#define ps2_dataIsHigh()	(PS2_KBDEV_PIN & PS2_KBDEV_DAT_BIT)
#define ps2_dataIsLow()		((PS2_KBDEV_PIN & PS2_KBDEV_DAT_BIT)==0)

#define ps2_pullData()		do { 	PS2_KBDEV_PORT &= ~(PS2_KBDEV_DAT_BIT); \
									PS2_KBDEV_DDR |= PS2_KBDEV_DAT_BIT; } while(0)
#define ps2_releaseData()	do	{	PS2_KBDEV_DDR &= ~(PS2_KBDEV_DAT_BIT); \
									PS2_KBDEV_PORT |= PS2_KBDEV_DAT_BIT; } while(0)

#define ps2_pullClk()		do { 	PS2_KBDEV_PORT &= ~(PS2_KBDEV_CLK_BIT); \
									PS2_KBDEV_DDR |= PS2_KBDEV_CLK_BIT; } while(0)
#define ps2_releaseClk()	do	{	PS2_KBDEV_DDR &= ~(PS2_KBDEV_CLK_BIT); \
									PS2_KBDEV_PORT |= PS2_KBDEV_CLK_BIT; } while(0)
#ifdef DEBUG_OUTPUT
#define TRACE_COMM_RX
#define TRACE_COMM_TX
#endif

static char g_disabled = 0;

/* Release the clock and wait until it is high. 
 * \return 0: Ok, 1: Timed out */
static unsigned char ps2_releaseClkTimeout() 
{
	unsigned char count=255;

	PS2_KBDEV_DDR &= ~(PS2_KBDEV_CLK_BIT); 
	PS2_KBDEV_PORT |= PS2_KBDEV_CLK_BIT; 
	
	do {
		if (ps2_clkIsHigh())
			return 0;
	} while (--count);

	return 1;	
}

static void clkDelay(void)
{
	unsigned char i;

	for (i=0; i<70; i++)
		asm volatile("nop\nnop\nnop\nnop\nnop\n");
}

static void settleDelay(void)
{
	unsigned char i;
	for (i=0; i<20; i++)
		asm volatile("nop\nnop\nnop\nnop\nnop\nnop\n");
}

/* Inserting this delay between bytes sent to the host
 * is a good idea. Otherwise, some computers beeps and 
 * thinks some keys are stuck. */
void ps2_kbdev_byteDelay(void)
{
	unsigned char i;
	for (i=0; i<8; i++)
		clkDelay();
}

void ps2_kbdev_init(void)
{
	ps2_releaseData();
	ps2_releaseClk();
}

/**
 * To be called after the host has released the clock!
 *
 * \ret 0: Byte received ok, 1: Framing error
 */
static unsigned char ps2_kbdev_readByte(unsigned char *dst)
{
	unsigned char dat, bit, p, rx_p, stop;
	int i;

	clkDelay();
	ps2_pullClk();				/* start bit */
	clkDelay();
	ps2_releaseClk();
	clkDelay();

	bit = 0x01;
	dat = 0x00;
	p = 0x01;
	for (i=0; i<8; i++) {
		ps2_pullClk();				/* bit i */
		if (ps2_dataIsHigh()) {
			p ^= 0x01;
			dat |= bit;
		}
		clkDelay();
		ps2_releaseClk();
		clkDelay();

		bit <<= 1;
	}

	ps2_pullClk();				/* parity bit */
	rx_p = ps2_dataIsHigh();
	clkDelay();
	ps2_releaseClk();

	clkDelay();
	ps2_pullClk();				/* stop bit */
	stop = ps2_dataIsHigh();
	clkDelay();
	ps2_releaseClk();
	ps2_pullData();
	clkDelay();


	/* Send and ack */
	ps2_pullClk();
	clkDelay();
	ps2_releaseClk();
	ps2_releaseData();

	/* Check framing and parity */
	if (!stop) {
		return 1;
	}

	if (	(p && !rx_p) ||
			(!p && rx_p) ) {
		return 1;
	}

	*dst = dat;
	return 0;
}


#define ST_IDLE								0
#define ST_WAIT_SET_STATUS_LEDS_2ND_BYTE	1
#define ST_WAIT_SET_SCAN_CODE_SET_2ND_BYTE	2
#define ST_WAIT_SET_TYPEMATIC_2ND_BYTE		3

/**
 * \param rep The reply is stored there
 *
 * \return 0: Ignored
 * \return 1: Must Reply 1 byte
 * \return 2: Must reply 2 bytes
 */
static char ps2_kbdev_doHostCommand(unsigned char cmd, unsigned char *rep, unsigned char *rep2)
{
	static char state = ST_IDLE;

	switch (state)
	{
		case ST_IDLE:
				ps2_kbdev_byteDelay();

				switch (cmd)
				{
					case PS2_HCMD_SET_STATUS_LEDS:
						*rep = PS2_KCMD_ACK;
						state = ST_WAIT_SET_STATUS_LEDS_2ND_BYTE;
						return 1;
					case PS2_HCMD_ECHO:
						*rep = PS2_KCMD_ECHO;
						return 1;
					case PS2_HCMD_SET_SCAN_SET:
						*rep = PS2_KCMD_ACK;
						state = ST_WAIT_SET_SCAN_CODE_SET_2ND_BYTE;
						return 1;
					case PS2_HCMD_READ_ID:
						*rep = 0x83;
						*rep2 = 0xAB;
						return 2;
					case PS2_HCMD_SET_TYPEMATIC_RATE:
						*rep = PS2_KCMD_ACK;
						state = ST_WAIT_SET_TYPEMATIC_2ND_BYTE;
						return 1;
					case PS2_HCMD_KEYBOARD_ENABLE:
						*rep = PS2_KCMD_ACK;
						state = ST_WAIT_SET_TYPEMATIC_2ND_BYTE;
						g_disabled = 0;
						return 1;
					case PS2_HCMD_KEYBOARD_DISABLE:
						*rep = PS2_KCMD_ACK;
						g_disabled = 1;
						return 1;
					case PS2_HCMD_RESET:
						g_disabled = 0;
						*rep2 = PS2_KCMD_ACK;
						*rep = 0xAA; /* Do as if we _really_ reset */ 
						return 2;
					case PS2_HCMD_SET_DEFAULT:
						*rep = PS2_KCMD_ACK;
						return 1;
					default:
						*rep = PS2_KCMD_RESEND;
						return 1;
				}
			break;

		case ST_WAIT_SET_SCAN_CODE_SET_2ND_BYTE:
			if (cmd==0x00) {	/* Get current set */
				/* send ack */
				*rep = 0x02; // Set 2
				*rep2 = PS2_KCMD_ACK;
				state = ST_IDLE;
				return 2;
			} else if (cmd != 0x02) {
				/* Reject other sets. */
				*rep = PS2_KCMD_RESEND;
				return 1;
			}
			else {
				/* send ack */
				*rep = PS2_KCMD_ACK;
				return 1;
			}

		case ST_WAIT_SET_TYPEMATIC_2ND_BYTE:
			// ignore too
		case ST_WAIT_SET_STATUS_LEDS_2ND_BYTE:
			// Just ack ; we dont have leds.
			state = ST_IDLE;
			*rep = PS2_KCMD_ACK;
			return 1;
	}

	return 0;
}



/**
 * \brief Send a byte to the host
 * \param b The data to send
 *
 * \return 0: Sent successfully, 1: Interrupted/Inhibitted by host
 */
static char ps2_kbdev_tx(unsigned char b)
{
	int i;
	unsigned char bit;
	char p;


	ps2_releaseData();
	if (ps2_releaseClkTimeout())
		goto abrt;

	/* we are allowed to transmit only when the bus is idle */
	if (!ps2_dataIsHigh() || !ps2_clkIsHigh())
		goto abrt;
	
	ps2_pullData();
	clkDelay();

	ps2_pullClk();			/* Start bit */
	clkDelay();

	bit = 0x01;
	p = 0x01;
	for (i=0; i<8; i++) {

		if (ps2_releaseClkTimeout())
			goto abrt;
		settleDelay();
		if (b & bit) {
			p ^= 1;
			ps2_releaseData();
		} else
			ps2_pullData();
		
		clkDelay();
		if (!ps2_clkIsHigh())
			goto abrt;

		ps2_pullClk();			/* Bit i */
		clkDelay();
		if (ps2_releaseClkTimeout())
			goto abrt;

		bit <<= 1;
	}

	if (ps2_releaseClkTimeout())
		goto abrt;
	
	settleDelay();
	
	/* Parity bit */
	if (p) {
		ps2_releaseData();
	} else {
		ps2_pullData();
	}
	clkDelay();
	if (!ps2_clkIsHigh())
		goto abrt;

	ps2_pullClk();			
	clkDelay();
	if (ps2_releaseClkTimeout())
		goto abrt;

	/* Stop bit */
	settleDelay();
	ps2_releaseData();
	clkDelay();
	ps2_pullClk();			
	clkDelay();
	ps2_releaseClk();
	clkDelay();

#ifdef TRACE_COMM_TX
	printf("<%02x\r\n", b);
#endif

	return 0;

abrt:
	ps2_releaseData();
	ps2_releaseClk();	
	return 1;
}


static unsigned char nextKeyTx;
static char keyTransmitted=1;

char ps2_kbdev_isByteSent(void)
{
	return keyTransmitted;
}

void ps2_kbdev_sendByte(unsigned char b)
{
	nextKeyTx = b;
	keyTransmitted = 0;
}

#define MODE_RUN	0
#define MODE_REPLY	1

void ps2_kbdev_run(void)
{
	char res;
	unsigned char host_cmd;

	/* Start in reply mode, as if we were replying
	 * 0xAA to a command. This makes us send the BAT
	 * code at initialisation (power-up) */
	static unsigned char cmd_rep1=0xaa, cmd_rep2=0x00;
	static unsigned char mode=MODE_REPLY;
	static unsigned char last_sent=0xff;
	static char toreply=1;

	switch(mode)
	{
		case MODE_RUN: /* Normal mode */
			if (!keyTransmitted && !g_disabled) {
				res = ps2_kbdev_tx(nextKeyTx);
				if (res==0) { 
					keyTransmitted = 1;
					last_sent = nextKeyTx;
				}
			}

	
			break;

		case MODE_REPLY: /* reply mode */
			if (toreply > 2)	/* sanity check */
				toreply = 0;

			if (toreply) {
				res = ps2_kbdev_tx((toreply==1) ? cmd_rep1 : cmd_rep2 );
				if (res==0) {
					toreply--;
					last_sent = nextKeyTx;
				}
				
				if (!toreply) 
					mode = 0;
			}
			break;
			
		default:
			mode = MODE_RUN;

	}


	/* In any state (Normal or reponding), we must answer to the
	 * host requests to send. If we were sending the answer to a
	 * command, forget about it and handle the now command! */	
	if (ps2_clkIsLow())
	{
		/* The host is pulling the clock */
		while (ps2_clkIsLow()) {
			
			/* If the host also pulls data low it
			 * is a RTS. But it has to release the clock first */
			if (ps2_dataIsLow()) {
				while (ps2_dataIsLow() && ps2_clkIsLow()) 
						{ /* do nothing */ }

				if (ps2_clkIsHigh() && ps2_dataIsLow()) {
					/* ok, host released the clock but
					 * kept data low. Read command. */
					res = ps2_kbdev_readByte(&host_cmd);

					if (res==0) {
						#ifdef TRACE_COMM_RX
						printf(">%02x\r\n", host_cmd);
						#endif
					
						/* Handle the resend command right here. */
						if (host_cmd == PS2_HCMD_RESEND) {
							toreply = 1;
							cmd_rep1 = last_sent;
						}
						else {		
							res = ps2_kbdev_doHostCommand(host_cmd, 
													&cmd_rep1, &cmd_rep2);
							if (res) {
								toreply = res;
								mode = 1;
							}						
						}
					}
					else {
						cmd_rep1 = 0xfe;
						toreply = 1;
						mode = 1;
					}
				}
			}
		}
	}

}

