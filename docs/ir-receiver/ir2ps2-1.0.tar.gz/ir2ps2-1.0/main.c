/*  
 *  ir2ps2: A firmware for the AVR Atmega8 which converts infrared events
 *  received from a Kenwood RC-KB2 keyboard to PS/2 key events.
 *  Copyright (C) 2007  Rapha�l Ass�nat <raph@raphnet.net>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License along
 *  with this program; if not, write to the Free Software Foundation, Inc.,
 *   51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include <util/delay.h>

#include "kenwood_ir.h"
#include "ps2_keyboard_dev.h"

#ifdef DEBUG_OUTPUT
static inline void uart_writeByte(unsigned char b)
{
	while ( !(UCSRA & (1<<UDRE)) )
		{ } /* empty statement */

	UDR = b;
}

static int uart_putchar(char c, FILE *f)
{
	uart_writeByte(c);
	return 1;
}
#endif

static char convertCode(unsigned short ir, unsigned char *dst)
{
	unsigned char cd;
	unsigned char a=0,b=0,s=0;
	static unsigned char dead_control=0, dead_alt=0;
	unsigned char idx;

	cd = ir & 0x00ff;	

	if ((ir & 0xff00) == 0x0000)
		goto lut00;
	if ((ir & 0xff00) == 0x9200)
		goto lut92;
	if ((ir & 0xff00) == 0x1200)
		goto lut12;

	return 0;

lut00:
	switch (cd)
	{
		case 0x81:	s = 1; a = 0x16; break;	// ! (1)
		case 0x02:	s = 1; a = 0x1E; break;	// @ (2)
		case 0xc1:	s = 1; a = 0x26; break;	// # (3)
		case 0x21:	s = 1; a = 0x25; break;	// $ (4)
		case 0xa1:	s = 1; a = 0x2E; break;	// % (5)
		case 0x7a:	s = 1; a = 0x36; break;	// ^ (6)
		case 0x61:	s = 1; a = 0x3D; break;	// & (7)
		case 0x51:	s = 1; a = 0x3E; break;	// * (8)
		case 0x11:	s = 1; a = 0x46; break;	// ( (9)
		case 0x91:	s = 1; a = 0x45; break;	// ) (0)
		case 0xfa:	s = 1; 				// _
		case 0xb1:	a = 0x4e; break;	// -
		case 0xd1:	s = 1;				// +
		case 0xb9:	a = 0x55; break;	// =

		case 0x8b: 	s = 1;
		case 0x8a:	a = 0x15; break;	// q
		case 0xeb:	s = 1;
		case 0xea:	a = 0x1d; break;	// w
		case 0xa3:	s = 1;
		case 0xa2:	a = 0x24; break;	// e
		case 0x4b:	s = 1;
		case 0x4a:	a = 0x2d; break;	// r
		case 0x2b:	s = 1;
		case 0x2a:	a = 0x2c; break;	// t
		case 0x9b:	s = 1;
		case 0x9a:	a = 0x35; break;	// y
		case 0xab:	s = 1;
		case 0xaa:	a = 0x3c; break;	// u
		case 0x93:	s = 1;
		case 0x92:	a = 0x43; break;	// i
		case 0xf3:	s = 1;
		case 0xf2:	a = 0x44; break;	// o
		case 0x0b:	s = 1;
		case 0x0a:	a = 0x4d; break;	// p
		case 0x03:	a = 0x0e; break;	// `

		case 0x83:	s = 1;
		case 0x82:	a = 0x1c; break;	// a
		case 0xcb:	s = 1;
		case 0xca:	a = 0x1b; break;	// s
		case 0x23:	s = 1;
		case 0x22:	a = 0x23; break;	// d
		case 0x63:	s = 1;
		case 0x62:	a = 0x2b; break;	// f
		case 0xe3:	s = 1;
		case 0xe2:	a = 0x34; break;	// g
		case 0x13:	s = 1;
		case 0x12:	a = 0x33; break;	// h
		case 0x53:	s = 1;
		case 0x52:	a = 0x3b; break;	// j
		case 0xd3:	s = 1;
		case 0xd2:	a = 0x42; break;	// k
		case 0x33:	s = 1;
		case 0x32:	a = 0x4b; break;	// l
		case 0x59:	s = 1;				// :
		case 0xd9:	a = 0x4c; break;	// ;
		case 0x41:	s = 1;				// "
		case 0xe1:	a = 0x52; break;	// '

		case 0x5b:	s = 1;
		case 0x5a:	a = 0x1a; break;	// z
		case 0x1b:	s = 1;
		case 0x1a:	a = 0x22; break;	// x
		case 0xc3:	s = 1;
		case 0xc2:	a = 0x21; break;	// c
		case 0x6b:	s = 1;
		case 0x6a:	a = 0x2a; break;	// v
		case 0x43:	s = 1;
		case 0x42:	a = 0x32; break;	// b
		case 0x73:	s = 1;
		case 0x72:	a = 0x31; break;	// n
		case 0xb3:	s = 1;
		case 0xb2:	a = 0x3a; break;	// m
		case 0x39:	s = 1;				// <
		case 0x31:	a = 0x41; break;	// ,
		case 0x79:	s = 1;				// >
		case 0x71:	a = 0x49; break;	// .
		case 0xf9:	s = 1;				// ?
		case 0xf1:	a = 0x4A; break;
		default: return 0;
	}
	goto ret;

lut92:
	switch (cd)
	{
		case 0x88:	b = 0x24; break;	// Stop
		case 0xc8:	b = 0x22; break;	// Play/Pause
		case 0x68:	b = 0x10; break;	// Previous track
		case 0xe8:	b = 0x19; break;	// Next track

		case 0x28:	b = 0x2e; break;	// Vol - (rew on kb)
		case 0xa8:	b = 0x30; break;	// Vol + (ff on kb)

		case 0x89:	a = 0x76; break;	// ESC (Power on kb)
		case 0x4b:	a = 0x06; break;	// F2 (Best.Sel. on kb)
		case 0x98:	a = 0x04; break;	// F3 (Repeat on kb)
		case 0xf2:  a = 0x0C; break;	// F4 (Random on kb)
		case 0x18:	a = 0x03; break;	// F5 (Display on kb)
		case 0x50:	a = 0x0A; break;	// F8 (+10 on kb)

		case 0x80:	a = 0x16; break;	// 1
		case 0x40:	a = 0x1E; break;	// 2
		case 0xc0:	a = 0x26; break;	// 3
		case 0x20:	a = 0x25; break;	// 4
		case 0xa0:	a = 0x2e; break;	// 5
		case 0x60:	a = 0x36; break;	// 6
		case 0xe0:	a = 0x3d; break;	// 7
		case 0x10:	a = 0x3e; break;	// 8
		case 0x90:	a = 0x46; break;	// 9
		case 0x00:	a = 0x45; break;	// 0
		case 0x2b:	a = 0x66; break;	// Backspace (marked DELETE on kb)
		case 0x39:	a = 0x0d; break;	// TAB (Disc.Sel. on kb)

		case 0xcb:	a = 0x5a; break;	// enter
		case 0x42:	a = 0x29; break;	// space

		case 0x1b:	b = 0x6b; break;	// left arrow (cursor L on kb)
		case 0x9b:	b = 0x74; break;	// right arrow (cursor R on kb)
		case 0x6b:	b = 0x72; break;	// down arrow (ch.search.dn on kb)
		case 0xeb:	b = 0x75; break;	// up arrow (ch.search.up on kb)
		case 0x59:	b = 0x7a; break;	// page down (disk skip down on kb)
		case 0xb2:  b = 0x7d; break;	// page up (disk skip up on kb)
		case 0xf8:	b = 0x5d; break;	// backslash (P.mode on kb)
		case 0xd8:	b = 0x70; break;	// insert (check on kb)
		case 0x58:  b = 0x71; break;	// delete (clear on kb)
		case 0xd9:	b = 0x6c; break;	// home (set on kb)
		default: return 0;
	}
	goto ret;

lut12:
	switch (cd)
	{
		case 0x40:	a = 0x05; break;	// F1 (confirm on kb)
		case 0x90:	a = 0x0B; break;	// F6 (Title input on kb)
		case 0x10:	a = 0x83; break;	// F7 (User file name)
		case 0x00:	a = 0x01; break;	// F9 (+100 on kb)

		// ROOM_B + DISC_SKIP_DN/UP will do Shift Pageup/down.
		// Very useful for scrolling in console history
		case 0xc2: s = 1; b = 0x7a; break; // (disk skip down on kb)
		case 0x42: s = 1; b = 0x7d; break; // (disk skip up on kb)

		case 0xa0: 	dead_control = !dead_control; 
					return 0; // Dont send anything now
		case 0x60: 	dead_alt = !dead_alt;
					return 0; // Dont send anything now

		case 0x50:	b = 0x69; break;	// end (mode on kb)
		default: return 0;
	}

ret:
	idx = 0;

	if (dead_control) {
		dst[idx++] = 0x14;	// Left control
	}
	if (dead_alt) {
		dst[idx++] = 0x11;	// Left Alt
	}

	if (a) { // Single byte keycode
		if (!s) {
			dst[idx++] = a;			// Our key
			dst[idx++] = 0xF0;		// Break code...
			dst[idx++] = a;			// for our key.
		}
		else {// Shifted one-byte keycode
			dst[idx++] = 0x12;	// Left shift
			dst[idx++] = a;		// our key
			dst[idx++] = 0xF0;	// break code..
			dst[idx++] = a;		// ... for our key
			dst[idx++] = 0xF0;	// break code...
			dst[idx++] = 0x12;	// for left shift
		}
	} 
	else if (b) { // Extended 2 byte keycode (first byte E0)
		dst[idx++] = 0xE0;	// Extended..
		dst[idx++] = b;		// ...key.
		dst[idx++] = 0xE0;	// Extended...
		dst[idx++] = 0xF0;	// ...break code...
		dst[idx++] = b;		// ...for our key.
	}

	if (dead_alt) {
		dst[idx++] = 0xF0;	// break code
		dst[idx++] = 0x11;	// Left Alt
		dead_alt = 0;
	}
	if (dead_control) {
		dst[idx++] = 0xF0;	// break code
		dst[idx++] = 0x14;	// Left control
		dead_control = 0;
	}

	return idx;
}

int main(void)
{
	/* All IO configured as inputs with pullups by default */
	DDRC = 0x00; 
	PORTC = 0xFF;
	DDRB = 0x00;
	PORTB = 0xFF;
	DDRD = 0x00;
	PORTD = 0xFF;

	UCSRB = (1 << TXEN);
	UCSRC = (1 << URSEL) | (1 << UCSZ1) | (1 << UCSZ0);

	UBRRL = 25; /* 38400 at 16mhz */

#ifdef DEBUG_OUTPUT
	stdout = fdevopen(uart_putchar, NULL);
	printf("ir2ps2\r\n");
#endif

	kenwoodInit();

	ps2_kbdev_init();
	sei();
	while(1) {
		unsigned short ev;
		unsigned char reply[16];
		char len;

		ps2_kbdev_run();
		if (kenwoodGetLastEvent(&ev)) {
			len = convertCode(ev, reply);
			if (len)
			{
				char i;
	
				for (i=0; i<len; i++)
				{
					ps2_kbdev_sendByte(reply[(int)i]);
					while (!ps2_kbdev_isByteSent()) {
						ps2_kbdev_run();
					}
				
					ps2_kbdev_byteDelay();
				}
			}
		}
	}

	return 0;
}
