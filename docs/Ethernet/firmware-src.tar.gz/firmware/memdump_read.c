
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
    uint16_t offset, count;

    if(argc < 3)
    {
        printf("Usage: %s <offset> <count>\n", argv[0]);
        return EXIT_FAILURE;
    }
    else
    {
        offset = atoi(argv[1]);
        count  = atoi(argv[2]);

        fwrite(&offset, sizeof(uint16_t), 1, stdout);
        fwrite(&count, sizeof(uint16_t), 1, stdout);
        fflush(stdout);

        return EXIT_SUCCESS;
    }

}
