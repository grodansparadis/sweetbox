/***************************************************************************
 * tcp.c: TCP layer for ATmega88.
 * Copyright (C) 2007 Michael C McTernan,
 *    Michael.McTernan.2001@cs.bris.ac.uk
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

#define MODULE_NAME "MEMDUMP"

#if defined(ENABLE_MEMDUMP)

/**************************************************************************
 * Include Files
 **************************************************************************/

#include <stdint.h>
#include <stdio.h>
#include "enc28j60.h"
#include "memdump.h"
#include "main.h"
#include "udp.h"
#include "ip.h"

/**************************************************************************
 * Manifest Constants
 **************************************************************************/

/**************************************************************************
 * Type Definitions
 **************************************************************************/

typedef struct
{
    uint16_t offset;  /** Offset into SRAM of first byte to return. */
    uint16_t count;   /** Count of bytes to return. */
}
memdumpheader_t;

/**************************************************************************
 * Variables
 **************************************************************************/

/** Gain access to linker symbol for start of SRAM section.
 * This symbol is defined to be the address of the first byte of SRAM.
 */
extern uint8_t __data_start;

/**************************************************************************
 * Macros
 **************************************************************************/

/**************************************************************************
 * Local Functions
 **************************************************************************/

/**************************************************************************
 * Global Functions
 **************************************************************************/

void MemdumpProcessPacket(const ipparam_t *ipp)
{
    memdumpheader_t hdr;

    /* Read header */
    enc28j60RxPktRead(sizeof(memdumpheader_t), &hdr);

    if(UdpWriteHeader(&ipHost,
                      &ipp->sAddr,
                      UDP_PORT_MEMDUMP,
                      UDP_PORT_MEMDUMP,
                      hdr.count))
    {
        uint8_t *p = &__data_start + hdr.offset;

        /* Write blocks of 255 bytes as needed */
        while(hdr.count > 255)
        {
            enc28j60TxPktAppend(255, p);
            hdr.count -= 255;
            p         += 255;
        }

        /* Write any remainer */
        enc28j60TxPktAppend(hdr.count, p);
        enc28j60TxPktSend();
    }
}

#endif /* ENABLE_MEMDUMP */

/* END OF FILE */
