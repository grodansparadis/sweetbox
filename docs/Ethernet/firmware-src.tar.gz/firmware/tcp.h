/***************************************************************************
 * tcp.h: TCP layer for ATmega88.
 * Copyright (C) 2007 Michael C McTernan,
 *    Michael.McTernan.2001@cs.bris.ac.uk
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

#ifndef TCP_H
#define TCP_H

/**************************************************************************
 * Manifest Constants
 **************************************************************************/

#define TCP_INVALID_TCB 0xff

/**************************************************************************
 * Types
 **************************************************************************/

/** Causes for calling a TCP callback.
 */
typedef enum
{
    /** The connection has been established and data can be sent. */
    TCP_CALLBACK_CAUSE_ESTABLISHED = 0,

    /** Data has been transmitted succesfully; more can be sent. */
    TCP_CALLBACK_CAUSE_TX_SENT,

    /** Some data needs retransmitting. */
    TCP_CALLBACK_CAUSE_TX_RETRY,

    /** Data has been recieved and can be read from the current packet. */
    TCP_CALLBACK_CAUSE_RX_DATA,

    /** All data received and the peer has indicated it will send no more. */
    TCP_CALLBACK_CAUSE_RX_CLOSED,

    /** Both peers have closed the connection. */
    TCP_CALLBACK_CAUSE_CLOSED,

    /** The connection was reset by the peer. */
    TCP_CALLBACK_CAUSE_CON_RESET,

}
tcpcallbackcause_t;

/** Callback function type.
 * This gives the type for the callback.
 */
typedef void (*tcpcallback_t)(uint8_t tcb, tcpcallbackcause_t cause, uint16_t c);

/**************************************************************************
 * Prototypes
 **************************************************************************/

void TcpRetransmitTick  (void);

void TcpProcessPacket   (const ipparam_t  *ipp);

void TcpReset           (void);

/* Socket creation API */
uint8_t TcpCreateClientSocket(const ipaddr_t *destIp,
                              uint16_t        dport,
                              tcpcallback_t   callback);

/* Call back API */

void TcbWriteData       (uint8_t           tcbIdx,
                         uint16_t          n,
                         const void       *data,
                         boolean_t         push);

void TcbClose           (uint8_t           tcbIdx);

#endif /* TCP_H */
