/***************************************************************************
 * main.h: Common types and functions.
 * Copyright (C) 2007 Michael C McTernan,
 *    Michael.McTernan.2001@cs.bris.ac.uk
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

#ifndef EVENT_H
#define EVENT_H

/**************************************************************************
 * Nested Includes
 **************************************************************************/

#if !defined(ON_PC)
#include <avr/io.h>
#else
#include <stdint.h>
#include "main.h"
#endif

/**************************************************************************
 * Macros
 **************************************************************************/

#if !defined(ON_PC)
#define EVENT_REG           GPIOR0
#else
#define EVENT_REG           evRegister
#endif

#define EV_ETH                   0
#define EV_TIMER_GEN             1
#define EV_TIMER_DHCP_RENEW      2
#define EV_TIMER_DHCP_REBIND     3
#define EV_TIMER_TCP_RETRANSMIT  4
#define EV_SEQ_COMPLETED         5

#if !defined(ON_PC)
#define M_EventIsSet(ev)  ((EVENT_REG & (1<<(ev))) != 0)
#define M_EventClr(ev)    EVENT_REG &= ~(1<<(ev))
#define M_EventSet(ev)    EVENT_REG |= (1<<(ev))
#else
#define M_EventIsSet(ev)  EventIsSetPc(1<<(ev))
#define M_EventClr(ev)    EventClrPc(1<<(ev))
#define M_EventSet(ev)    EventSetPc(1<<(ev))
#endif

/**************************************************************************
 * Types
 **************************************************************************/

/**************************************************************************
 * Global Variables
 **************************************************************************/

extern uint8_t evRegister;

/**************************************************************************
 * Prototypes
 **************************************************************************/

#if defined(ON_PC)
void      EventSetPc(uint8_t evMask);
void      EventClrPc(uint8_t evMask);
boolean_t EventIsSetPc(uint8_t evMask);
void      EventIsr(void);
#endif

#endif

/* END OF FILE */
