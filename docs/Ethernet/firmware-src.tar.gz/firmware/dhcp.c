/***************************************************************************
 * dhcp.c: RFC2131 implementation for ATmega88.
 * Copyright (C) 2007 Michael C McTernan,
 *    Michael.McTernan.2001@cs.bris.ac.uk
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

/**************************************************************************
 * Include Files
 **************************************************************************/

#if !defined(ON_PC)
#include <avr/pgmspace.h>
#else
#define PROGMEM
#endif
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "enc28j60.h"
#include "autoip.h"
#include "event.h"
#include "timer.h"
#include "event.h"
#include "dhcp.h"
#include "eth.h"
#include "udp.h"
#include "arp.h"

/**************************************************************************
 * Manifest Constants
 **************************************************************************/

#define DHCP_OP_BOOTREQUEST    1
#define DHCP_OP_BOOTREPLY      2

#define BOOTP_OPT_DHCP_REQUESTED_IP_ADDR  50
#define BOOTP_OPT_DHCP_LEASE_TIME         51
#define BOOTP_OPT_DHCP_MSG_TYP            53
#define BOOTP_OPT_DHCP_SERVER_ID          54
#define BOOTP_OPT_DHCP_PARAM_REQ_LIST     55
#define BOOTP_OPT_DHCP_RENEWAL_TIME_VAL   58 /* T1 */
#define BOOTP_OPT_DHCP_REBINDING_TIME_VAL 59 /* T2 */

#define BOOTP_OPT_VEND_EXT_SUBNET_MASK     1
#define BOOTP_OPT_VEND_EXT_ROUTER_OPTION   3

#define BOOTP_OPT_END_MARKER             255

/* DHCP message types stored in option 0x53 */
#define DHCP_MSG_TYP_DHCPDISCOVER 1
#define DHCP_MSG_TYP_DHCPOFFER    2
#define DHCP_MSG_TYP_DHCPREQUEST  3
#define DHCP_MSG_TYP_DHCPDECLINE  4
#define DHCP_MSG_TYP_DHCPACK      5
#define DHCP_MSG_TYP_DHCPNAK      6
#define DHCP_MSG_TYP_DHCPRELEASE  7

/* Lease value that indicates an infinite lease. */
#define DHCP_LEASE_INFINITE       0xffffffff

#define DHCP_FLAG_BCAST     0x80

/**************************************************************************
 * Types
 **************************************************************************/


/** DHCP message header.
 */
typedef struct
{
    uint8_t   op;
    uint8_t   htype;
    uint8_t   hlen;
    uint8_t   hops;
    uint32_t  xid;
    uint16_t  seconds;
    uint16_t  flags;
    ipaddr_t  ciaddr;
    ipaddr_t  yiaddr;
    ipaddr_t  siaddr;
    ipaddr_t  giaddr;
    struct
    {
        macaddr_t mac;
        uint8_t   pad[10];
    }
    chaddr;
}
dhcpheader_t;

/**************************************************************************
 * Local Variables
 **************************************************************************/

static struct
{
    uint8_t     type;
    ipaddr_t    serverAddr;
    ipaddr_t    yiaddr;
    uint8_t     subnetBits;
    ipaddr_t    router;
    uint32_t    t1Seconds, t2Seconds;
}
dhcpMessageData;

static uint32_t      transactionId;

static const uint8_t PROGMEM magicCookie[] = { 99, 130, 83, 99 };

/**************************************************************************
 * Local Functions
 **************************************************************************/

#if defined(ON_PC)
static char *messageToString(uint8_t msg)
{
    switch(msg)
    {
        case DHCP_MSG_TYP_DHCPDISCOVER:
            return "DHCP_MSG_TYP_DHCPDISCOVER";
        case DHCP_MSG_TYP_DHCPOFFER:
            return "DHCP_MSG_TYP_DHCPOFFER";
        case DHCP_MSG_TYP_DHCPREQUEST:
            return "DHCP_MSG_TYP_DHCPREQUEST";
        case DHCP_MSG_TYP_DHCPDECLINE:
            return "DHCP_MSG_TYP_DHCPDECLINE";
        case DHCP_MSG_TYP_DHCPACK:
            return "DHCP_MSG_TYP_DHCPACK";
        case DHCP_MSG_TYP_DHCPNAK:
            return "DHCP_MSG_TYP_DHCPNAK";
        case DHCP_MSG_TYP_DHCPRELEASE:
            return "DHCP_MSG_TYP_DHCPRELEASE";
        default:
            return "????";
    }
}
#endif

static uint8_t countLeadingOnes(const ipaddr_t *v)
{
    uint8_t  c = 0;
    uint32_t b;

    b = ((uint32_t)v->b[0] << 24) |
        ((uint32_t)v->b[1] << 16) |
        ((uint32_t)v->b[2] <<  8) |
        ((uint32_t)v->b[3] <<  0);

    while((b & 0x80000000) != 0)
    {
        c++;
        b <<= 1;
    }

    return c;
}

/** Move the read pointer to the start of the options block.
 *
 * \param[in] ipHdrLen  The length of the IP header on the packet in bytes.
 */
static void seekOption(uint8_t ipHdrLen)
{
    enc28j60RxPktRewind();

    /* Skip in two portions to prevent overflowing uint8_t parameter */
    enc28j60RxPktSkip((sizeof(macaddr_t) * 2) + 2 + /* Eth header */
                      ipHdrLen +                    /* IP  header */
                      UDP_HDR_LEN_BYTES);           /* UDP header */
    enc28j60RxPktSkip(sizeof(dhcpheader_t) +        /* DHCP header */
                      64 + 128 +                    /*   sname + file */
                      sizeof(magicCookie));         /*   cookie */
}

/** Move the read pointer to the start of some option.

 * \retval TRUE  The option was found and the read pointer aligns to the
 *                length byte.
 * \retval FALSE The option was not found.
 */
static boolean_t findOption(const uint8_t optId, uint8_t *const len)
{
    struct { uint8_t opt, len; } data;

    do
    {
        /* Read the option Id and length */
        enc28j60RxPktRead(sizeof(data), &data);

        /* Compare byte with desired option */
        if(data.opt == optId)
        {
            /* Found a match */
            *len = data.len;
            return TRUE;
        }
        else if(data.opt == 255)
        {
            /* End option marker */
            return FALSE;
        }
        else
        {
            /* Skip the option */
            enc28j60RxPktSkip(data.len);
        }

    }
    while(!enc28j60RxEop());

    return FALSE;
}


/** Write some option to the packet buffer.
 * This writes some option value, length and data to the packet buffer for
 * transmission.  If \a data is passed as NULL, nothing is written, otherwise
 * \a len bytes from \a *data are written after an option header.
 *
 * \param[in] msg  The option ID to write.
 * \param[in] len  The number of bytes to write.
 * \param[in] data If non-NULL, the data to write.
 */
static void writeOption(const uint8_t msg, const uint8_t len, const void *data)
{
    if(data)
    {
        const uint8_t opt[] = { msg, len };

        enc28j60TxPktAppend(sizeof(opt), opt);
        enc28j60TxPktAppend(len, data);
    }
}

static boolean_t startTimer(uint8_t *const lastTimeoutSec)
{
    /* Clear the timer event */
    M_EventClr(EV_TIMER_GEN);

    /* Check if the last timeout was for the maximum duration */
    if(*lastTimeoutSec < 31)
    {
        uint8_t r = rand();
        int8_t  jitter;

        /* Determine the random offset between -1 and 1 */
        if(r & 0x2)
        {
            jitter = -(r & 0x1);
        }
        else
        {
            jitter = (r & 0x1);
        }

        /* Double timeout */
        *lastTimeoutSec *= 2;

        /* Start the timer with the duration */
        TimerHsStart(TIMER_GEN, (*lastTimeoutSec + jitter) * 10);
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}


/** Send some DHCP message.
 *
 * \param[in] msgType      The DHCP message type.
 * \param[in] sourceIp     The IP address from which to send the request.
 * \param[in] destIp       The IP address of the server to the request should be
 *                          sent.
 * \param[in] reqIpAddrOpt If non-NULL, add IP address request option.
 * \param[in] serverIdOpt  If non-NULL, add server Id option.
 * \param[in] ciAddr       Set the ciaddr field to this value.
 * \param[in] bcastReply   If TRUE, request broadcast reply.
 */
static boolean_t sendDhcp(const uint8_t   msgType,
                          const ipaddr_t *sourceIp,
                          const ipaddr_t *destIp,
                          const ipaddr_t *reqIpAddrOpt,
                          const ipaddr_t *serverIdOpt,
                          const ipaddr_t *ciaddr,
                          boolean_t       bcastReply)
{
    const uint8_t options[]  = { BOOTP_OPT_DHCP_MSG_TYP, 1 /* , x*/ };
    const uint8_t reqParam[] = { BOOTP_OPT_DHCP_PARAM_REQ_LIST, 4,
                                 BOOTP_OPT_VEND_EXT_SUBNET_MASK,
                                 BOOTP_OPT_VEND_EXT_ROUTER_OPTION,
                                 BOOTP_OPT_DHCP_RENEWAL_TIME_VAL,      /* Can be calculated from lease time     */
                                 BOOTP_OPT_DHCP_REBINDING_TIME_VAL,    /*  but may suffer rounding, so request. */
                                 BOOTP_OPT_END_MARKER };
    uint16_t      length  = 243 + sizeof(reqParam);
    boolean_t     success = FALSE;
    dhcpheader_t  hdr;

    printd("DHCP: Send %s\n", messageToString(msgType));

    /* Compute the length */
    if(serverIdOpt != NULL)
    {
        length += sizeof(ipaddr_t) + 2;
    }

    if(reqIpAddrOpt != NULL)
    {
        length += sizeof(ipaddr_t) + 2;
    }

    /* Start the DHCP packet */
    if(UdpWriteHeader(sourceIp, destIp, UDP_PORT_BOOTPC, UDP_PORT_BOOTPS, length))
    {
        /* Setup the DHCP packet */
        memset(&hdr, 0, sizeof(dhcpheader_t));
        hdr.op    = DHCP_OP_BOOTREQUEST;
        hdr.htype = 0x01;  /* Ethernet */
        hdr.hlen  = sizeof(macaddr_t);
        hdr.xid   = transactionId;
        if(bcastReply) hdr.flags = DHCP_FLAG_BCAST;
        memcpy(&hdr.ciaddr, ciaddr, sizeof(ipaddr_t));
        enc28j60GetMac(&hdr.chaddr.mac);

        /* Add the pre-filled DHCP header */
        enc28j60TxPktAppend(sizeof(dhcpheader_t), &hdr);
        enc28j60TxPktFill(64 + 128, 0);  /* Clear sname + file */

        /* Now the 'magic cookie' and message type */
        enc28j60TxPktAppendPrgMem(sizeof(magicCookie), magicCookie);
        enc28j60TxPktAppend(sizeof(options), options);
        enc28j60TxPktFill(1, msgType);

        /* Add options if needed */
        writeOption(BOOTP_OPT_DHCP_SERVER_ID,
                    sizeof(ipaddr_t), serverIdOpt);
        writeOption(BOOTP_OPT_DHCP_REQUESTED_IP_ADDR,
                    sizeof(ipaddr_t), reqIpAddrOpt);

        /* Ask for some handy options and end marker */
        enc28j60TxPktAppend(sizeof(reqParam), reqParam);

        enc28j60TxPktSend();

        success = TRUE;
    }

    return success;
}


/** Run the DHCP discovery phase.
 * This sends a DHCP discover message and collates and results into the DHCP
 * offer table.
 *
 * \retval TRUE at least one offer has been found and exists in offerTable.
 * \retval FALSE if no offers were found within the required time, or the
 *                physical link has gone down during discovery.
 */
static boolean_t discover(void)
{
    uint8_t timeout = 4;

    printd("DHCP: Start discover\n");

    /* Clear any received message */
    dhcpMessageData.type = 0;

    /* Retry until the delay limit is hit */
    while(startTimer(&timeout))
    {
        /* Transmit the request */
        sendDhcp(DHCP_MSG_TYP_DHCPDISCOVER, &ipZero, &ipBCast, NULL, NULL, &ipZero, TRUE);

        /* Wait until the timer expires or an offer is received */
        while(!M_EventIsSet(EV_TIMER_GEN))
        {
            /* Wait for a packet */
            if(!EthWaitPacket(NULL))
            {
                /* Link dropped */
                return FALSE;
            }

            /* Check if an offer has been received */
            if(dhcpMessageData.type == DHCP_MSG_TYP_DHCPOFFER)
            {
                return TRUE;
            }
        }
    }

    return FALSE;
}


/** Send a DHCPREQUEST message and wait for a response.
 *
 */
static boolean_t request(const ipaddr_t *sourceIp,
                         const ipaddr_t *destIp,
                         const ipaddr_t *ciaddr,
                         const ipaddr_t *serverIdOpt,
                         const ipaddr_t *reqIpAddrOpt,
                         boolean_t       bcastReply)
{
    uint8_t timeout = 4;

    /* Clear the message type */
    dhcpMessageData.type = 0;

    /* Retry until the delay limit is hit */
    while(startTimer(&timeout))
    {
        /* Send the request */
        if(!sendDhcp(DHCP_MSG_TYP_DHCPREQUEST, sourceIp, destIp, reqIpAddrOpt, serverIdOpt, ciaddr, bcastReply))
        {
            /* Failed to send the request.
             *  This only occurs if not using unicast and ARP lookup fails.
             */
             return FALSE;
        }

        /* Wait until the timer expires or a confirm is received */
        while(!M_EventIsSet(EV_TIMER_GEN))
        {
            /* Wait for a packet */
            if(!EthWaitPacket(NULL))
            {
                /* Link dropped */
                return FALSE;
            }

            /* Check if a message was received */
            if(dhcpMessageData.type == DHCP_MSG_TYP_DHCPACK)
            {
                return TRUE;
            }
            else if(dhcpMessageData.type == DHCP_MSG_TYP_DHCPNAK)
            {
                return FALSE;
            }
        }
    }

    return FALSE;
}

void resetLeaseTimers(void)
{
    /* Check for a finite lease */
    if(dhcpMessageData.t1Seconds != DHCP_LEASE_INFINITE)
    {
        /* Start the lease timers */
        TimerLsStart(TIMER_DHCP_RENEW,  dhcpMessageData.t1Seconds);
        TimerLsStart(TIMER_DHCP_REBIND, dhcpMessageData.t2Seconds);

        /* Set t1 to the next value it should take */
        dhcpMessageData.t1Seconds = (dhcpMessageData.t2Seconds -
                                   dhcpMessageData.t1Seconds) / 2;
    }
}

/**************************************************************************
 * Global Functions
 **************************************************************************/

boolean_t Dhcp(void)
{
    /* Stop any previous timers */
    DhcpStop();

    /* Clear state, create random transaction ID */
    memset(&dhcpMessageData, 0, sizeof(dhcpMessageData));
    transactionId = rand() | 0x4D4D0000;

    /* Run discover and request phases */
    if(discover() &&
       request(&ipZero, &ipBCast, &ipZero, &dhcpMessageData.serverAddr, &dhcpMessageData.yiaddr, TRUE))
    {
        if(!AutoIpProbe(&dhcpMessageData.yiaddr))
        {
            /* Been allocated an address that is already in use.
             *  Should send a DECLINE message here and try again.
             */
#if 0
            sendDhcp(DHCP_MSG_TYP_DHCPDECLINE,
                     &ipZero,
                     &ipBCast
                     &dhcpMessageData.yiaddr,
                     &dhcpMessageData.yiaddr,
                     &ipZero,
                     FALSE);
#endif

            return FALSE;
        }

        /* Set the lease timers */
        resetLeaseTimers();

        /* Set the host address and subnet route */
        IpSetHostAddr(&dhcpMessageData.yiaddr, dhcpMessageData.subnetBits);
#if 0
        /* Force configuration of gateway */
        dhcpMessageData.router.b[0] = 192;
        dhcpMessageData.router.b[1] = 168;
        dhcpMessageData.router.b[2] = 1;
        dhcpMessageData.router.b[3] = 1;
#endif
        /* Now add the default gateway if one is known */
        boolean_t haveGateway = memcmp(&ipZero, &dhcpMessageData.router.b[0], sizeof(ipaddr_t)) != 0;
        if(haveGateway)
        {
            /* Mask of 0 bits means everything will match ipZero */
            IpSetRoute(&dhcpMessageData.router, &ipZero, 0);
        }
        else
        {
            /* Mask of 32 bits means nothing will match ipZero */
            IpSetRoute(&dhcpMessageData.router, &ipZero, 32);
        }

        /* Now announce our IP address via ARP */
        AutoIpAnnounce(&dhcpMessageData.yiaddr);

        /* Lookup MAC for the gateway in advance */
        if(haveGateway)
        {
            ArpRequestMacAddress(&dhcpMessageData.router, FALSE);
        }

        return TRUE;
    }
    else
    {
        return FALSE;
    }
}


/** Stop any ongoing DHCP session.
 */
void DhcpStop(void)
{
    /* Stop timers */
    TimerStop(TIMER_DHCP_RENEW);
    TimerStop(TIMER_DHCP_REBIND);

    /* Clear the events incase they are pending */
    M_EventClr(EV_TIMER_DHCP_RENEW | EV_TIMER_DHCP_REBIND);
}


/** Renew the lease from the same server.
 */
void DhcpRenew(void)
{
    printd("DHCP: Renew\n");

    /* Check if the renew timer is sufficiently in the future */
    if(dhcpMessageData.t1Seconds > 16)
    {
        /* Restart the timer and set next interval */
        TimerLsStart(TIMER_DHCP_RENEW,  dhcpMessageData.t1Seconds);
        dhcpMessageData.t1Seconds /= 2;
    }

    /* Request the IP address already assigned, from the same server.
     *  From RFC 2131:
     *   "'server identifier' MUST NOT be filled in, 'requested IP address'
     *   option MUST NOT be filled in, 'ciaddr' MUST be filled in with
     *   client's IP address."
     */
    if(request(&ipHost, &dhcpMessageData.serverAddr, &ipHost, NULL, NULL, FALSE))
    {
        /* A new message was received */
        resetLeaseTimers();
    }
    /* else either retry when T1 expires again, or at T2 */
}


/** Try to rebind existing IP address from any server.
 */
boolean_t DhcpRebind(void)
{
    boolean_t success;

    printd("DHCP: Rebind\n");

    /* Request the IP address already assigned, from any server.
     *  From RFC2131:
     *   "'server identifier' MUST NOT be filled in, 'requested IP address'
     *   option MUST NOT be filled in, 'ciaddr' MUST be filled in with
     *   client's IP address. In this situation, the client is completely
     *   configured, and is trying to extend its lease. This message MUST
     *   be broadcast to the 0xffffffff IP broadcast address."
     */
    if(request(&ipHost, &ipBCast, &ipHost, NULL, NULL, FALSE))
    {
        /* A new message was received*/
        resetLeaseTimers();
        success = TRUE;
    }
    else
    {
        /* IP address lost */
        IpReset();

        /* Ensure timers are stopped */
        DhcpStop();

        success = FALSE;
    }

    return success;
}


/** Process some received packet.
 */
void DhcpProcessPacket(const ipparam_t  *ipp,
                       const udpparam_t *udpp)
{
    dhcpheader_t hdr;
    uint8_t      optLen;

    /* Verify source port */
    if(udpp->sport != UDP_PORT_BOOTPS)
    {
        printd("DHCP: Wrong port: %d\n", udpp->sport);
        return;
    }

    /* Read the header */
    enc28j60RxPktRead(sizeof(dhcpheader_t), &hdr);
    enc28j60RxPktSkip(64 + 128);  /* Skip sname + file */

    /* Check the magic cookie and find operation option */
    if(!enc28j60RxPktCmpPrgMem(sizeof(magicCookie), magicCookie) ||
       !findOption(BOOTP_OPT_DHCP_MSG_TYP, &optLen))
    {
        printd("DHCP: Bad cookie or no msgtyp option\n");
        return;
    }

    /* Check if this is some reply for our transaction */
    if(hdr.op == DHCP_OP_BOOTREPLY && hdr.xid == transactionId)
    {
        uint8_t dhcpMsgType;

        /* Read the message type */
        enc28j60RxPktRead(1, &dhcpMsgType);

        printd("DHCP: Received %s\n", messageToString(dhcpMsgType));

        /* Check on the message type */
        switch(dhcpMsgType)
        {
            case DHCP_MSG_TYP_DHCPOFFER:
            {
                ipaddr_t mask         = { { 0xff, 0xff, 0xff, 0xff } };
                uint32_t leaseSeconds = 0;

                const struct
                {
                    uint8_t  id;        /**< The option ID. */
                    uint8_t  len;       /**< Option length. */
                    void    *ptr;       /**< Storage pointer. */
                }
                options[] = {
                    { BOOTP_OPT_DHCP_SERVER_ID,          sizeof(ipaddr_t), &dhcpMessageData.serverAddr},
                    { BOOTP_OPT_DHCP_LEASE_TIME,         sizeof(uint32_t), &leaseSeconds },
                    { BOOTP_OPT_DHCP_RENEWAL_TIME_VAL,   sizeof(uint32_t), &dhcpMessageData.t1Seconds },
                    { BOOTP_OPT_DHCP_REBINDING_TIME_VAL, sizeof(uint32_t), &dhcpMessageData.t2Seconds },
                    { BOOTP_OPT_VEND_EXT_SUBNET_MASK,    sizeof(ipaddr_t), &mask},
                    { BOOTP_OPT_VEND_EXT_ROUTER_OPTION,  sizeof(ipaddr_t), &dhcpMessageData.router } };

                /* Set times to allow detection of unset */
                dhcpMessageData.t1Seconds = 0;

                /* Loop over each sought option */
                for(uint8_t t = 0; t < sizeof(options) / sizeof(options[0]); t++)
                {
                    /* Attempt to find the option */
                    seekOption(ipp->hLen);
                    if(findOption(options[t].id, &optLen))
                    {
                        /* Check if the option has enough bytes */
                        if(optLen >= options[t].len)
                        {
                            /* Store option data */
                            enc28j60RxPktRead(options[t].len, options[t].ptr);
                        }

                    }
                }

                /* Byte swap values if needed */
                dhcpMessageData.t1Seconds = ntohl(dhcpMessageData.t1Seconds);
                dhcpMessageData.t2Seconds = ntohl(dhcpMessageData.t2Seconds);

                /* Convert the local mask to the count of zeros */
                dhcpMessageData.subnetBits = countLeadingOnes(&mask);

                /* Check if default t1 and t2 values need computing */
                if(dhcpMessageData.t1Seconds == 0)
                {
                    /* No durations or infinite */
                    if(leaseSeconds == 0 || leaseSeconds == DHCP_LEASE_INFINITE)
                    {
                        dhcpMessageData.t1Seconds = DHCP_LEASE_INFINITE;
                    }
                    else
                    {
                        /* Decode the lease seconds */
                        leaseSeconds = ntohl(leaseSeconds) / 2;

                        /* T1 defaults to lease * 0.5 */
                        dhcpMessageData.t1Seconds = leaseSeconds;

                        /* T2 defaults to lease * 0.875 */
                        dhcpMessageData.t2Seconds = leaseSeconds;
                        for(uint8_t t = 0; t < 2; t++)
                        {
                            leaseSeconds /= 2;
                            dhcpMessageData.t2Seconds += leaseSeconds;
                        }
                    }
                }

                /* Fall through */
            }
            case DHCP_MSG_TYP_DHCPACK:

                /* Store the allocated IP address */
                memcpy(&dhcpMessageData.yiaddr, &hdr.yiaddr, sizeof(ipaddr_t));

                /* Fall through */

            case DHCP_MSG_TYP_DHCPNAK:

                /* Store the message type */
                dhcpMessageData.type = dhcpMsgType;
                break;

            default:
                printd("DHCP: Unknown message type: %d\n", dhcpMsgType);
                break;
        }

    }
}

/* END OF FILE */
