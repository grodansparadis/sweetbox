/***************************************************************************
 * light.c: Custom light protocol or ATmega88.
 * Copyright (C) 2007 Michael C McTernan,
 *    Michael.McTernan.2001@cs.bris.ac.uk
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

/**************************************************************************
 * Include Files
 **************************************************************************/

#if !defined(ON_PC)
#include <avr/eeprom.h>
#else
#define eeprom_read_byte(b) (*(b))
#define eeprom_read_block   memcpy
#endif
#include <string.h>
#include <stdint.h>
#include "enc28j60.h"
#include "eprom.h"
#include "light.h"
#include "seq.h"

/**************************************************************************
 * Local Data
 **************************************************************************/

static ipaddr_t lightSrcHost;
static uint16_t lightSrcPort;
static uint8_t  lightCmdBuffer[128];
static uint8_t  lightCmdBufferLen;

/**************************************************************************
 * Global Data
 **************************************************************************/

/**************************************************************************
 * Global Functions
 **************************************************************************/

boolean_t LightSendAck(uint8_t code)
{
    if(UdpWriteHeader(&ipHost, &lightSrcHost, UDP_PORT_LIGHTCONTROL, lightSrcPort, 1))
    {
        enc28j60TxPktFill(1, code);
        enc28j60TxPktSend();
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}


void LightProcessPacket(const ipparam_t  *ipp,
                        const udpparam_t *udpp)
{
    /* Stop any ongoing sequence before changing state */
    SeqStop();

    /* Save the source host and port */
    lightSrcHost = ipp->sAddr;
    lightSrcPort = udpp->sport;

    /* Read the command length from the packet */
    enc28j60RxPktRead(1, &lightCmdBufferLen);

    /* Check length */
    if(lightCmdBufferLen < sizeof(lightCmdBuffer) &&
       lightCmdBufferLen <= udpp->payloadLen)
    {
        /* Read remaining buffer and start sequencer */
        enc28j60RxPktRead(lightCmdBufferLen, lightCmdBuffer);
        SeqStart(lightCmdBuffer, lightCmdBufferLen);
    }
}


void LightStartEpromSeq(EpromLightSequence seq)
{
    const uint8_t len = eeprom_read_byte(&epromImage.predefNum);

    /* Stop any ongoing sequence before changing state */
    SeqStop();

    /* Check that the length is programmed and sequence is in range */
    if(len != 0xff && seq < len)
    {
        uint16_t i = eeprom_read_byte(&epromImage.predefOffset[seq]) * 2;
        uint16_t j = eeprom_read_byte(&epromImage.predefOffset[seq + 1]) * 2;

        lightCmdBufferLen = j - i;

        eeprom_read_block(&lightCmdBuffer[0],
                          &epromImage.predef[i],
                          lightCmdBufferLen);

        SeqStart(lightCmdBuffer, lightCmdBufferLen);
    }
}


void LightStartRamSeq(const uint8_t *buf, uint8_t len)
{
    /* Stop any ongoing sequence before changing state */
    SeqStop();

    lightCmdBufferLen = len;

    /* Truncate length if needed */
    if(lightCmdBufferLen > sizeof(lightCmdBuffer))
    {
        lightCmdBufferLen = sizeof(lightCmdBuffer);
    }

    /* Copy into command buffer and start */
    memcpy(lightCmdBuffer, buf, lightCmdBufferLen);
    SeqStart(lightCmdBuffer, lightCmdBufferLen);

}

/* END OF FILE */
