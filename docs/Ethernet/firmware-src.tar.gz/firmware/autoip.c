/***************************************************************************
 * autoip.c: RFC3927 implementation for ATmega88.
 * Copyright (C) 2007 Michael C McTernan,
 *    Michael.McTernan.2001@cs.bris.ac.uk
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

/**************************************************************************
 * Includes
 **************************************************************************/

#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "enc28j60.h"
#include "autoip.h"
#include "event.h"
#include "timer.h"
#include "eth.h"
#include "arp.h"


/**************************************************************************
 * Manifest Constants
 **************************************************************************/

#define PROBE_WAIT           1
#define PROBE_NUM            3
#define PROBE_MIN            1
#define PROBE_MAX            2
#define ANNOUNCE_WAIT        2
#define ANNOUNCE_NUM         2
#define ANNOUNCE_INTERVAL    2
#define MAX_CONFLICTS       10
#define RATE_LIMIT_INTERVAL 60
#define DEFEND_INTERVAL     10

/**************************************************************************
 * Local Functions
 **************************************************************************/

/** Pick a psuedo-random IP address in the 169.254 auto IP range.
 * This picks some IP address and returns it in \a ip.  If \a initial
 * is TRUE, this will return some IP address that may have been previously
 * used by this host.  If \a initial is FALSE, \a rand() is used to return
 * a more pseud-random address.
 *
 * \param[in]     initial If TRUE, return the starting IP address.
 * \param[in,out] ip      Pointer to IP address array to be filled.
 */
static void pickIpAddress(boolean_t initial, ipaddr_t *const ip)
{
    macaddr_t m;
    uint8_t   t, a, b;

    /* Decide how to seed the IP address */
    if(initial)
    {
        a = b = 0;
    }
    else
    {
        a = b = rand();
    }

    /* Get our MAC address */
    enc28j60GetMac(&m);

    /* Produce two hashes from the MAC address */
    for(t = 0; t < sizeof(m); t++)
    {
        a += m.b[t];
        b ^= m.b[t] + a;
    }

    /* Pick an IP address in the auto IP range */
    ip->b[0] = 169;
    ip->b[1] = 254;
    ip->b[2] = (a & ~0x2) + 1; /* 1 - 254 */
    ip->b[3] = b;              /* 0 - 255 */
}


/** Wait for some duration while monitoring ARP packets for possible conflicts.
 *
 * \param[in] wait  The duration to wait.
 * \retval FALSE if any conflicts were found.
 */
static boolean_t autoIpWaitTimer(uint8_t hSec)
{
    /* Clear the timer event */
    M_EventClr(EV_TIMER_GEN);

    /* Start the timer */
    TimerHsStart(TIMER_GEN, hSec);

    /* Wait until the timer expires */
    while(!M_EventIsSet(EV_TIMER_GEN))
    {
        boolean_t arpConflict = FALSE;

        /* Wait for a packet and check if a conflict is found */
        if(!EthWaitPacket(&arpConflict) || arpConflict)
        {
            /* Conflict detected or link failed */
            return FALSE;
        }
    }

    /* Timer expired */
    return TRUE;
}


/**************************************************************************
 * Global Functions
 **************************************************************************/


boolean_t AutoIp(boolean_t selectNewAddress)
{
    uint8_t   conflictsRemaining = MAX_CONFLICTS;
    boolean_t first;
    ipaddr_t  ip;

    /* Clear any existing IP address */
    ArpClearIpAddress();

    /* Pick a new IP address if a conflict occured */
    first = !selectNewAddress;

    /* Loop while there is a link */
    while(conflictsRemaining > 0 && enc28j60IsLinkUp())
    {
        pickIpAddress(first, &ip);

        if(AutoIpProbe(&ip) && AutoIpAnnounce(&ip))
        {
            /* Probe and announce passed, success */
            IpSetHostAddr(&ip, 16);

            return TRUE;
        }

        first = FALSE;
        conflictsRemaining--;
    }

    return FALSE;
}


/** Perform an ARP probe.
 *
 * \param[in] ip  The IP address to probe.
 * \retval TRUE if no other hosts responded to the probe.
 * \retval FALSE if other hosts responded to the probe.
 */
boolean_t AutoIpProbe(const ipaddr_t *ip)
{
    uint8_t probesRemaining = PROBE_NUM + 1;
    uint8_t wait;

    /* Set the IP address for conflict checking */
    ArpSetIpAddress(ip);

    do
    {
        /* Determine probe timeout */
        wait = (rand() & 0x7) + (rand() & 0x3);

        /* If not the first iteration, delay at least 1 second */
        if(probesRemaining != PROBE_NUM + 1)
        {
            wait += (PROBE_MIN * 10);
        }

        if(!autoIpWaitTimer(wait))
        {
            return FALSE;
        }

        /* Count probe attempts */
        probesRemaining--;
        if(probesRemaining > 0)
        {
            ArpRequestMacAddress(ip, TRUE);
        }
    }
    while(probesRemaining > 0);

    /* Wait for any more responses */
    return autoIpWaitTimer(ANNOUNCE_WAIT*10);
}


boolean_t AutoIpAnnounce(__attribute__((unused)) const ipaddr_t *ip)
{
    /* First announcement */
    ArpAnnounce();

    /* Delay and ignore conflicts */
    autoIpWaitTimer(ANNOUNCE_INTERVAL*10);

    /* Second announcement */
    ArpAnnounce();

    return TRUE;
}


/* END OF FILE */
