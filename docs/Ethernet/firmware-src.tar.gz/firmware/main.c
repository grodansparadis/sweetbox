/***************************************************************************
 * main.c: Ambient Device main loop for ATmega.
 * Copyright (C) 2007 Michael C McTernan,
 *    Michael.McTernan.2001@cs.bris.ac.uk
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

/**************************************************************************
 * Includes
 **************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#if !defined(ON_PC)
#include <avr/io.h>
#include <avr/interrupt.h>
#else
#include <unistd.h>
#include <ctype.h>
#endif
#include "stackmon.h"
#include "enc28j60.h"
#include "autoip.h"
#include "timer.h"
#include "event.h"
#include "light.h"
#include "dhcp.h"
#include "seq.h"
#include "arp.h"
#include "eth.h"
#include "tcp.h"
#include "udp.h"
#include "ip.h"

/**************************************************************************
 * Manifest Constants
 **************************************************************************/

/**************************************************************************
 * Global Variables
 **************************************************************************/

/**************************************************************************
 * Local Variables
 **************************************************************************/

/**************************************************************************
 * Local Functions
 **************************************************************************/

/** Initialise the random number generator.
 */
static void randInit(void)
{
    macaddr_t m;
    uint8_t   s = 0, t;

    /* Get the MAC address */
    enc28j60GetMac(&m);

    /* Sum the MAC address */
    for(t = 0; t < sizeof(macaddr_t); t++)
    {
        s += m.b[t];
    }

    /* Could also read some count or similar stored in the EEPROM? */

    /* Seed the random number generator */
    srand(s);
}


static void checkLinkStatus(void *up)
{
    static boolean_t linkStateLast = FALSE;
    boolean_t        linkStateNow  = enc28j60IsLinkUp();
    boolean_t *const goneUp = (boolean_t *)up;

    /* Check if link status has changed */
    if(linkStateLast != linkStateNow)
    {
        /* Link gone up */
        if(linkStateNow)
        {
            LightStartEpromSeq(EPROM_LIGHT_ETH_UP);
            if(goneUp != NULL) *goneUp = TRUE;
        }
        /* Link gone down */
        else
        {
            /* Run light sequence.
             *  This also prevents the sequencer attempting to call TCP.
             */
            LightStartEpromSeq(EPROM_LIGHT_ETH_DOWN);

            /* Stop DHCP and clear IP address */
            DhcpStop();
            IpReset();
        }

        /* Store new status */
        linkStateLast = linkStateNow;
    }
}


/** Attempt to get a new IP address for the host.
 * This calls DHCP and possibly AutoIP to get a suitable IP address for the
 * host.
 *
 * \param[in] autoIpNewAddress  If TRUE, AutoIP should assign a new IP address
 *                               before starting it's probe sequence.
 * \retval TRUE   A new IP address has been configured.
 * \retval FALSE  A new IP address could not be configured.
 */
static boolean_t getIp(boolean_t autoIpNewAddress)
{
    /* Try DHCP */
    LightStartEpromSeq(EPROM_LIGHT_DHCP_START);
    if(Dhcp())
    {
        LightStartEpromSeq(EPROM_LIGHT_DHCP_CONFIGURED);
        return TRUE;
    }

    /* Try AutoIp */
    LightStartEpromSeq(EPROM_LIGHT_AUTOIP_START);
    if(AutoIp(autoIpNewAddress))
    {
        LightStartEpromSeq(EPROM_LIGHT_AUTOIP_CONFIGURED);
        return TRUE;
    }

    return FALSE;
}


/**************************************************************************
 * Global Functions
 **************************************************************************/

/** Delay some count of milliseconds.
 */
void delay_ms(uint16_t ms)
{
#if !defined(ON_PC)
    while(ms--)
    {
        _delay_ms(0.96);
    }
#else
    usleep(ms * 1000);
#endif
}


int main(void)
{
    boolean_t runStartup = FALSE;

#if !defined(ON_PC)
    /* Enable clock rate changes for the next 4 cycles */
    CLKPR = (1<<CLKPCE);

    /* Set the pre-scaler to 8 MHz */
    CLKPR = 0;
#endif

    /* Initialise the timers.
     *  This will also disable the watchdog and needs to be done with
     *  interrupts disabled.
     */
    TimerInit();
#if !defined(ON_PC)
    /* Turn off unused hw */
    PRR |= (1<<PRTWI) | (1<<PRTIM2) | (1<<PRTIM1) |
           (1<<PRTIM0) | (1<<PRUSART0) | (1<<PRADC) | (1<<PRSPI);

    /* Set B1 (led) to output and ensure off by setting high */
    PORTB |= (1<<PB1);
    DDRB |= (1<<DDB1);
#endif
    /* Initialise ethernet device */
    enc28j60Init();

    /* Enable interrupts */
    sei();

    /* Initialise random number generator */
    randInit();

    /* Init the colour sequencer */
    SeqInit();

    /* Run test pattern and wait for it to complete */
    LightStartEpromSeq(EPROM_LIGHT_POST);
    SeqWait();

    /* Set the Eth event so that link state is checked */
    M_EventSet(EV_ETH);

    while(1)
    {
        /* Check if an ethernet event occured */
        if(M_EventIsSet(EV_ETH))
        {
            boolean_t goneUp = FALSE, arpConflict = FALSE;

            /* Clear the event */
            M_EventClr(EV_ETH);

            enc28j60HandleEvents(checkLinkStatus, &goneUp,
                                 EthProcessPacket, &arpConflict);

            /* Check if the link just went up */
            if(goneUp || arpConflict)
            {
                /* Wait 1 second if link just started */
                if(goneUp) delay_ms(1000);

                /* Attempt to get an IP address */
                runStartup = getIp(arpConflict);
            }
        }

        if(M_EventIsSet(EV_TIMER_DHCP_RENEW))
        {
            M_EventClr(EV_TIMER_DHCP_RENEW);
            DhcpRenew();
        }

        if(M_EventIsSet(EV_TIMER_DHCP_REBIND))
        {
            M_EventClr(EV_TIMER_DHCP_REBIND);

            /* Try to rebind the IP address */
            if(!DhcpRebind())
            {
                /* Failed.  Try to get a new IP address. */
                getIp(TRUE);
            }
        }

        if(M_EventIsSet(EV_TIMER_TCP_RETRANSMIT))
        {
            TcpRetransmitTick();
        }

        if(M_EventIsSet(EV_SEQ_COMPLETED))
        {
            M_EventClr(EV_SEQ_COMPLETED);

            if(runStartup)
            {
                runStartup = FALSE;
                LightStartEpromSeq(EPROM_LIGHT_START);

                /* Allow the EPROM to be reprogrammed for a while */
                EpromAllowReprogramming(TRUE);
            }
        }


        /* Some modules may use the general timer, but to save a bit of space
         *  either don't stop the timer or clear the event.  This event is
         *  just cleared here since there is not other general timing here.
         */
        M_EventClr(EV_TIMER_GEN);

        /* Try to sleep */
        SleepUntilIsr();
    }
}


/** Determine a suitable sleep mode and sleep.
 * This check the Power Reduction Register to see whether any timers
 * are active, and selects idle or power-down modes as required.  Having
 * set the Sleep Enable bit, it finally checks the event register to
 * determine if the sleep instruction should be executed.  ISRs that set
 * an event and also clear the Sleep Enable bit therefore can prevent
 * the execution of the sleep instruction.
 */
#if !defined(ON_PC)
void SleepUntilIsr(void)
{
#if !defined(DISABLE_STACK_MONITOR)
    static uint16_t maxFreeStack = 0xffff;
    uint16_t        freeStack;

    freeStack = StackCount();
    if(freeStack < maxFreeStack)
    {
        UdpDebug(5, enc28j60GetRevId(),
                 freeStack >> 8, freeStack,
                 maxFreeStack >> 8, maxFreeStack);

        maxFreeStack = freeStack;
    }
#endif

    /* Check if any timers are running */
    if((~PRR & ((1<<PRTIM0) | (1<<PRTIM1) | (1<<PRTIM2))) == 0)
    {
        /* Idle */
        SMCR = (1<<SE);
    }
    else
    {
        /* Power down */
        SMCR = (1<<SM1);
    }

    /* Having set SE, check that EVENT_REG is still zero */
    if(EVENT_REG == 0)
    {
        /* Disable SPI; the enc28j60 driver will reconfigure when needed */
        PRR |= (1<<PRSPI);

        PORTB |= (1<<PB1); /* Led off */

        /* An interrupt may occur here.  In such a case, sleep should be
         *  prevented by ensuring that the ISR clears the SE bit.
         */
        __asm volatile ("sleep" ::);

        PORTB &= ~(1<<PB1); /* Led on */
    }

    /* Disable sleep */
    SMCR &= ~(1<<SE);
}
#endif

/* END OF FILE */
