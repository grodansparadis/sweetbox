/***************************************************************************
 * timer.c: Timer unit for ATmega88.
 * Copyright (C) 2007 Michael C McTernan,
 *    Michael.McTernan.2001@cs.bris.ac.uk
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

#ifndef TIMER_H
#define TIMER_H

/**************************************************************************
 * Macros
 **************************************************************************/

#if !defined(ON_PC)
#define TimerInit()                                                         \
{   /* Ensure watchdog reset flag is clear as this overrides the WDE bit */ \
    MCUSR &= ~(1<<WDRF);                                                    \
    /* Enable changes in the next 4 cycles */                               \
    WDTCSR |= (1<<WDCE) | (1<<WDE);                                         \
    /* Disable the watchdog */                                              \
    WDTCSR = 0x00;                                                          \
}
#endif


/**************************************************************************
 * Types
 **************************************************************************/

typedef enum
{
    /* Counting timers */
    TIMER_GEN = 0,                   /**< General timer. */

    TIMER_DHCP_RENEW,                /**< DHCP lease renewal timer. */
    TIMER_DHCP_REBIND,               /**< DHCP lease rebind timer. */

    TIMER_SEQ_SUSPEND,               /**< Sequence long delay. */

    TIMER_TCP_RETRANSMIT,            /**< TCP retransmit timer. */

    TIMER_EPROM_REPROG,              /**< EPROM reprogramming timeout. */

    NUM_TICK_TIMERS,

    /* Non-counting timers */
    TIMER_SEQ                        /**< Light sequencer timer. */
}
timerid_t;

/**************************************************************************
 * Manifest constants
 **************************************************************************/

/**************************************************************************
 * Prototypes
 **************************************************************************/

#if defined(ON_PC)
void TimerInit(void);
#endif
void TimerLsStart(timerid_t timer, uint32_t secs);
void TimerHsStart(timerid_t timer, uint8_t  hSecs);
void TimerStop(timerid_t timer);

#endif

/* END OF FILE */
