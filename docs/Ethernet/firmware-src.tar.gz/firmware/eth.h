/***************************************************************************
 * eth.h: Ethernet layer for ATmega88.
 * Copyright (C) 2007 Michael C McTernan,
 *    Michael.McTernan.2001@cs.bris.ac.uk
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

#ifndef ETH_H
#define ETH_H

/**************************************************************************
 * Includes
 **************************************************************************/

#include <stdint.h>

/**************************************************************************
 * Types
 **************************************************************************/

/** Type for an Ethernet MAC address.
 */
typedef struct
{
    uint8_t b[6];
}
macaddr_t;

/**************************************************************************
 * Prototypes
 **************************************************************************/

void      EthProcessPacket(void *arpConflict);
void      EthWriteHeader(const macaddr_t *dMac);
boolean_t EthWaitPacket(boolean_t *arpConflict);

#endif

/* END OF FILE */
