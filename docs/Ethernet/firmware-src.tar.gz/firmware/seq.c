/***************************************************************************
 * seq.c: PWM Sequencer for ATmega88.
 * Copyright (C) 2007 Michael C McTernan,
 *    Michael.McTernan.2001@cs.bris.ac.uk
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

/**************************************************************************
 * Includes
 **************************************************************************/

#if !defined(ON_PC)
#include <avr/interrupt.h>
#else
#include <stdio.h>
#endif
#include <stdint.h>
#include <assert.h>
#include <stdlib.h>
#include <ctype.h>
#include "enc28j60.h"
#include "light.h"
#include "timer.h"
#include "event.h"
#include "main.h"
#include "seq.h"
#include "tcp.h"
#include "pwm.h"
#include "udp.h"
#include "ip.h"

/**************************************************************************
 * Manifest Constants
 **************************************************************************/

#define NUM_SEQ_REGISTERS 4

/** Timeout after which a HTTP fetch is aborted.
 */
#define HTTP_TIMEOUT_MS   60000

/**************************************************************************
 * Macros
 **************************************************************************/

#if defined(ON_PC)
#define sei()
#define cli()
#define TimerStart(a, b)
#define TimerStop(a)
#endif

/**************************************************************************
 * Types
 **************************************************************************/

typedef struct SeqInterpDataTag
{
    /** Ramp direction, 1 or -1 for up or down. */
    int8_t  yStep;

    /** Total change in Y, for Bresenham's. */
    uint8_t deltaY;

    /** Count of error for Bresenham's. */
    int16_t error;

    /** Total change in X, for Bresenham's. */
    int16_t deltaX;
}
SeqInterpData;

typedef enum SeqStateTag
{
    SEQ_STATE_START,
    SEQ_STATE_STOPPED,
    SEQ_STATE_RUNNING,
    SEQ_STATE_SUSPENDED,
    SEQ_STATE_HTTP_FETCHING,
    SEQ_STATE_HOLDING,
    SEQ_STATE_ACK,
}
SeqState;

typedef enum SeqFetchTxStateTag
{
    SEQ_TCP_FETCH_STATE_TX_GET,
    SEQ_TCP_FETCH_STATE_TX_PAGE,
    SEQ_TCP_FETCH_STATE_TX_PROT,
    SEQ_TCP_FETCH_STATE_TX_HOST,
    SEQ_TCP_FETCH_STATE_TX_PROT_TAIL,
    SEQ_TCP_FETCH_STATE_TX_COMPLETE,
}
SeqFetchTxState;


typedef enum SeqFetchRxStateTag
{
    SEQ_TCP_FETCH_STATE_RX_START,

    SEQ_TCP_FETCH_STATE_RX_START_H = SEQ_TCP_FETCH_STATE_RX_START,
    SEQ_TCP_FETCH_STATE_RX_START_T0,
    SEQ_TCP_FETCH_STATE_RX_START_T1,
    SEQ_TCP_FETCH_STATE_RX_START_P,
    SEQ_TCP_FETCH_STATE_RX_START_SLASH,
    SEQ_TCP_FETCH_STATE_RX_START_NUM0,
    SEQ_TCP_FETCH_STATE_RX_START_DOT,
    SEQ_TCP_FETCH_STATE_RX_START_NUM1,
    SEQ_TCP_FETCH_STATE_RX_START_SPACE,
    SEQ_TCP_FETCH_STATE_RX_START_TWO,
    SEQ_TCP_FETCH_STATE_RX_START_R0,
    SEQ_TCP_FETCH_STATE_RX_START_N0,
    SEQ_TCP_FETCH_STATE_RX_START_R1,
    SEQ_TCP_FETCH_STATE_RX_START_N1,
    SEQ_TCP_FETCH_STATE_RX_STORE,
    SEQ_TCP_FETCH_STATE_RX_DISCARD
}
SeqFetchRxState;

typedef struct SeqDataTag
{
    /** Pointer to list of colour commands */
    const SeqCommand *cmdList;

    /** Count of commands */
    uint8_t           cmdCount;

    /** The current command being ran */
    uint8_t           cmdCur;

    /** Current state */
    SeqState          state;

    /** State of any ongoing TCP request. */
    SeqFetchTxState   fetchTxState;
    SeqFetchRxState   fetchRxState;
    uint8_t           tcb;

    /** State for each of the colours */
    SeqInterpData     interpData[3];

    /** Counter for change, hold and HTTP fetch.
     * Tick counter, operates at tick rate of 4ms.
     */
    uint16_t          count;

    /** Registers for the control language. */
    uint8_t           regFile[NUM_SEQ_REGISTERS];
}
SeqData;

/** Sequencer command processing function.
 */
typedef SeqState (*ProcSeqFunction)(SeqCommand cmdByte, const SeqCommand *cmd);

/**************************************************************************
 * Local Variables
 **************************************************************************/

/** State used for the sequencer.
 */
static SeqData gState;

static uint8_t tcpFetchBuffer[128];
static uint8_t tcpFetchBufferLen;

/**************************************************************************
 * Function Prototypes
 **************************************************************************/

static void     tcpCallback(uint8_t tcb, tcpcallbackcause_t cause, uint16_t c);

/**************************************************************************
 * Local Functions
 **************************************************************************/

static void interpCompute(uint16_t             duration,
                          uint8_t              y0,
                          uint8_t              y1,
                          SeqInterpData *const state)

{
    assert(duration != 0);

    /* Setup variables for Bresenham's */
    if(y0 < y1)
    {
        state->yStep  = 1;
        state->deltaY = y1 - y0;
    }
    else
    {
        state->yStep  = -1;
        state->deltaY = y0 - y1;
    }

    state->error  = 0;
    state->deltaX = duration;
}


static uint8_t interpStep(SeqInterpData *const state,
                          uint8_t              y)
{
    const int16_t deltaX = state->deltaX;
    const int8_t  yStep  = state->yStep;
    int16_t       error  = state->error;

    assert(deltaX != 0);

    /* Bresenham's */
    error += state->deltaY;

    /* Here we loop to reduce the error for gradients of > 45
     * degrees.  A classical implementation would swap x and y to
     * plot in the other direction in such a case, but since x is
     * time, this cannot be done.
     */
    while((error * 2) >= deltaX)
    {
        y += yStep;
        error -= deltaX;
    }

    /* Store the error */
    state->error = error;

    return y;
}


/** Skip the read web command.
 * Increments the \a cmdCur pointer past the current read web command.
 */
static void skipReadWebCmd(void)
{
    /* Check the current command is a web read */
    assert(gState.cmdList[gState.cmdCur] == 0xff &&
           gState.cmdList[gState.cmdCur + 1] == 0x00);

    gState.cmdCur += 6;                                  /* Header + IP address */
    gState.cmdCur += gState.cmdList[gState.cmdCur] + 1;  /* Host */
    gState.cmdCur += gState.cmdList[gState.cmdCur] + 1;  /* Page */
}


static SeqState startSeqCmdRgb(const uint16_t del, const SeqCommand *colours)
{
    /* Check the delay count */
    if(del != 0)
    {
        gState.count = del;

        interpCompute(del,
                      M_PwmReadR(),
                      colours[0],
                      &gState.interpData[0]);
        interpCompute(del,
                      M_PwmReadG(),
                      colours[1],
                      &gState.interpData[1]);
        interpCompute(del,
                      M_PwmReadB(),
                      colours[2],
                      &gState.interpData[2]);

        return SEQ_STATE_RUNNING;
    }
    else
    {
        PwmSet(colours);

        return SEQ_STATE_START;
    }
}


static SeqState procSeqCmdRgb(uint8_t cmdByte, const SeqCommand *cmd)
{
    gState.cmdCur += 4;

    return startSeqCmdRgb((uint16_t)cmdByte * 8, cmd);
}


static SeqState procSeqCmdDelayMs(SeqCommand cmdByte, __attribute__((unused)) const SeqCommand *cmd)
{
    /* Count is in multiples of 4ms */
    gState.count = (uint16_t)cmdByte * 8;

    gState.cmdCur++;

    return SEQ_STATE_HOLDING;
}

static SeqState procSeqCmdStartPreDef(SeqCommand cmdByte, __attribute__((unused)) const SeqCommand *cmd)
{
    LightStartEpromSeq((EpromLightSequence)cmdByte);

    return gState.state;
}


static SeqState procSeqCmdDelaySec(SeqCommand cmdByte, const SeqCommand *cmd)
{
    const uint16_t sec = (cmdByte << 8) | *cmd;

    /* Skip the command */
    gState.cmdCur += 2;

    /* Stop the high speed timer and start the low speed */
    TimerStop(TIMER_SEQ);
    TimerLsStart(TIMER_SEQ_SUSPEND, sec);

    return SEQ_STATE_SUSPENDED;
}


static SeqState procSeqCmdJumpAndStops(SeqCommand cmdByte, const SeqCommand *cmd)
{
    const int8_t jumpDistance = *cmd;
    boolean_t    jump = TRUE;

    /* Check if it is a conditional jump or stop */
    if(cmdByte & 0x04)
    {
        /* Compare register value with 0 */
        if(gState.regFile[cmdByte & 0x03] != 0)
        {
            /* Non-zero, don't jump */
            jump = FALSE;
        }
    }

    /* Determine whether to take the jump */
    if(jump)
    {
        if(jumpDistance != 0)
        {
            /* Implement the jump */
            gState.cmdCur += jumpDistance;

            return SEQ_STATE_START;
        }
        else
        {
            /* A jump of 0 is a stop */
            return SEQ_STATE_STOPPED;
        }
    }
    else
    {
        /* Skip and start the next command */
        gState.cmdCur += 2;

        return SEQ_STATE_START;
    }
}


static SeqState procSeqCmdRegSet(SeqCommand cmdByte, const SeqCommand *cmd)
{
    /* Set the register value */
    gState.regFile[cmdByte] = *cmd;

    /* Skip the command */
    gState.cmdCur += 2;

    return SEQ_STATE_START;
}


static SeqState procSeqCmdAckHost(__attribute__((unused)) SeqCommand cmdByte, const SeqCommand *cmd)
{
    if(LightSendAck(*cmd & 0x07) || gState.state == SEQ_STATE_ACK)
    {
        /* Sent, or retry failed.  Move on. */
        gState.cmdCur++;
        return SEQ_STATE_START;
    }
    else
    {
        /* Failed to send the ack, possibly because an ARP lookup
         *  is needed.  Wait a short delay and retry once.
         */
        gState.count = 16;
        return SEQ_STATE_ACK;
    }
}


static SeqState procSeqCmdRegArith( __attribute__((unused)) SeqCommand cmdByte, const SeqCommand *cmd)
{
    const uint8_t reg = *cmd >> 6;
    int8_t        val;

    /* Check the sign bit */
    if(*cmd & 0x20)
    {
        /* Negative, sign extend */
        val = *cmd | 0xc0;
    }
    else
    {
        /* Positive, remove register */
        val = *cmd & ~0xc0;
    }

    /* Alter the register value */
    gState.regFile[reg] += val;

    /* Skip command and start next */
    gState.cmdCur += 2;

    return SEQ_STATE_START;
}


static SeqState procSeqCmdExtReadWeb(const SeqCommand *cmd, const __attribute__((unused)) uint8_t param)
{
    const ipaddr_t *addr = (ipaddr_t *)cmd;

    /* Setup a TCP connection */
    gState.tcb = TcpCreateClientSocket(addr, 80, tcpCallback);
    if(gState.tcb != TCP_INVALID_TCB)
    {
        /* Move to fetching state until the fetch succeeds or fails
         *  via callback, or timeout.
         */
        gState.count = HTTP_TIMEOUT_MS / 4;

        return SEQ_STATE_HTTP_FETCHING;
    }
    else
    {
        /* Could not create the socket; skip the command and run next */
        skipReadWebCmd();

        return SEQ_STATE_START;
    }
}


static SeqState procSeqCmdExtLoadRandReg(const SeqCommand *cmd, const uint8_t param)
{
    const uint8_t min = cmd[0], max = cmd[1];

    /* Generate a random number between min and max.
     *  This is a poor way of generating the number, but doesn't require
     *  floating arithmetic.
     */
    gState.regFile[param] = (random() % (1 + max - min)) + min;

    gState.cmdCur += 4;

    return SEQ_STATE_START;
}


static SeqState procSeqCmdExtDelayMsReg(const __attribute__((unused)) SeqCommand *cmd, const uint8_t param)
{
    /* Count is in multiples of 4ms */
    gState.count = gState.regFile[param];

    gState.cmdCur += 2;

    return SEQ_STATE_HOLDING;
}


static SeqState procSeqCmdExtColourMsReg(const __attribute__((unused)) SeqCommand *cmd, const uint8_t param)
{
    gState.cmdCur += 5;

    return startSeqCmdRgb(gState.regFile[param], cmd);
}


static SeqState procSeqCmdExt(__attribute__((unused)) SeqCommand cmdByte, const SeqCommand *cmd)
{
    const uint8_t param  = *cmd >> 6;
    const uint8_t extCmd = *cmd & 0x3f;

    /* Skip the extended command byte */
    cmd++;

    /* Decode the extended instruction */
    switch(extCmd)
    {
        case SEQ_CMD_READ_WEB:
            return procSeqCmdExtReadWeb(cmd, param);

        case SEQ_CMD_LOAD_RAND_REG:
            return procSeqCmdExtLoadRandReg(cmd, param);

        case SEQ_CMD_DELAY_MS_REG:
            return procSeqCmdExtDelayMsReg(cmd, param);

        case SEQ_CMD_COLOUR_MS_REG:
            return procSeqCmdExtColourMsReg(cmd, param);
    }

    /* Unknown command */
    return SEQ_STATE_STOPPED;
}


static SeqState startNextState(void)
{
    const ProcSeqFunction process[] =
    {
        procSeqCmdRgb,
        procSeqCmdDelayMs,
        procSeqCmdStartPreDef,
        procSeqCmdDelaySec,
        procSeqCmdJumpAndStops,
        procSeqCmdRegSet,
        procSeqCmdAckHost,
        procSeqCmdRegArith,
        procSeqCmdExt
    };

    SeqState s = SEQ_STATE_STOPPED;
    uint8_t  c = 64;

    /* Loop upto 'c' times or until a command starts.
     *  This allows the processing functions to return SEQ_STATE_START
     *  if more instructions need decoding.  This is in preference to
     *  recursion.
     */
    do
    {
        c--;

        /* Ensure the command buffer is not exceeded and the loop is fininte */
        if(gState.cmdCur >= gState.cmdCount || c == 0)
        {
            s = SEQ_STATE_STOPPED;
        }
        else
        {
            const SeqCommand *cmd     = &gState.cmdList[gState.cmdCur];
            uint8_t           cmdByte = *cmd;
            boolean_t         matched = FALSE;

            cmd++;

            /* Count leading 1's to determine the command */
            for(uint8_t t = 0; t < 9 && !matched; t++)
            {
                const uint8_t bit = 0x80 >> t;

                /* Check if the bit is clear */
                if((cmdByte & bit) == 0)
                {
                    s = process[t](cmdByte, cmd);
                    matched = TRUE;
                }

                /* Clear the bit from the command byte */
                cmdByte &= ~bit;
            }
        }
    }
    while(s == SEQ_STATE_START);

    return s;
}


/** Tick the sequencer engine.
 * This is called once every 4ms to tick the sequencer engine.
 */
void SeqTick(void)
{
    switch(gState.state)
    {
        case SEQ_STATE_START:
            gState.state = startNextState();
            break;

        case SEQ_STATE_RUNNING:

            if(gState.count != 0)
            {
                uint8_t c[3] = { M_PwmReadR(), M_PwmReadG(), M_PwmReadB() };

                for(uint8_t t = 0; t < 3; t++)
                {
                    c[t] = interpStep(&gState.interpData[t], c[t]);
                }

                PwmSet(c);
            }

            /* Fall through */

        case SEQ_STATE_ACK:
        case SEQ_STATE_HOLDING:

            if(gState.count != 0)
            {
                gState.count--;
            }
            else
            {
                gState.state = startNextState();
            }
            break;

        case SEQ_STATE_HTTP_FETCHING:

            if(gState.count != 0)
            {
                gState.count--;
            }
            else
            {
                /* HTTP fetch has taken too long, close connection.
                 *  This will cause the callback function to be called,
                 *  which then updates the sequencer state to skip the
                 *  readWeb command.
                 */
                TcbClose(gState.tcb);
            }
            break;

        case SEQ_STATE_SUSPENDED:
            /* Do nothing */
            break;

        case SEQ_STATE_STOPPED:

            /* Stop the timers */
            TimerStop(TIMER_SEQ);
            TimerStop(TIMER_SEQ_SUSPEND);

            /* Set the completion event */
            M_EventSet(EV_SEQ_COMPLETED);
            break;
    }
#if !defined(ON_PC)
    /* Prevent sleeping */
    SMCR &= ~(1<<SE);
#endif
}

/**************************************************************************
 * TCP client
 **************************************************************************/

static void tcpSend(uint8_t tcb, SeqFetchTxState state)
{
    const uint8_t *host = &gState.cmdList[gState.cmdCur + 6];
    const uint8_t *page = host + *host + 1;

    switch(state)
    {
        case SEQ_TCP_FETCH_STATE_TX_GET:
            TcbWriteData(tcb, 4, "GET ", FALSE);
            break;

        case SEQ_TCP_FETCH_STATE_TX_PAGE:

            /* Check if any page has been given */
            if(*page == 0)
            {
                TcbWriteData(tcb, 1, "/", FALSE);
            }
            else
            {
                TcbWriteData(tcb, *page, page + 1, FALSE);
            }
            break;

        case SEQ_TCP_FETCH_STATE_TX_PROT:
            TcbWriteData(tcb, 17, " HTTP/1.0\r\nHost: ", FALSE);
            break;

        case SEQ_TCP_FETCH_STATE_TX_HOST:
            TcbWriteData(tcb, *host, host + 1, FALSE);
            break;

        case SEQ_TCP_FETCH_STATE_TX_PROT_TAIL:
            TcbWriteData(tcb, 4, "\r\n\r\n", FALSE);
            break;

        case SEQ_TCP_FETCH_STATE_TX_COMPLETE:
            break;

        default:
            assert(0);
            break;
    }
}


static void tcpCallback(uint8_t tcb, tcpcallbackcause_t cause, uint16_t c)
{
    switch(cause)
    {
        case TCP_CALLBACK_CAUSE_ESTABLISHED:
            printd("TCP Client: Establish OK\n");

            gState.fetchTxState = SEQ_TCP_FETCH_STATE_TX_GET;
            gState.fetchRxState = SEQ_TCP_FETCH_STATE_RX_START;
            tcpSend(tcb, gState.fetchTxState);

            /* Clear the buffer */
            tcpFetchBufferLen = 0;
            break;

        case TCP_CALLBACK_CAUSE_TX_RETRY:
            printd("TCP Client: Retry transmit last %u bytes\n", c);
            tcpSend(tcb, gState.fetchTxState);
            break;

        case TCP_CALLBACK_CAUSE_TX_SENT:
            printd("TCP Client: %u bytes sent\n", c);
            gState.fetchTxState++;
            tcpSend(tcb, gState.fetchTxState);
            break;

        case TCP_CALLBACK_CAUSE_RX_DATA:
            printd("TCP Client: Rx Data, %u bytes\n", c);

            while(c > 0)
            {
                SeqFetchRxState nextState = SEQ_TCP_FETCH_STATE_RX_DISCARD;
                uint8_t b;

                /* Read a byte */
                enc28j60RxPktRead(1, &b);
                c--;

                printd(" '%c', %u -> ", b, gState.fetchRxState);

                switch(gState.fetchRxState)
                {
                    case SEQ_TCP_FETCH_STATE_RX_START_H:
                        if(b == 'H') nextState = gState.fetchRxState + 1;
                        break;

                    case SEQ_TCP_FETCH_STATE_RX_START_T0:
                    case SEQ_TCP_FETCH_STATE_RX_START_T1:
                        if(b == 'T') nextState = gState.fetchRxState + 1;
                        break;

                    case SEQ_TCP_FETCH_STATE_RX_START_P:
                        if(b == 'P') nextState = gState.fetchRxState + 1;
                        break;

                    case SEQ_TCP_FETCH_STATE_RX_START_SLASH:
                        if(b == '/') nextState = gState.fetchRxState + 1;
                        break;

                    case SEQ_TCP_FETCH_STATE_RX_START_NUM0:
                    case SEQ_TCP_FETCH_STATE_RX_START_NUM1:
                        if(isdigit(b)) nextState = gState.fetchRxState + 1;
                        break;

                    case SEQ_TCP_FETCH_STATE_RX_START_DOT:
                        if(b == '.') nextState = gState.fetchRxState + 1;
                        break;

                    case SEQ_TCP_FETCH_STATE_RX_START_SPACE:
                        if(b == ' ') nextState = gState.fetchRxState + 1;
                        break;

                    case SEQ_TCP_FETCH_STATE_RX_START_TWO:
                        if(b == '2') nextState = gState.fetchRxState + 1;
                        break;

                    case SEQ_TCP_FETCH_STATE_RX_START_R0:
                    case SEQ_TCP_FETCH_STATE_RX_START_R1:

                        if(b == '\r')
                        {
                            nextState = gState.fetchRxState + 1;
                        }
                        else
                        {
                            nextState = SEQ_TCP_FETCH_STATE_RX_START_R0;
                        }
                        break;

                    case SEQ_TCP_FETCH_STATE_RX_START_N0:
                    case SEQ_TCP_FETCH_STATE_RX_START_N1:

                        if(b == '\n')
                        {
                            nextState = gState.fetchRxState + 1;
                        }
                        else
                        {
                            nextState = SEQ_TCP_FETCH_STATE_RX_START_R0;
                        }
                        break;

                    case SEQ_TCP_FETCH_STATE_RX_STORE:

                        /* Copy data to buffer if there is space */
                        if(tcpFetchBufferLen < sizeof(tcpFetchBuffer))
                        {
                            tcpFetchBuffer[tcpFetchBufferLen++] = b;
                        }

                        nextState = SEQ_TCP_FETCH_STATE_RX_STORE;
                        break;

                    case SEQ_TCP_FETCH_STATE_RX_DISCARD:

                        /* Error in the fetch or similar; discard data */
                        nextState = SEQ_TCP_FETCH_STATE_RX_DISCARD;
                        break;

                    default:
                        assert(0);
                }

                gState.fetchRxState = nextState;

                printd("%u\n", gState.fetchRxState);
            }

            break;

        case TCP_CALLBACK_CAUSE_RX_CLOSED:
            printd("TCP Client: Rx closed\n");
            TcbClose(tcb);
            break;

        case TCP_CALLBACK_CAUSE_CON_RESET:
            printd("TCP Client: Reset\n");

            /* Skip the fetch command */
            skipReadWebCmd();

            /* Resume at the next command */
            gState.state = startNextState();
            break;

        case TCP_CALLBACK_CAUSE_CLOSED:
            printd("TCP Client: Closed: finalRxState=%u\n", gState.fetchRxState);

            /* Check if the fetch was successful and retrieved all the data */
            if(gState.fetchRxState == SEQ_TCP_FETCH_STATE_RX_STORE &&
               tcpFetchBufferLen - 1 == tcpFetchBuffer[0] && tcpFetchBufferLen > 1)
            {
                /* Start processing the new buffer */
                LightStartRamSeq(&tcpFetchBuffer[1], tcpFetchBufferLen - 1);
            }
            else
            {
                /* Skip the fetch command */
                skipReadWebCmd();

                /* Resume at the next command */
                gState.state = startNextState();
            }
            break;
    }
}


/**************************************************************************
 * Global Functions
 **************************************************************************/

void SeqInit(void)
{
    gState.state    = SEQ_STATE_STOPPED;

    /* Initialise the PWM module */
    PwmInit();
}


/** Waits until the current sequence has completed.
 */
void SeqWait(void)
{
    volatile SeqState *state = &gState.state;

    while(*state != SEQ_STATE_STOPPED)
    {
        SleepUntilIsr();
    }
}


void SeqStart(const SeqCommand *cmdList, uint8_t nCmd)
{
    /* Ensure any interrupts do not access data as it changes */
    cli();

    /* Ensure the low speed timer is not running */
    TimerStop(TIMER_SEQ_SUSPEND);

    /* Store the command list */
    gState.cmdList  = cmdList;
    gState.cmdCount = nCmd;
    gState.cmdCur   = 0;

    /* Set to start state and start the high speed timer */
    SeqResume();

    /* Clear the sequencer event */
    M_EventClr(EV_SEQ_COMPLETED);

    sei();
}


void SeqStop(void)
{
    /* Ensure any interrupts do not access data as it changes */
    cli();
    gState.state = SEQ_STATE_STOPPED;
    sei();
}


void SeqResume(void)
{
    gState.state = SEQ_STATE_START;

    /* Start the sequencing timer */
    TimerHsStart(TIMER_SEQ, 0);
}


#if defined(ON_PC) && defined(UNIT_TEST_INTERP)
int main()
{
    SeqInterpData s;
    uint16_t      x;
    uint8_t       y;

    interpCompute(480,
                  0x00,
                  0x80,
                  &s);

    for(x = y = 0; x < 480; x++)
    {
        y = interpStep(&s, y);

        printf("%d, %d\n", x, y);
    }
}
#endif


#if defined(ON_PC) && defined(UNIT_TEST_SEQ)
int main()
{
    const SeqCommand cmd[] = {
      M_SeqCmdRgb(500, 0xff, 0x00, 0x00), /* red */
      M_SeqCmdRgb(500, 0xff, 0x80, 0x00), /* orange */
      M_SeqCmdRgb(500, 0xff, 0xff, 0x00), /* yellow */
      M_SeqCmdRgb(500, 0x00, 0xff, 0x00), /* green */
      M_SeqCmdRgb(500, 0x00, 0x00, 0xff), /* blue */
      M_SeqCmdRgb(500, 0x44, 0x00, 0x88), /* indigo */
      M_SeqCmdRgb(500, 0xff, 0x00, 0xff), /* magenta */
      M_SeqCmdRgb(500, 0x00, 0x00, 0x00),
      M_SeqCmdStop()
    };

    const SeqCommand cmd1[] =
    {
      M_SeqCmdRgb(0, 0xff, 0x00, 0x00),
      M_SeqCmdDelayMs(333),
      M_SeqCmdRgb(0, 0x00, 0xff, 0x00),
      M_SeqCmdDelayMs(333),
      M_SeqCmdRgb(0, 0x00, 0x00, 0xff),
      M_SeqCmdDelayMs(333),
      M_SeqCmdRgb(0, 0x00, 0x00, 0x00),
      M_SeqCmdStop()
    };


    FILE *log;

    SeqStart(cmd, sizeof(cmd));

    log = NULL; //fopen("log.csv", "w");

    printf("<table>\n");

    while(gState.state != SEQ_STATE_STOPPED)
    {
#if 0
        printf("<tr><td BGCOLOR=\"#%02x%02x%02x\">%d %d %d</td><tr>\n",
               M_PwmReadR(), M_PwmReadG(), M_PwmReadB(),
               M_PwmReadR(), M_PwmReadG(), M_PwmReadB());
#else
        printf("State: %d Count: %03d RGB: %03d %03d %03d\n",
               gState.state, gState.count, M_PwmReadR(), M_PwmReadG(), M_PwmReadB());
#endif
        if(log) fprintf(log, "%d, %d, %d\n", M_PwmReadR(), M_PwmReadG(), M_PwmReadB());
        SeqTick();
    }

    printf("</table>\n");

    fclose(log);

    return 0;
}
#endif

/* END OF FILE */
