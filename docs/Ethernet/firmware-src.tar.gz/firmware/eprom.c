/***************************************************************************
 * eprom.c: Eprom image for pre-defined light sequences.
 * Copyright (C) 2007 Michael C McTernan,
 *    Michael.McTernan.2001@cs.bris.ac.uk
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

/**************************************************************************
 * Include Files
 **************************************************************************/

#if !defined(ON_PC)
#include <avr/eeprom.h>
#else
#define EEMEM
#define eeprom_write_byte(w,b) { *(w) = (b); }
#endif
#include <stdint.h>
#include <stdio.h>
#include "enc28j60.h"
#include "timer.h"
#include "eprom.h"
#include "pwm.h"
#include "udp.h"
#include "seq.h"

/**************************************************************************
 * Manifest Constants
 **************************************************************************/

/** Duration for which the EPROM can be reprogrammed after device configuration.
 */
#define EPROM_REPROGRAM_ALLOWED_SECONDS 30

/**************************************************************************
 * Global Variables
 **************************************************************************/

/** The default EPROM image.
 */
EpromImage EEMEM epromImage =
{
    /* Number of pre-defined */
    NUM_EPROM_LIGHT,

    /* Offsets */
    {
          0 / 2, /* EPROM_LIGHT_POST */
         22 / 2, /* EPROM_LIGHT_ETH_UP */
         28 / 2, /* EPROM_LIGHT_ETH_DOWN */
         38 / 2, /* EPROM_LIGHT_DHCP_START */
         44 / 2, /* EPROM_LIGHT_DHCP_CONFIGURED */
         78 / 2, /* EPROM_LIGHT_AUTOIP_START */
         84 / 2, /* EPROM_LIGHT_AUTOIP_CONFIGURED */
        118 / 2, /* EPROM_LIGHT_START */
        184 / 2
    },


    /* Sequences */
    {
        /* EPROM_LIGHT_POST */
/* 0 */ M_SeqCmdRgb(0, 0xff, 0x00, 0x00),
        M_SeqCmdDelayMs(333),
        M_SeqCmdRgb(0, 0x00, 0xff, 0x00),
        M_SeqCmdDelayMs(333),
        M_SeqCmdRgb(0, 0x00, 0x00, 0xff),
        M_SeqCmdDelayMs(333),
        M_SeqCmdRgb(0, 0x00, 0x00, 0x00),
        M_SeqCmdStop(), 0,

        /* EPROM_LIGHT_ETH_UP */
/* 22 */M_SeqCmdRgb(0, 0x0, 0xff, 0x00),
        M_SeqCmdStop(),

        /* EPROM_LIGHT_ETH_DOWN */
/* 28 */M_SeqCmdRgb(200, 0x0, 0x3f, 0x00),
        M_SeqCmdRgb(300, 0x0, 0x00, 0x00),
        M_SeqCmdStop(),

        /* EPROM_LIGHT_DHCP_START */
/* 38 */M_SeqCmdRgb(0, 0x0, 0xff, 0x00),
        M_SeqCmdStop(),

        /* EPROM_LIGHT_DHCP_CONFIGURED */
/* 44 */M_SeqCmdRgb(160, 0xff, 0x00, 0x00), /* red */
        M_SeqCmdRgb(160, 0xff, 0x88, 0x00), /* orange */
        M_SeqCmdRgb(160, 0xff, 0xff, 0x00), /* yellow */
        M_SeqCmdRgb(160, 0x00, 0xff, 0x00), /* green */
        M_SeqCmdRgb(160, 0x00, 0x00, 0xff), /* blue */
        M_SeqCmdRgb(160, 0x64, 0x00, 0xff), /* indigo */
        M_SeqCmdRgb(160, 0xff, 0x00, 0x64), /* magenta */
        M_SeqCmdRgb(160, 0x00, 0x00, 0x00),
        M_SeqCmdStop(),

        /* EPROM_LIGHT_AUTOIP_START */
/* 78 */M_SeqCmdRgb(0, 0xff, 0xff, 0x00),
        M_SeqCmdStop(),

        /* EPROM_LIGHT_AUTOIP_CONFIGURED */
/* 84 */M_SeqCmdRgb(500, 0xff, 0x00, 0x64), /* magenta */
        M_SeqCmdRgb(500, 0x64, 0x00, 0xff), /* indigo */
        M_SeqCmdRgb(500, 0x00, 0x00, 0xff), /* blue */
        M_SeqCmdRgb(500, 0x00, 0xff, 0x00), /* green */
        M_SeqCmdRgb(500, 0xff, 0xff, 0x00), /* yellow */
        M_SeqCmdRgb(500, 0xff, 0x88, 0x00), /* orange */
        M_SeqCmdRgb(500, 0xff, 0x00, 0x00), /* red */
        M_SeqCmdRgb(500, 0x00, 0x00, 0x00),
        M_SeqCmdStop(),

        /* EPROM_LIGHT_START */
/* 118 */
        M_SeqCmdReadWeb(84, 92, 1, 6),
        29, 'c', 'c', 'g', 'i', '.', 'm', 'm', '7', '3', '2', '3', '.', 'f', 'r', 'e', 'e', '-', 'o', 'n', 'l', 'i', 'n', 'e', '.', 'c', 'o', '.', 'u', 'k',
        21, '/', 'c', 'g', 'i', '-', 'b', 'i', 'n', '/', 'w', 'e', 'a', 't', 'h', 'e', 'r', '.', 's', 'h', '?', '1',
        M_SeqCmdRgb(4000, 0xff, 0x00, 0x00),
        M_SeqCmdRgb(4000, 0x00, 0x00, 0x00),
        M_SeqCmdStop(),
/* 184 */
    }
};

/**************************************************************************
 * Local Data
 **************************************************************************/

/** Flag to indicate if the EEPROM can be reprogrammed or not.
 * This flag is manipulated by EpromAllowReprogramming() to allow the
 * EEPROM to be reprogrammed for a short duration of time after the device
 * has initially been configured.
 */
static boolean_t epromReprogramAllowed = FALSE;

/**************************************************************************
 * Local Functions
 **************************************************************************/

static boolean_t checkEpromImage(const uint16_t payloadBytes)
{
    uint8_t prevOff = 0;
    uint8_t numPredef;
    uint8_t off;

    /* Read count of predefined sequences */
    enc28j60RxPktRead(1, &numPredef);

    /* Check that there is enough payload for the offset vector */
    if((uint16_t)numPredef + 1 > payloadBytes)
    {
        printd("EpromImage: Failed vector length\n");
        return FALSE;
    }

    /* Read each of the offsets */
    for(uint8_t t = 0; t < numPredef; t++)
    {
        enc28j60RxPktRead(1, &off);

        /* Check the supplied offset is within the buffer,
         *  and that the offsets are correctly ordered.
         */
        if(((uint16_t)off * 2) >= payloadBytes - (numPredef + 1) && off >= prevOff)
        {
            printd("EpromImage: Failed vector[%d] range or increment\n", t);
            return FALSE;
        }

        prevOff = off;
    }

    /* Finally read the last offset which gives the data array length */
    enc28j60RxPktRead(1, &off);

    /* Check that length against the packet payload */
    if(((uint16_t)off * 2) > (payloadBytes - ((uint16_t)numPredef + 1)) && off >= prevOff)
    {
        printd("EpromImage: Failed final length, %u > %u && %u >= %u\n",
               off * 2, payloadBytes - (numPredef + 1),
               off, prevOff);
        return FALSE;
    }

    /* All passed */
    return TRUE;
}

/**************************************************************************
 * Global Functions
 **************************************************************************/

void EpromProcessPacket(const ipparam_t *ipp)
{
    const uint16_t payloadBytes = ipp->payloadLen - UDP_HDR_LEN_BYTES;
    const uint16_t payloadPos   = enc28j60RxPktOffset();

    /* Check if the EEPROM can be updated and if the packet looks valid */
    if(!epromReprogramAllowed || payloadBytes < 1)
    {
        /* Ignore the packet */
        printd("EpromProcessPacket: Packet ignored, too short, or EEPROM locked\n");
        return;
    }

    /* Stop any sequencer */
    SeqStop();

    /* Perform some validation */
    if(checkEpromImage(payloadBytes))
    {
        const uint8_t start[]    = { 255, 136, 000 };
        const uint8_t complete[] = { 000, 255, 000 };
        uint8_t *w = (uint8_t *)&epromImage;

        PwmSet(start);

        /* Seek back to the data */
        enc28j60RxPktRewind();
        enc28j60RxPktSkip(payloadPos);

        /* Update the eeprom */
        for(uint16_t b = 0; b < payloadBytes; b++)
        {
            uint8_t byte;

            enc28j60RxPktRead(sizeof(uint8_t), &byte);
            eeprom_write_byte(w, byte);
            w++;
        }

        PwmSet(complete);
    }
    else
    {
        const uint8_t fail[] = { 255, 0, 0 };
        PwmSet(fail);
    }
}

void EpromAllowReprogramming(boolean_t allow)
{
    /* Start timeout to disallow programming after some duration */
    if(allow)
    {
        TimerLsStart(TIMER_EPROM_REPROG, EPROM_REPROGRAM_ALLOWED_SECONDS);
    }

    /* Store the lock state */
    epromReprogramAllowed = allow;

    printd("EpromAllowReprogramming: allow=%d\n", allow);
}

/* END OF FILE */

