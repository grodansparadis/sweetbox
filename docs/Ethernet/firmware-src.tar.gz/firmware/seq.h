/***************************************************************************
 * seq.h: PWM Sequencer for ATmega88.
 * Copyright (C) 2007 Michael C McTernan,
 *    Michael.McTernan.2001@cs.bris.ac.uk
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

#ifndef SEQ_H
#define SEQ_H

/**************************************************************************
 * Includes
 **************************************************************************/

#include <stdint.h>
#if !defined(ON_PC)
#include "main.h"
#endif

/**************************************************************************
 * Macros
 **************************************************************************/

#define M_SeqMsToTick(v) ((v) / (4*8))

/**************************************************************************
 * Sequencer Command Macros
 **************************************************************************/

/** Change to r,g,b over a period of upto 0x7f ticks.
 *
 * \param[in] upMs  Count of milliseconds over which to transition.
 * \param[in] r     The desired red value.
 * \param[in] g     The desired green value.
 * \param[in] b     The desired blue value.
 */
#define M_SeqCmdRgb(upMs, r, g, b)          /* 0mmmmmmm */          \
            (0x00 | (M_SeqMsToTick(upMs) & 0x7f)), r, g, b

/** Delay for upto 0x3f ticks. */
#define M_SeqCmdDelayMs(ms)                 /* 10mmmmmm */          \
            (0x80 | (M_SeqMsToTick(ms) & 0x3f))

/** Start a predefined command sequence from EEPROM.
 * This starts predefined command sequence number \a num from the EEPROM.
 */
#define M_SeqCmdStartPreDef(num)            /* 110nnnnn */          \
            (0xc0 | (num & 0x1f))

/** Delay for upto 0x0fff seconds. */
#define M_SeqCmdDelaySec(sec)               /* 1110ssss */          \
            (0xe0 | ((sec) >> 8 & 0x0f)), ((sec) & 0x00ff)

/** Jump up or down by upto 0xff as a 2's compliment signed number. */
#define M_SeqCmdJump(rel)                   /* 111100xx */          \
            (0xf0), rel

/** Stop the running sequence. */
#define M_SeqCmdStop()                      /* 111100xx */          \
            M_SeqCmdJump(0)

/** Conditional jump.
 * Like M_SeqCmdJump(), but the jump is only taken if \a reg is zero.
 *
 * \param[in] reg  The register value to check.
 * \param[in] rel  The 2's compliment signed jump distance.
 */
#define M_SeqCmdJumpRegZe(reg, rel)         /* 111101rr */          \
            (0xf4 | (reg)), rel

/** Conditional stop.
 * Stop if the given register value is zero.
 */
#define M_SeqCmdStopRegZe(reg)              /* 111101rr */          \
            M_SeqCmdJumpRegZe(reg, 0)

/** Set a register to some value.
 * This sets the given register to some 8-bit unsigned value.
 *
 * \param[in] reg  The register to set.
 * \param[in] val  The value with which to load the register.
 */
#define M_SeqCmdRegSet(reg, val)            /* 111110rr */          \
            (0xf8 | ((reg) & 0x03)), val

/** Send a UDP packet back to source host.
 * \param[in] code  An 8 bit code to return to the host.
 */
#define M_SeqCmdAckHost(code)               /* 1111110x */          \
            (0xfc), code

/** Add a 5-bit value to a register.
 *
 * \param[in] reg    The register to which the value is added.
 * \param[in] value  The 5-bit value to add.
 */
#define M_SeqCmdAddReg(reg, value)          /* 11111110, rr0vvvvv */\
            (0xfe), (reg << 6) | ((value) & 0x1f)

/** Subtract a 5-bit value from a register.
 *
 * \param[in] reg    The register to which the value is added.
 * \param[in] value  The 5-bit value to subtract.
 */
#define M_SeqCmdDecReg(reg, value)          /* 11111110, rr1vvvvv */\
            (0xfe), (reg << 6) | ((-value) & 0x1f) | (0x20)

/** One of 256 extended commands.
 *
 * \param[in] extCmd  The 6 bit extended command type.
 * \param[in] param   The 2 bit parameter to the command.
 */
#define M_SeqCmdExt(extCmd, param)         /* 11111111 */ \
            (0xff), (extCmd | (param << 6))

/** Fetch new command list from a website using HTTP.
 * This gives the header to indicate that an HTTP fetch is required.
 * The first four parameters give the IPv4 address of the server.
 * This must be followed by a byte that gives the length of the host
 * name string, then the bytes for the host.  After that, a byte
 * gives the length of the page to fetch which is again followed by
 * the fetch string e.g.
 *
 * \code
 *   M_SeqCmdReadWeb(84, 92, 1, 6),
 *   29, 'c', 'c', 'g', 'i', '.', 'm', 'm', '7', '3', '2', '3', '.', 'f', 'r', 'e', 'e', '-', 'o', 'n', 'l', 'i', 'n', 'e', '.', 'c', 'o', '.', 'u', 'k',
 *   21, '/', 'c', 'g', 'i', '-', 'b', 'i', 'n', '/', 'w', 'e', 'a', 't', 'h', 'e', 'r', '.', 's', 'h', '?', '1',
 * \endcode
 *
 * Finally, the strings must be encoded in UTF-8.
 */
#define M_SeqCmdReadWeb(ip1, ip2, ip3, ip4) \
            M_SeqCmdExt(SEQ_CMD_READ_WEB, 0), ip1, ip2, ip3, ip4

/** Load a register with a random value.
 *
 * \param[in] reg  The register number, 0 to 3.
 * \param[in] min  Minimum allowable 8 bit value after randomisation.
 * \param[in] max  Maximum allowable 8 bit value after randomisation.
 */
#define M_SeqCmdRandReg(reg, min, max) \
            M_SeqCmdExt(SEQ_CMD_LOAD_RAND_REG, reg), min, max

/** Delay for some number of ticks.
 * Delay for \a reg * 4 miliseconds.
 *
 * \param[in] reg   The register number, 0 to 3.
 */
#define M_SeqCmdDelayRegTicks(reg) \
            M_SeqCmdExt(SEQ_CMD_DELAY_MS_REG, reg)

/** Change to r,g,b over a period of register * 4ms .
*
* \param[in] reg   The register number, 0 to 3.
* \param[in] r     The desired red value.
* \param[in] g     The desired green value.
* \param[in] b     The desired blue value.
*/
#define M_SeqCmdRgbRegTicks(reg, r, g, b) \
            M_SeqCmdExt(SEQ_CMD_COLOUR_MS_REG, reg), r, g, b

/**************************************************************************
 * Types
 **************************************************************************/

typedef uint8_t SeqCommand;

typedef enum
{
    SEQ_CMD_READ_WEB,
    SEQ_CMD_LOAD_RAND_REG,
    SEQ_CMD_DELAY_MS_REG,
    SEQ_CMD_COLOUR_MS_REG
}
SeqExtCommand;

/**************************************************************************
 * Prototypes
 **************************************************************************/

void      SeqInit   (void);
void      SeqStart  (const SeqCommand *cmdList, uint8_t nCmd);
void      SeqTick   (void);
void      SeqResume (void);
void      SeqWait   (void);
void      SeqStop   (void);

#endif

/* END OF FILE */
