/***************************************************************************
 * udp.c: UPD layer for ATmega88.
 * Copyright (C) 2007 Michael C McTernan,
 *    Michael.McTernan.2001@cs.bris.ac.uk
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

/**************************************************************************
 * Include Files
 **************************************************************************/

#include <stdint.h>
#include "enc28j60.h"
#include "netbios.h"
#include "memdump.h"
#include "eprom.h"
#include "light.h"
#include "main.h"
#include "dhcp.h"
#include "udp.h"
#include "ip.h"

/**************************************************************************
 * Typedefs
 **************************************************************************/

/** UDP header as a structure.
 */
typedef struct
{
    uint16_t sport;     /**< Source port. */
    uint16_t dport;     /**< Destination port. */
    uint16_t length;    /**< Length of datagram, including header and data. */
    uint16_t checksum;  /**< Optional checksum. */
}
udpheader_t;

/**************************************************************************
 * Manifest Constants
 **************************************************************************/

/** Read a UDP header from the Ethernet device buffer.
 * This reads a UDP header from the Ethernet device and extracts any
 * useful parameters.
 *
 * \param[in,out] udpp  Pointer to fill with useful packet parameters.
 * \returns The UDP destination port taken from the packet header.
 *
 * \note  This function is prevented from being inlined.  This is because
 *         it reads the UDP header onto the stack, and would cause a large
 *         amount of stack space to be used for all descendant functions.
 */
static uint16_t __attribute__ ((noinline)) readPacket(udpparam_t *const udpp)
{
    udpheader_t hdr;

    /* Read header */
    enc28j60RxPktRead(sizeof(udpheader_t), &hdr);

    /* Save useful parameters */
    udpp->sport      = ntohs(hdr.sport);
    udpp->payloadLen = ntohs(hdr.length) - sizeof(udpheader_t);

    /* At this point, the checksum could be validated and the packet
     *  discarded if needed by returning 0.
     */

    return ntohs(hdr.dport);
}

/**************************************************************************
 * Global Functions
 **************************************************************************/

void UdpProcessPacket(const ipparam_t *ipp)
{
    udpparam_t udpp;

    switch(readPacket(&udpp))
    {
        case UDP_PORT_BOOTPC:
            DhcpProcessPacket(ipp, &udpp);
            break;
        case UDP_PORT_NETBIOS_NS:
            NetBiosNsProcessPacket(ipp /*, &udpp*/);
            break;
        case UDP_PORT_LIGHTCONTROL:
            LightProcessPacket(ipp, &udpp);
            break;
        case UDP_PORT_LIGHTUPDATE:
            EpromProcessPacket(ipp);
            break;
#if defined(ENABLE_MEMDUMP)
        case UDP_PORT_MEMDUMP:
            MemdumpProcessPacket(ipp);
            break;
#endif
    }
}


/** Write a UDP header to the transmit buffer.
 *
 * \param[in] sport  The source port.
 * \param[in] dport  The destination port.
 * \param[in] length Length of the user data part of the datagram.
 *
 * \retval TRUE if the headers have been written and the packet body can be
 *               written and sent.
 * \retval FALSE if some header failed to be written and no further data should
 *                be written or sent.
 */
boolean_t UdpWriteHeader(const ipaddr_t *sAddr,
                         const ipaddr_t *dAddr,
                         uint16_t        sport,
                         uint16_t        dport,
                         uint16_t        length)
{
    length += sizeof(udpheader_t);

    if(IpWriteHeader(sAddr, dAddr, length, IP_PROT_UDP))
    {
        udpheader_t hdr;

        hdr.sport    = htons(sport);
        hdr.dport    = htons(dport);
        hdr.length   = htons(length);
        hdr.checksum = 0; /* No checksum */

        enc28j60TxPktAppend(sizeof(udpheader_t), &hdr);

        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

void UdpDebug(uint8_t v1, uint8_t v2, uint8_t v3,
              uint8_t v4, uint8_t v5, uint8_t v6)
{
    if(UdpWriteHeader(&ipZero, &ipBCast, 5, 777, 6))
    {
        enc28j60TxPktAppend(1, &v1);
        enc28j60TxPktAppend(1, &v2);
        enc28j60TxPktAppend(1, &v3);
        enc28j60TxPktAppend(1, &v4);
        enc28j60TxPktAppend(1, &v5);
        enc28j60TxPktAppend(1, &v6);

        enc28j60TxPktSend();
    }
}

/* END OF FILE */
