/***************************************************************************
 * tcp.c: TCP layer for ATmega88.
 * Copyright (C) 2007 Michael C McTernan,
 *    Michael.McTernan.2001@cs.bris.ac.uk
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

#define MODULE_NAME "TCP"

/**************************************************************************
 * Include Files
 **************************************************************************/

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <inttypes.h>
#include "main.h"
#include "ip.h"
#include "tcp.h"
#include "event.h"
#include "timer.h"
#include "enc28j60.h"

#include "udp.h"

/**************************************************************************
 * Manifest Constants
 **************************************************************************/

/** Count of supportable simultaneous sockets.
 */
#define TCP_MAX_SOCKETS 1

/** Reserved TCP port number to indicate a TCB is fee.
 */
#define TCP_PORT_FREE   0

/** TCP header flag definitions.
 */
#define TCP_FLAG_RS1    0x80  /* Reserved */
#define TCP_FLAG_RS2    0x40  /* Reserved */
#define TCP_FLAG_URG    0x20
#define TCP_FLAG_ACK    0x10
#define TCP_FLAG_PSH    0x08
#define TCP_FLAG_RST    0x04
#define TCP_FLAG_SYN    0x02
#define TCP_FLAG_FIN    0x01

/** Blocksize to use when checksumming data segments.
 */
#define TCP_CSUM_BLOCK_BYTES 8

/** Maximum number of retransmission attempts.
 * One retransmission occurs once retransDelay has expired for a given TCB.
 * After this many retransmission attempts have failed,  the connection
 * is reset.
 */
#define TCP_MAX_RETRANS_ATTEMPTS 6

/**************************************************************************
 * Type Definitions
 **************************************************************************/

typedef struct
{
    uint16_t  sport;
    uint16_t  dport;
    uint32_t  seqnum;
    uint32_t  acknum;
    uint8_t   reserved:4;
    uint8_t   dataOffset:4;
    uint8_t   flags;
    uint16_t  window;
    uint16_t  checksum;
    uint16_t  urgentPtr;
    uint32_t  options:24;
    uint8_t   padding;
}
tcpheader_t;

typedef struct
{
    uint16_t  sport;
    uint16_t  dport;
    uint32_t  seqnum;
    uint32_t  acknum;
    uint8_t   flags;
    uint8_t   dataOffset; /**< Data offset from header start in bytes. */
    uint16_t  pktStart;   /**< Address of first byte of TCP header in the
                                Ethernet device buffer. */
}
tcpparam_t;

typedef struct
{
    ipaddr_t saddr;
    ipaddr_t daddr;
    uint8_t  zero;
    uint8_t  ptcl;
    uint16_t tcplen;

}
tcppseudoheader_t;

typedef enum
{
    TCP_STATE_CLOSED = 0,
    TCP_STATE_SYN_SENT,
    TCP_STATE_SYN_RECEIVED,
    TCP_STATE_ESTABLISHED,
    TCP_STATE_CLOSE_WAIT,
    TCP_STATE_LAST_ACK,
}
tcpstate_t;

typedef struct
{
    tcpstate_t    state;

    /** The local port number for the connection. */
    uint16_t      localPort;

    /** The port number for the connection peer. */
    uint16_t      peerPort;

    /** The IP address for the connection peer. */
    ipaddr_t      peerIp;

    /** Next sequence number to send. */
    uint32_t      sndNxt;

    /** Sequence number of the first unacknowledged byte. */
    uint32_t      sndUna;

    /** Next sequence number to receive. */
    uint32_t      rcvNxt;

    /** If TRUE, \a rcvNxt has been advanced without an ACK being sent. */
    boolean_t     ackPending;

    /** Retransmission count down delay. */
    uint8_t       retransDelay;

    /** Count of retransmission attempts. */
    uint8_t       retransAttempts;

    /** Application callback function. */
    tcpcallback_t callback;
}
tcpcontrolblock_t;

/**************************************************************************
 * Variables
 **************************************************************************/

/** TCB control blocks.
 * Each control block stores the state for one socket.
 */
static tcpcontrolblock_t tcb[TCP_MAX_SOCKETS];

/**************************************************************************
 * Macros
 **************************************************************************/

/**************************************************************************
 * Local Functions
 **************************************************************************/

#if defined(ON_PC)
static const char *tcpStateToString(tcpstate_t s)
{
    switch(s)
    {
        case TCP_STATE_CLOSED:       return "TCP_STATE_CLOSED";
        case TCP_STATE_SYN_SENT:     return "TCP_STATE_SYN_SENT";
        case TCP_STATE_SYN_RECEIVED: return "TCP_STATE_SYN_RECEIVED";
        case TCP_STATE_ESTABLISHED:  return "TCP_STATE_ESTABLISHED";
        case TCP_STATE_CLOSE_WAIT:   return "TCP_STATE_CLOSE_WAIT";
        case TCP_STATE_LAST_ACK:     return "TCP_STATE_LAST_ACK";
        default: return "????";
    }
}


static void printFlags(uint8_t f)
{
    if(f & TCP_FLAG_FIN) printd(" FIN");
    if(f & TCP_FLAG_SYN) printd(" SYN");
    if(f & TCP_FLAG_ACK) printd(" ACK");
    if(f & TCP_FLAG_RST) printd(" RST");
}
#else
#define printFlags(a)
#endif

/** Select an initial sequence number for a new connection.
 *
 */
static uint32_t selectInitialSeqNum(void)
{
    return random();
}


/** Find a free TCB.
 * \param[in,out] idx  Pointer to receive the selected index.
 * \retval TRUE  A free TCB was found and \a *idx has been updated.
 * \retval FALSE No free TCB was found.
 */
static boolean_t findTcb(uint16_t localPort, uint8_t *const idx)
{
    for(uint8_t r = 0; r < TCP_MAX_SOCKETS; r++)
    {
        if(tcb[r].localPort == localPort)
        {
            *idx = r;
            return TRUE;
        }
    }

    return FALSE;
}


/** Free some TCB, informing the application as to some cause.
 * Default any state in a TCB, and inform the application that the
 * TCB has been freed using it's callback and the supplied \a cause.
 *
 * \param[in] tcbIdx  Index of the TCB to free.
 * \param[in] cause   The cause for closing the connection.
 */
static void freeTcb(const uint8_t tcbIdx, const tcpcallbackcause_t cause)
{
    /* Update state */
    tcb[tcbIdx].retransDelay = 0;
    tcb[tcbIdx].state        = TCP_STATE_CLOSED;
    tcb[tcbIdx].ackPending   = FALSE;
    tcb[tcbIdx].localPort    = TCP_PORT_FREE;

    /* Inform application */
    tcb[tcbIdx].callback(tcbIdx, cause, 0);
}


/** Seek to the start of the payload data in the current packet.
 * This sets the buffer read pointer to the start of the packet data.
 *
 * \param[in] tcpp  The TCP packet parameters.
 */
static void seekData(const tcpparam_t *tcpp)
{
    enc28j60RxPktRewind();
    enc28j60RxPktSkip(tcpp->pktStart + tcpp->dataOffset);
}


/** Checksum the TCP pseudo header.
 * Compute the seed for the TCP checksum based on the pseudo header.
 *
 * \param[in] peer       IP address of peer.
 * \param[in] tcpLength  Length of the header and payload on the packet.
 * \returns   The 32-bit value to pass into IpChecksum() when adding further
 *             bytes to the checksum.
 */
static uint32_t pseudoHeaderCheckSum(const ipaddr_t *peer, uint16_t tcpLength)
{
    uint32_t           csumState = 0;
    tcppseudoheader_t  phdr;

    /* Create the pseudo header.
     *  Note that order of source and destination addresses does not change
     *  the result.
     */
    phdr.saddr  = ipHost;
    phdr.daddr  = *peer;
    phdr.zero   = 0;
    phdr.ptcl   = IP_PROT_TCP;
    phdr.tcplen = htons(tcpLength);

    /* Compute the checksum */
    IpChecksum(&csumState, sizeof(tcppseudoheader_t), &phdr);

    /* Return the checksum state */
    return csumState;
}


/** Check if some value is within a 32 bit circular window.
 * This checks that \a start <= \a num <= \a end in such a way that wrapping
 * is correctly handled in cases where \a start maybe numerically less than
 * \a end.
 *
 * \retval TRUE  \a num is determined to be in the window.
 * \retval FALSE \a num is outside the window.
 */
static boolean_t isInWindow(uint32_t num, uint32_t start, uint32_t end)
{
    boolean_t r;

    if(start <= end)
        r = (num >= start) && (num <= end);
    else
        r = (num >= start) || (num <= end);

    printd("TCP: IsInWindow(%" PRIu32 ", %" PRIu32 ", %" PRIu32 ") = %u\n",
           num, start, end, r);

    return r;
}


/** Check if a packet has some flags set.
 */
static boolean_t flagSet(uint8_t flags, const tcpparam_t *tcpp)
{
    return (tcpp->flags & flags) == flags;
}


/** Verify the checksum on some packet.
 * Check that some packet has a valid IP checksum.
 *
 * \param[in] peerIp    Address of the peer.
 * \param[in] hdr       The packet header.
 * \param[in] totalLen  Sum of TCP header and data length.
 */
static boolean_t verifyChecksum(const ipaddr_t    *peerIp,
                                const tcpheader_t *hdr,
                                const uint16_t     totalLen)
{
    uint32_t cSumSeed = 0;
    uint16_t cSum;
    uint16_t dataLen;

    /* Compute checksum of pseudo header and real header */
    cSumSeed = pseudoHeaderCheckSum(peerIp, totalLen);
    cSum     = IpChecksum(&cSumSeed, hdr->dataOffset * 4, hdr);

    /* Now check if there is a payload */
    dataLen = totalLen - (hdr->dataOffset * 4);
    if(dataLen > 0)
    {
        uint8_t buf[TCP_CSUM_BLOCK_BYTES];

        /* Read blocks of data and checksum */
        do
        {
            const uint8_t n = dataLen > sizeof(buf) ? sizeof(buf) : dataLen;

            enc28j60RxPktRead(n, buf);
            cSum = IpChecksum(&cSumSeed, n, buf);
            dataLen -= n;
        }
        while(dataLen > 0);
    }

    /* The checksum is good if it equals zero.
     *  This is because the header contains the inverted checksum.
     */
    return cSum == 0;
}


static void sendTcpReset(const ipparam_t  *ipp,
                         const tcpparam_t *tcpp)
{
    if(IpWriteHeader(&ipHost,
                     &ipp->sAddr,
                     sizeof(tcpheader_t),
                     IP_PROT_TCP))
    {
        uint32_t    csumState = pseudoHeaderCheckSum(&ipp->sAddr, sizeof(tcpheader_t));
        tcpheader_t hdr;

        /* Create the actual header */
        memset(&hdr, 0, sizeof(hdr));
        hdr.sport      = htons(tcpp->dport);
        hdr.dport      = htons(tcpp->sport);
        if(flagSet(TCP_FLAG_ACK, tcpp))
        {
            hdr.seqnum = htonl(tcpp->acknum);
            hdr.flags  = TCP_FLAG_RST;
        }
        else
        {
            hdr.acknum = htonl(tcpp->seqnum +
                               (ipp->payloadLen - tcpp->dataOffset));
            hdr.flags  = TCP_FLAG_RST | TCP_FLAG_ACK;
        }
        hdr.dataOffset = sizeof(tcpheader_t) / 4;

        hdr.window     = htons(1024);

        /* Add checksum */
        hdr.checksum = IpChecksum(&csumState, sizeof(tcpheader_t), &hdr);

        /* Write the header */
        enc28j60TxPktAppend(sizeof(hdr), &hdr);

        /* Send the packet */
        enc28j60TxPktSend();
    }
}


/** Send a single TCP packet.
 *
 * \param[in] tcbIdx      Index of the TCB.
 * \param[in] ackNum      Acknowledgment number to send.
 * \param[in] flags       TCP flags to send.
 * \param[in] payloadLen  The length of the payload to transmit, in bytes.
 * \param[in] payload     Pointer to the payload bytes.
 * \retval TRUE if the packet was sent.
 * \retval FALSE if the packet could not be sent.
 */
static boolean_t sendTcp(uint8_t     tcbIdx,
                         uint32_t    acknum,
                         uint8_t     flags,
                         uint16_t    payloadLen,
                         const void *payload)
{
    const uint16_t tcpLen = sizeof(tcpheader_t) + payloadLen;

    printd("TCP: Send packet: ack=%" PRIu32 ", seq=%" PRIu32 ", ",
           acknum, tcb[tcbIdx].sndNxt);
    printFlags(flags);
    printd("\n");

    if(IpWriteHeader(&ipHost,
                     &tcb[tcbIdx].peerIp,
                     tcpLen,
                     IP_PROT_TCP))
    {
        uint32_t    csumState = pseudoHeaderCheckSum(&tcb[tcbIdx].peerIp, tcpLen);
        tcpheader_t hdr;

        /* Create the actual header */
        memset(&hdr, 0, sizeof(hdr));
        hdr.sport      = htons(tcb[tcbIdx].localPort);
        hdr.dport      = htons(tcb[tcbIdx].peerPort);
        hdr.seqnum     = htonl(tcb[tcbIdx].sndUna);
        hdr.acknum     = htonl(acknum);
        hdr.dataOffset = sizeof(tcpheader_t) / 4;
        hdr.flags      = flags;
        hdr.window     = htons(1024);

        /* Add checksum */
        IpChecksum(&csumState, sizeof(tcpheader_t), &hdr);
        hdr.checksum = IpChecksum(&csumState, payloadLen, payload);

        /* Write the header */
        enc28j60TxPktAppend(sizeof(hdr), &hdr);

        /* Write payload */
        enc28j60TxPktAppend(payloadLen, payload);

        /* Send the packet */
        enc28j60TxPktSend();

        return TRUE;
    }

    return FALSE;
}


static void tcpTransmitStateMachine(uint8_t tcbIdx)
{
    const uint16_t unAcked = tcb[tcbIdx].sndNxt - tcb[tcbIdx].sndUna;

    /* Check how many attempts have been made */
    if(tcb[tcbIdx].retransAttempts > TCP_MAX_RETRANS_ATTEMPTS)
    {
        /* Count exceeded, take state specific action */
        switch(tcb[tcbIdx].state)
        {
            case TCP_STATE_SYN_SENT:
            case TCP_STATE_ESTABLISHED:
                freeTcb(tcbIdx, TCP_CALLBACK_CAUSE_CON_RESET);
                break;

            case TCP_STATE_LAST_ACK:
                freeTcb(tcbIdx, TCP_CALLBACK_CAUSE_CLOSED);
                break;

            default:
                assert(0);
                freeTcb(tcbIdx, TCP_CALLBACK_CAUSE_CLOSED);
                break;
        }
    }
    else
    {
        /* Handle retransmission according to state */
        switch(tcb[tcbIdx].state)
        {
            case TCP_STATE_SYN_SENT:
                sendTcp(tcbIdx, 0, TCP_FLAG_SYN, 0, NULL);
                tcb[tcbIdx].retransDelay = 5;
                break;

            case TCP_STATE_LAST_ACK:
                sendTcp(tcbIdx, tcb[tcbIdx].rcvNxt, TCP_FLAG_FIN | TCP_FLAG_ACK, 0, NULL);
                tcb[tcbIdx].ackPending      = FALSE;
                tcb[tcbIdx].retransDelay    = 5;
                break;

            case TCP_STATE_ESTABLISHED:

                /* Check if there is any untransmitted data */
                if(unAcked != 0)
                {
                    tcb[tcbIdx].callback(tcbIdx, TCP_CALLBACK_CAUSE_TX_RETRY, unAcked);
                }

                break;

            default:
                assert(0);
                break;
        }
    }
}


static void processTcbPacket(uint8_t     tcbIdx,
                             tcpparam_t *tcpp,
                             uint16_t    tcpLen)
{
    const boolean_t inTxWindow = isInWindow(tcpp->acknum, tcb[tcbIdx].sndUna, tcb[tcbIdx].sndNxt);
    const boolean_t inRxWindow = (tcpp->seqnum == tcb[tcbIdx].rcvNxt);

    printd("TCP: Stt_processTcbPacket: %s", tcpStateToString(tcb[tcbIdx].state));
    printFlags(tcpp->flags);
    printd("\n");

    /* Check for a reset */
    if(flagSet(TCP_FLAG_RST, tcpp))
    {
        /* Validate */
        if((tcb[tcbIdx].state == TCP_STATE_SYN_SENT &&
           flagSet(TCP_FLAG_ACK, tcpp) && inRxWindow) ||
           inRxWindow)
        {
            printd("TCP: Connection reset\n");
            freeTcb(tcbIdx, TCP_CALLBACK_CAUSE_CON_RESET);
        }
    }
    else
    {
        switch(tcb[tcbIdx].state)
        {
            case TCP_STATE_CLOSED:
                assert(0);
                break;

            /* Sent a SYN, looking for an ACK */
            case TCP_STATE_SYN_SENT:

                /* Check for SYN,ACK */
                if(flagSet(TCP_FLAG_ACK | TCP_FLAG_SYN, tcpp) && inTxWindow)
                {
                    /* Syn successfully sent, update transmit number */
                    tcb[tcbIdx].sndNxt++;
                    tcb[tcbIdx].sndUna = tcpp->acknum;

                    /* Initialise the next expected receive number */
                    tcb[tcbIdx].rcvNxt = tcpp->seqnum + 1;

                    /* Update state and cancel retransmission timer */
                    tcb[tcbIdx].state  = TCP_STATE_ESTABLISHED;
                    tcb[tcbIdx].retransDelay = 0;

                    /* Acknowledge */
                    tcb[tcbIdx].ackPending = TRUE;

                    /* Inform the application.
                     *  Note that the application may send some data in which
                     *  case the ACK can be sent on the data.  In such a case
                     *  tcb[tcbIdx].ackPending will get cleared.
                     */
                    tcb[tcbIdx].callback(tcbIdx, TCP_CALLBACK_CAUSE_ESTABLISHED, 0);
                }

                break;

            case TCP_STATE_SYN_RECEIVED:
                break;

            case TCP_STATE_ESTABLISHED:

                /* Check if there is any Rx data attached */
                if(inRxWindow)
                {
                    const uint16_t dataLen = tcpLen - tcpp->dataOffset;

                    if(dataLen > 0)
                    {
                        /* Update the next expected data */
                        tcb[tcbIdx].rcvNxt += dataLen;

                        /* Send an ACK */
                        tcb[tcbIdx].ackPending = TRUE;

                        /* Track back to the user data portion */
                        seekData(tcpp);

                        /* Inform application that it can read the bytes */
                        tcb[tcbIdx].callback(tcbIdx, TCP_CALLBACK_CAUSE_RX_DATA, dataLen);
                    }
                }
                else
                {
                    /* received out of sequence data, resend the last ack */
                    tcb[tcbIdx].ackPending = TRUE;
                }

                /* Fall through */

            case TCP_STATE_CLOSE_WAIT:

                /* Check if any Tx data is ACK'd by this packet */
                if((tcpp->flags & TCP_FLAG_ACK) != 0 && inTxWindow)
                {
                    uint16_t bytesAckd = tcpp->acknum - tcb[tcbIdx].sndUna;

                    /* Check if this acknowledges any outstanding data */
                    if(bytesAckd != 0)
                    {
                        /* Advance the transmit window and prevent retransmission */
                        tcb[tcbIdx].sndUna       = tcpp->acknum;
                        tcb[tcbIdx].retransDelay = 0;

                        /* Inform app incase it wishes to send more data */
                        tcb[tcbIdx].callback(tcbIdx, TCP_CALLBACK_CAUSE_TX_SENT, bytesAckd);
                    }

                    /* Check for a FIN,ACK that is in sequence */
                    if((tcpp->flags & TCP_FLAG_FIN) &&
                       tcpp->seqnum == tcb[tcbIdx].rcvNxt)
                    {
                        /* The connection is closed by the peer */
                        tcb[tcbIdx].state = TCP_STATE_CLOSE_WAIT;

                        /* Send an ACK for the FIN */
                        tcb[tcbIdx].rcvNxt++;
                        sendTcp(tcbIdx, tcb[tcbIdx].rcvNxt, TCP_FLAG_ACK, 0, NULL);
                        tcb[tcbIdx].ackPending = FALSE;

                        /* Tell the app that nothing more will be received */
                        tcb[tcbIdx].callback(tcbIdx, TCP_CALLBACK_CAUSE_RX_CLOSED, 0);
                    }
                }
                break;

            case TCP_STATE_LAST_ACK:

                /* Check for ACK to our FIN,ACK */
                if((tcpp->flags & TCP_FLAG_ACK) != 0 && inRxWindow)
                {
                    /* All done */
                    freeTcb(tcbIdx, TCP_CALLBACK_CAUSE_CLOSED);
                }
                break;
        }


        /* Check if an ACK should be sent */
        if(tcb[tcbIdx].ackPending)
        {
            sendTcp(tcbIdx, tcb[tcbIdx].rcvNxt, TCP_FLAG_ACK, 0, NULL);
            tcb[tcbIdx].ackPending = FALSE;
        }

    }

    printd("TCP: End_processTcbPacket: %s\n\n", tcpStateToString(tcb[tcbIdx].state));
}


/** Read TCP header from Ethernet device buffer.
 * This reads a TCP header from the Ethernet buffer, validates that packet
 * and then extracts the useful parameters for return in \a tcpp.
 *
 * \note  This function is prevented from being inlined.  This is because
 *         it reads the TCP header onto the stack, and would cause a large
 *         amount of stack space to be used for all descendant functions.
 *
 * \param[in] ipp       IP header parameters applicable to this packet.
 * \param[in,out] tcpp  Pointer to be filled in with TCP header parameters.
 * \retval TRUE  A valid header has been processed.
 * \retval FALSE The header or data failed some test and should be ignored.
 */
static boolean_t __attribute__ ((noinline)) readPacket(const ipparam_t *ipp,
                                                       tcpparam_t *const tcpp)
{
    struct
    {
        tcpheader_t hdr;        /* Minimal header */
        uint8_t     opts[8];    /* Extra padding for options */
    }
    hdr;
    int16_t optLen;

    /* Note the start of the TCP packet */
    tcpp->pktStart = enc28j60RxPktOffset();

    /* Read minimum header */
    enc28j60RxPktRead(sizeof(tcpheader_t), &hdr);

    /* Convert fields to local byte order */
    tcpp->dport  = ntohs(hdr.hdr.dport);
    tcpp->sport  = ntohs(hdr.hdr.sport);
    tcpp->seqnum = ntohl(hdr.hdr.seqnum);
    tcpp->acknum = ntohl(hdr.hdr.acknum);
    tcpp->flags  = hdr.hdr.flags;
    tcpp->dataOffset = hdr.hdr.dataOffset * 4; /* Convert to bytes */

    /* Check if extra option octets need reading */
    optLen = tcpp->dataOffset - sizeof(tcpheader_t);
    if(optLen > 0 && (unsigned)optLen < sizeof(hdr.opts))
    {
        enc28j60RxPktRead(optLen, hdr.opts);
    }

    /* Seek to the start of the data */
    seekData(tcpp);

    /* Ensure the packet is intact */
    return verifyChecksum(&ipp->sAddr, (tcpheader_t *)&hdr, ipp->payloadLen);
}


/**************************************************************************
 * Global Functions
 **************************************************************************/

uint8_t TcpCreateClientSocket(const ipaddr_t *destIp,
                              uint16_t        dport,
                              tcpcallback_t   callback)
{
    uint8_t tcbIdx;

    /* Find a TCB */
    if(!findTcb(TCP_PORT_FREE, &tcbIdx))
    {
        return TCP_INVALID_TCB;
    }

    /* Setup the TCB */
    tcb[tcbIdx].state           = TCP_STATE_SYN_SENT;
    tcb[tcbIdx].localPort       = (random() & ~0x07ff) + 2048; /* Pick random port >= 2048 */
    tcb[tcbIdx].peerPort        = dport;
    tcb[tcbIdx].peerIp          = *destIp;
    tcb[tcbIdx].sndUna          = selectInitialSeqNum();
    tcb[tcbIdx].sndNxt          = tcb[tcbIdx].sndUna + 1;
    tcb[tcbIdx].ackPending      = FALSE;
    tcb[tcbIdx].retransDelay    = 1;  /* Causes immediate expiry */
    tcb[tcbIdx].retransAttempts = 0;
    tcb[tcbIdx].callback        = callback;

    /* This will cause the SYN to be transmitted.
     *  It also adds an extra tick to the retransmission accounting,
     *  but for code density we prefer to reuse this functionality.
     */
    TcpRetransmitTick();

    return tcbIdx;
}


void TcpRetransmitTick(void)
{
    boolean_t needTimer = FALSE;

    M_EventClr(EV_TIMER_TCP_RETRANSMIT);

    /* Check each socket */
    for(uint8_t t = 0; t < TCP_MAX_SOCKETS; t++)
    {
        /* Check if the counter is set */
        if(tcb[t].retransDelay > 0)
        {
            /* Decrement and check if timer expired */
            tcb[t].retransDelay--;
            if(tcb[t].retransDelay == 0)
            {
                /* Count the attempt */
                tcb[t].retransAttempts++;

                /* Expired, so run transmit logic */
                tcpTransmitStateMachine(t);
            }

            /* Check if the timer should be restarted */
            if(tcb[t].retransDelay != 0)
            {
                needTimer = TRUE;
            }
        }
    }

    /* Check if the timer should be restarted */
    if(needTimer)
    {
        TimerLsStart(TIMER_TCP_RETRANSMIT, 1);
    }
}


void TcpProcessPacket(const ipparam_t  *ipp)
{
    tcpparam_t tcpp;
    uint8_t    tcbIdx;

    /* Read and validate packet, extract useful parameters */
    if(readPacket(ipp, &tcpp))
    {
        /* Attempt to locate the TCB for the connection */
        if(!findTcb(tcpp.dport, &tcbIdx) ||
           tcb[tcbIdx].state == TCP_STATE_CLOSED)
        {
            printd("TCP: TcpProcessPacket(): No TCB or closed\n");

            /* Don't send a reset for a reset */
            if(!flagSet(TCP_FLAG_RST, &tcpp))
            {
                sendTcpReset(ipp, &tcpp);
            }
        }
        else
        {
            printd("TCP: TcpProcessPacket(): Header passed\n");

            /* Process the packet */
            processTcbPacket(tcbIdx, &tcpp, ipp->payloadLen);
        }
    }
    else
    {
        printd("TCP: TcpProcessPacket(): Checksum failed\n");
    }
}


void TcpReset(void)
{
    /* Stop retransmit timer if running */
    TimerStop(TIMER_TCP_RETRANSMIT);
    M_EventClr(EV_TIMER_TCP_RETRANSMIT);

    /* Close any open sockets */
    for(uint8_t tcbIdx = 0; tcbIdx < TCP_MAX_SOCKETS; tcbIdx++)
    {
        if(tcb[tcbIdx].state != TCP_STATE_CLOSED)
        {
            freeTcb(tcbIdx, TCP_CALLBACK_CAUSE_CON_RESET);
        }
    }
}

/**************************************************************************
 * Callback API
 **************************************************************************/

void TcbWriteData(uint8_t tcbIdx, uint16_t n, const void *data, boolean_t push)
{
    uint8_t flags = TCP_FLAG_ACK;

    /* Determine if push should be set */
    if(push) flags |= TCP_FLAG_PSH;

    /* Attempt to send the packet */
    sendTcp(tcbIdx, tcb[tcbIdx].rcvNxt, flags, n, data);

    /* Increment the sequencer number */
    tcb[tcbIdx].sndNxt     += n;

    /* Note that the ack has been sent */
    tcb[tcbIdx].ackPending = FALSE;

    /* Start the retransmission timer */
    tcb[tcbIdx].retransDelay    = 5;
    tcb[tcbIdx].retransAttempts = 0;
    TimerLsStart(TIMER_TCP_RETRANSMIT, 1);

}

void TcbClose(uint8_t tcbIdx)
{
    switch(tcb[tcbIdx].state)
    {
        case TCP_STATE_SYN_SENT:
            /* Close right away */
            freeTcb(tcbIdx, TCP_CALLBACK_CAUSE_CLOSED);
            break;

        case TCP_STATE_SYN_RECEIVED:
        case TCP_STATE_ESTABLISHED:
            /* Fin-1, Fin-2 here */

            /* Since not implemented, force a close */
            freeTcb(tcbIdx, TCP_CALLBACK_CAUSE_CLOSED);
            break;

        case TCP_STATE_CLOSE_WAIT:
            /* Update the state */
            tcb[tcbIdx].state = TCP_STATE_LAST_ACK;

            /* Send the FIN,ACK via the retransmit mechanism */
            tcb[tcbIdx].retransDelay    = 1;
            tcb[tcbIdx].retransAttempts = 0;
            TcpRetransmitTick();
            break;

        default:
            /* Invalid close state */
            assert(0);
            break;
    }
}

/* END OF FILE */

