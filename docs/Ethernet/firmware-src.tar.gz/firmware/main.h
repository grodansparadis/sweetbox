/***************************************************************************
 * main.h: Common types and functions.
 * Copyright (C) 2007 Michael C McTernan,
 *    Michael.McTernan.2001@cs.bris.ac.uk
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

#ifndef MAIN_H
#define MAIN_H

/**************************************************************************
 * Nested Includes
 **************************************************************************/

#ifndef F_CPU
#define F_CPU 8000000UL  /* 8 MHz */
#endif

#if !defined(ON_PC)
#include <util/delay.h>
#else
#include <stdio.h>
#endif

/**************************************************************************
 * Macros
 **************************************************************************/


#define htons(A)  ((((uint16_t)(A) & 0xff00) >> 8) | \
                   (((uint16_t)(A) & 0x00ff) << 8))

#define ntohs(A)  htons(A)

#define htonl(A)  ((((uint32_t)(A) & 0xff000000) >> 24) | \
                   (((uint32_t)(A) & 0x00ff0000) >> 8)  | \
                   (((uint32_t)(A) & 0x0000ff00) << 8)  | \
                   (((uint32_t)(A) & 0x000000ff) << 24))

#define ntohl(A ) htonl(A)


#if defined(ON_PC)
#define sei()
#define printd(...)  printf( __VA_ARGS__)
#else
#define printd(...)
#pragma GCC poison printf sprintf fprintf
#endif

/**************************************************************************
 * Types
 **************************************************************************/

typedef enum { FALSE = 0, TRUE } boolean_t;

/**************************************************************************
 * Prototypes
 **************************************************************************/

void delay_ms(uint16_t ms);
void SleepUntilIsr(void);

#endif

/* END OF FILE */

