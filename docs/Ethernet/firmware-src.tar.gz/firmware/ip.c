/***************************************************************************
 * ip.c: IP layer for ATmega88.
 * Copyright (C) 2007 Michael C McTernan,
 *    Michael.McTernan.2001@cs.bris.ac.uk
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

/**************************************************************************
 * Include Files
 **************************************************************************/

#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include "enc28j60.h"
#include "main.h"
#include "icmp.h"
#include "tcp.h"
#include "udp.h"
#include "ip.h"

/**************************************************************************
 * Manifest Constants
 **************************************************************************/

#define IP_VER_4         4
#define IP_FLAG_MF    0x01

/** Dummy IP protocol used to indicate that a packet should be ignored.
 */
#define IP_PROT_NULL     0

/**************************************************************************
 * Typedefs
 **************************************************************************/

/** Type for a single IP routing table entry.
 */
typedef struct
{
    ipaddr_t subnet;        /**< The subnet address. */
    uint8_t  maskbits;      /**< The number of leading 1's in the subnet mask. */
    ipaddr_t gateway;       /**< The next hop to use. */
}
IpRoute;

/** IP header as a structure.
 */
typedef struct
{
    uint8_t  hLength:4;         /**< Length of header in 4 byte words. */
    uint8_t  version:4;
    uint8_t  tos;
    uint16_t tLength;
    uint16_t identification;
    uint16_t fragmentOffset:13;
    uint16_t flags:3;
    uint8_t  ttl;
    uint8_t  prot;
    uint16_t checksum;
    ipaddr_t sAddr;
    ipaddr_t dAddr;
}
ipheader_t;

/**************************************************************************
 * Global Variables
 **************************************************************************/

const ipaddr_t ipZero  = { { 0, 0, 0, 0 } };
const ipaddr_t ipBCast = { { 255, 255, 255, 255 } };
      ipaddr_t ipHost  = { { 0, 0, 0, 0 } };
      ipaddr_t ipSCast = { { 0, 0, 0, 0 } };

/**************************************************************************
 * Local Variables
 **************************************************************************/

#define IP_ROUTE_SUBNET   0
#define IP_ROUTE_GATEWAY  1

static IpRoute routeTable[2] = { { { { 0, 0, 0, 0 } }, 0, { { 0, 0, 0, 0 } } },
                                 { { { 0, 0, 0, 0 } }, 0, { { 0, 0, 0, 0 } } } };

/**************************************************************************
 * Local Functions
 **************************************************************************/

/** Write a mask of some number of bits to an IP address structure.
 * Returns a network mask of some number of bits.  For example, if passed
 * 12 as \a bits, the returned \a addr will contain { 0xff, 0xff, 0xf0, 0x00 }
 * where \a addr[3] = 0x00.
 *
 * \param[in] bits      The number of tailing 0's in the mask.
 * \param[in,out] addr  The address to populate.
 */
static void makeMask(uint8_t bits, ipaddr_t *const addr)
{
    for(uint8_t b = 0 ; b < sizeof(ipaddr_t); b++)
    {
        if(bits == 0)
        {
            addr->b[b] = 0;
        }
        else if(bits >= 8)
        {
            addr->b[b] = 0xff;
            bits -= 8;
        }
        else
        {
            addr->b[b] = ~(0xff >> bits);
            bits = 0;
        }
    }
}


/** Check the routing table to get the destination IP address for some packet.
 * Given a destination IP address, this checks the routing table to determine
 * to which host the packet should be sent.
 *
 * \param[in] addr  The ultimate destination IP address.
 * \returns  A pointer to the IP address of the next hop destination.
 * \retval NULL  If the next hop could not be found.
 */
static const ipaddr_t *getDestIp(const ipaddr_t *addr)
{
    printd("Ip: GetDestIp: %d.%d.%d.%d -> ",
           addr->b[0], addr->b[1], addr->b[2], addr->b[3]);

    /* Check each route */
    for(uint8_t n = 0; n < sizeof(routeTable) / sizeof(routeTable[0]); n++)
    {
        const IpRoute *route = &routeTable[n];
        ipaddr_t       mask;

        /* Construct the subnet mask */
        makeMask(route->maskbits, &mask);

        /* Check address and mask */
        if((addr->l & mask.l) == route->subnet.l)
        {
            /* Check if the gateway is this host itself */
            if(memcmp(&route->gateway, &ipHost, sizeof(ipaddr_t)) == 0)
            {
                printd("%d.%d.%d.%d (local)\n",
                       addr->b[0], addr->b[1], addr->b[2], addr->b[3]);

                /* Peer should be on the local link so can send direct */
                return addr;
            }
            else
            {
                printd("%d.%d.%d.%d (gateway)\n",
                       route->gateway.b[0], route->gateway.b[1],
                       route->gateway.b[2], route->gateway.b[3]);

                /* Needs routing via the gateway */
                return &route->gateway;
            }
        }
    }

    printd("no route to host\n");

    /* Nothing matched */
    return NULL;
}


/** Read an IP packet header from the Ethernet device buffer.
 * This reads a packet, performs some validation and then extracts some
 * of the useful data.  The protocol is returned, or IP_PROT_NULL if the
 * packet should be ignored for any reason.
 *
 * \note  This function is prevented from being inlined.  This is because
 *         it reads the IP header onto the stack, and would cause a large
 *         amount of stack space to be used for all descendant functions.
 *
 * \param[in,out] ipp  Pointer to fill with useful packet parameters.
 * \retval  IP_PROT_NULL if the packet should be ignored.
 * \returns The IP protocol number taken from the packet header.
 */
static uint8_t __attribute__ ((noinline)) readPacket(ipparam_t *const ipp)
{
    ipheader_t hdr;

    /* Read header */
    enc28j60RxPktRead(sizeof(ipheader_t), &hdr);

    /* Check the version, fragmented bit and length */
    if((hdr.version != IP_VER_4) ||
       (hdr.flags & IP_FLAG_MF) != 0 ||
       (unsigned)(hdr.hLength * 4) < sizeof(ipheader_t))
    {
        return IP_PROT_NULL;
    }

    /* Check if the packet should be allowed to pass */
    if(memcmp(&hdr.dAddr, &ipHost, sizeof(ipaddr_t)) != 0 &&
       memcmp(&hdr.dAddr, &ipBCast, sizeof(ipaddr_t)) != 0 &&
       memcmp(&hdr.dAddr, &ipSCast, sizeof(ipaddr_t)) != 0)
    {
        /* Not broadcast, or for our IP address */
        return IP_PROT_NULL;
    }

    /* Translate byte order for the length */
    hdr.tLength = ntohs(hdr.tLength);

    /* Skip any remaining header */
    enc28j60RxPktSkip((hdr.hLength * 4) - sizeof(ipheader_t));

    /* Save return parameters */
    ipp->hLen       = hdr.hLength * 4;
    ipp->payloadLen = hdr.tLength - ipp->hLen;
    ipp->sAddr      = hdr.sAddr;

    /* Return the protocol */
    return hdr.prot;
}

/**************************************************************************
 * Global Functions
 **************************************************************************/

/** Process an IP packet.
 * This assumes that the next bytes in the Ethernet device buffer are an IP
 * header, such that the data can be read and processed accordingly.
 *
 * \note Since IP provides routing and uses ARP to find destination MAC
 *        adddesses, there is no need for IP to be passed MAC addresses from
 *        the Ethernet layer.
 */
void IpProcessPacket(void)
{
    ipparam_t ipp;

    switch(readPacket(&ipp))
    {
        case IP_PROT_ICMP:
            IcmpProcessPacket(&ipp);
            break;

        case IP_PROT_UDP:
            UdpProcessPacket(&ipp);
            break;

        case IP_PROT_TCP:
            TcpProcessPacket(&ipp);
            break;

        case IP_PROT_NULL:
            /* Do nothing */
            break;
    }
}

/** Write headers from IP header downwards to the ethernet device.
 *
 * \param[in] sAddr   The source address for the packet.
 * \param[in] dAddr   The destination address for the packet.
 * \param[in] length  The the user data portion of the packet, which includes
 *                     any other protocol headers such as UDP.
 * \param[in] prot    The protocol to use for the field.
 */
boolean_t IpWriteHeader(const ipaddr_t *sAddr,
                        const ipaddr_t *dAddr,
                        const int16_t   length,
                        uint8_t         prot)
{
    ipheader_t hdr;
    uint32_t   csumState = 0;

    /* Write the ethernet header */
    if(memcmp(dAddr->b, ipBCast.b, sizeof(ipaddr_t)) == 0
#if defined(ENABLE_IP_SCAST)
       || memcmp(dAddr->b, ipSCast.b, sizeof(ipaddr_t)) == 0
#endif
                                                            )
    {
        enc28j60TxPktStart();
        EthWriteHeader(NULL);
    }
    else
    {
        /* Check the routing table */
        const macaddr_t *d = ArpLookup(getDestIp(dAddr));
        if(d == NULL)
        {
            return FALSE;
        }

        enc28j60TxPktStart();
        EthWriteHeader(d);
    }

    /* Zero the structure */
    memset(&hdr, 0, sizeof(ipheader_t));

    /* Copy in the addresses */
    memcpy(&hdr.sAddr, sAddr, sizeof(ipaddr_t));
    memcpy(&hdr.dAddr, dAddr, sizeof(ipaddr_t));

    /* Set other fields */
    hdr.version = IP_VER_4;
    hdr.hLength = sizeof(ipheader_t) / 4;
    hdr.ttl     = 128;
    hdr.prot    = prot;
    hdr.tLength = htons(length + sizeof(ipheader_t));

    /* Finally compute and set the checksum */
    hdr.checksum = IpChecksum(&csumState, sizeof(ipheader_t), &hdr);

    /* Add IP protocol identifier (not strictly part of IP) */
    enc28j60TxPktFill(1, 0x08);
    enc28j60TxPktFill(1, 0x00);

    /* Add IP header */
    enc28j60TxPktAppend(sizeof(ipheader_t), &hdr);

    return TRUE;
}


/** Compute an IP header checksum for some block of data.
 * Compute the IP 2's complement checksum for some block of data.
 * Multiple blocks can be checksummed in parts by storing and passing
 * \a *state.  The first block should be checksummed with \a *state passed
 * as 0.  If the checksum is to be computed in blocks, each block is assumed
 * to start at an even offset within the stream such that only the last
 * block can have an odd length.
 *
 * \param[in,out] state  Initial checksum state, which is then updated to
 *                        return the final checksum state.
 * \param[in]     n      The number of bytes to hash, which maybe 0.
 * \param[in]     data   Pointer to the bytes to hash.
 * \returns  The inverted 2's compliment IP checksum.
 */
uint16_t IpChecksum(uint32_t *const state, uint16_t n, const void *data)
{
    const uint8_t *d = (uint8_t *)data;
    uint32_t       r, s;

    /* Load the state */
    s = *state;

    /* If checksumming an odd count of bytes */
    if(n & 1)
    {
        /* Account for the last byte here and make even */
        s += d[--n];
    }

    /* Add an even count of bytes */
    while(n > 0)
    {
        /* Depending on whether it is an odd or even byte, shift
         *  the byte up to the correct part of the sum.
         */
        s += (n & 1) ? ((uint32_t)*d << 8) : (*d);
        d++; n--;
    }

    /* Save back the state */
    *state = s;

    /* Add the carries */
    r = s + (s >> 16);

    /* Invert, truncate and return checksum */
    return ~r;
}


/** Set the hosts IP address.
 *
 * \param[in] ipaddr   Pointer to the IP address to set.
 * \param[in] maskbits The length of the subnet mask.
 */
void IpSetHostAddr(const ipaddr_t *ipaddr, uint8_t maskbits)
{
    ipaddr_t m;

    /* Store the local IP address */
    memcpy(&ipHost, ipaddr, sizeof(ipaddr_t));

    /* Save gateway and bits */
    memcpy(&routeTable[IP_ROUTE_SUBNET].gateway, ipaddr, sizeof(ipaddr_t));
    routeTable[IP_ROUTE_SUBNET].maskbits = maskbits;

    /* Convert IP address to the subnet mask */
    makeMask(maskbits, &m);

    uint8_t b = sizeof(ipaddr_t);
    do
    {
        b--;

        /* Create the subnet mask */
        routeTable[IP_ROUTE_SUBNET].subnet.b[b] = ipaddr->b[b] & m.b[b];

        /* Create the subnet broadcast address */
        ipSCast.b[b] = ipaddr->b[b] | ~m.b[b];
    }
    while(b > 0);
}


/** Set an IP route.
 */
void IpSetRoute(const ipaddr_t *gateway,
                const ipaddr_t *subnet,
                const uint8_t   maskbits)
{
    /* Store the route */
    memcpy(&routeTable[IP_ROUTE_GATEWAY].subnet,  subnet, sizeof(ipaddr_t));
    memcpy(&routeTable[IP_ROUTE_GATEWAY].gateway, gateway, sizeof(ipaddr_t));
    routeTable[IP_ROUTE_GATEWAY].maskbits = maskbits;
}

/** Clear host address and route.
 */
void IpReset(void)
{
    /* Propagate reset to TCP */
    TcpReset();

    /* Erase local IP address and route */
    IpSetHostAddr(&ipZero, 32);
    IpSetRoute(&ipZero, &ipZero, 32);
}

/* END OF FILE */
