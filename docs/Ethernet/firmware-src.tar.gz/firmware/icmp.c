/***************************************************************************
 * icmp.c: ICMP layer for ATmega88.
 * Copyright (C) 2007 Michael C McTernan,
 *    Michael.McTernan.2001@cs.bris.ac.uk
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

/**************************************************************************
 * Include Files
 **************************************************************************/

#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include "enc28j60.h"
#include "icmp.h"

/**************************************************************************
 * Manifest Constants
 **************************************************************************/

#define ICMP_ECHO_REP    0
#define ICMP_ECHO_REQ    8

/**************************************************************************
 * Global functions
 **************************************************************************/

void IcmpProcessPacket(const ipparam_t *ipp)
{
    uint8_t type;

    enc28j60RxPktRead(1, &type);

    switch(type)
    {
        case ICMP_ECHO_REQ:
        {
            /* IP header, send from this host incase responding to broadcast */
            if(IpWriteHeader(&ipHost,
                             &ipp->sAddr,
                             ipp->payloadLen,
                             IP_PROT_ICMP))
            {
                /* Write the ICMP reply */
                enc28j60TxPktFill(1, ICMP_ECHO_REP);

                /* Copy the code */
                enc28j60TxPktAppendRx(1);

                uint16_t csum;

                /* Read the checksum */
                enc28j60RxPktRead(2, &csum);

                /* The request has been turned into a reply, removing 8.
                 *  Rather than recompute the checksum, it can be adjusted.
                 */
                if((csum + 8) < csum) csum++; /* Check it if would roll over */
                csum += 8;
                enc28j60TxPktAppend(2, &csum);

                /* Copy the remaining data */
                enc28j60TxPktAppendRx(ipp->payloadLen);

                enc28j60TxPktSend();
            }
            break;
        }
    }
}


/** Send an ICMP echo request to some host.
 *
 * \param[in] addr  The IP address of the host to which the 'ping' should be
 *                   sent.
 */
void IcmpPing(const ipaddr_t *addr)
{
    if(IpWriteHeader(&ipHost, addr, 8 + 32, IP_PROT_ICMP))
    {
        enc28j60TxPktFill(1, ICMP_ECHO_REQ);
        enc28j60TxPktFill(1, 0);
        enc28j60TxPktFill(1, 0xea);  /* Pre-computed checksum */
        enc28j60TxPktFill(1, 0xf2);
        enc28j60TxPktFill(4, 0);
        enc28j60TxPktFill(32, 0xd0); /* Payload pattern */

        enc28j60TxPktSend();
    }
}

/* END OF FILE */
