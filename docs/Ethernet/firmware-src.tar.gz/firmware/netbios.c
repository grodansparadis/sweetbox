/***************************************************************************
 * netbios.c: NetBIOS NBMS partial implementation ATmega88.
 * Copyright (C) 2007 Michael C McTernan,
 *    Michael.McTernan.2001@cs.bris.ac.uk
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

#if !defined(ON_PC)
#include <avr/pgmspace.h>
#else
#define PROGMEM
#endif
#include <stdint.h>
#include <stdlib.h>
#include "enc28j60.h"
#include "netbios.h"
#include "ip.h"

/**************************************************************************
 * Manifest Constants
 **************************************************************************/

#define NETBIOS_OPCODE_BIT_REQUEST  0x10
#define NETBIOS_OPCODE_QUERY        0
#define NETBIOS_OPCODE_REGISTRATION 5
#define NETBIOS_OPCODE_RELEASE      6
#define NETBIOS_OPCODE_WACK         7
#define NETBIOS_OPCODE_REFRESH      8

/**************************************************************************
 * Types
 **************************************************************************/

typedef struct
{
    uint16_t trnId;

    union
    {
        uint16_t op;

        struct
        {
            uint16_t rcode:4;
            uint16_t nmflags:7;
            uint16_t opcode:5;
        } s;
    } u;

    uint16_t qdcount;
    uint16_t ancount;
    uint16_t nscount;
    uint16_t arcount;
}
netbiosheader_t;

#define M_NetBiosChar(c) ((c >> 4) + 'A'), ((c & 0x0f) + 'A')

static const PROGMEM uint8_t netbiosName[] =
    { 0x20,
      M_NetBiosChar('L'),  /*  0x45, 0x4d, */
      M_NetBiosChar('I'),  /*  0x45, 0x4a, */
      M_NetBiosChar('G'),  /*  0x45, 0x48, */
      M_NetBiosChar('H'),  /*  0x45, 0x49, */
      M_NetBiosChar('T'),  /*  0x46, 0x45, */
      M_NetBiosChar('B'),  /*  0x45, 0x43, */
      M_NetBiosChar('U'),  /*  0x46, 0x46, */
      M_NetBiosChar('L'),  /*  0x45, 0x4d, */
      M_NetBiosChar('B'),  /*  0x45, 0x43, */
      M_NetBiosChar(' '),  /*  0x43, 0x41, */
      M_NetBiosChar(' '),  /*  0x43, 0x41, */
      M_NetBiosChar(' '),  /*  0x43, 0x41, */
      M_NetBiosChar(' '),  /*  0x43, 0x41, */
      M_NetBiosChar(' '),  /*  0x43, 0x41, */
      M_NetBiosChar(' '),  /*  0x43, 0x41, */
      M_NetBiosChar('\0'), /*  0x41, 0x41, */
      0x00,
      0x00, 0x20, /* RR_TYPE:  NB */
      0x00, 0x01, /* RR_CLASS: IN */
    };

/**************************************************************************
 * Local functions
 **************************************************************************/


/**************************************************************************
 * Global Functions
 **************************************************************************/

#if 0
/** Claim the name on the sub-net.
 * This doesn't actually seem to flush caches on Windows PCs, viewable with
 * 'nbtstat.exe -c'.  Watching an XP machine have its IP address changed,
 * showed that it didn't take any special actions not implemented here, and
 * also didn't clear the cache of a second XP machine on the sub-net.
 * Therefore it seems that NBNS doesn't really have a way to 'claim' a name,
 * only to discover and avoid collisions.
 *
 */
void NetBiosNsSetHostname(void)
{
    /* IP header */
    if(UdpWriteHeader(&ipHost,
                      &ipSCast,
                      UDP_PORT_NETBIOS_NS,
                      UDP_PORT_NETBIOS_NS,
                      68))
    {
        netbiosheader_t hdr;

        //hdr.trnId   = random();
        hdr.u.op    = htons(t == 3 ? 0x2810 : 0x2910);
        hdr.qdcount = htons(1);
        hdr.ancount = 0;
        hdr.nscount = 0;
        hdr.arcount = htons(1);

        enc28j60TxPktAppend(sizeof(hdr), &hdr);

        /* QUESTION_NAME */
        enc28j60TxPktAppendPrgMem(sizeof(netbiosName), netbiosName);

        /* RR_NAME, pointer back the QUESTION NAME */
        enc28j60TxPktFill(1, 0xc0);
        enc28j60TxPktFill(1, 0x0c);
        enc28j60TxPktAppendPrgMem(4, &netbiosName[sizeof(netbiosName) - 4]);

        /* TTL */
        enc28j60TxPktFill(4, 0x01);

        /* RDLENGTH */
        enc28j60TxPktFill(1, 0x00);
        enc28j60TxPktFill(1, 0x06);

        /* NB_FLAGS */
        enc28j60TxPktFill(1, 0x60);
        enc28j60TxPktFill(1, 0x00);

        /* NB_ADDRESS */
        enc28j60TxPktAppend(sizeof(ipaddr_t), ipHost.b);

        enc28j60TxPktSend();
    }
}
#endif

void NetBiosNsProcessPacket(const ipparam_t  *ipp)
{
    netbiosheader_t hdr;

    /* Read the header */
    enc28j60RxPktRead(sizeof(hdr), &hdr);
    hdr.u.op = ntohs(hdr.u.op);

    switch(hdr.u.s.opcode)
    {
        case NETBIOS_OPCODE_QUERY:
            /* Name request, check if it is for this host */
            if(enc28j60RxPktCmpPrgMem(sizeof(netbiosName), netbiosName))
            {
                /* IP header */
                if(UdpWriteHeader(&ipHost,
                                  &ipp->sAddr,
                                  UDP_PORT_NETBIOS_NS,
                                  UDP_PORT_NETBIOS_NS,
                                  62))
                {
                    /* Write the header Id */
                    enc28j60TxPktAppend(2, &hdr.trnId);
                    enc28j60TxPktFill(1, 0x85);
                    enc28j60TxPktFill(4, 0x00);
                    enc28j60TxPktFill(1, 0x01);
                    enc28j60TxPktFill(4, 0x00);

                    /* RR_NAME, RR_TYPE, RR_CLASS */
                    enc28j60TxPktAppendPrgMem(sizeof(netbiosName), netbiosName);

                    /* TTL, 0 = infinite */
                    enc28j60TxPktFill(1, 0x00);
                    enc28j60TxPktFill(3, 0x0f);

                    /* RDLENGTH */
                    enc28j60TxPktFill(1, 0x00);
                    enc28j60TxPktFill(1, 0x06);

                    /* NB_FLAGS */
                    enc28j60TxPktFill(1, 0x60);
                    enc28j60TxPktFill(1, 0x00);

                    /* NB_ADDRESS */
                    enc28j60TxPktAppend(sizeof(ipaddr_t), ipHost.b);

                    enc28j60TxPktSend();
                }
            }
            break;
    }
}

/* END OF FILE */
