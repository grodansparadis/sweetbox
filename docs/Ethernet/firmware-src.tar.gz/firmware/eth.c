/***************************************************************************
 * eth.h: Ethernet layer for ATmega88.
 * Copyright (C) 2007 Michael C McTernan,
 *    Michael.McTernan.2001@cs.bris.ac.uk
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

/**************************************************************************
 * Includes
 **************************************************************************/

#include <stdint.h>
#include <stdio.h>
#include "enc28j60.h"
#include "event.h"
#include "timer.h"
#include "arp.h"
#include "ip.h"

/**************************************************************************
 * Manifest Constants
 **************************************************************************/


#define ETH_TYPE_ARP  0x06
#define ETH_TYPE_IP   0x00

/**************************************************************************
 * Global Functions
 **************************************************************************/

void EthProcessPacket(void *arpConflict)
{
    /* Setup processing of packet */
    if(enc28j60RxPktStart())
    {
        uint8_t   prot[2];
        macaddr_t smac;

        /* Skip destination MAC, read source */
        enc28j60RxPktSkip(6);
        enc28j60RxPktRead(sizeof(macaddr_t), smac.b);

        /* Read the protocol field */
        enc28j60RxPktRead(2, prot);

        /* Check if it is an ARP packet */
        if(prot[0] == 0x08)
        {
            switch(prot[1])
            {
                case ETH_TYPE_ARP:
                    ArpProcessPacket(TRUE, (boolean_t *)arpConflict);
                    break;
                case ETH_TYPE_IP:
                    IpProcessPacket();
                    break;
            }
        }

        /* Discard packet */
        enc28j60RxPktFree();
    }
}


/** Write and Ethernet header.
 * This writes the destination MAC address and the local hosts MAC address
 * to start a packet.
 *
 * \param[in] dMac  The destination MAC address to write, or NULL if the
 *                   broadcast address is required.
 */
void EthWriteHeader(const macaddr_t *dMac)
{
    if(dMac != NULL)
    {
        enc28j60TxPktAppend(sizeof(macaddr_t), &dMac->b[0]);
    }
    else
    {
        enc28j60TxPktWriteMacAddr(MAC_ADDR_TYP_BCAST);
    }

    enc28j60TxPktWriteMacAddr(MAC_ADDR_TYP_LOCAL);
}

/** Waits until a packet is recieved, EV_TIMER_GEN is set, or the link goes down.
 *
 * \param[in,out] arpConflict  Pointer which, if non-NULL, is set to TRUE if an
 *                              ARP conflict is detected.
 * \retval TRUE if a packet was recieved or the timer expired.
 * \retval FALSE if the link failed.
 */
boolean_t EthWaitPacket(boolean_t *arpConflict)
{
    do
    {
        SleepUntilIsr();

        /* Check if an ethernet event occured */
        if(M_EventIsSet(EV_ETH))
        {
            /* Clear the event */
            EVENT_REG &= ~(1<<EV_ETH);

            /* Handle ethernet events */
            enc28j60HandleEvents(NULL, NULL,
                                 EthProcessPacket, arpConflict);
            return TRUE;
        }

    }
    while(!M_EventIsSet(EV_TIMER_GEN) && enc28j60IsLinkUp());

    /* Fail if the link goes down */
    return enc28j60IsLinkUp();
}

/* END OF FILE */
