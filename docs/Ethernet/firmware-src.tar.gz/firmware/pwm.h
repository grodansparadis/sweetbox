/***************************************************************************
 * pwm.c: Pulse Width Modulation controller for ATmega88.
 * Copyright (C) 2007 Michael C McTernan,
 *    Michael.McTernan.2001@cs.bris.ac.uk
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

#ifndef PWM_H
#define PWM_H

/**************************************************************************
 * Includes
 **************************************************************************/

#if !defined(ON_PC)
#include <avr/io.h>
#endif
#include <stdint.h>

/**************************************************************************
 * Macros
 **************************************************************************/

#if !defined(ON_PC)
#define M_PwmReadR() OCR0B
#define M_PwmReadG() OCR2B
#define M_PwmReadB() OCR0A
#else
#define M_PwmReadR() pwmR
#define M_PwmReadG() pwmG
#define M_PwmReadB() pwmB

#define PwmSet(v)                                   \
{                                                   \
    printf("R%3u G%3u B%3u\n", v[0], v[1], v[2]);   \
    pwmR = v[0]; pwmG = v[1]; pwmB = v[2];          \
}

extern uint8_t pwmR, pwmG, pwmB;
#endif

/**************************************************************************
 * Prototypes
 **************************************************************************/

#define PwmInit()

#if !defined(ON_PC)
void    PwmSet(const uint8_t c[3]);
#endif

#endif

/* END OF FILE */
