/***************************************************************************
 * timer_pc.c: Timer unit for ATmega88.
 * Copyright (C) 2007 Michael C McTernan,
 *    Michael.McTernan.2001@cs.bris.ac.uk
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

/**************************************************************************
 * Include Files
 **************************************************************************/

#include <stdint.h>
#include <unistd.h>
#include <assert.h>
#include <pthread.h>
#include <inttypes.h>
#include "timer.h"
#include "event.h"
#include "eprom.h"
#include "seq.h"

/**************************************************************************
 * Macros
 **************************************************************************/

/** Bitmap of timers that are enabled. */
static uint8_t timersEn = 0;

/** Bitmap of low-speed timers that are enabled. */
static uint8_t timersEnLs = 0;


/**************************************************************************
 * Local variables
 **************************************************************************/

static uint32_t timersCount[NUM_TICK_TIMERS];

pthread_t timerHsTickThread;
pthread_t timerLsTickThread;

pthread_mutex_t timerMutex  = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t  timerCondHs = PTHREAD_COND_INITIALIZER;
pthread_cond_t  timerCondLs = PTHREAD_COND_INITIALIZER;

/**************************************************************************
 * Local Functions
 **************************************************************************/

static char *timerName(timerid_t timer)
{
    switch(timer)
    {
        case TIMER_GEN:            return "TIMER_GEN";
        case TIMER_DHCP_RENEW:     return "TIMER_DHCP_RENEW";
        case TIMER_DHCP_REBIND:    return "TIMER_DHCP_REBIND";
        case TIMER_SEQ_SUSPEND:    return "TIMER_SEQ_SUSPEND";
        case NUM_TICK_TIMERS:      return "NUM_TICK_TIMERS";
        case TIMER_SEQ:            return "TIMER_SEQ";
        case TIMER_TCP_RETRANSMIT: return "TIMER_TCP_RETRANSMIT";
        case TIMER_EPROM_REPROG:   return "TIMER_EPROM_REPROG";
        default:                   return "????";
    }
}


/** Stop a timer, without locking mutex.
 * This stops a timer, but without performing any locking such that deadlock
 * can be avoided.
 */
static void timerStopUnsafe(timerid_t timer)
{
    /* Check that it is already locked */
    assert(pthread_mutex_trylock(&timerMutex) != 0);

    printf("TimerStop: %s\n", timerName(timer));
    timersEnLs &= ~(1<<timer);
    timersEn   &= ~(1<<timer);
}


/** Run the tick timers with IDs in a given mask.
 */
static void runTickTimers(uint8_t mask)
{
    /* Modify the mask to contain only enabled timers */
    mask &= timersEn;

    /* Now check the timers */
    for(uint8_t t = 0; t < NUM_TICK_TIMERS; t++)
    {
        /* Check if the timer should be examined */
        if((mask & 1) != 0)
        {
            /* Check for expiry conditions */
            if(timersCount[t] == 0)
            {
                printf("TimerExpiry: %s\n", timerName(t));

                /* Disable timer */
                timerStopUnsafe(t);

                /* Call handling function */
                switch(t)
                {
                    case TIMER_GEN:
                        M_EventSet(EV_TIMER_GEN);
                        break;

                    case TIMER_DHCP_RENEW:
                        M_EventSet(EV_TIMER_DHCP_RENEW);
                        break;

                    case TIMER_DHCP_REBIND:
                        M_EventSet(EV_TIMER_DHCP_REBIND);
                        break;

                    case TIMER_SEQ_SUSPEND:
                        SeqResume();
                        break;

                    case TIMER_TCP_RETRANSMIT:
                        M_EventSet(EV_TIMER_TCP_RETRANSMIT);
                        break;

                    case TIMER_EPROM_REPROG:
                        EpromAllowReprogramming(FALSE);
                        break;
                }
            }
            else
            {
                timersCount[t]--;
            }
        }

        mask >>= 1;
    }
}

void *timerLsTickLoop(void *v)
{
    while(1)
    {
        pthread_mutex_lock(&timerMutex);

        runTickTimers(timersEnLs);
        EventIsr();

        if(!timersEnLs) pthread_cond_wait(&timerCondLs, &timerMutex);


        pthread_mutex_unlock(&timerMutex);

        /* Wait 1 second */
        usleep(1000000);
    }
}

void *timerHsTickLoop(void *v)
{
    while(1)
    {
        pthread_mutex_lock(&timerMutex);

        /* Check if the sequencer timer is running */
        if((timersEn & (1<<TIMER_SEQ)) != 0)
        {
            pthread_mutex_unlock(&timerMutex);
            SeqTick();
            pthread_mutex_lock(&timerMutex);
        }

        runTickTimers(~timersEnLs);
        EventIsr();

        if(!(timersEn & ~timersEnLs)) pthread_cond_wait(&timerCondHs, &timerMutex);

        pthread_mutex_unlock(&timerMutex);

        /* Wait 4 ms */
        usleep(4000);
    }
}


/**************************************************************************
 * Global Functions
 **************************************************************************/

void TimerInit(void)
{
    printf("TimerInit\n");
    pthread_create(&timerHsTickThread, NULL, timerHsTickLoop, NULL);
    pthread_create(&timerLsTickThread, NULL, timerLsTickLoop, NULL);
}

/** Start a timer.
 * Start some timer, with an optional timeout duration.
 *
 * \param[in] timer  The identifier for the timer.
 * \param[in] hSecs  The duration in hundreths of a second.
 */
void TimerHsStart(timerid_t timer, uint8_t hSecs)
{
    pthread_mutex_lock(&timerMutex);

    printf("TimerHsStart: %s, %u\n", timerName(timer), hSecs);

    /* Store the duration in ticks if a ticker */
    if(timer < NUM_TICK_TIMERS)
    {
        timersCount[timer] = ((uint32_t)hSecs) * 25;
    }

    /* Mark timer as highspeed and running */
    timersEnLs &= ~(1<<timer);
    timersEn   |= 1<<timer;

    pthread_cond_signal(&timerCondHs);
    pthread_mutex_unlock(&timerMutex);

}

void TimerLsStart(timerid_t timer, uint32_t secs)
{
    pthread_mutex_lock(&timerMutex);
    printf("TimerLsStart: %s, %" PRIu32 "\n", timerName(timer), secs);

    /* Store the duration in ticks if a ticker */
    if(timer < NUM_TICK_TIMERS)
    {
        timersCount[timer] = secs;
    }

    /* Mark timer as lowspeed and running */
    timersEnLs |= 1<<timer;
    timersEn   |= 1<<timer;

    pthread_cond_signal(&timerCondLs);
    pthread_mutex_unlock(&timerMutex);
}


void TimerStop(timerid_t timer)
{
    pthread_mutex_lock(&timerMutex);

    timerStopUnsafe(timer);

    pthread_mutex_unlock(&timerMutex);
}

/* END OF FILE */
