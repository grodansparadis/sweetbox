/***************************************************************************
 * pwm.c: Pulse Width Modulation controller for ATmega88.
 * Copyright (C) 2007 Michael C McTernan,
 *    Michael.McTernan.2001@cs.bris.ac.uk
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

/**************************************************************************
 * Includes
 **************************************************************************/

#include <stdint.h>
#include <assert.h>
#include "main.h"
#include "pwm.h"

/**************************************************************************
 * Local Variables
 **************************************************************************/

/**************************************************************************
 * Global Variables
 **************************************************************************/

#if defined(ON_PC)
uint8_t pwmR = 0, pwmG = 0, pwmB = 0;
#endif

/**************************************************************************
 * Local Functions
 **************************************************************************/

/**************************************************************************
 * Global Functions
 **************************************************************************/

#if !defined(ON_PC)
void PwmSet(const uint8_t v[3])
{
    uint8_t offMask = 0, onMask = 0;

    for(uint8_t t = 0; t < 3; t++)
    {
        uint8_t bit;

        /* Get the output bit for the channel */
        switch(t)
        {
            case 0:
                bit = (1<<DDD5);
                break;
            case 1:
                bit = (1<<DDD3);
                break;
            case 2:
                bit = (1<<DDD6);
                break;
        }

        /* Check if channel has output */
        if(v[t] != 0)
        {
            /* If PWM output required but HW is disabled, switch on */
            if(!onMask && (PRR & ((1<<PRTIM2) | (1<<PRTIM0))) != 0)
            {
                /* Ensure HW blocks are enabled */
                PRR &= ~((1<<PRTIM2) | (1<<PRTIM0));

                /* Enable PD3/5/6 as outputs */
                DDRD |= (1<<DDD3) | (1<<DDD5) | (1<<DDD6);

                /* Configue fast PWM with:
                 *  output set on OCRx match, cleared at top for both A and B
                 *  fast PWM Top=0xff, TOV at match.
                 */
                TCCR0A = (1<<COM0A1) | (1<<COM0B1) | (1<<WGM01) | (1<<WGM00);
                TCCR2A =               (1<<COM2B1) | (1<<WGM01) | (1<<WGM00);

                /* Set prescalers to /1 */
                TCCR0B = (1<<CS00);
                TCCR2B = (1<<CS20);
            }

            /* Ensure output is enabled */
            onMask |= bit;
        }
        else
        {
            /* Clear DDR to force low */
            offMask |= bit;
        }

        /* Write PWM timer count.
         *  This is always written to store the
         *  last output incase it is read back.
         */
        switch(t)
        {
            case 0:
                OCR0B = v[t];
                break;
            case 1:
                OCR2B = v[t];
                break;
            case 2:
                OCR0A = v[t];
                break;
        }
    }

    /* Set the new outputs */
    DDRD &= ~offMask;
    DDRD |= onMask;

    /* Disable timer HW if outputs are all zero */
    if(!onMask)
    {
        PRR |= (1<<PRTIM2) | (1<<PRTIM0);
    }
}
#endif

/* END OF FILE */

