/***************************************************************************
 * arp.h: Address Resolution Protocol for ATmega88 and enc28j60.
 * Copyright (C) 2007 Michael C McTernan,
 *    Michael.McTernan.2001@cs.bris.ac.uk
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

#ifndef ARP_H
#define ARP_H

/**************************************************************************
 * Includes
 **************************************************************************/

#include <stdint.h>
#include "main.h"
#include "eth.h"
#include "ip.h"

/**************************************************************************
 * Types
 **************************************************************************/

/**************************************************************************
 * Prototypes
 **************************************************************************/

void      ArpClearIpAddress   (void);
void      ArpSetIpAddress     (const ipaddr_t *ip);
void      ArpAnnounce         (void);
void      ArpRequestMacAddress(const ipaddr_t *ip,
                               boolean_t       cloaked);
void      ArpProcessPacket    (boolean_t       allowReply,
                               boolean_t      *conflict);
const macaddr_t *ArpLookup    (const ipaddr_t *ip);


#endif

/* END OF FILE */

