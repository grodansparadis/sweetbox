/***************************************************************************
 * event_pc.c: PC simulation for event.
 * Copyright (C) 2007 Michael C McTernan,
 *    Michael.McTernan.2001@cs.bris.ac.uk
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

#include <stdint.h>
#include <pthread.h>
#include "main.h"
#include "event.h"

/**************************************************************************
 * Global Variables
 **************************************************************************/

uint8_t evRegister = 0;

static pthread_mutex_t evMutex =  PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  evCond  =  PTHREAD_COND_INITIALIZER;

/**************************************************************************
 * Global Functions
 **************************************************************************/

void SleepUntilIsr(void)
{
    pthread_mutex_lock(&evMutex);
    pthread_cond_wait(&evCond, &evMutex);
    pthread_mutex_unlock(&evMutex);
}

void EventIsr(void)
{
    pthread_cond_signal(&evCond);
}

void EventSetPc(uint8_t evMask)
{
    pthread_mutex_lock(&evMutex);
    evRegister |= evMask;
    pthread_cond_signal(&evCond);
    pthread_mutex_unlock(&evMutex);

}

void EventClrPc(uint8_t evMask)
{
    pthread_mutex_lock(&evMutex);
    evRegister &= ~evMask;
    pthread_mutex_unlock(&evMutex);
}

boolean_t EventIsSetPc(uint8_t evMask)
{
    boolean_t r;

    pthread_mutex_lock(&evMutex);
    r = (evRegister & evMask) ? TRUE : FALSE;
    pthread_mutex_unlock(&evMutex);

    return r;
}

/* END OF FILE */
