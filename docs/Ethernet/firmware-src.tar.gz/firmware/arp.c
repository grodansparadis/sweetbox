/***************************************************************************
 * arp.h: Address Resolution Protocol for ATmega88 and enc28j60.
 * Copyright (C) 2007 Michael C McTernan,
 *    Michael.McTernan.2001@cs.bris.ac.uk
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

/**************************************************************************
 * Includes
 **************************************************************************/

#if !defined(ON_PC)
#include <avr/pgmspace.h>
#else
#define PROGMEM
#endif
#include <stdint.h>
#include <string.h>
#include "main.h"
#include "enc28j60.h"
#include "arp.h"

/**************************************************************************
 * Manifest Constants
 **************************************************************************/

#define ARP_REQ  1
#define ARP_REP  2

/** Number of elements in the ARP cache.
 */
#define ARP_CACHE_ELEMENTS 4

/**************************************************************************
 * Types
 **************************************************************************/

typedef struct
{
    macaddr_t mac;
    ipaddr_t  ip;
    uint8_t   timestamp:7;
    boolean_t valid:1;
}
ArpCache;

/**************************************************************************
 * Variables
 **************************************************************************/

/** Cache of known IP,MAC addresses.
 */
static ArpCache arpCache[ARP_CACHE_ELEMENTS];

/** The current IP address of the host.
 */
static ipaddr_t ipAddress;

/** ARP packet header for IP and ethernet MAC addresses.
 */
static const uint8_t PROGMEM arpHeader[] =
        { 0x08, 0x06, 0x00, 0x01, 0x08, 0x00, 0x06, 0x04, 0x00 };

/**************************************************************************
 * Local Functions
 **************************************************************************/

static ArpCache *searchCache(const ipaddr_t *ipAddr)
{
   uint8_t t = ARP_CACHE_ELEMENTS;

   do
   {
       t--;

        /* Check if this is the sought entry */
        if(memcmp(&arpCache[t].ip, ipAddr, sizeof(ipaddr_t)) == 0)
        {
            return &arpCache[t];
        }
   }
   while(t > 0);

   return NULL;
}

/**************************************************************************
 * Global Functions
 **************************************************************************/

/** Clear the locally stored IP address.
 */
void ArpClearIpAddress(void)
{
    memset(&ipAddress, 255, sizeof(ipaddr_t));
}


/** Set our local IP address.
 */
void ArpSetIpAddress(const ipaddr_t *ip)
{
    /* Store locally */
    memcpy(&ipAddress, ip, sizeof(ipaddr_t));
}


/** Send a gratuitous ARP packet announcing our IP address.
 */
void ArpAnnounce(void)
{
    /* Start a gratuitous ARP packet */
    enc28j60TxPktStart();

    /* To all from us */
    enc28j60TxPktWriteMacAddr(MAC_ADDR_TYP_BCAST);
    enc28j60TxPktWriteMacAddr(MAC_ADDR_TYP_LOCAL);

    /* Add ARP header for MAC/IP */
    enc28j60TxPktAppendPrgMem(sizeof(arpHeader), arpHeader);

    /* Set the operation code */
    enc28j60TxPktFill(1, ARP_REQ);

    /* Set sha and spa */
    enc28j60TxPktWriteMacAddr(MAC_ADDR_TYP_LOCAL);
    enc28j60TxPktAppend(sizeof(ipaddr_t), &ipAddress);

    /* Set tha and tpa */
    enc28j60TxPktWriteMacAddr(MAC_ADDR_TYP_ZERO);
    enc28j60TxPktAppend(sizeof(ipaddr_t), &ipAddress);

    /* Send */
    enc28j60TxPktSend();
}


/** Send a request for some MAC address.
 * This sends an ARP request on the wire.
 *
 * \param[in] ip      The IP address for which the MAC address is required.
 * \param[in] cloaked If TRUE, do not include this hosts IP address in the
 *                     request.
 */
void ArpRequestMacAddress(const ipaddr_t *ip,
                          boolean_t       cloaked)
{
    /* Send a request */
    enc28j60TxPktStart();

    /* To all from us */
    enc28j60TxPktWriteMacAddr(MAC_ADDR_TYP_BCAST);
    enc28j60TxPktWriteMacAddr(MAC_ADDR_TYP_LOCAL);

    /* Add ARP header for MAC/IP */
    enc28j60TxPktAppendPrgMem(sizeof(arpHeader), arpHeader);

    /* Set the operation code */
    enc28j60TxPktFill(1, ARP_REQ);

    /* Set sha and spa */
    enc28j60TxPktWriteMacAddr(MAC_ADDR_TYP_LOCAL);
    if(!cloaked)
    {
        enc28j60TxPktAppend(sizeof(ipaddr_t), &ipAddress);
    }
    else
    {
        /* Don't set our IP address */
        enc28j60TxPktFill(sizeof(ipaddr_t), 0);
    }

    /* Set tha and tpa */
    enc28j60TxPktWriteMacAddr(MAC_ADDR_TYP_ZERO);
    enc28j60TxPktAppend(sizeof(ipaddr_t), ip);

    /* Send */
    enc28j60TxPktSend();
}


/** Process an ARP packet.
 *
 */
void ArpProcessPacket(boolean_t allowReply, boolean_t *conflict)
{
    /* Check if it is a valid ARP packet */
    if(enc28j60RxPktCmpPrgMem(sizeof(arpHeader) - 2, &arpHeader[2]))
    {
        uint8_t   op;
        macaddr_t sMac;
        ipaddr_t  sIp;

        /* Read the operation */
        enc28j60RxPktRead(1, &op);

        /* Read requesters MAC and IP address */
        enc28j60RxPktRead(sizeof(macaddr_t), &sMac);
        enc28j60RxPktRead(sizeof(ipaddr_t), &sIp);

        /* Check if this should be added to the cache */
        ArpCache *cache = searchCache(&sIp);
        if(cache != NULL)
        {
            /* Store in cache */
            memcpy(&cache->mac, &sMac, sizeof(macaddr_t));
            cache->valid = TRUE;
            cache->timestamp = 0;
        }

        /* Optionally check for configuration conflict */
        if(conflict != NULL && memcmp(sIp.b, ipAddress.b, sizeof(ipaddr_t)) == 0)
        {
            macaddr_t thisMac;

            enc28j60GetMac(&thisMac);
            if(memcmp(thisMac.b, sMac.b, sizeof(macaddr_t)) != 0)
            {
                *conflict  = TRUE;

                /* Having detected a conflict, don't try to respond */
                allowReply = FALSE;
            }
        }

        /* Check if this is a request that should be handled */
        if(op == ARP_REQ && allowReply)
        {
            /* Skip target MAC address (should be 0x000000) */
            enc28j60RxPktSkip(sizeof(macaddr_t));

            /* Check if it is requesting our IP address */
            if(enc28j60RxPktCmp(sizeof(ipaddr_t), &ipAddress))
            {
                /* Start a reply packet */
                enc28j60TxPktStart();

                /* To requester from us */
                enc28j60TxPktAppend(sizeof(macaddr_t), sMac.b);
                enc28j60TxPktWriteMacAddr(MAC_ADDR_TYP_LOCAL);

                /* Add ARP header for MAC/IP */
                enc28j60TxPktAppendPrgMem(sizeof(arpHeader), arpHeader);

                /* Set the operation code */
                enc28j60TxPktFill(1, ARP_REP);

                /* Set sha and spa */
                enc28j60TxPktWriteMacAddr(MAC_ADDR_TYP_LOCAL);
                enc28j60TxPktAppend(sizeof(ipaddr_t), ipAddress.b);

                /* Set tha and tpa */
                enc28j60TxPktAppend(sizeof(macaddr_t), sMac.b);
                enc28j60TxPktAppend(sizeof(ipaddr_t), sIp.b);

                /* Send */
                enc28j60TxPktSend();
            }
        }
    }
}

/** Lookup the MAC address for some host.
 *
 */
const macaddr_t *ArpLookup(const ipaddr_t *ipAddr)
{
    ArpCache *result;

    /* If passed NULL, return NULL */
    if(ipAddr == NULL)
    {
        return NULL;
    }

    /* Search the cache */
    result = searchCache(ipAddr);
    if(result != NULL && result->valid)
    {
        return &result->mac;
    }
    else
    {
        ArpCache *oldest = &arpCache[ARP_CACHE_ELEMENTS - 1];
        uint8_t   t      = ARP_CACHE_ELEMENTS - 1;

        /* Check the cache entries */
        do
        {
            t--;

            if(arpCache[t].valid)
            {
                /* Decide if this entry is a candidate for replacement */
                if(arpCache[t].timestamp > oldest->timestamp)
                {
                    oldest = &arpCache[t];
                }
            }
            else
            {
                /* Prefer to replace invalid entries */
                if(oldest->valid)
                {
                    oldest = &arpCache[t];
                }
            }
        }
        while(t > 0);

        /* Add IP address and timestamp to the cache */
        memcpy(&oldest->ip, ipAddr, sizeof(ipaddr_t));
        oldest->timestamp = 0;
        oldest->valid     = FALSE;

        /* Make a request */
        ArpRequestMacAddress(ipAddr, FALSE);

        return NULL;
    }
}

/* END OF FILE */
