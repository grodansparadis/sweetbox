/***************************************************************************
 * timer.c: Timer unit for ATmega88.
 * Copyright (C) 2007 Michael C McTernan,
 *    Michael.McTernan.2001@cs.bris.ac.uk
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

/**************************************************************************
 * Include Files
 **************************************************************************/

#include <stdint.h>
#include <avr/interrupt.h>
#include <avr/io.h>
#include "eprom.h"
#include "timer.h"
#include "event.h"
#include "seq.h"

/**************************************************************************
 * Macros
 **************************************************************************/

/** Bitmap of timers that are enabled. */
#define timersEn GPIOR1

/** Bitmap of low-speed timers that are enabled. */
static uint8_t timersEnLs = 0;


/**************************************************************************
 * Local variables
 **************************************************************************/

static uint32_t timersCount[NUM_TICK_TIMERS];

/**************************************************************************
 * Local Functions
 **************************************************************************/

/** Run the tick timers with IDs in a given mask.
 */
static void runTickTimers(uint8_t mask)
{
    /* Modify the mask to contain only enabled timers */
    mask &= timersEn;

    /* Now check the timers */
    for(uint8_t t = 0; t < NUM_TICK_TIMERS; t++)
    {
        /* Check if the timer should be examined */
        if((mask & 1) != 0)
        {
            /* Check for expiry conditions */
            if(timersCount[t] == 0)
            {
                /* Disable timer */
                TimerStop(t);

                /* Call handling function */
                switch(t)
                {
                    case TIMER_GEN:
                        M_EventSet(EV_TIMER_GEN);
                        break;

                    case TIMER_DHCP_RENEW:
                        M_EventSet(EV_TIMER_DHCP_RENEW);
                        break;

                    case TIMER_DHCP_REBIND:
                        M_EventSet(EV_TIMER_DHCP_REBIND);
                        break;

                    case TIMER_SEQ_SUSPEND:
                        SeqResume();
                        break;

                    case TIMER_TCP_RETRANSMIT:
                        M_EventSet(EV_TIMER_TCP_RETRANSMIT);
                        break;

                    case TIMER_EPROM_REPROG:
                        EpromAllowReprogramming(FALSE);
                        break;
                }

                /* Prevent sleeping */
                SMCR &= ~(1<<SE);
            }
            else
            {
                timersCount[t]--;
            }
        }

        mask >>= 1;
    }
}

ISR(TIMER1_COMPA_vect)
{
    /* Check if the sequencer timer is running */
    if((timersEn & (1<<TIMER_SEQ)) != 0)
    {
        SeqTick();
    }

    /* Run the highspeed timers */
    runTickTimers(~timersEnLs);
}

ISR(WDT_vect)
{
    /* Run the low-speed timers */
    runTickTimers(timersEnLs);
}

/**************************************************************************
 * Global Functions
 **************************************************************************/

/** Start a timer.
 * Start some timer, with an optional timeout duration.
 *
 * \param[in] timer  The identifier for the timer.
 * \param[in] hSecs  The duration in hundreths of a second.
 */
void TimerHsStart(timerid_t timer, uint8_t hSecs)
{
    /* Store the duration in ticks if a ticker */
    if(timer < NUM_TICK_TIMERS)
    {
        timersCount[timer] = ((uint32_t)hSecs) * 25;
    }

    /* Mark timer as highspeed and running */
    timersEnLs &= ~(1<<timer);
    timersEn   |= 1<<timer;

    /* Ensure highspeed HW block is enabled */
    if((PRR | (1<<PRTIM1)) != 0)
    {
        /* Enable */
        PRR &= ~(1<<PRTIM1);

        /* Disable counter */
        TCCR1A = 0;
        TCCR1B = 0;

        /* Set top. 125*8MHz/256 = 4ms */
        OCR1A = 125;
        TCNT1 = 120;

        /* Enable interrupt when OCR1A is met */
        TIMSK1 |= (1<<OCIE1A);

        /* Start and configure CTC and prescale/256*/
        TCCR1B = (1<<WGM12) | (1<<CS12);
    }
}

void TimerLsStart(timerid_t timer, uint32_t secs)
{
    /* Store the duration in ticks if a ticker */
    if(timer < NUM_TICK_TIMERS)
    {
        timersCount[timer] = secs;
    }

    /* Mark timer as lowspeed and running */
    timersEnLs |= 1<<timer;
    timersEn   |= 1<<timer;

    /* Ensure the watchdog is running */
    if((WDTCSR & (1<<WDIE)) == 0)
    {
        /* Disable interrupts */
        cli();

        /* Reset the watchdog */
        __asm volatile ("wdr" ::);

        /* Enable pre-scaler change in the next 4 cycles */
        WDTCSR |= (1<<WDE) | (1<<WDCE);

        /* Enable interrupt and set the pre-scaler */
        WDTCSR = (1<<WDIE) | (1<<WDP2) | (1<<WDP1);

        /* Enable interrupts */
        sei();
    }
}


void TimerStop(timerid_t timer)
{
    /* Clear the timer bit */
    timersEn &= ~(1<<timer);

    /* Check if any hardware can be powered down */
    if((timersEn & ~timersEnLs) == 0)
    {
        /* Disable counter and hardware block */
        TCCR1B = 0;
        PRR |= (1<<PRTIM1);
    }

    if((timersEn & timersEnLs) == 0)
    {
        cli();

        /* Enable pre-scaler change in the next 4 cycles */
        WDTCSR |= (1<<WDCE) | (1<<WDE);

        /* Turn off WDT */
        WDTCSR = 0x00;

        sei();
    }
}

/* END OF FILE */
