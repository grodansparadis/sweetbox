/***************************************************************************
 * autoip.h: RFC3927 implementation for ATmega88.
 * Copyright (C) 2007 Michael C McTernan,
 *    Michael.McTernan.2001@cs.bris.ac.uk
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 ***************************************************************************/

#ifndef AUTOIP_H
#define AUTOIP_H

/**************************************************************************
 * Includes
 **************************************************************************/

#include "main.h"
#include "ip.h"

/**************************************************************************
 * Prototypes
 **************************************************************************/

boolean_t AutoIp        (boolean_t conflict);

boolean_t AutoIpProbe   (const ipaddr_t *ip);
boolean_t AutoIpAnnounce(const ipaddr_t *ip);

#endif

/* END OF FILE */
