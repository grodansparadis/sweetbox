#ifndef _INTTYPES_H
#define _INTTYPES_H

typedef unsigned char uint8_t;

#endif
