#ifndef SPI_H
#define SPI_H

#include"uip.h"

// public functions
void initSPI(void);
u16_t SPIWrite(u8_t*, u16_t);
u16_t SPIRead(u8_t*, u16_t);

#endif
