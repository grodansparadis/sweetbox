
/******************************************************************************/
/** \file main.c
 *  \brief Setup micro for uIP stack and ENCJ2860
 *  \author Iain Derrington (www.kandi-electronics.com)
 *  \date 
 *  \revision
 */
/*******************************************************************************/

/*******************************************************includeds***************/
#include <cross_studio_io.h>
#include <ctl_api.h>
#include <targets/lpc21xx.h>
#include "uip.h"
#include "uip_arp.h"
#include "timer.h"




void initMicro(void);
void timerISR(void);


#define BUF ((struct uip_eth_hdr *)&uip_buf[0])
/***********************************************************************/
/** \brief Main loop for controlling uIP
 *
 * Description: Test Code for uip. Primarily based upon uIP example code
 *              
 *              
 * \author Iain Derrington
 * \date WIP
 */
/**********************************************************************/
int main(void)
{
  volatile int i;
  uip_ipaddr_t ipaddr;
  struct timer periodic_timer,arp_timer;
  

  initMicro();    // Setup LPC2106
  
  initMAC();      // Setup ENC28J60
  
  uip_init();     // Setup TCP/IP stack
  uip_arp_init();

  clock_init();   // Start Clock

  timer_set(&periodic_timer, CLOCK_SECOND/2);
  timer_set(&arp_timer, CLOCK_SECOND*10);

  /*Setup the IP address and netmask. */
  uip_ipaddr(ipaddr, 192,168,1,20);
  uip_sethostaddr(ipaddr);
  uip_ipaddr(ipaddr, 255,255,255,0);
  uip_setnetmask(ipaddr);

  /* Configure the IP address of the default router. */
  uip_ipaddr(ipaddr, 192,168,1,1);
  uip_setdraddr(ipaddr);
  
  
  telnetd_init();

  for(;;)
  {
    uip_len = MACRead();
    if(uip_len > 0) 
    {
      if(BUF->type == htons(UIP_ETHTYPE_IP)) 
      {
        uip_arp_ipin();
        uip_input();
        /* If the above function invocation resulted in data that
        should be sent out on the network, the global variable
        uip_len is set to a value > 0. */
        if(uip_len > 0) 
        {
          uip_arp_out();
          MACWrite();
        }      
      }
      else if(BUF->type == htons(UIP_ETHTYPE_ARP)) 
      {
	uip_arp_arpin();
	/* If the above function invocation resulted in data that
	   should be sent out on the network, the global variable
	   uip_len is set to a value > 0. */
	if(uip_len > 0) 
        {
	  MACWrite();
	}
      }
    }
    else if(timer_expired(&periodic_timer)) 
    {
      timer_reset(&periodic_timer);
      for(i = 0; i < UIP_CONNS; i++) 
      {
        uip_periodic(i);
	/* If the above function invocation resulted in data that
	   should be sent out on the network, the global variable
	   uip_len is set to a value > 0. */
        if(uip_len > 0) 
        {
            MACWrite();
        }
      }
      if(timer_expired(&arp_timer)) 
      {
	timer_reset(&arp_timer);
	uip_arp_timer();
      }
    }
  }
}
/***********************************************************************/
/** \brief init LPC2106 for project.
 * \author Iain Derrington
 * \date WIP
 */
/**********************************************************************/
void initMicro(void)
{  
  IO0DIR = 0x0000ffff;            // Configure Port
  ctl_global_interrupts_enable(); // Enable IRQ
}

void uip_log(char *msg)
{
 //debug_printf("%s \n",msg);
}
