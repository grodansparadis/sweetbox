#ifndef _NETHELP_H_
#define _NETHELP_H_

unsigned int nethelp_checksum(unsigned char *buffer, unsigned int len, unsigned long csum32);

#endif
