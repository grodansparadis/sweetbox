#ifndef _BUILD_H_
#define _BUILD_H_
#define BUILD_ID "AVRVi"
#define BUILD_TIMESTAMP "Build started 21.5.2008 at 16:23:58"
#endif


