#include<targets/lpc21xx.h>
#include"enc28j60.h"

typedef struct
{
  u08 dstAddress[6];
  u08 srcAddress[6];
  u16 Type;
  u08 bytData[1000];
}tMACPacket;

typedef struct
{
  u16 suiHTYPE;  //2
  u16 suiPTYPE;  //4
  u08 bytHLEN;   //5
  u08 bytPLEN;   //6
  u16 suiOPER;   //8
  u08 bytSHA[6]; //14
  u08 bytSPA[4]; //16
  u08 bytTHA[6]; //22
  u08 bytTPA[4]; //26
}tARP;


const u08 bytMACAddress[6] = {0x01,0x01,0x01,0x01,0x01,0x01};   //mymax
const u08 bytIPAddress[4] = {192,168,0,1};
const u08 bytTIPAddress[4] = {192,168,0,2};

tARP ArpPacket;
tMACPacket MACPacket;
tMACPacket RxMac;
/******************************************************************************/
/** \file main.c
 *  \brief Test code for enc28j60 driver
 *  \author Iain Derrington (www.kandi-electronics.com)
 * 
 */
/*******************************************************************************/
static void init2106(void);

/***********************************************************************/
/** \brief entry point for code
 *
 * Description: Simple routine for testing the enc28j60. Changes on a daily basis.
 *
 * \author Iain Derrington
 *
 * \return int
 */
/**********************************************************************/
int main(void)
{
  
  volatile long int i;
  
  // Configure the LPC2106 & Set up and ARP Packey
  init2106();

  
  for(;;)
  {
    // Transmit an ARP packet
    MACWrite((u08*)&MACPacket,42); 
    
    // See if there is any data in the Rx Buffer
    if (MACRead((u08*)&RxMac)==0)
    {
      for(i=0;i<0xfff;i++){}       
    }
  }
  
 
}

/***********************************************************************/
/** \brief init LPC2106.
 *
 * Description: (Filthy code ;o) )All the initialisation calls are placed in this function.
 *         
 * \author Iain Derrington (www.kandi-electronics.com)
 */
/**********************************************************************/
void init2106(void)
{
  u16 i;
  
  IO0DIR=0x0000ffff;
  initMAC();
  for(i=0;i<0xfff;i++){}
  for(i=0;i<0xfff;i++){}
  for(i=0;i<0xfff;i++){}
  for(i=0;i<0xfff;i++){}

  
  ArpPacket.suiHTYPE = 0x0100;
  ArpPacket.suiPTYPE = 0x0008;
  ArpPacket.bytHLEN = 0x06;
  ArpPacket.bytPLEN = 0x04;
  ArpPacket.suiOPER = 0x0100;
  
  for (i=0;i<6;i++)
  {
    ArpPacket.bytSHA[i] = bytMACAddress[i];
    ArpPacket.bytTHA[i] = 0xff;
  }
  
  for (i=0;i<4;i++)
  {
    ArpPacket.bytSPA[i] = bytIPAddress[i];
    ArpPacket.bytTPA[i] = bytTIPAddress[i];
  }
  
  for(i=0;i<6;i++)
    MACPacket.srcAddress[i]= 0x00;

  for(i=0;i<6;i++)
    MACPacket.dstAddress[i]= 0xff;

  MACPacket.Type = 0x0608;
  memcpy(MACPacket.bytData, &ArpPacket, sizeof(ArpPacket)); 


}
