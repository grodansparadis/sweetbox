#ifndef SPI_H
#define SPI_H

#include"typedef.h"

// public functions
void initSPI(void);
u16 SPIWrite(u08*, u16);
u16 SPIRead(u08*, u16);

#endif
