#ifndef TYPEDEF_H
#define TYPEDEF_H



typedef short unsigned int u16 ;
typedef short int  s16;
typedef unsigned char u08;
typedef char s08;
typedef unsigned int u32;
typedef int s32;


#define TRUE    1
#define FALSE   0
#define HIGH    1
#define LOW     0

#endif
