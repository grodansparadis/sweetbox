#ifndef _DELAY_H_
#define _DELAY_H_

#define  F_CPU  14745600   /* The AVR clock frequency in Hertz */

void delay_ms(unsigned char ms);

#endif
 
