#include "stdio.h"


asm(".global HEAPSIZE");
asm(".equiv HEAPSIZE,0x100");

