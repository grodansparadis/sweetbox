/**********************************************************************
* � 2007 Microchip Technology Inc.
*
* FileName:        main.c
* Dependencies:    Header (.h) files if applicable, see below
* Processor:       dsPIC33Fxxxx
* Compiler:        MPLAB� C30 v3.01 or higher
*
* SOFTWARE LICENSE AGREEMENT:
* Microchip Technology Incorporated ("Microchip") retains all ownership and 
* intellectual property rights in the code accompanying this message and in all 
* derivatives hereto.  You may use this code, and any derivatives created by 
* any person or entity by or on your behalf, exclusively with Microchip's
* proprietary products.  Your acceptance and/or use of this code constitutes 
* agreement to the terms and conditions of this notice.
*
* CODE ACCOMPANYING THIS MESSAGE IS SUPPLIED BY MICROCHIP "AS IS".  NO 
* WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED 
* TO, IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY AND FITNESS FOR A 
* PARTICULAR PURPOSE APPLY TO THIS CODE, ITS INTERACTION WITH MICROCHIP'S 
* PRODUCTS, COMBINATION WITH ANY OTHER PRODUCTS, OR USE IN ANY APPLICATION. 
*
* YOU ACKNOWLEDGE AND AGREE THAT, IN NO EVENT, SHALL MICROCHIP BE LIABLE, WHETHER 
* IN CONTRACT, WARRANTY, TORT (INCLUDING NEGLIGENCE OR BREACH OF STATUTORY DUTY), 
* STRICT LIABILITY, INDEMNITY, CONTRIBUTION, OR OTHERWISE, FOR ANY INDIRECT, SPECIAL, 
* PUNITIVE, EXEMPLARY, INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, FOR COST OR EXPENSE OF 
* ANY KIND WHATSOEVER RELATED TO THE CODE, HOWSOEVER CAUSED, EVEN IF MICROCHIP HAS BEEN 
* ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE.  TO THE FULLEST EXTENT 
* ALLOWABLE BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO 
* THIS CODE, SHALL NOT EXCEED THE PRICE YOU PAID DIRECTLY TO MICROCHIP SPECIFICALLY TO 
* HAVE THIS CODE DEVELOPED.
*
* You agree that you are solely responsible for testing the code and 
* determining its suitability.  Microchip has no obligation to modify, test, 
* certify, or support the code.
*
* ADDITIONAL NOTES:
* Code Tested on:
* Explorer16 Demo board with dsPIC33FJ256GP710 controller 
**********************************************************************/

#define USE_SIMULATION 0

#include "p33fxxxx.h"
#include "dsp.h"
#include "..\h\adcDrv1.h"
#include "..\h\FIR.h"
#include "..\h\printf.h"

int Decimate(int numsamp, fractional* output, fractional* input, int rate, int fl);
int computeSNR(int*, int*, int);

//Macros for Configuration Fuse Registers:
//Invoke macros to set up  device configuration fuse registers.
//The fuses will select the oscillator source, power-up timers, watch-dog
//timers etc. The macros are defined within the device
//header files. The configuration fuse registers reside in Flash memory.

// Internal FRC Oscillator
_FOSCSEL(FNOSC_FRC);			// FRC Oscillator
_FOSC(FCKSM_CSECMD & OSCIOFNC_ON  & POSCMD_NONE); 
								// Clock Switching is wnabled and Fail Safe Clock Monitor is disabled
								// OSC2 Pin Function: OSC2 is Clock Output
								// Primary Oscillator Mode: Disabled


_FWDT(FWDTEN_OFF);              // Watchdog Timer Enabled/disabled by user software
								// (LPRC can be disabled by clearing SWDTEN bit in RCON register

int SNR_12OFD, SNR_12; 

int main (void)
{


#if(!USE_SIMULATION)
// Enables peripheral demonstration  

	// FIR Output Buffer
	fractional outputSignal[NUMSAMP];
	//fractional IP1K[NUMSAMP];					// Uncomment if collecting regular 12-bit samples
	fractional OPFIR256Kto1K[NUMSAMP];

	fractional output[NUMSAMP/RATE];
	//fractional output2[NUMSAMP/RATE];			// Uncomment if collecting regular 12-bit samples

	int count = -1;	

	// Configure FRC to operate the device at 40MIPS
	// Fosc= Fin*M/(N1*N2), Fcy=Fosc/2
	// Fosc= 7.37M*43/(2*2)=79.2275Mhz for 40MIPS input clock
	PLLFBD=41;									// M=43
	CLKDIVbits.PLLPOST=0;						// N1=2
	CLKDIVbits.PLLPRE=0;						// N2=2
	OSCTUN=0;									// Tune FRC oscillator, if FRC is used

	// Disable Watch Dog Timer
	RCONbits.SWDTEN=0;

	// Clock switch to incorporate PLL
	__builtin_write_OSCCONH(0x01);				// Initiate Clock Switch to
												// FRC with PLL (NOSC=0b001)
	__builtin_write_OSCCONL(0x01);				// Start clock switching

	while (OSCCONbits.COSC != 0b001);			// Wait for Clock switch to occur

	while(OSCCONbits.LOCK!=1) {};				// Wait for PLL to lock

	// FIR filter structure initialization
	FIRStruct FIRfilter;
	FIRStructInit(&FIRfilter,NY,coeffecients,0xFF00,z);
	FIRDelayInit(&FIRfilter);

	// Peripheral Initialisation
   	initAdc1();             					// Initialize the A/D converter to convert Channel 5
	initDma0();									// Initialise the DMA controller to buffer ADC data in conversion order
	initTmr3();									// Initialise the Timer to generate sampling event to ADC @ 256Khz rate

	extern fractional BufferA[NUMSAMP];			// Ping pong buffer A
	extern fractional BufferB[NUMSAMP];			// Ping pong buffer B

	extern unsigned int DmaBuffer;				// DMA flag
	extern int flag;							// Flag

	int j;


    while (1)               					//Loop Endlessly - Execution is interrupt driven
    { 
			 
		if(flag) 
		{            

			if(DmaBuffer == 0)
			{
				//Decimate(NUMSAMP/RATE, output2, &BufferA[0], RATE, DmaBuffer);  // Decimation of the non-filtered signal to get the regular 12-bit samples
				FIR(NUMSAMP, &outputSignal[0], &BufferA[0], &FIRfilter);		  // FIR filtering on BufferA 
			}
			else
			{
				//Decimate(NUMSAMP/RATE, output2, &BufferB[0], RATE, DmaBuffer);  // Decimation of the non-filtered signal to get the regular 12-bit samples
				FIR(NUMSAMP, &outputSignal[0], &BufferB[0], &FIRfilter);		  // FIR filtering on BufferB 
			}

			Decimate(NUMSAMP/RATE, output, outputSignal, RATE, DmaBuffer);		
			
			for(j = 0; j < NUMSAMP/RATE; j++)			
			{
				count++;
				//	IP1K[count] = output2[j];		// Populate the buffer with original 12-bit samples 
				OPFIR256Kto1K[count] = output[j];	// Populate the buffer with oversampled, filtered, and decimated samples
			}
			
			flag = 0;
			
			// TODO: add buffer processing code here
			// if(count == NUMSAMP-1)
			//	 ProcessTheBuffer();		// When the number of samples populated is equal to NUMSAMP-1 
										    // further processing can be performed on the same
		}
		
	}
    
	return 1;

#else
// Enables simulation demonstration
// The oversampled data is to be loaded in the input[] buffer defined as a constant

	int Rate = 256; 
	int flag = 0;
	int i, j, k = 0, n = 0, globe_i;

	// FIR filter structure initialization
	FIRStruct FIRfilter;
	FIRStructInit(&FIRfilter,NY,coeffecients,0xFF00,z);
	FIRDelayInit(&FIRfilter);

	for(globe_i = 0; globe_i < 2; globe_i++)
	{

		for (i = 0; i < (MAX_SIZE_IN_PGMMEM-1); i++)
		{
			for (j = 0; j < NX; j++)
				if(globe_i == 1)
					ipBuffX[j] = -input[i++];
				else
					ipBuffX[j] = input[i++];
			i--;

			FIR(512, &opBuffXR[0], &ipBuffX[0], &FIRfilter);	 

			flag = Decimate(2, opBuffR, opBuffXR, Rate, flag);	

			// opBuffX[] buffer contains samples obtained after 12-bit oversampling, filtering and decimation.
			// SNR is measured using opBuffXT[] and 16-bit samples in input16[] buffer
			for (j = 0; j < 2; j++)
				opBuffX[k++] = opBuffR[j];

			Decimate(2, opBuffR, ipBuffX, Rate, flag);
			
			// opBuffXT[] buffer contains regular 12 bit data 
			// SNR is measured using opBuffXT[] and 16-bit samples in input16[] buffer
			for (j = 0; j < 2; j++)
				opBuffXT[n++] = opBuffR[j];

		}
	
	}

	for(i = 0; i < 99; i++)
		opBuffX[i] = opBuffX[i+1] - input16[i];

	// Compute SNR of the oversampled, filtered and decimated 12-bit ADC signal 
	// with 16-bit signal as the clean signal
	SNR_12OFD = computeSNR((fractional*) &input16[0], &opBuffX[0], 99);

	for(i = 0; i < 100; i++)
		opBuffXT[i] -= input16[i];

	// Compute SNR of the 12-bit ADC signal with 16-bit signal as the clean signal
	SNR_12 = computeSNR((fractional*) &input16[0], &opBuffXT[0], 100);

	// SNR improvement of oversampled, filtered and decimated 12-bit ADC signal
	// over regular 12-bit ADC signal
	printf("\n SNR Improvement = %d dB", (SNR_12OFD-SNR_12));

	return 1;


#endif

}

int Decimate(int numsamp, fractional* output, fractional* input, int rate, int fl)
{

	int m;
	for(m = 0; m < numsamp; m++)
			//if(fl == 0)
			{
				//output[i] = input[(i==0)? 0 : i*rate-1];	
			if(m==0)
				output[m] = input[0];
			else
				output[m] = input[255];
				//fl = 1;
			}
			//else
			{
				//output[i] = input[(i==0)? 0 : i*rate-1];	
				//fl = 0;
			}	
	return fl;

}

