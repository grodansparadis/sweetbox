/**********************************************************/
/*                                                        */
/*  Module         : SD.c                                 */
/*  Language used  : CS                                   */
/*  Microprocessor : LPC2138                              */
/*                                                        */
/*  Function       : Functions related to SD memory card  */
/*                   (low level drivers)                  */
/* -------------------------------------------------------*/
/*  Revision History :                                    */ 
/*  Author				 Date				       Reason               */
/*  Jan Szymanski  18 September 2005 Initial Design       */
/*  Jan Szymanski  18 April 2006     Ported to LPC2148    */
/*                                                        */
/**********************************************************/

#define SD_OWNER
#include "includes.h"

/* SPI mode is implemented and SPI0 is used */
/* P0.4 SCK0 is CLK */
/* P0.5/MISO0 is DO */
/* P0.6 MOSI0 is DI */
/* P0.22 is CS */

#define SDCS_LOW			IO0CLR = 1 << 22;  // P0.22 is SDCS
#define SDCS_HIGH			IO0SET = 1 << 22;

/**********************************************************/
/*  Name        : SD_init                                 */
/*  Parameters  : void                                    */
/*  Returns     : void                                    */
/*  Scope       : System                                  */
/*  Function    : to initialize SD                        */
/*--------------------------------------------------------*/

unsigned char SD_init(void)
{
unsigned int i,j;

for(j=0; j<3; j++)	// try 3 times to cycle power if failed to initialize
	{
	SD_param.error = SD_ERROR_NOCARD;
	SD_var.open=0;		
	SD_var.cardOK=0;
	//SD_POWER_OFF		// try to power off-on again
	delay_ms(20);		// wait for 200 ms			
	//SD_POWER_ON
	delay_ms(20);		// wait for 200 ms
	if(SD_card_present()==FALSE)	/* no SD */ 
		{
    #ifdef DEBUG
      putstring_PC((unsigned char *)"No SD Card detected\r\n");
    #endif
		SD_param.error = SD_ERROR_NOCARD;
		return FAIL;
		}
	SD_status=SD_InitSPI();
	if(SD_status!=0) /* SD error */ 
		{
    #ifdef DEBUG
      putstring_PC((unsigned char *)"SD Card Error\r\n");
    #endif
		SD_param.error = SD_ERROR_FTI;	// failed to initialize
		}else
			{
			SD_Id();
			// for debug only
			SD_ReadBlock(SD_param.FAT1,SD_buf1);
			SD_ReadBlock(SD_param.dir,SD_buf1);
			SD_ReadBlock(SD_param.data,SD_buf);

			//for(i=0; i<512; i++)
			//	SD_ReadBlock((SD_param.data)+i,SD_buf);	

			//SD_ReadBlock(0,SD_buf);
			// check if there are files available */
			SD_param.error = SD_ERROR_OK;
      }
	if(SD_param.error == SD_ERROR_OK) break;	
		//else
			//{
			//SD_POWER_OFF		// try to power off-on again
			//delay_ms(20);		// wait for 200 ms
			//}
	}
// check if success here
if(SD_param.error == SD_ERROR_OK)
	{
	SD_var.cardOK=1;
  #ifdef DEBUG
    putstring_PC((unsigned char *)"SD Init OK\r\n");
  #endif
	return PASS;
	} else return FAIL;
}
/*--------------------------------------------------------*/
/* End of Function: SD_init                               */
/**********************************************************/

/**********************************************************/
/*  Name        : SD_card_present                         */
/*  Parameters  : void                                    */
/*  Returns     : TRUE if present, FALSE if not           */
/*  Scope       :                                         */
/*  Function    : to detect SD card presense              */
/*--------------------------------------------------------*/

unsigned char SD_card_present(void)
{
if((IO0PIN && 0x00008000) == 0x00000000)	// P0.15/EINT2 = 0, no card
	{
	return FALSE;
	} else
			return TRUE;
}
/*--------------------------------------------------------*/
/* End of Function: SD_card_present                       */
/**********************************************************/

/**********************************************************/
/*  Name        : SD_ReadByte                             */
/*  Parameters  : none                                    */
/*  Returns     : one byte of data                        */
/*  Scope       :                                         */
/*  Function    : to read one byte from SD                */
/*--------------------------------------------------------*/
unsigned char SD_ReadByte(void)
{
unsigned char c;
//while (ischar_SD()==TRUE) getchar_SD(); /* dummy reads */
//putchar_SD(0xff);  /* dummy to generate clock */
//while(ischar_SD()==FALSE){}
//c=getchar_SD();

SPDR = 0xff;
while (!(SPSR & 0x80)){} // wait till SPIF == 1 (transmit completed)
c = SPDR;
return c;
}
/* End of SD_ReadByte *************************************/

/**********************************************************/
/*  Name        : SD_WriteByte                            */
/*  Parameters  : byte to be written                      */
/*  Returns     : none                                    */
/*  Scope       :                                         */
/*  Function    : to write one byte to SD                 */
/*--------------------------------------------------------*/
void SD_WriteByte(unsigned char byte)
{
putchar_SD(byte);
}
/* End of SD_WriteByte ************************************/

/**********************************************************/
/*  Name        : SD_SendCmd                              */
/*  Parameters  : byte to be written                      */
/*  Returns     :                                         */
/*  Scope       :                                         */
/*  Function    : to send command to SD                   */
/*--------------------------------------------------------*/
unsigned int SD_SendCmd(unsigned char cmd, unsigned long arg,
                         enum SD_END end)
{
unsigned int i,j,n;
unsigned int res;
unsigned char c;

putchar_SD(0xff); /* dummy to make data line high */
while(ischar_SD()!=0) getchar_SD();

SDCS_LOW
SD_WriteByte(0x40 | cmd);
SD_WriteByte(arg >> 24);
SD_WriteByte(arg >> 16);
SD_WriteByte(arg >> 8);
SD_WriteByte(arg);
SD_WriteByte(0x95); /* good checksum for cmd 64 0 0 0 0 */

n=0;
do
  {
  res=SD_ReadByte();
//  debug_printf(":%X",res);
//  for(j=0;j<100;j++)
//    {
//    for(i=0; i<50000; i++){}
//    }
  n++;
  if(n>30000) break;	// was 5
  }while((unsigned char)res & R1_BUSY);

if(cmd==SD_SEND_STATUS)
  res=(res<<8) | SD_ReadByte();

if(end)
  SD_EndCmd();
return res;
}
/* End of SD_SendCmd **************************************/

/**********************************************************/
/*  Name        : SD_EndCmd                               */
/*  Parameters  : none                                    */
/*  Returns     : none                                    */
/*  Scope       :                                         */
/*  Function    : to deactivate SD                        */
/*--------------------------------------------------------*/
void SD_EndCmd(void)
{
SDCS_HIGH
SD_ReadByte(); /* one empty cycle */
}
/* End of SD_EndCmd ***************************************/

/**********************************************************/
/*  Name        : SD_Flush                                */
/*  Parameters  : number of cycles                        */
/*  Returns     : none                                    */
/*  Scope       :                                         */
/*  Function    : to flush SD                             */
/*--------------------------------------------------------*/
void SD_Flush(unsigned int n)
{
while(n--)
  SD_ReadByte();
SD_EndCmd();
}
/* End of SD_Flush ***************************************/

/**********************************************************/
/*  Name        : SD_FlushAndRead                         */
/*  Parameters  : buffer pointer, number of cycles        */
/*  Returns     : result                                  */
/*  Scope       :                                         */
/*  Function    : to flush SD and read into a buffer      */
/*--------------------------------------------------------*/
unsigned int SD_FlushAndRead(unsigned char *d, unsigned char n)
{
unsigned char c;
unsigned int i;
i=0;
//c=SD_ReadByte(); //?????
while(c != 0xfe) 
  {
  c = SD_ReadByte();
  //debug_printf("%X,",c);
  i++;
  if(i>0x200) break;
  } /* data token */
//*d++ = SD_ReadByte();


while(n--)
  { 
  *d++ = SD_ReadByte();
  }
SD_EndCmd();

if(i>0x200) return i;
  else return 0;
}
/* End of SD_FlushAndRead *********************************/

/**********************************************************/
/*  Name        : SD_ExtractBits                          */
/*  Parameters  : d = LAST data address, big endian, i.e. */
/*                bits 0..7 in first byte                 */
/*                pos = start bit position (high pos)     */
/*                bits = number of bits to read           */
/*          To read bits 22:17: ExtractBits(data, 22, 6); */
/*  Returns     : extracted bits value                    */
/*  Scope       :                                         */
/*  Function    : to extract bits                         */
/*--------------------------------------------------------*/

unsigned char ExtractBits(unsigned char *d, unsigned char pos, unsigned char bits)
{
unsigned int res;
static unsigned char bitMasks[8] = { 1, 3, 7, 15, 31, 63, 127, 255 };

pos -= bits-1;
d -= (pos>>3)+1;
res = d[1] | ((unsigned int)d[0] << 8);
res >>= pos & 7;
res &= bitMasks[bits-1];

return res;
}
/* End of SD_ExtractBits **********************************/

/**********************************************************/
/*  Name        : SD_InitSPI                              */
/*  Parameters  : none                                    */
/*  Returns     : result of the operation                 */
/*  Scope       :                                         */
/*  Function    : to initialize SD into SPI mode          */
/*--------------------------------------------------------*/
unsigned int SD_InitSPI(void)
{
unsigned int i,j, num;
unsigned int temp;

// start with low SPI clock
//S0SPCCR = 248;  // 60 MHz/248 = 241935 Hz clock
SPCCR = 248;  // 60 MHz/248 = 241935 Hz clock

// delay of minimum 74 clocks required
SDCS_LOW
/* Let SD reset itself, 80 SPI cycles */
for (i=0; i<10; i++)  
  putchar_SD(0xff);
while(ischar_SD()!=0) getchar_SD();
SDCS_HIGH

// delay of 16 clocks required
for (i=0; i<2; i++)  
  putchar_SD(0xff);
while(ischar_SD()!=0) getchar_SD();

// put the card in the idle state
temp = SD_SendCmd(SD_GO_IDLE_STATE, 0, sdFinish);
if (temp==0) return 0xffff;	

delay_ms(3);	// 30ms delay

num=0;
do 
  {
  i = SD_SendCmd(SD_CMD55, 0, sdFinish);
	i = SD_SendCmd(SD_ACMD41, 0, sdFinish);

  num++;
  if (num>=2000) return 0xffff;
  } while ((i & 0x0001) == 1);

i = SD_SendCmd(SD_SEND_CSD, 0, sdLeave);
num=SD_FlushAndRead(bCSD, 18);

// back to maximum possible SPI clock 
//S0SPCCR = 8;  // 60 MHz/8 = 7.5 MHz clock
SPCCR = 8;  // 60 MHz/8 = 7.5 MHz clock
return num;
}
/* End of SD_InitSPI **************************************/

/**********************************************************/
/*  Name        : SD_ReadBlock                            */
/*  Parameters  : block number, pointer to 512 bytes buffer */
/*  Returns     : data in a buffer                        */
/*  Scope       :                                         */
/*  Function    : to read 512 bytes from SD into buffer   */
/*--------------------------------------------------------*/
void SD_ReadBlock(unsigned long block, unsigned char *ptr)
{
unsigned int i,num;
unsigned char c;
unsigned char *p;
unsigned long addr;
addr=512*block;
p=ptr;

while(SD_SendCmd(SD_READ_SINGLE_BLOCK, addr, sdLeave)) SD_EndCmd();
/* set watchdog timer here */
num=0;
while(SD_ReadByte() != 0xFE)
  {
  num++;
  if(num>0x8000) /* error */
    {
    SD_EndCmd();
    //ressour=0x5a97;
    //WDTCTL=0x5a00;  /* watchdog reset */
    //while(1);   /* wait for watchdog reset */
    }
  }
/* reset watchdog timer */
//WDTCTL = 0x5a80; 

//c=SD_ReadByte(); /* data token 0xFE */ 
//*p++=c;
for (i=0; i<512; i++) 
  {
  c=SD_ReadByte();
  //debug_printf(" %X",c);
  *p++=c;
  }
c=SD_ReadByte(); /* first byte CRC */ 
//*p++=c;
c=SD_ReadByte(); /* second byte CRC */ 
//*p++=c;
SD_EndCmd();
}
/* End of SD_ReadBlock ************************************/

/**********************************************************/
/*  Name        : SD_Id                                   */
/* Parameters   : none                                    */
/*  Returns     : none (data structure updated)           */
/*  Scope       :                                         */
/*  Function    : to define memory card parameters        */
/*--------------------------------------------------------*/
void SD_Id(void)
{
unsigned int i,temp;
unsigned int FATblocks;
unsigned int c_size, mult;
unsigned long capacity;

/* first find a boot sector */
for(i=0; i<512; i++)
  {
  SD_ReadBlock(i,SD_buf); /* read block into tmp buffer */
  if(strncmp((char*)(SD_buf+0x36),(char*)("FAT16"),5)==0)
		{
		SD_param.filesystem = FAT16;
    SD_param.dirblocks = 32;
		break;
		}
  if(strncmp((char*)(SD_buf+0x36),(char*)("FAT12"),5)==0)
		{
		SD_param.filesystem = FAT12;
    SD_param.dirblocks = 32;
		break;
		}
  }

// if not FAT16 or not FAT12 signal an error here


SD_param.FAT1=i+SD_buf[0x0e]; /* reserved sectors after boot is FAT1 */
/* read some parameters from boot block */
SD_param.clusters=SD_buf[0x0d];
FATblocks=SD_buf[0x17]*256+SD_buf[0x16];  /* blocks per FAT */
SD_param.dir=SD_param.FAT1+FATblocks;   /* add FAT1 */
SD_param.dir+=FATblocks;   /* add FAT2 */
SD_param.data=SD_param.dir+SD_param.dirblocks;

/* data area starts with cluster 2 */
SD_param.data -= SD_param.clusters;
SD_param.data -= SD_param.clusters;
//SD_param.data -= SD_param.clusters;

//SD_ReadBlock(SD_param.FAT1,SD_buf); /* read block into tmp buffer */
//SD_ReadBlock(SD_param.data,SD_buf1); /* read block into tmp buffer */
}
/* End of SD_Id *******************************************/

/**********************************************************/
/* END OF FILE sd.c                                       */
/**********************************************************/
