#ifndef MP3_H
#define MP3_H

#ifdef MP3_OWNER

#define READBUF_SIZE		(1024*1)	/* feel free to change this, but keep big enough for >= one frame at high bitrates */
#define RB_BLOCKS 2   // READBUF_SIZE/512

//#define MAX_ARM_FRAMES		100
//#define ARMULATE_MUL_FACT	1
/*--------------------------------------------------------*/
/* Local variables and data                               */
/*--------------------------------------------------------*/

#include "coder.h"

MP3DecInfo  mp3DecInfo;     //  0x7f0 =  2032 
SubbandInfo sbi;            // 0x2204 =  8708
IMDCTInfo mi;               // 0x1b20 =  6944
HuffmanInfo hi;             // 0x1210 =  4624
DequantInfo di;             //  0x348 =   840
ScaleFactorInfo sfi;        //  0x124 =   292
SideInfo si;                //  0x148 =   328
FrameHeader fh;             //   0x38 =    56
//-------------------------------------------
//                             0x5d10 = 23824 bytes
MP3FrameInfo mp3FrameInfo;  // 
HMP3Decoder hMP3Decoder;
volatile int bytesLeft, nRead, err, offset, outOfData, eofReached;
//unsigned char readBuf[READBUF_SIZE], 
unsigned char *readPtr;
volatile short outBuf[MAX_NCHAN * MAX_NGRAN * MAX_NSAMP];
volatile int nFrames;
volatile short sample16;
volatile  unsigned char sample8l, sample8h;

/*--------------------------------------------------------*/
/* Local functions prototypes                             */
/*--------------------------------------------------------*/
void mp3_init(void);
int myFillReadBuffer(unsigned char *readBuf, unsigned char *readPtr, int bufSize, int bytesLeft);
void SD_play_mp3(void);
unsigned int SD_read_next_sector(void);
void LCD_show_frame(void);
#else
/*--------------------------------------------------------*/
/* Global variables and data                              */
/*--------------------------------------------------------*/
extern HMP3Decoder hMP3Decoder;
extern MP3FrameInfo mp3FrameInfo;
/*--------------------------------------------------------*/
/* Global functions prototypes                            */
/*--------------------------------------------------------*/
void mp3_init(void);
void SD_play_mp3(void);

#endif

#endif

/**********************************************************/
/* END OF FILE mp3.h                                      */
/**********************************************************/
