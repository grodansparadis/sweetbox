/**********************************************************/
/*                                                        */
/*  Module         : Ints.c                               */
/*  Language used  : CrossStudio                          */
/*  Microprocessor : LPC2138, LPC2148                     */
/*                                                        */
/*  Function       : Interrupt Service Routines           */
/*                                                        */
/* -------------------------------------------------------*/
/*  Revision History :                                    */ 
/*  Author         Date              Reason               */
/*  Jan Szymanski  18 September 2005 Initial Design       */
/*  Jan Szymanski  18 April 2006     Ported to LPC2148    */
/*                                                        */
/**********************************************************/
#define INTS_OWNER
#include "includes.h"

/**********************************************************/
/*  Name        : timer0ISR                               */
/*  Parameters  : none                                    */
/*  Returns     : none                                    */
/*  Scope       :                                         */
/*  Function    : periodical timer IRQ ISR                */ 
/*                we are here every 10ms                  */
/*--------------------------------------------------------*/
void timer0ISR(void)
{
free10ms++;
t10ms_1++;
//timer_tick++;			// M_OS Timer tick 

// show on P1.24
if(((free10ms & 0x00000001) == 0x00000001))  IO1SET = 1 << 24;
  else IO1CLR = 1 << 24;

T0IR = 0x01;      // Clear the timer 0 interrupt 
VICVectAddr = 0;  // Update VIC priorities
}
/*--------------------------------------------------------*/
/* End of Function: timer0ISR                             */
/**********************************************************/

/**********************************************************/
/*  Name        : timer1ISR                               */
/*  Parameters  : none                                    */
/*  Returns     : none                                    */
/*  Scope       :                                         */
/*  Function    : periodical timer IRQ ISR                */ 
/*                we are here every 1ms                   */
/*--------------------------------------------------------*/
void timer1ISR(void)
{
freems++;

T1IR = 0x01;      /* Clear the timer 1 interrupt */
VICVectAddr = 0;  /* Update VIC priorities */
}
/*--------------------------------------------------------*/
/* End of Function: timer1_ISR                            */
/**********************************************************/

/**********************************************************/
/*  Name        : uart0ISR                                */
/*  Parameters  : none                                    */
/*  Returns     : none                                    */
/*  Scope       :                                         */
/*  Function    : uart0 IRQ ISR                           */ 
/*                                                        */
/*--------------------------------------------------------*/
void uart0ISR(void)
{
unsigned char c, iid;

// loop until not more interrupt sources
while (((iid = U0IIR) & 0x01) == 0)
  {
  // identify & process the highest priority interrupt
  switch (iid & 0x0e)
    {
    case 0x06:                // Receive Line Status
      U0LSR;                  // read LSR to clear
      break;

    case 0x0c:                // Character Timeout Indicator
    case 0x04:                // Receive Data Available
      do
        {
        c = U0RBR;  /* read character */
        *pwr_uart0++ = c;				// and put into a buffer
        // adjust pointer if necessary 
        if (pwr_uart0 >= &buffer_rxuart0[UART0_RX_BUFFER_SIZE])
          pwr_uart0 = buffer_rxuart0;
        }
        while (U0LSR & 0x01);

      break;

      case 0x02:               // Transmit Holding Register Empty
        break;

      default:                 // Unknown
        U0LSR;
        U0RBR;
        break;
    } // end of switch
  } // end of while

VICVectAddr = 0;  /* Update VIC priorities */
}
/*--------------------------------------------------------*/
/* End of Function: uart0ISR                              */
/**********************************************************/

/**********************************************************/
/*  Name        : spi0ISR                                 */
/*  Parameters  : none                                    */
/*  Returns     : none                                    */
/*  Scope       :                                         */
/*  Function    : spi0 IRQ ISR                            */ 
/*                                                        */
/*--------------------------------------------------------*/
void spi0ISR(void)
{
//S0SPINT = 1;      // Clear the spi0 interrupt 
SPINT = 1;        // Clear the spi0 interrupt
VICVectAddr = 0;  // Update VIC priorities 
}
/*--------------------------------------------------------*/
/* End of Function: spi0ISR                               */
/**********************************************************/

/**********************************************************/
/*  Name        : sspISR                                  */
/*  Parameters  : none                                    */
/*  Returns     : none                                    */
/*  Scope       :                                         */
/*  Function    : ssp IRQ ISR                             */ 
/*                                                        */
/*--------------------------------------------------------*/
void sspISR(void)
{
unsigned char c;
c = SSPMIS;
SSPMIS = 0x1f;  // try
SSPICR = 0x03;  // reset INT errors

left.b8[0] = *pcm_play_ptr++;   //bb[play_index++];
left.b8[1] = *pcm_play_ptr++;   //bb[play_index++];
right.b8[0] = *pcm_play_ptr++;   //bb[play_index++];
right.b8[1] = *pcm_play_ptr++;   //bb[play_index++];

left1.b8[0] = *pcm_play_ptr++;   //bb[play_index++];
left1.b8[1] = *pcm_play_ptr++;   //bb[play_index++];
right1.b8[0] = *pcm_play_ptr++;   //bb[play_index++];
right1.b8[1] = *pcm_play_ptr++;   //bb[play_index++];

SSPDR = left.b16[0];
SSPDR = right.b16[0];
SSPDR = left1.b16[0];
SSPDR = right1.b16[0];

if(pcm_play_ptr > (unsigned char *)PCM_BUFFER_END) 
  pcm_play_ptr = (unsigned char *)PCM_BUFFER_START;

VICVectAddr = 0;  // Update VIC priorities 
}
/*--------------------------------------------------------*/
/* End of Function: sspISR                                */
/**********************************************************/

/**********************************************************/
/* END OF FILE ints.c                                     */
/**********************************************************/

