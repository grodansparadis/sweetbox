/**********************************************************/
/*                                                        */
/*  Module         : codec.c                              */
/*  Language used  : CrossStudio for ARM                  */
/*  Microprocessor : LPC2138                              */
/*  Function       : all functions related to audio codec */
/*                                                        */
/* -------------------------------------------------------*/
/*  Revision History :                                    */ 
/*  Author				 Date				       Reason               */
/*  Jan Szymanski  18 September 2005 Initial Design       */
/*  Jan Szymanski  18 April 2006     Ported to LPC2148    */
/*                                                        */
/**********************************************************/

#define CODEC_OWNER
#include "includes.h"

/**********************************************************/
/*  Name        : dac_init                                */
/*  Parameters  : none                                    */
/*  Returns     : none                                    */
/*  Scope       :                                         */
/*  Function    : to initialize dac operation after POR   */
/*                the code is for audio DAC               */
/*                TLV320DAC26 from TI                     */
/*--------------------------------------------------------*/
void dac_init(void)
{
//unsigned int i;
//unsigned short reg1[32];

//putint_DAC(0x0880); // Command Word - write, page 1, register 4
//putint_DAC(0xbb00); // reset all registers
DAC_SEL_LOW
putchar_DAC(0x08);
putchar_DAC(0x80);
putchar_DAC(0xbb);
putchar_DAC(0x00);
DAC_SEL_HIGH

// the proper initialization sequence is needed
// first set and enable PLL

//putint_DAC(0x1360); // Command Word - write, page 2, register 1b
DAC_SEL_LOW
putchar_DAC(0x13);    // 
putchar_DAC(0x60);
//putint_DAC(0x911C); // register 1b value for 12 MHz MCLK
putchar_DAC(0x91);     // enable PLL, (Q=2) P = 1, J = 7
putchar_DAC(0x1c);
//putint_DAC(0x60b8); // register 1c value for 12 MHz MCLK, D = 6190 0x182e << 2
putchar_DAC(0x60);
putchar_DAC(0xb8);
DAC_SEL_HIGH

//putint_DAC(0x1000); // Command Word - write, page 2, register 0
//putint_DAC(0x0000); // 16 bit, I2S, Fsref / 1
DAC_SEL_LOW
putchar_DAC(0x10);  
putchar_DAC(0x00);
putchar_DAC(0x00);  
putchar_DAC(0x00);
DAC_SEL_HIGH

//putint_DAC(0x1040); // Command Word - write, page 2, register 2
//putint_DAC(0x0000); // left and gight channel not muted and gain = 0 dB
DAC_SEL_LOW
putchar_DAC(0x10);
putchar_DAC(0x40);
putchar_DAC(0x00);
putchar_DAC(0x00);
//putint_DAC(0xc580); // register 3 value
putchar_DAC(0x80);    // analog sidetone muted
putchar_DAC(0x00);
//putint_DAC(0xf4fd); // register 4 value
putchar_DAC(0x00);
putchar_DAC(0x00);
//putint_DAC(0x1900); // register 5 value 
putchar_DAC(0x10);
putchar_DAC(0x01);
//putint_DAC(0x2000); // register 6 value
putchar_DAC(0x20);
putchar_DAC(0x00);
//putint_DAC(0x6be3); // register 7 value
//putchar_DAC(0x6b);
//putchar_DAC(0xe3);
DAC_SEL_HIGH

return;
}
/*--------------------------------------------------------*/
/* End of Function: dac_init                              */
/**********************************************************/

/**********************************************************/
/* END OF FILE codec.c                                    */
/**********************************************************/
