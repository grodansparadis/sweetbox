/**********************************************************/
/*                                                        */
/*  Module         : DiskAppl.c                           */
/*  Language used  : CS                                   */
/*  Microprocessor : MSP430                               */
/*                                                        */
/*  Function       : Functions related to file system on  */
/*                   SD cards                             */
/* -------------------------------------------------------*/
/*  Revision History :                                    */ 
/*  Author				 Date				       Reason               */
/*  Jan Szymanski  18 September 2005 Initial Design       */
/*  Jan Szymanski  18 April 2006     Ported to LPC2148    */
/*                                                        */
/**********************************************************/

#define DA_OWNER  1
#include "includes.h"


/**********************************************************/
/*  Name        : SD_FATStart                             */
/*  Parameters  : filename                                */
/*  Returns     : first entry in FAT                      */
/*  Scope       :                                         */
/*  Function    : to find first entry in FAT              */
/*--------------------------------------------------------*/

unsigned int SD_FATStart(unsigned char *filename)
{
unsigned int i,j;
unsigned long block;
unsigned int start;

unsigned char name[11];

strncpy((char*)name,(char*)filename,8);
strncpy((char*)name+8,(char*)filename+9,3);

block=SD_param.dir;
for (i=0; i<SD_param.dirblocks; i++)
  {
  SD_ReadBlock(block++,SD_buf1); /* read block into SD_buf1 */

  for (j=0; j<16;j++)
    {
    if (SD_buf1[0+j*32]!=0xe5)
			{
			if(strncmp((char*)SD_buf1+j*32,(char*)name,11)==0)
				{
				start=256*SD_buf1[j*32+27];
				start += SD_buf1[j*32+26];
				filesize = SD_buf1[j*32+31];	// byte 3
				filesize <<= 8;
				filesize += SD_buf1[j*32+30];	// byte 2
				filesize <<= 8;
				filesize += SD_buf1[j*32+29];	// byte 1
				filesize <<= 8;
				filesize += SD_buf1[j*32+28];	// byte 0
				tmpfilesize = 512;
				return start;
				}
			}
		}
	} 
return 0;
}
/*--------------------------------------------------------*/
/* End of Function: SD_FATstart                           */
/**********************************************************/

/**********************************************************/
/*  Name        : SD_fopen                                */
/*  Parameters  : filename                                */
/*  Returns     : result                                  */
/*  Scope       :                                         */
/*  Function    : to initialize datastructure for the file*/
/*--------------------------------------------------------*/

unsigned char SD_fopen(unsigned char *filename)
{
unsigned int temp,temp1,firstentry;
unsigned int i;
SD_var.cluster=SD_FATStart((unsigned char*)filename); /* first entry in FAT */
/* find the position within FAT */
SD_var.FATblock=SD_param.FAT1;  /* start block of FAT1 */
if(SD_param.filesystem == FAT16)
	{
	temp=SD_var.cluster>>8; /* /256 2 bytes per entry for FAT16 */
	SD_var.entry=SD_var.cluster & 0x00ff; /* entry=0-255 */
	SD_var.FATblock+=temp;
  // read the block of FAT into buffer SD_buf1
	SD_ReadBlock(SD_var.FATblock,SD_buf1);
	}else // FAT12
		{
		// 12 bits (1.5 bytes) per FAT entry in FAT12
		temp=SD_var.cluster;
    if((temp&0x0001)==0x0001) SD_var.even = 0;
			else SD_var.even = 1;
		temp /= 2;
		temp *= 3;
		SD_var.fbptr = temp & 0x01ff;	// 0-511
		temp /= 512;
		SD_var.FATblock+=temp;
		// read the block of FAT into buffer SD_buf1
		SD_ReadBlock(SD_var.FATblock,SD_buf1);
		}

SD_var.blocknum=(long)SD_param.data;
SD_var.blocknum += (long)SD_var.cluster*(long)SD_param.clusters; /* first block of cluster */
SD_var.blockcount = 0;
SD_var.open=1;
SD_var.bptr=SD_buf;
SD_ReadBlock(SD_var.blocknum,SD_buf); /* read block into a buffer */

if(strncmp(filename+9,(char*)"WAV",3)==0) // for *.wav file preload buffer
{
// preload bb
//load_index = 0;
//play_index = 0;
//SD_ReadBlock(SD_var.blocknum,(unsigned char *)&bb[load_index]);  
pcm_load_ptr = (unsigned char*)PCM_BUFFER_START;
pcm_play_ptr = (unsigned char *)PCM_BUFFER_START;

for(i=0; i<(BB_BLOCKS-1); i++)
  {
  //load_index += 512;
  pcm_load_ptr += 512;
  // prepare the next block
  SD_var.blocknum++;
  SD_var.blockcount++;
  if(SD_var.blockcount>=SD_param.clusters)
  // read next cluster from FAT
    {
    //cluster = 256*tmp1[2*i+1];  /* high byte */
    SD_var.cluster = SD_buf1[2*SD_var.entry+1]<<8;
    SD_var.cluster += SD_buf1[2*SD_var.entry];   /* low byte */
    if(SD_var.cluster==0xffff)
      {
      SD_fclose();
      return;
      }else
        {
        SD_var.blocknum=(long)SD_param.data;
        SD_var.blocknum += (long)SD_var.cluster*(long)SD_param.clusters; /* first block of cluster */
        SD_var.blockcount = 0;
        //SD_ReadBlock(SD_var.blocknum,SD_buf); /* read block into a buffer */
        }
    SD_var.entry++;
    if(SD_var.entry>255)	// read next FAT page into buffer
      {
      SD_var.FATblock++;
      SD_var.entry=0;
      SD_ReadBlock(SD_var.FATblock,SD_buf1);
      }
    }
    //SD_ReadBlock(SD_var.blocknum,(unsigned char *)&bb[load_index]); /* read block into a buffer */
    SD_ReadBlock(SD_var.blocknum,pcm_load_ptr); 
    tmpfilesize += 512;
    if(tmpfilesize >= filesize)
      {
      SD_fclose();
      return;
      }
  }
}// end of preloading buffer for *.WAV only
return PASS;
}
/*--------------------------------------------------------*/
/* End of Function: SD_fopen                              */
/**********************************************************/

/**********************************************************/
/*  Name        : SD_fclose                               */
/*  Parameters  : none                                    */
/*  Returns     : none                                    */
/*  Scope       :                                         */
/*  Function    : to close current file                   */
/*--------------------------------------------------------*/
void SD_fclose(void)
{
unsigned int i;

SD_var.open=0;
// disable SSP
//SSPCR1 = 0x00;
//VICIntEnClr = 0x800;    // disable SSP interrupt
//SSPMIS = 0x1f;  // try
//SSPICR = 0x03;  // reset INT errors

pcm_play_ptr = (unsigned char *)PCM_BUFFER_START;
pcm_load_ptr = (unsigned char *)PCM_BUFFER_START;
for(i=0; i<PCM_BUFFER_SIZE; i++)
  *pcm_load_ptr++ = 0;
pcm_load_ptr = (unsigned char *)PCM_BUFFER_START;

return;
}
/*--------------------------------------------------------*/
/* End of Function: SD_fclose                             */
/**********************************************************/

/**********************************************************/
/*  Name        : SD_play_wave                            */
/*  Parameters  : taken from SD_var                       */
/*  Returns     : none                                    */
/*  Scope       :                                         */
/*  Function    : to play wave file                       */
/*--------------------------------------------------------*/
void SD_play_wave(void)
{
SSPICR = 0x03;  // reset INT errors
VICIntEnable = 0x800;     // enable SSP interrupt

while(1)
  {
// this part for FAT16
	if(SD_param.filesystem == FAT16)
			{
//      load_index += 512;
//      if(load_index >= BIG_SIZE) load_index = 0;
      pcm_load_ptr += 512;
      if(pcm_load_ptr > (unsigned char *)PCM_BUFFER_END) pcm_load_ptr = (unsigned char *)PCM_BUFFER_START;
			SD_var.blocknum++;
			SD_var.blockcount++;
			if(SD_var.blockcount>=SD_param.clusters)
			// read next cluster from FAT
				{
				//cluster = 256*tmp1[2*i+1];  /* high byte */
				SD_var.cluster = SD_buf1[2*SD_var.entry+1]<<8;
				SD_var.cluster += SD_buf1[2*SD_var.entry];   /* low byte */
				if(SD_var.cluster==0xffff)
					{
					SD_fclose();
					return;
					}else
						{
						SD_var.blocknum=(long)SD_param.data;
						SD_var.blocknum += (long)SD_var.cluster*(long)SD_param.clusters; /* first block of cluster */
						SD_var.blockcount = 0;
						//SD_ReadBlock(SD_var.blocknum,SD_buf); /* read block into a buffer */
						}
				SD_var.entry++;
				if(SD_var.entry>255)	// read next FAT page into buffer
					{
					SD_var.FATblock++;
					SD_var.entry=0;
					SD_ReadBlock(SD_var.FATblock,SD_buf1);
					}
				}
      SD_ReadBlock(SD_var.blocknum,SD_buf); /* read block into a buffer */
      // need to synchronize here with play_index
      //while(abs(play_index-load_index)<512){} // was 1024
      //memcpy((void*)&bb[load_index], SD_buf, 512);
      while(abs(pcm_play_ptr - pcm_load_ptr)<512){} // was 1024
      memcpy((void*)pcm_load_ptr, SD_buf, 512);
      tmpfilesize += 512;
      if(tmpfilesize >= filesize)
        {
        SD_fclose();
        return;
        }
			} 
// end of FAT16
  } // end of while(1)
//set_event(OS_FILE_PLAY,SD_play_wave);
return;

}
//SD_ReadBlock(SD_var.blocknum,SD_buf); /* read block into a buffer */
/*--------------------------------------------------------*/
/* End of Function: SD_play_wave                          */
/**********************************************************/

/**********************************************************/
/* END OF FILE DiskAppl.c                                 */
/**********************************************************/




