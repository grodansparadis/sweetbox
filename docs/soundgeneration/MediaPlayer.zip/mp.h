#ifndef	MP_H
#define	MP_H

#ifdef MP_OWNER

/*--------------------------------------------------------*/
/* Local variables and data                               */
/*--------------------------------------------------------*/
// for timers 
volatile unsigned int freems; 
volatile unsigned int free10ms;
volatile unsigned int t10ms_1;
/*--------------------------------------------------------*/
/* Local functions prototypes                             */
/*--------------------------------------------------------*/
void init_vars(void);
void init_hardware(void);

#else
/*--------------------------------------------------------*/
/* Global variables and data                              */
/*--------------------------------------------------------*/
// for timers
extern volatile unsigned int freems; 
extern volatile unsigned int free10ms;
extern volatile unsigned int t10ms_1;
/*--------------------------------------------------------*/
/* Global functions prototypes                            */
/*--------------------------------------------------------*/
void init_vars(void);
void init_hardware(void);


#endif

#endif

/**********************************************************/
/* END OF FILE mp.h                                       */
/**********************************************************/


