#ifndef CONTROL_H
#define CONTROL_H

#ifdef CONTROL_OWNER

/*--------------------------------------------------------*/
/* Local variables and data                               */
/*--------------------------------------------------------*/
unsigned int filenum;
unsigned int total_files;
/*--------------------------------------------------------*/
/* Local functions prototypes                             */
/*--------------------------------------------------------*/
void mp_play(void);
unsigned int SD_NOF(void);
void SD_find_name(unsigned int num);
#else
/*--------------------------------------------------------*/
/* Global variables and data                              */
/*--------------------------------------------------------*/
extern unsigned int filenum;
extern unsigned int total_files;
/*--------------------------------------------------------*/
/* Global functions prototypes                            */
/*--------------------------------------------------------*/
void mp_play(void);
unsigned int SD_NOF(void);
void SD_find_name(unsigned int num);
#endif

#endif

/**********************************************************/
/* END OF FILE control.h                                  */
/**********************************************************/
