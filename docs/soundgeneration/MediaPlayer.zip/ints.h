#ifndef	INTS_H
#define	INTS_H

#ifdef INTS_OWNER

/*--------------------------------------------------------*/
/* Local variables and data                               */
/*--------------------------------------------------------*/

/*--------------------------------------------------------*/
/* Local functions prototypes                             */
/*--------------------------------------------------------*/
void timer0ISR(void) __attribute__ ((interrupt ("IRQ")));
void timer1ISR(void) __attribute__ ((interrupt ("IRQ")));
void uart0ISR(void) __attribute__ ((interrupt ("IRQ")));
void spi0ISR(void) __attribute__ ((interrupt ("IRQ")));
void sspISR(void) __attribute__ ((interrupt ("IRQ")));
#else
/*--------------------------------------------------------*/
/* Global variables and data                              */
/*--------------------------------------------------------*/

/*--------------------------------------------------------*/
/* Global functions prototypes                            */
/*--------------------------------------------------------*/
extern void timer0ISR(void) __attribute__ ((interrupt ("IRQ")));
extern void timer1ISR(void) __attribute__ ((interrupt ("IRQ")));
extern void uart0ISR(void) __attribute__ ((interrupt ("IRQ")));
extern void spi0ISR(void) __attribute__ ((interrupt ("IRQ")));
extern void sspISR(void) __attribute__ ((interrupt ("IRQ")));
#endif

#endif

/**********************************************************/
/* END OF FILE ints.h                                     */
/**********************************************************/

