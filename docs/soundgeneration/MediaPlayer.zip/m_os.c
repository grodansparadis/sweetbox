/**********************************************************/
/*                                                        */
/*  Module         : m_os.c                               */
/*  Language used  : CW                                   */
/*  Microprocessor : TI MSP430                            */
/*                                                        */
/*  Function       : Interface files for the              */
/*                   Operating System                     */
/* -------------------------------------------------------*/
/*  Revision History :                                    */ 
/*  Author				 Date				       Reason               */
/*  xxx            May 2002    	     Initial Design       */
/*                                                        */
/**********************************************************/


/**********************************************************/
/*   SYSTEM  Includes                                     */
/**********************************************************/
#define MOS_OWNER
#include "includes.h"

/**********************************************************/
/*  Definitions                                           */
/**********************************************************/


/**********************************************************/
/*  Local Function Prototypes                             */
/**********************************************************/


/**********************************************************/
/*  Name        :init_OS                                  */
/*  Parameters  :void                                     */
/*  Returns     :void                                     */
/*  Scope       : System                                  */
/*  Function    : To init the operating sysem             */
/*--------------------------------------------------------*/
void init_OS(void)
{
init_timers();  /* Initialise the Timers    */
init_event_Q(); /* Initialise the event Q   */
}
/*--------------------------------------------------------*/
/* End of Function: init_OS                               */
/**********************************************************/

/**********************************************************/
/*  Name        :init_event_Q                             */
/*  Parameters  :void                                     */
/*  Returns     :void                                     */
/*  Scope       : System                                  */
/*  Function    : To clear the event Q                    */
/*--------------------------------------------------------*/
void init_event_Q(void)
{
unsigned int e_cnt;
e_cnt = 0;
while ( e_cnt < MAX_EVENTS )
  {
  event_Q[e_cnt].event_ID = FREE_EVENT;
  e_cnt++;
  }
}
/*--------------------------------------------------------*/
/* End of Function: init_event_Q                          */
/**********************************************************/

/**********************************************************/
/*  Name        :do_events                                */
/*  Parameters  :void                                     */
/*  Returns     :void                                     */
/*  Scope       : System                                  */
/*  Function    : execute all the events on the Q         */
/*--------------------------------------------------------*/
void do_events(void)
{
unsigned int e_cnt;
e_cnt = 0;
while ( e_cnt <  MAX_EVENTS)
  {
  if ( event_Q[e_cnt].event_ID != FREE_EVENT )
    {
    (*event_Q[e_cnt].event_fp)();           /* execute the event    */
    event_Q[e_cnt].event_ID = FREE_EVENT;   /* Free the event space */
    }
  e_cnt++;
  }
}
/*--------------------------------------------------------*/
/* End of Function: do_events                             */
/**********************************************************/

/**********************************************************/
/*  Name        :set_event                                */
/*  Parameters  :unsigned int e_ID,  event ID             */
/*               void (* e_fp)(void)  function to execute */
/*  Returns     :char  EVENT_STARTED   added to Q         */
/*                      EVENT_FAIL     Failed for whatever reason */
/*  Scope       : Module only                             */
/*  Function    : To find the closest free event slot in forward direction*/
/*              avalible place                                            */
/*--------------------------------------------------------*/
char set_event(unsigned int e_ID,void (* e_fp)(void) )
{
unsigned int e_cnt;
unsigned char status;
status = EVENT_FAIL;
e_cnt = 0;
while( ( e_cnt < MAX_EVENTS ) && ( status == EVENT_FAIL ))// was &
  {
  if ( event_Q[e_cnt].event_ID == FREE_EVENT )
    {
    event_Q[e_cnt].event_ID = e_ID;
    event_Q[e_cnt].event_fp = e_fp;
    status = EVENT_STARTED;
    }
  e_cnt++;
  }
return (status);
}
/*--------------------------------------------------------*/
/* End of Function: set_event                             */
/**********************************************************/


/**********************************************************/
/*  Name        :free_event                               */
/*  Parameters  :unsigned int e_ID,                       */
/*  Returns     :char TMR_STARTED TMR_FAIL                */
/*  Function    :To free event from the Q                 */
/*--------------------------------------------------------*/
char free_event(unsigned int e_ID)
{
unsigned int e_cnt;
e_cnt = 0;
while( e_cnt < MAX_EVENTS )
  {
  if ( event_Q[e_cnt].event_ID == e_ID )
    {
    event_Q[e_cnt].event_ID = FREE_EVENT ;
    }
  e_cnt++;
  }
return (EVENT_STARTED);
}
/*--------------------------------------------------------*/
/* End of Function: free_event                            */
/**********************************************************/

/**********************************************************/
/*  Name        :init_timers                              */
/*  Parameters  :void                                     */
/*  Returns     :void                                     */
/*  Scope       : System                                  */
/*  Function    : To Clear all the timers                 */
/*--------------------------------------------------------*/
void init_timers(void)
{
unsigned int tmr_cnt;
tmr_cnt = 0;
while ( tmr_cnt < MAX_100MS_TIMER )
  {
  ms100_timer[tmr_cnt].timer_ID = FREE_TIMER;
  tmr_cnt++;
  }
}
/*--------------------------------------------------------*/
/* End of Function: init_timers                           */
/**********************************************************/

/**********************************************************/
/*  Name        :service_timers                           */
/*  Parameters  :void                                     */
/*  Returns     :void                                     */
/*  Scope       : Timer Interrupt will set the timer tick counter */
/*  Function    : To process ALL the 100mS_timer for EACH TIMER TICK */
/*--------------------------------------------------------*/
void service_timers(void)
{
unsigned int tmr_cnt;
/*----- counter increments in Int(f) ---------------------*/
if( timer_tick > 0 )
  {
  while( timer_tick > 0 )
    {
    timer_tick--;
    /*----------------------------------------------------*/
    tmr_cnt = 0;
    while ( tmr_cnt < MAX_100MS_TIMER )
      {
      if ( ms100_timer[tmr_cnt].timer_ID > FREE_TIMER )
        {
        if (--ms100_timer[tmr_cnt].timer == 0 )    /* timer just expired */
          {
          set_event(  ms100_timer[tmr_cnt].timer_ID, ms100_timer[tmr_cnt].time_out_fp ); /* Place function onto event_que */
          ms100_timer[tmr_cnt].timer_ID = FREE_TIMER;
          }
        }
      tmr_cnt++;
      }
    }
  }
}
/*--------------------------------------------------------*/
/* End of Function: service_timers                        */
/**********************************************************/

/**********************************************************/
/*  Name        :set_timer                                */
/*  Parameters  :unsigned int t_ID,  timer ID             */
/*               unsigned int t_cnt,  Timer count 100ms   */
/*               void (* t_fp)(void)  function to execute on expiry */
/*  Returns     :char  TMR_STARTED                        */
/*                      TMR_FAIL                          */
/*  Scope       : Module only                             */
/*  Function    : T0 check the timer list and add a timer to the 1st */
/*              avalible place                            */
/*--------------------------------------------------------*/
char set_timer(unsigned int t_ID,unsigned int t_cnt,void (* t_fp)(void) )
{
unsigned int tmr_cnt;
unsigned char status;
status = TMR_FAIL;
tmr_cnt = 0;
while( ( tmr_cnt < MAX_100MS_TIMER ) && ( status == TMR_FAIL ))
  {
  if ( ms100_timer[tmr_cnt].timer_ID == FREE_TIMER )
    {
    ms100_timer[tmr_cnt].timer_ID = t_ID;
    ms100_timer[tmr_cnt].timer = t_cnt;
    ms100_timer[tmr_cnt].time_out_fp = t_fp;
    status = TMR_STARTED;
    }
  tmr_cnt++;
  }
return (status);
}
/*--------------------------------------------------------*/
/* End of Function: set_timer                             */
/**********************************************************/

/**********************************************************/
/*  Name        :restart_timer                            */
/*  Parameters  :unsigned int t_ID,  timer ID             */
/*               unsigned int t_cnt,  Timer count 100ms   */
/*               void (* t_fp)(void)  function to execute on expiry */
/*  Returns     :char  TMR_STARTED                        */
/*                      TMR_FAIL                          */
/*  Scope       : Module only                             */
/*  Function    : T0 check the timer list to see if a timer has started   */
/*                  If the not found add timer, if found reset the expire */
/*                  time. Update the function             */
/*--------------------------------------------------------*/
char restart_timer(unsigned int t_ID,unsigned int t_cnt,void (* t_fp)(void) )
{
unsigned int tmr_cnt;
unsigned int tmp_free_ID;
unsigned char status;
status = TMR_FAIL;
tmr_cnt = 0;
tmp_free_ID = MAX_100MS_TIMER + 1;
while( ( tmr_cnt < MAX_100MS_TIMER ) && ( status == TMR_FAIL ))//was &
  {
  if ( ms100_timer[tmr_cnt].timer_ID == FREE_TIMER )   /* remember a free timer slot */
    {
    tmp_free_ID = tmr_cnt;
    }
  if ( ms100_timer[tmr_cnt].timer_ID == t_ID )
    {
    ms100_timer[tmr_cnt].timer = t_cnt;
    ms100_timer[tmr_cnt].time_out_fp = t_fp;
    status = TMR_STARTED;
    }
  tmr_cnt++;
  }
if ( ( status == TMR_FAIL ) && ( tmp_free_ID < MAX_100MS_TIMER ))//was &
  {
  ms100_timer[tmp_free_ID].timer_ID = t_ID;
  ms100_timer[tmp_free_ID].timer = t_cnt;
  ms100_timer[tmp_free_ID].time_out_fp = t_fp;
  status = TMR_STARTED;
  }
return (status);
}
/*--------------------------------------------------------*/
/* End of Function: restart_timer                         */
/**********************************************************/

/**********************************************************/
/*  Name        :free_timer                               */
/*  Parameters  :unsigned int t_ID,  timer ID             */
/*  Returns     :char TMR_STARTED TMR_FAIL                */
/*  Function    :To free timer that is set in time list   */
/*--------------------------------------------------------*/
char free_timer(unsigned int t_ID)
{
unsigned int tmr_cnt;
unsigned char status;
tmr_cnt = 0;
while( tmr_cnt < MAX_100MS_TIMER )
  {
  if ( ms100_timer[tmr_cnt].timer_ID == t_ID )
    {
    ms100_timer[tmr_cnt].timer_ID = FREE_TIMER;
    status = TMR_FAIL;
    }
  tmr_cnt++;
  }
return (status);
}
/*--------------------------------------------------------*/
/* End of Function: free_timer                            */
/**********************************************************/


/**********************************************************/
/*  Name        :end_task                                 */
/*  Parameters  :unsigned int t_ID                        */
/*  Returns     :char TMR_STARTED TMR_FAIL                */
/*  Function    :To end a task, take off the Timer and event Q */
/*--------------------------------------------------------*/
char end_task(unsigned int t_ID)
{
unsigned char status;
status = free_timer(t_ID) || free_event(t_ID);
return (status);
}
/*--------------------------------------------------------*/
/* End of Function: end_task                              */
/**********************************************************/

/**********************************************************/
/* End of Module: m_os.c                                  */
/**********************************************************/

