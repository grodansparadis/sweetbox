/**********************************************************/
/* Includes                                               */ 
/**********************************************************/
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "defines.h"

#include "LPC2148.h"

// for helix code
#include "mp3dec.h"

#include "mp.h"
#include "ints.h"
//#include "m_os.h"
#include "mischard.h"
#include "serial.h"
#include "sd.h"
#include "diskappl.h"
#include "codec.h"
#include "control.h"
#include "mp3.h"

/**********************************************************/
/* END OF FILE includes.h                                 */
/**********************************************************/



