#ifndef DA_H
#define DA_H

typedef struct disk_var
  {
	unsigned char open;			// open = 1, closed = 0
	unsigned char cardOK;		// 
  unsigned char filename[12];
	//unsigned int firstentry;
	unsigned int entry;
  unsigned int FATblock;
	unsigned int cluster;
	unsigned long blocknum;	// absolute number of 512 bytes block
	unsigned char blockcount;
	unsigned char *bptr;	// pointer to data buffer
	unsigned int fbptr;	// for FAT12, pointer to FAT buffer
	unsigned char even;	// for FAT12
	unsigned char fbyte1;	// for FAT12
	unsigned char fbyte2;	// for FAT12
	unsigned char fbyte3;	// for FAT12
  }disk_var;

typedef union {
  unsigned char b8[4];
  unsigned short b16[2];
  unsigned int b32;
    } wave_data;

#if(DA_OWNER==1)
/*--------------------------------------------------------*/
/* Local variables and data                               */
/*--------------------------------------------------------*/
unsigned int SD_total_files;
unsigned int SD_current_file;

struct disk_var SD_var;
unsigned long filesize;
unsigned long tmpfilesize;

// new 22/04/2006
//volatile unsigned char bb[BIG_SIZE];   // big buffer
//volatile unsigned int load_index;
//volatile unsigned int play_index;

unsigned char *pcm_play_ptr;
unsigned char *pcm_load_ptr;
// end of new 22/04/2006

wave_data left;
wave_data right;
wave_data left1;
wave_data right1;
/*--------------------------------------------------------*/
/* Local functions prototypes                             */
/*--------------------------------------------------------*/
unsigned int SD_FATStart(unsigned char *filename);
unsigned char SD_fopen(unsigned char *filename);
void SD_fclose(void);
void SD_play_wave(void);
#else
/*--------------------------------------------------------*/
/* Global variables and data                              */
/*--------------------------------------------------------*/
extern const unsigned char filename[5][12];
extern struct disk_var SD_var;

// new 22/04/2006
//extern volatile unsigned char bb[BIG_SIZE];   // big buffer
//extern volatile unsigned int load_index;
//extern volatile unsigned int play_index;

extern unsigned char *pcm_play_ptr;
extern unsigned char *pcm_load_ptr;
// end of new 22/04/2006

extern wave_data left;
extern wave_data right;
extern wave_data left1;
extern wave_data right1;
extern unsigned long filesize;
extern unsigned long tmpfilesize;
/*--------------------------------------------------------*/
/* Global functions prototypes                            */
/*--------------------------------------------------------*/
unsigned int SD_FATStart(unsigned char *filename);
unsigned char SD_fopen(unsigned char *filename);
void SD_fclose(void);
//void SD_PlayFile(void);
void SD_play_wave(void);
#endif

#endif

/**********************************************************/
/* END OF FILE diskappl.h                                 */
/**********************************************************/
