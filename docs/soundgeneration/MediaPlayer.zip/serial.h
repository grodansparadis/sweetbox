#ifndef	SERIAL_H
#define	SERIAL_H

#define putchar_PC putchar_uart0
#define putstring_PC putstring_uart0
#define getchar_PC getchar_uart0
#define ischar_PC ischar_uart0

#define putchar_SD putchar_spi0
#define putstring_SD putstring_spi0
#define getchar_SD getchar_spi0
#define ischar_SD ischar_spi0

#define putchar_DAC putchar_spi0
#define getchar_DAC getchar_spi0
#define putint_DAC putint_spi0
#define getint_DAC getint_spi0
#define ischar_DAC ischar_spi0

#ifdef  SERIAL_OWNER
/*--------------------------------------------------------*/
/* Local variables and data                               */
/*--------------------------------------------------------*/
unsigned char *prd_uart0;
unsigned char *pwr_uart0;
unsigned char buffer_rxuart0[UART0_RX_BUFFER_SIZE];
unsigned char *prd_uart1;
unsigned char *pwr_uart1;
unsigned char buffer_rxuart1[UART1_RX_BUFFER_SIZE];
/*--------------------------------------------------------*/
/* Local functions prototypes                             */
/*--------------------------------------------------------*/
void putchar_uart0(unsigned char c);
void putstring_uart0(unsigned char *str);
unsigned char getchar_uart0(void);
unsigned char ischar_uart0(void);
void putchar_uart1(unsigned char c);
unsigned char getchar_uart1(void);
void putstring_uart1(unsigned char *str);
unsigned char ischar_uart1(void);
void putchar_spi0(unsigned char c);
unsigned char getchar_spi0(void);
void putint_spi0(unsigned int i);
unsigned int getint_spi0(void);
void putstring_spi0(unsigned char *str);
unsigned char ischar_spi0(void);
#else
/*--------------------------------------------------------*/
/* Global variables and data                              */
/*--------------------------------------------------------*/
extern unsigned char *prd_uart0;
extern unsigned char *pwr_uart0;
extern unsigned char buffer_rxuart0[UART0_RX_BUFFER_SIZE];
extern unsigned char *prd_uart1;
extern unsigned char *pwr_uart1;
extern unsigned char buffer_rxuart1[UART1_RX_BUFFER_SIZE];
/*--------------------------------------------------------*/
/* Global functions prototypes                            */
/*--------------------------------------------------------*/
void putchar_uart0(unsigned char c);
void putstring_uart0(unsigned char *str);
unsigned char getchar_uart0(void);
unsigned char ischar_uart0(void);
void putchar_uart1(unsigned char c);
unsigned char getchar_uart1(void);
void putstring_uart1(unsigned char *str);
unsigned char ischar_uart1(void);
void putchar_spi0(unsigned char c);
unsigned char getchar_spi0(void);
void putint_spi0(unsigned int i);
unsigned int getint_spi0(void);
void putstring_spi0(unsigned char *str);
unsigned char ischar_spi0(void);

#endif
#endif

/**********************************************************/
/* END OF FILE serial.h                                   */
/**********************************************************/
