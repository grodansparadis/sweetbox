#ifndef	DEFINES_H
#define	DEFINES_H

/**********************************************************/
/* definitions                                            */
/**********************************************************/ 

//#define DEBUG 1
//#define VERSION (unsigned char *) "Media Player version 18/09/2005"
#define VERSION (unsigned char *) "Media Player version 18/04/2006"

#define	TRUE	(unsigned char)1
#define FALSE	(unsigned char)0
#define	ON		(unsigned char)1
#define OFF		(unsigned char)0
#define	CR		0x0d
#define	LF		0x0a
#define PASS	(unsigned char)1
#define FAIL	(unsigned char)0

#define	UART0_RX_BUFFER_SIZE 64	// serial receive interrupt buffer size
#define	UART1_RX_BUFFER_SIZE 64	// serial receive interrupt buffer size

#define PCM_BUFFER_START  0x7fd01000  // use USB buffer
#define PCM_BUFFER_END  0x7fd01fff    // 4096 bytes
#define BB_BLOCKS 8                   // 4096 = 8 * 512
#define PCM_BUFFER_SIZE 4096

#define MP3_SDBUF_START  0x7fd00000   // use USB buffer
#define MP3_SDBUF_END  0x7fd00fff     // 4098 bytes
#define MP3_BLOCKS 8
#define MP3_BUFFER_SIZE 4096

//#define PCM_BUFFER_START  0x7fd00800  // use USB buffer
//#define PCM_BUFFER_END  0x7fd01fff    // 6144 bytes
//#define BB_BLOCKS 12                   // 6144 = 12 * 512
//#define PCM_BUFFER_SIZE 6144

//#define MP3_SDBUF_START  0x7fd00000   // use USB buffer
//#define MP3_SDBUF_END  0x7fd007ff     // 2048 bytes
//#define MP3_BLOCKS 4                  // 2048 = 4 * 512
//#define MP3_BUFFER_SIZE 2048



#define SD_BUFFER_SIZE  512
#define SDB_BLOCKS  1 // 512/512 = 1

#endif

/**********************************************************/
/* END OF FILE defines.h                                  */
/**********************************************************/
