#ifndef SD_H
#define SD_H

typedef struct param
  {
  unsigned int FAT1;  /* start block of FAT1 */
  unsigned int dir;   /* start block of root directory */
  unsigned int dirblocks; /* directory size in blocks */
  unsigned int data;  /* start block of data */
  unsigned int clusters; /* number of blocks per cluster */
	unsigned char filesystem;	/* FAT12 and FAT16 only */
	unsigned char error;	/* error code */
  }param;
#define FAT12		1
#define FAT16		2

// error codes
#define SD_ERROR_OK	0
#define SD_ERROR_NOCARD	1
#define SD_ERROR_FTI	2		// Failed To Initialize
#define SD_ERROR_MISSING_FILE	3

#ifdef  SD_OWNER

#define SD_GO_IDLE_STATE	 0
#define SD_SEND_OP_COND	 1
#define SD_SEND_CSD		 9
//#define SD_SEND_CID		10
#define SD_SEND_STATUS		13
#define SD_READ_SINGLE_BLOCK	17

#define SD_CMD55	55
#define SD_ACMD41	41

#define R1_BUSY		128
#define R1_PARAMETER	 64
#define R1_ADDRESS	 32
#define R1_ERASE_SEQ	 16
#define R1_COM_CRC	  8
#define R1_ILLEGAL_COM	  4
#define R1_ERASE_RESET	  2
#define R1_IDLE_STATE	  1

#define R2_BUSY		32768
#define R2_PARAMETER	16384
#define R2_ADDRESS	 8192
#define R2_ERASE_SEQ	 4096
#define R2_COM_CRC	 2048
#define R2_ILLEGAL_COM	 1024
#define R2_ERASE_RESET	  512
#define R2_IDLE_STATE	  256
#define R2_OUT_OF_RANGE	  128
#define R2_ERASE_PARAM	   64
#define R2_WP_VIOLATION	   32
#define R2_CARD_ECC_FAILED 16
#define R2_CC_ERROR	    8
#define R2_ERROR	    4
#define R2_WP_ERASE_CHIP    2
#define R2_ZERO		    1
/*--------------------------------------------------------*/
/* Local variables and data                               */
/*--------------------------------------------------------*/
enum SD_END 
  {
  sdLeave,
  sdFinish
  };

unsigned int SD_status;
unsigned char bCSD[20];
unsigned char SD_buf[512];
unsigned char SD_buf1[512];

unsigned char *SD_buf_ptr;  // new 22/04/2006 

/* data structure to keep memory card parameters */ 
struct param SD_param;

/*--------------------------------------------------------*/
/* Local functions prototypes                             */
/*--------------------------------------------------------*/
unsigned char SD_card_present(void);
unsigned char SD_init(void);
unsigned char SD_ReadByte(void);
void SD_WriteByte(unsigned char byte);
void SD_EndCmd(void);
void SD_Flush(unsigned int n);
unsigned int SD_SendCmd(unsigned char cmd, unsigned long arg,
                         enum SD_END end);
void SD_Id(void);
unsigned int SD_InitSPI(void);
void SD_ReadBlock(unsigned long block, unsigned char *ptr);

#else
/*--------------------------------------------------------*/
/* Global variables and data                              */
/*--------------------------------------------------------*/
extern struct param SD_param;
extern unsigned char SD_buf[512];
extern unsigned char SD_buf1[512];

extern unsigned char *SD_buf_ptr;  // new 22/04/2006 
/*--------------------------------------------------------*/
/* Global functions prototypes                            */
/*--------------------------------------------------------*/
unsigned char SD_init(void);
void SD_ReadBlock(unsigned long block, unsigned char *ptr);
void SD_Id(void);

#endif

#endif

/**********************************************************/
/* END OF FILE sd.h                                       */
/**********************************************************/

