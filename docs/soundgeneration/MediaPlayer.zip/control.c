/**********************************************************/
/*                                                        */
/*  Module         : control.c                            */
/*  Language used  : CS                                   */
/*  Microprocessor : MSP430                               */
/*                                                        */
/*  Function       : Functions related to the control of  */
/*                   media player                         */
/* -------------------------------------------------------*/
/*  Revision History :                                    */ 
/*  Author				 Date				       Reason               */
/*  Jan Szymanski  18 September 2005 Initial Design       */
/*  Jan Szymanski  18 April 2006     Ported to LPC2148    */
/*                                                        */
/**********************************************************/

#define CONTROL_OWNER  1
#include "includes.h"


/**********************************************************/
/*  Name        : mp_play                                 */
/*  Parameters  : none                                    */
/*  Returns     : none                                    */
/*  Scope       :                                         */
/*  Function    : demo task to play all *.wav and *.mp3   */
/*                files from SD card                      */
/*--------------------------------------------------------*/
// as there is no navigation keys on MCB2130 board
// the audio files will be played around in a sequence
// they appear on SD card 

void mp_play(void)
{

SD_find_name(filenum);

SD_fopen(SD_var.filename);

//#ifdef DEBUG
  printf("%s","now playing: ");
  printf("%d%c", filenum,' ');
  printf("%s%s",SD_var.filename,"\r\n");
//#endif

if(strncmp(SD_var.filename+9,"WAV",3)==0)
  {
  SD_play_wave();
  }else
    {
    if(strncmp(SD_var.filename+9,"MP3",3)==0)
      {
      mp3_init();
      SD_play_mp3();
      }
    }

filenum++;
if(filenum > total_files) filenum = 1;

return;
}
/*--------------------------------------------------------*/
/* End of Function: mp_play                               */
/**********************************************************/

/**********************************************************/
/*  Name        : SD_NOF                                  */
/*  Parameters  : none                                    */
/*  Returns     : number of audio files on SD             */
/*  Scope       :                                         */
/*  Function    : to find a number of audio files on SD   */
/*--------------------------------------------------------*/

unsigned int SD_NOF(void)
{
unsigned int i,j;
unsigned long block;
unsigned int start;
unsigned int nof;

nof = 0;
block=SD_param.dir;
for (i=0; i<SD_param.dirblocks; i++)
  {
  SD_ReadBlock(block++,SD_buf1); /* read block into SD_buf1 */

  for (j=0; j<16;j++)
    {
    if (SD_buf1[0+j*32]!=0xe5)
			{
			if(strncmp((char*)SD_buf1+8+j*32,(char*)"WAV",3)==0)
				nof++;
			if(strncmp((char*)SD_buf1+8+j*32,(char*)"MP3",3)==0)
				nof++;
			}
		}
	} 
return nof;
}
/*--------------------------------------------------------*/
/* End of Function: SD_NOF                                */
/**********************************************************/

/**********************************************************/
/*  Name        : SD_find_name                            */
/*  Parameters  : filenumber                              */
/*  Returns     : none                                    */
/*  Scope       :                                         */
/*  Function    : to find filename in DIR and update      */
/*                SD_var.filename                         */
/*--------------------------------------------------------*/

void SD_find_name(unsigned int num)
{
unsigned int i,j;
unsigned long block;
unsigned int locnum;

locnum = 0;
block=SD_param.dir;
for (i=0; i<SD_param.dirblocks; i++)
  {
  SD_ReadBlock(block++,SD_buf1); /* read block into SD_buf1 */

  for (j=0; j<16;j++)
    {
    if (SD_buf1[0+j*32]!=0xe5)
			{
			if(strncmp((char*)SD_buf1+8+j*32,(char*)"MP3",3)==0)
        locnum++;
			if(strncmp((char*)SD_buf1+8+j*32,(char*)"WAV",3)==0)
        locnum++;      
			}
    if(locnum==num)
      {
      strncpy(SD_var.filename, SD_buf1+j*32, 8);
      SD_var.filename[8] = '.';
      strncpy(SD_var.filename+9, SD_buf1+8+j*32, 3);
      return;
      }
		}
	} 
return;
}
/*--------------------------------------------------------*/
/* End of Function: SD_find_name                          */
/**********************************************************/

/**********************************************************/
/* END OF FILE control.c                                  */
/**********************************************************/




