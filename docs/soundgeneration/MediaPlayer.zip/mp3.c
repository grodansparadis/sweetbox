/**********************************************************/
/*                                                        */
/*  Module         : mp3.c                                */
/*  Language used  : CS                                   */
/*  Microprocessor : MSP430                               */
/*                                                        */
/*  Function       : Functions related to mp3 audio files */
/*                                                        */
/* -------------------------------------------------------*/
/*  Revision History :                                    */ 
/*  Author				 Date:             Reason:              */
/*  xxxx           18 September 2005 Initial Design       */
/**********************************************************/

#define MP3_OWNER  1
#include "includes.h"

//#include "data/mp3d.h"
#include "mp3common.h" 


static void ClearBuffer(void *buf, int nBytes)
{
	int i;
	unsigned char *cbuf = (unsigned char *)buf;

	for (i = 0; i < nBytes; i++)
		cbuf[i] = 0;

	return;
}

/**********************************************************/
/*  Name        : mp3_init                                */
/*  Parameters  : none                                    */
/*  Returns     : none                                    */
/*  Scope       :                                         */
/*  Function    : to initialize mp3 decoder               */
/*--------------------------------------------------------*/
void mp3_init(void)
{
hMP3Decoder = &mp3DecInfo;

//hMP3Decoder = MP3InitDecoder();

mp3DecInfo.FrameHeaderPS = &fh;
mp3DecInfo.SideInfoPS = &si;
mp3DecInfo.ScaleFactorInfoPS = &sfi;
mp3DecInfo.HuffmanInfoPS = &hi;
mp3DecInfo.DequantInfoPS = &di;
mp3DecInfo.IMDCTInfoPS = &mi;
mp3DecInfo.SubbandInfoPS = &sbi;

/* important to do this - DSP primitives assume a bunch of state variables are 0 on first use */
ClearBuffer(&fh,  sizeof(FrameHeader));
ClearBuffer(&si,  sizeof(SideInfo));
ClearBuffer(&sfi, sizeof(ScaleFactorInfo));
ClearBuffer(&hi,  sizeof(HuffmanInfo));
ClearBuffer(&di,  sizeof(DequantInfo));
ClearBuffer(&mi,  sizeof(IMDCTInfo));
ClearBuffer(&sbi, sizeof(SubbandInfo));

bytesLeft = 0;
outOfData = 0;
eofReached = 0;
//readPtr = readBuf;
nRead = 0;
nFrames = 0;
tmpfilesize = 0;

}
/*--------------------------------------------------------*/
/* End of Function: mp3_init                              */
/**********************************************************/


/**********************************************************/
/*  Name        : SD_play_mp3                             */
/*  Parameters  : taken from SD_var                       */
/*  Returns     : none                                    */
/*  Scope       :                                         */
/*  Function    : to play mp3 file                        */
/*--------------------------------------------------------*/
void SD_play_mp3(void)
{
unsigned int i;
//unsigned char c;
//unsigned short w;
unsigned char *readBuf;
unsigned char *oBptr;
int error;

//hMP3Decoder = MP3InitDecoder();
hMP3Decoder = &mp3DecInfo;

bytesLeft = 0;
outOfData = 0;
eofReached = 0;
readPtr = (unsigned char *)MP3_SDBUF_START;
readBuf = (unsigned char *)MP3_SDBUF_START;
nRead = 0;
nFrames = 0; 
SD_buf_ptr = (unsigned char *)SD_buf;

pcm_play_ptr = (unsigned char *)PCM_BUFFER_START;
pcm_load_ptr = (unsigned char *)PCM_BUFFER_START;
for(i=0; i<PCM_BUFFER_SIZE; i++)
  *pcm_load_ptr++ = 0;

for(i=0; i<MP3_BUFFER_SIZE; i++)
  *readPtr++ = 0;
readPtr = (unsigned char *)MP3_SDBUF_START;

pcm_load_ptr = (unsigned char *)PCM_BUFFER_START;

//SSPCR1 = 0x00;
//SSPICR = 0x03;            // reset INT errors
//SSPMIS = 0x1f;  // try
//VICIntEnable = 0x800;     // enable SSP interrupt
// enable SSP
//SSPCR1 = 0x02;

do
  {
  /* somewhat arbitrary trigger to refill buffer - should always be enough for a full frame */
  if (bytesLeft < 2*MAINBUF_SIZE && !eofReached) 
    {
    nRead = myFillReadBuffer(readBuf, readPtr, MP3_BUFFER_SIZE, bytesLeft);
    bytesLeft += nRead;
    readPtr = readBuf;
    if (nRead == 0)
      eofReached = 1;
		}

  /* find start of next MP3 frame - assume EOF if no sync found */
  offset = MP3FindSyncWord(readPtr, bytesLeft);
  if (offset < 0) 
    {
    outOfData = 1;
    break;
		}
		readPtr += offset;
		bytesLeft -= offset;
  
  /* decode one MP3 frame - if offset < 0 then bytesLeft was less than a full frame */
  err = MP3Decode(hMP3Decoder, &readPtr, (int *)&bytesLeft, (short *)outBuf, 0);
  nFrames++; 

  if (err) 
    {
    /* error occurred */
    switch (err) 
      {
			case ERR_MP3_INDATA_UNDERFLOW:
				outOfData = 1;
				break;
			case ERR_MP3_MAINDATA_UNDERFLOW:
				/* do nothing - next call to decode will provide more mainData */
				break;
			case ERR_MP3_FREE_BITRATE_SYNC:
			default:
				outOfData = 1;
				break;
			}
		} else 
        {
        /* no error */
        MP3GetLastFrameInfo(hMP3Decoder, &mp3FrameInfo);
        oBptr = (unsigned char *)outBuf;
        for(i=0; i < mp3FrameInfo.outputSamps; i++)
          {
          free10ms = 0;
          while(abs(pcm_play_ptr - pcm_load_ptr)< 2) // synchronize
            {
            if(free10ms > 5) break; // timeout
            } // synchronize
          *pcm_load_ptr++ = *oBptr++;
          *pcm_load_ptr++ = *oBptr++;
          if(pcm_load_ptr > (unsigned char *)PCM_BUFFER_END) 
            pcm_load_ptr = (unsigned char *)PCM_BUFFER_START;
          }
        if(nFrames == 4)  // printf is to slow, so only show one frame
          LCD_show_frame();

        
        }

  if(tmpfilesize >= filesize)
    eofReached = 1;
  } while (!outOfData && !eofReached);


//#ifdef DEBUG
  putstring_PC((unsigned char *)"end of SD_play_mp3\r\n");
//#endif

SD_fclose();
//IO1CLR = 0x00010000;
return;

}
/*--------------------------------------------------------*/
/* End of Function: SD_play_mp3                           */
/**********************************************************/

/**********************************************************/
/*  Name        : myFillReadBuffer                        */
/*  Parameters  :                        */
/*  Returns     :                                     */
/*  Scope       :                                         */
/*  Function    :                         */
/*--------------------------------------------------------*/
int myFillReadBuffer(unsigned char *readBuf, unsigned char *readPtr, int bufSize, int bytesLeft)
{
int n_Read;
unsigned int bytesinSD,leftinSD;
unsigned char *ptr;

/* move last, small chunk from end of buffer to start, then fill with new data */
if(bytesLeft <= bufSize)  // data abort INT
  memmove(readBuf, readPtr, bytesLeft);	
 
// here we read from SD card
if((tmpfilesize + 512) < filesize)
  {
  // if there is anything left in SD_buf move it into MP3_BUFFER
  ptr = readBuf + bytesLeft;


  n_Read = 0;

  leftinSD = (unsigned int)(SD_buf + 512 - SD_buf_ptr);
  if(leftinSD > 0)
    {
    while((ptr < (readBuf + bufSize)) && (SD_buf_ptr < (SD_buf + 512)))
      {
      *ptr++ = *SD_buf_ptr++;
      n_Read++;
      }
    }

  while(ptr <= (readBuf + bufSize - 512))
    {
    bytesinSD = SD_read_next_sector();  
    n_Read += bytesinSD;
    memcpy(ptr, SD_buf, bytesinSD);
    ptr += bytesinSD;
    //SD_buf_ptr = (unsigned char *)SD_buf;
    //if(bytesinSD == 0) 
      //break;
    }

  if((tmpfilesize + 512) < filesize)
    {
    bytesinSD = SD_read_next_sector(); 
    SD_buf_ptr = (unsigned char *)SD_buf;
    while(ptr < (readBuf + bufSize))
      {
      *ptr++ = *SD_buf_ptr++;
      n_Read++;
      }
    }
  } else 
      outOfData = 1;
// end of reading from SD card

/* zero-pad to avoid finding false sync word after last frame (from old data in readBuf) */
if(bytesLeft <= bufSize) 
  {
  if (n_Read < bufSize - bytesLeft)
    memset(readBuf + bytesLeft + n_Read, 0, bufSize - bytesLeft - n_Read);	
  }
return n_Read;
}
/*--------------------------------------------------------*/
/* End of Function: my_FillReadBuffer                     */
/**********************************************************/

/**********************************************************/
/*  Name        : SD_read_next_sector                     */
/*  Parameters  : none                                    */
/*  Returns     : number of bytes in SD_buf               */
/*  Scope       :                                         */
/*  Function    : to read next 512 bytes from SD          */
/*--------------------------------------------------------*/
unsigned int SD_read_next_sector(void)
{

SD_var.blocknum++;
SD_var.blockcount++;
SD_buf_ptr = (unsigned char *)SD_buf;

if(SD_var.blockcount>=SD_param.clusters)
// read next cluster from FAT
  {
  //cluster = 256*tmp1[2*i+1];  /* high byte */
  SD_var.cluster = SD_buf1[2*SD_var.entry+1]<<8;
  SD_var.cluster += SD_buf1[2*SD_var.entry];   /* low byte */
  if(SD_var.cluster==0xffff)
    {
    SD_buf_ptr = (unsigned char *)SD_buf;
    eofReached = 1;
    return 0;
    }else
      {
      SD_var.blocknum=(long)SD_param.data;
      SD_var.blocknum += (long)SD_var.cluster*(long)SD_param.clusters; /* first block of cluster */
      SD_var.blockcount = 0;
      //SD_ReadBlock(SD_var.blocknum,SD_buf); /* read block into a buffer */
      }
  SD_var.entry++;
  if(SD_var.entry>255)	// read next FAT page into buffer
    {
    SD_var.FATblock++;
    SD_var.entry=0;
    SD_ReadBlock(SD_var.FATblock,SD_buf1);
    }
  }
SD_ReadBlock(SD_var.blocknum,SD_buf); /* read block into a buffer */
tmpfilesize += 512;

return 512;

}
/*--------------------------------------------------------*/
/* End of Function: SD_read_next_sector                   */
/**********************************************************/

/**********************************************************/
/*  Name        : LCD_show_frame                          */
/*  Parameters  : taken from mp3FrameInfo                 */
/*  Returns     : none                                    */
/*  Scope       :                                         */
/*  Function    : to display some mp3 frame parameters    */
/*                of current frame                        */
/*--------------------------------------------------------*/
// currently outputs to serial port 1 (115200,n,8,1)
void LCD_show_frame(void)
{
//#ifdef DEBUG
  //printf("%s%d%s","frame-", nFrames,", ");
  printf("%s%d%s","ver.", mp3FrameInfo.version,", ");
  printf("%s%d%s","layer=", mp3FrameInfo.layer,", ");
  printf("%s%d%s","bitrate=", mp3FrameInfo.bitrate,", ");
  printf("%s%d%s","samprate=", mp3FrameInfo.samprate,", ");
  printf("%s","\r\n"); 
//#endif
}
/*--------------------------------------------------------*/
/* End of Function: LCD_show_frame                        */
/**********************************************************/

/**********************************************************/
/* END OF FILE mp3.c                                      */
/**********************************************************/




