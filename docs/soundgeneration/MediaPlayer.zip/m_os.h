/**********************************************************/
/*  Module         : m_os.h                               */
/*  Language used  : GNU C                                */
/*  Microprocessor : TI  MSP430                           */
/*                                                        */
/*  Function       : Interface file for the m_os          */
/*                                                        */
/*  Revision History :                                    */
/*  Author         Date              Reason               */
/*  xxx            May 2002          Initial Design       */
/**********************************************************/
#ifndef MOS_H
#define MOS_H

#define		OS_LED_FLASH						2
//#define		OS_RED_LED_FLASH				3
//#define		OS_GREEN_LED_FLASH			4
//#define  OS_SCAN_KEY					7
//#define  OS_KEY_PRESSED				8
//#define		OS_INPUT_CHANGE					9
#define		OS_SD_PLAY							10
#define	  OS_FILE_PLAY							11


/*--------------------------------------------------------*/
/* Event Q module Defines                                 */
/*--------------------------------------------------------*/
#define MAX_EVENTS    10  // was 50
#define FREE_EVENT    0
#define EVENT_FAIL    0
#define EVENT_STARTED 1

/*--------------------------------------------------------*/
/* Timer Defines                                          */
/*--------------------------------------------------------*/
#define TMR_STARTED   1
#define TMR_FAIL      0

/*--------------------------------------------------------*/
/* Timer module Defines                                   */
/*--------------------------------------------------------*/
#define  MAX_100MS_TIMER    10  // was 50
#define  FREE_TIMER         0
#define  MS_10              1
#define  MS_20              2
#define  MS_30              3
#define  MS_40              4
#define  MS_50              5
#define  MS_60              6
#define  MS_70              7
#define  MS_80              8
#define  MS_90              9
#define  MS_100             10
#define  MS_200             20
#define  MS_300             30
#define  MS_400             40
#define  MS_500             50
#define  MS_600             60
#define  MS_700             70
#define  MS_800             80
#define  MS_900             90
#define  SEC_1              100
#define  MS_1500            150
#define  SEC_2              200
#define  MS_2500            250
#define  SEC_3              300
#define  SEC_4              400
#define  SEC_5              500
#define  SEC_6              600
#define  SEC_7              700
#define  SEC_8              800
#define  SEC_9              900
#define  SEC_10             1000
#define  SEC_15             1500
#define  SEC_20             SEC_10 + SEC_10
#define  SEC_30             3000
#define  SEC_60             6000
#define  MIN_1              6000
#define  MIN_2              MIN_1 + MIN_1

/*--------------------------------------------------------*/
/* Application data prototypes                            */
/*--------------------------------------------------------*/
typedef  struct
{
unsigned int event_ID;
void (* event_fp)(void);     /* Pointer to time_out_fp() */
} event_t;

typedef  struct
{
unsigned int timer_ID;          /* Timer ID Number          */
unsigned int timer;             /* Timer count value        */
void (* time_out_fp)(void);     /* Pointer to time_out_fp() */
} timer_t;

/*--------------------------------------------------------*/
/* Application data types                                 */
/*--------------------------------------------------------*/
#ifdef  MOS_OWNER

event_t event_Q[MAX_EVENTS];          /* Array of events */
timer_t ms100_timer[MAX_100MS_TIMER]; /* Array of  timers */
unsigned int timer_tick;              /* Cntr in int routine */

/*--------------------------------------------------------*/
/* Local function prototypes                              */
/*--------------------------------------------------------*/
void init_OS(void);
void init_event_Q(void);
void do_events(void);
char set_event(unsigned int e_ID,void (* e_fp)(void) );
char free_event(unsigned int e_ID);
void service_timers(void);
void init_timers(void);
char set_timer(unsigned int t_ID,unsigned int t_cnt,void (* t_fp)(void) );
char restart_timer(unsigned int t_ID,unsigned int t_cnt,void (* t_fp)(void) );
char free_timer(unsigned int t_ID);
char end_task(unsigned int t_ID);

#else
/*--------------------------------------------------------*/
/* Data avalible to other functions                       */
/*--------------------------------------------------------*/
extern unsigned int timer_tick;

/*--------------------------------------------------------*/
/* External Application function prototypes               */
/*--------------------------------------------------------*/
void init_OS(void);
void init_event_Q(void);
void do_events(void);
char set_event(unsigned int e_ID,void (* e_fp)(void) );
char free_event(unsigned int e_ID);
void service_timers(void);
void init_timers(void);
char set_timer(unsigned int t_ID,unsigned int t_cnt,void (* t_fp)(void) );
char restart_timer(unsigned int t_ID,unsigned int t_cnt,void (* t_fp)(void) );
char free_timer(unsigned int t_ID);
char end_task(unsigned int t_ID);

#endif
#endif

/**********************************************************/
/* End of Module: m_os.h                                  */
/**********************************************************/



