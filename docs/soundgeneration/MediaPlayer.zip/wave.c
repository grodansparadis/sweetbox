/**********************************************************/
/*                                                        */
/*  Module         : wave.c                               */
/*  Language used  : CS                                   */
/*  Microprocessor : MSP430                               */
/*                                                        */
/*  Function       : Functions related to wave audio files*/
/*                                                        */
/* -------------------------------------------------------*/
/*  Revision History :                                    */ 
/*  Author				 Date        Reason               */
/*  xxxx           18 September 2005 Initial Design       */
/**********************************************************/

#define WAVE_OWNER  1
#include "includes.h"


/**********************************************************/
/*  Name        : SD_FATStart                             */
/*  Parameters  : filename                                */
/*  Returns     : first entry in FAT                      */
/*  Scope       :                                         */
/*  Function    : to find first entry in FAT              */
/*--------------------------------------------------------*/

/*--------------------------------------------------------*/
/* End of Function: SD_FATStart                           */
/**********************************************************/




/**********************************************************/
/* END OF FILE wave.c                                     */
/**********************************************************/




