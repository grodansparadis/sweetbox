/**********************************************************/
/*                                                        */
/*  Module         : serial.c                             */
/*  Language used  : CS                                   */
/*  Microprocessor : LPC2138 , LPC2148                    */
/*                                                        */
/*  Function       : Functions related to serial ports    */
/*                   (low level drivers)                  */
/* -------------------------------------------------------*/
/*  Revision History :                                    */ 
/*  Author				 Date				       Reason               */
/*  Jan Szymanski  28 March 2005     Initial Design       */
/*  Jan Szymanski  18 April 2006     Ported to LPC2148    */
/*                                                        */
/**********************************************************/

#define SERIAL_OWNER
#include  "includes.h"

/**********************************************************/
/*  Name        : putchar_uart0                           */
/*  Parameters  : character to be sent                    */
/*  Returns     : none                                    */
/*  Scope       :                                         */
/*  Function    : sends character through UART0           */
/*--------------------------------------------------------*/
void putchar_uart0(unsigned char c)
{
while (!(U0LSR & 0x20)){}    // wait for TX buffer to empty
U0THR = c;
}
/*--------------------------------------------------------*/
/* End of Function: putchar_UART0                         */
/**********************************************************/

/**********************************************************/
/*  Name        : putstring_uart0                         */
/*  Parameters  : pointer to string to be sent            */
/*  Returns     : none                                    */
/*  Scope       :                                         */
/*  Function    : sends a string through UART0            */
/*--------------------------------------------------------*/
void putstring_uart0(unsigned char *str)
{
while (*str !=0x00)
	putchar_uart0(*str++);
}
/*--------------------------------------------------------*/
/* End of Function: putstring_UART0                       */
/**********************************************************/

/**********************************************************/
/*  Name        : getchar_uart0                           */
/*  Parameters  : none                                    */
/*  Returns     : character received from serial port     */
/*  Scope       :                                         */
/*  Function    :                                         */
/*--------------------------------------------------------*/
unsigned char getchar_uart0(void)
{
  unsigned char c;
	if(prd_uart0==pwr_uart0) return(0);	/* ??? */
  c = *prd_uart0++;		/* read and increment read pointer */
	if (prd_uart0 >= &buffer_rxuart0[UART0_RX_BUFFER_SIZE])
			prd_uart0 = buffer_rxuart0;	/* circular buffer */
  return c;
}
/*--------------------------------------------------------*/
/* End of Function: getchar_UART0                         */
/**********************************************************/

/**********************************************************/
/*  Name        : ischar_uart0                            */
/*  Parameters  : none                                    */
/*  Returns     : FALSE or TRUE                           */
/*  Scope       :                                         */
/*  Function    : check if character available from       */
/*                serial port                             */
/*--------------------------------------------------------*/
unsigned char ischar_uart0(void)
{
  if (prd_uart0==pwr_uart0) return FALSE;
    else
      return TRUE;
}
/*--------------------------------------------------------*/
/* End of Function: ischar_UART0                          */
/**********************************************************/

/**********************************************************/
/*  Name        : putchar_uart1                           */
/*  Parameters  : character to be sent                    */
/*  Returns     : none                                    */
/*  Scope       :                                         */
/*  Function    : sends character through UART1           */
/*--------------------------------------------------------*/
void putchar_uart1(unsigned char c)
{
while (!(U1LSR & 0x20)){}    // wait for TX buffer to empty
U1THR = c;
}
/*--------------------------------------------------------*/
/* End of Function: putchar_UART1                         */
/**********************************************************/

/**********************************************************/
/*  Name        : putstring_uart1                         */
/*  Parameters  : pointer to string to be sent            */
/*  Returns     : none                                    */
/*  Scope       :                                         */
/*  Function    : sends a string through UART1            */
/*--------------------------------------------------------*/
void putstring_uart1(unsigned char *str)
{
while (*str !=0x00)
	putchar_uart1(*str++);
}
/*--------------------------------------------------------*/
/* End of Function: putstring_UART1                       */
/**********************************************************/
/**********************************************************/
/*  Name        : getchar_uart1                           */
/*  Parameters  : none                                    */
/*  Returns     : character                               */
/*  Scope       :                                         */
/*  Function    : reads character from UART1, no INT      */
/*--------------------------------------------------------*/
unsigned char getchar_uart1(void)
{
unsigned char c;
if(prd_uart1==pwr_uart1) return(0);	/* ??? */
c = *prd_uart1++;		/* read and increment read pointer */
if (prd_uart1 >= &buffer_rxuart1[UART1_RX_BUFFER_SIZE])
  prd_uart1 = buffer_rxuart1;	/* circular buffer */
return c;
}
/*--------------------------------------------------------*/
/* End of Function: getchar_UART1                         */
/**********************************************************/

/**********************************************************/
/*  Name        : ischar_uart1                            */
/*  Parameters  : none                                    */
/*  Returns     : FALSE or TRUE                           */
/*  Scope       :                                         */
/*  Function    : check if character available from       */
/*                serial port                             */
/*--------------------------------------------------------*/
unsigned char ischar_uart1(void)
{
  if (prd_uart1==pwr_uart1) return FALSE;
    else
      return TRUE;
}
/*--------------------------------------------------------*/
/* End of Function: ischar_UART1                          */
/**********************************************************/

/**********************************************************/
/*  Name        : putchar_spi0                            */
/*  Parameters  : character to be sent                    */
/*  Returns     : none                                    */
/*  Scope       :                                         */
/*  Function    : sends character through spi0            */
/*--------------------------------------------------------*/
void putchar_spi0(unsigned char c)
{
//S0SPDR = c;
//while (!(S0SPSR & 0x80)){} // wait till SPIF == 1 (transmit completed)
SPDR = c;
while (!(SPSR & 0x80)){} // wait till SPIF == 1 (transmit completed)
}
/*--------------------------------------------------------*/
/* End of Function: putchar_spi0                          */
/**********************************************************/

/**********************************************************/
/*  Name        : putint_spi0                             */
/*  Parameters  : integer to be sent                      */
/*  Returns     : none                                    */
/*  Scope       :                                         */
/*  Function    : sends integer through spi0              */
/*--------------------------------------------------------*/
void putint_spi0(unsigned int i)
{
//S0SPDR = c;
//while (!(S0SPSR & 0x80)){} // wait till SPIF == 1 (transmit completed)
SPDR = i;
while (!(SPSR & 0x80)){} // wait till SPIF == 1 (transmit completed)
}
/*--------------------------------------------------------*/
/* End of Function: putint_spi0                           */
/**********************************************************/
/**********************************************************/
/*  Name        : putstring_spi0                          */
/*  Parameters  : pointer to string to be sent            */
/*  Returns     : none                                    */
/*  Scope       :                                         */
/*  Function    : sends a string through spi0             */
/*--------------------------------------------------------*/
void putstring_spi0(unsigned char *str)
{
while (*str !=0x00)
	putchar_spi0(*str++);
}
/*--------------------------------------------------------*/
/* End of Function: putstring_spi0                        */
/**********************************************************/

/**********************************************************/
/*  Name        : getchar_spi0                            */
/*  Parameters  : none                                    */
/*  Returns     : character received from SPI port        */
/*  Scope       :                                         */
/*  Function    :                                         */
/*--------------------------------------------------------*/
unsigned char getchar_spi0(void)
{
unsigned char c;
//c = S0SPDR;
c = SPDR;
return c;
}
/*--------------------------------------------------------*/
/* End of Function: getchar_spi0                          */
/**********************************************************/

/**********************************************************/
/*  Name        : getint_spi0                             */
/*  Parameters  : none                                    */
/*  Returns     : integer received from SPI port          */
/*  Scope       :                                         */
/*  Function    :                                         */
/*--------------------------------------------------------*/
unsigned int getint_spi0(void)
{
unsigned int i;
//c = S0SPDR;
i = SPDR;
return i;
}
/*--------------------------------------------------------*/
/* End of Function: getint_spi0                           */
/**********************************************************/

/**********************************************************/
/*  Name        : ischar_spi0                             */
/*  Parameters  : none                                    */
/*  Returns     : FALSE or TRUE                           */
/*  Scope       :                                         */
/*  Function    : check if character available from       */
/*                serial port                             */
/*--------------------------------------------------------*/
unsigned char ischar_spi0(void)
{
//if((S0SPSR & 0x80)==0x80)
if((SPSR & 0x80)==0x80)
  return TRUE;
    else
      return FALSE;
}
/*--------------------------------------------------------*/
/* End of Function: ischar_spi0                           */
/**********************************************************/

int __putchar(int ch)
{
  putchar_PC((unsigned char)ch);
}


/**********************************************************/
/* END OF FILE serial.c                                   */
/**********************************************************/
