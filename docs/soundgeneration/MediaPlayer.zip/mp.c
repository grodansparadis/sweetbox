/**********************************************************/
/*                                                        */
/*  Module         : mp.c                                 */
/*  Language used  : CrossStudio for ARM                  */
/*  Microprocessor : LPC2138, LPC2148                     */
/*  Function       : Main project file for Media Player   */
/*                                                        */
/* -------------------------------------------------------*/
/*  Revision History :                                    */ 
/*  Author				 Date				       Reason               */
/*  Jan Szymanski  18 September 2005 Initial Design       */
/*  Jan Szymanski  18 April 2006     Ported to LPC2148    */
/*                                                        */
/**********************************************************/

#define MP_OWNER
#include "includes.h"

/**********************************************************/
/*  Name        : main                                    */
/*  Parameters  : none                                    */
/*  Returns     : never returns                           */
/*  Scope       :                                         */
/*  Function    : the main program loop                   */
/*--------------------------------------------------------*/
int main(void)
{
unsigned char c;

init_hardware();  // low level hardware initialization
init_vars();      // initialize variables 

__ARMLIB_enableIRQ();  // Enable Interrupts 

//#ifdef DEBUG
  putstring_PC((unsigned char *)"\r\nHello LPC2148 \r\n");
//#endif

SD_init();
dac_init();

mp3_init();

total_files = SD_NOF();   // find a number of audio files in DIR on SD
filenum = 1;

/*--------------------------------------------------------*/
/*  Main Loop                                             */
/*--------------------------------------------------------*/
while(1) 
  {
  mp_play();
  }
}
/*--------------------------------------------------------*/
/*              End of Function: main                     */
/**********************************************************/

/**********************************************************/
/*  Name        : init_vars                               */
/*  Parameters  : none                                    */
/*  Returns     : none                                    */
/*  Scope       :                                         */
/*  Function    : initialize variables after power on     */
/*--------------------------------------------------------*/
void init_vars(void)
{
unsigned int i;

// for timers
freems = 0; 
free10ms = 0;
t10ms_1 = 0;
// init serial buffer
prd_uart0 = pwr_uart0 = buffer_rxuart0;
prd_uart1 = pwr_uart1 = buffer_rxuart1;

// fill the play buffer with zeros
pcm_play_ptr = (unsigned char *)PCM_BUFFER_START;
pcm_load_ptr = (unsigned char *)PCM_BUFFER_START;
for(i=0; i<PCM_BUFFER_SIZE; i++)
  *pcm_load_ptr++ = 0;
}
/*--------------------------------------------------------*/
/* End of Function: init_vars                             */
/**********************************************************/

/**********************************************************/
/*  Name        : init_hardware                           */
/*  Parameters  : none                                    */
/*  Returns     : none                                    */
/*  Scope       :                                         */
/*  Function    : initialize hardware after reset         */
/*--------------------------------------------------------*/
void init_hardware(void)
{
// pin functionality for Port 0

// P0.0/TxD0/PWM1 is used as TxD0 (UART0 function) - PC
// P0.1/RxD0/PWM3/EINT0 is used as RxD0 (UART0 function) - PC
// P0.2/SCL0/CAP0.0 is used as SCL0 (I2C0 function) - audio DAC
// P0.3/SDA0/MAT0.0/EINT1 is used as SDA0 (I2C0 function) - audio DAC
// P0.4/SCK0/CAP0.1/AD0.6 is used as SCK0 (SPI0 function) - SD card
// P0.5/MISO0/MAT0.1/AD0.7 is used as MISO0 (SPI0 function) - SD card
// P0.6/MOSI0/CAP0.2/AD1.0 is used as MOSI0 (SPI0 function) - SD card
// P0.7/SSEL0/PWM2/EINT2 is used as output - ORES for OLED

// P0.8/TxD1/PWM4/AD1.1 is used as TxD1 (UART1 function) - embedded com
// P0.9/RxD1/PWM6/EINT3 is used as RxD1 (UART1 function) - embedded com
// P0.10/RTS1/CAP1.0/AD1.2 is used as CAP1.0 (input capture function) - I2S timing
// P0.11/CTS1/CAP1.1/SCL1 is used as output - OD/C for OLED
// P0.12/DSR1/MAT1.0/AD1.3 is used as MAT1.0 (output on match) - LRCK for I2S timing
// P0.13/DTR1/MAT1.1/AD1.4 is used as output DSEL - audio DAC
// P0.14/DCD/EINT1/SDA1 is used as EINT1 input - KEY2 
// P0.15/RI1/EINT2/AD1.5 is used as EINT2 input - KEY3

// P0.16/EINT0/MAT0.2/CAP0.2 is used as EINT0 input - SDIN SD card
// P0.17/CAP1.2/SCK1/MAT1.2 is used as SCK1 (SSP function) - audio DAC
// P0.18/CAP1.3/MISO1/MAT1.3 is used as MISO1 (SSP function) - audio DAC
// P0.19/MAT1.2/MOSI1/CAP1.2 is used as MOSI1 (SSP function) - audio DAC
// P0.20/MAT1.3/SSEL1/EINT3 is used as SSEL1 (SSP function) - FS signal for I2S circuitry
// P0.21/PWM5/AD1.6/CAP1.3 is used as PWM5 (PWM function) - audio DAC
// P0.22/AD1.7/CAP0.0/MAT0.0 is used as output SDCS - SD card 
// P0.23/VBUS is used as VBUS for USB

// P0.25/AD0.4/AOUT is used as output - OCS OLED
// P0.26/AD0.5/D+ is used as USB D+
// P0.27/AD0.0/CAP0.1/MAT0.1/D- is used as USB D-
// P0.28/AD0.1/CAP0.2/MAT0.2 is used as output - OE/RD OLED
// P0.29/AD0.2/CAP0.3/MAT0.3 is used as output - OR/W OLED
// P0.30/AD0.3/EINT3/CAP0.0 is used as EINT3 input - KEY4
// P0.31/UP_LED/CONNECT is used as USB connect

// pin functionality for Port 1

// P1.16/TRACEPKT0 is used as output - OD0 OLED
// P1.17/TRACEPKT1 is used as output - OD1 OLED
// P1.18/TRACEPKT2 is used as output - OD2 OLED
// P1.19/TRACEPKT3 is used as output - OD3 OLED
// P1.20/TRACESYNC is used as output - OD4 OLED
// P1.21/PIPESTAT0 is used as output - OD5 OLED
// P1.22/PIPESTAT1 is used as output - OD6 OLED
// P1.23/PIPESTAT2 is used as output - OD7 OLED

// P1.24/TRACECLK is used as output - O12EN OLED power supply
// P1.25/EXTINT0 is used as EINT0 input - KEY1
// P1.26 - P1.31 used as standard JTAG port only

// IO0DIR 1011 111x 1111 1110 0011 1001 1101 1101
// IO0CLR 0011 111x 1111 1110 0011 1001 1101 1101
IO0DIR = 0xbffe39dd;
IO0CLR = 0x3ffe39dd;

// IO1DIR 1111 1111 1111 1111 xxxx xxxx xxxx xxxx
// IO1CLR 1111 1111 1111 1111 xxxx xxxx xxxx xxxx
IO1DIR = 0xffff0000;
IO1CLR = 0xffff0000;


IO0DIR |= 1 << 22; // P0.22 SDCS is out
IO0SET = 1 << 22;  // SDCS high (inactive)

IO0DIR |= 1 << 13; // P0.13 is DSEL
IO0SET = 1 << 13;  // DSEL high (inactive)

// setup for timer 0
VICIntSelect &= ~0x10;    /* Timer 0 interrupt is an IRQ interrupt */
VICIntEnable = 0x10;      /* Enable timer 0 interrupt */
VICVectCntl0 = 0x24;      /* Use slot 0 for timer 0 interrupt */
VICVectAddr0 = (unsigned int)timer0ISR; /* Set the address of ISR for slot 0 */

PINSEL0 &= 0xfccfffff;  // clear bits 21,20 and 25,24
PINSEL0 |= 0x02200000;  // select funcion 2 CAP1.0 for P0.10 and MAT1.0 for P0.12
T0TCR = 2;      // timer disable
T0PR = 0;
T0MR0 = 594000;  // set timer 0 match register */
//T0MR1 = 5;
//T0EMR = 0x00c0; // toggle MAT01
T0MCR = 3;      // was 3 generate interrupt and reset counter on match */
T0TCR = 1;      // Start timer 0 

// for this project we don't use timer1, so the following is commented out
//VICIntSelect &= ~0x20;    /* Timer 1 interrupt is an IRQ interrupt */
//VICIntEnable = 0x20;      /* Enable timer 1 interrupt */
//VICVectCntl1 = 0x25;      /* Use slot 1 for timer 1 interrupt */
//VICVectAddr1 = (unsigned int)timer1ISR;  /* Set the address of ISR for slot 1 */
//T1TCR = 0;      /* Reset timer 1 */
//T1PR = 600;    /* Set the timer 1 prescale counter */
//T1MR0 = 99;     /* Set timer 1 match register */
//T1MCR = 3;      /* Generate interrupt and reset counter on match */
//T1TCR = 1;      /* Start timer 1 */


// setup for timer 1
PINSEL0 &= 0xfccfffff;  // clear bits 21,20 and 25,24
PINSEL0 |= 0x02200000;  // select funcion 2 CAP1.0 for P0.10 and MAT1.0 for P0.12
T1TCR = 0x02;   // reset timer 1
T1PR = 0;
T1CTCR = 0x03;  
// 0000 0011
// |||| |||_________ counter mode, both edges
// |||| |___________ CAP1.0 is input
// |________________ reserved
T1MR0 = 1;
T1MCR = 0x0002; // was 2 reset on MR0
T1EMR = 0x0030; // togle MAT1.0 on match
T1TCR = 0x01;   // start timer 1

// PWM used to generate clock for codec
PINSEL1 &= 0xfffff3ff;  // clear bits 11,10
PINSEL1 |= 0x00000400;  // P0.21 is PWM5
PWMTCR = 0x02; // reset PWM counter
PWMPR = 0;  // reset prescaler
PWMMR0 = 5; // was 10 was 5 cycle register
PWMMR5 = 2; // was 5 was 2 match register
PWMMCR = 0x00000002;  // reset MR0 on match
PWMPCR = 0x2000;  // enable PWM5 
PWMTCR = 0x09;  // enable PWM

PINSEL0 &= 0xfffffff0;  // clear bits 0,1,2,3
PINSEL0 |= 0x00000005;  // select funcion 1 (UART0) for P0.0 and P0.1
U0IER = 0x00;           // disable all interrupts
//U0IIR = 0x00;           // clear interrupt ID
U0RBR;                  // clear receive register
U0LSR;                  // clear line status register
// set the baudrate 115200 60MHz/(115200*16)=32.55
U0LCR = 0x80;           // select divisor latches 
U0DLL = 33;             // set for baud low byte
U0DLM = 0;              // set for baud high byte

U0LCR = 0x03;           // 8 bit, 1 stop bit, no parity, disable DLAB 
U0FCR = 0x01;           // FIFO mode 1 char

VICIntSelect &= ~0x40;  // UART0 selected as IRQ
VICIntEnable = 0x40;    // UART0 interrupt enabled
VICVectCntl2 = 0x26;    
VICVectAddr2 = (unsigned int)uart0ISR;    // address of the ISR

U0IER = 0x01;            // enable receiver interrupts

// initialise SPI0
// setup SCK pin P04
PINSEL0 &= ~(3<<8);
PINSEL0 |= 1<<8;
// setup MISO pin P05
PINSEL0 &= ~(3<<10);
PINSEL0 |= 1<<10;
// setup MOSI pin P06
PINSEL0 &= ~(3<<12);
PINSEL0 |= 1<<12;

//S0SPCR = 0x0020;  // first test, no INT
SPCR = 0x0020;  // first test, no INT
// 0000 0000 1010 0000
// |||| |||| |||| ||||___ reserved
// |||| |||| |||| ||_____ 8 bit per transfer
// |||| |||| |||| |______ CPHA = 0
// |||| |||| ||||________ CPOL = 0
// |||| |||| |||_________ master mode
// |||| |||| ||__________ msb first
// |||| |||| |___________ SPIE = 1

//S0SPCCR = 8;  // 60 MHz/8 = 7.5 MHz clock
SPCCR = 8;  // 60 MHz/8 = 7.5 MHz clock
//VICIntSelect &= ~0x400;  // SPI0 selected as IRQ
//VICIntEnable = 0x400;    // SPI0 interrupt enabled
//VICVectCntl3 = 0x2a;    
//VICVectAddr3 = (unsigned int)spi0ISR;    // address of the ISR

// initialize SSP
PINSEL1 &= 0xfffffc03;  // clear bits 2-9
PINSEL1 |= 0x000002a8;  // select funcion 2(bin 10) (SSP) for P0.17 - P0.20
SSPCR0 = 0x001f;  
// 0000 0000 0001 1111 
// |||| |||| |||| |_________ DSS = 16 bit transfer
// |||| |||| ||||___________ Frame Format = SSI
// |||| |||| ||_____________ CPOL NA
// |||| |||| |______________ CPHA NA
// |||| ||||________________ SCR = 0x01
// I2S Bit Rate = 16 x 2 x Sampling Frequency Fs
// Fs == 44100 Hz -> I2S Bit Rate = 1411200
// 60 MHz / 1411200 Hz = 42.5, use 42 = 0x2a 
// CPSR = 42, SCR = 0

//SSPCPSR = 0x2a; // clock divider 0-254
SSPCPSR = 42; // clock divider 0-254
// interrupt when TX FIFO is at least half empty
SSPIMSC = 0x08; // 0000 1000 enable TXIM

VICIntSelect &= ~0x800;   // SSP selected as IRQ (bit 11)
VICIntEnable = 0x800;     // enable SSP interrupt
//VICIntEnClr = 0x800;    // disable SSP interrupt
VICVectCntl4 = 0x2b;      // Use slot 4 for ssp interrupt 
VICVectAddr4 = (unsigned int)sspISR; // address of the ISR
//VICIntEnClr = 0x800;    // disable SSP interrupt
SSPICR = 0x03;  // reset INT errors
// enable SSP
SSPCR1 = 0x02;
// 0000 0010 
// |||| ||||_____ LBM = 0 Normal Mode
// |||| |||______ SSP Enable = 1
// |||| ||_______ MS = 0 Master Mode
// |||| |________ SOD NA
// ||||__________ Reserved NA

PCONP |= 1 << 31;  // enable USB power/clock, so we can use USB RAM 
                      // 0x7fd0 0000 - 0x7fd0 1fff (8 kB)
}
/*--------------------------------------------------------*/
/* End of Function: init_hardware                         */
/**********************************************************/

/**********************************************************/
/* END OF FILE mp.c                                       */
/**********************************************************/
