/**********************************************************/
/*                                                        */
/*  Module         : mischard.c                           */
/*  Language used  : CS                                   */
/*  Microprocessor : MSP430                               */
/*                                                        */
/*  Function       : Miscallenous hardware functions      */
/* -------------------------------------------------------*/
/*  Revision History :                                    */ 
/*  Author				 Date				       Reason               */
/*  Jan Szymanski  18 September 2005 Initial Design       */
/*  Jan Szymanski  18 April 2006     Ported to LPC2148    */
/*                                                        */
/**********************************************************/

#define MISCH_OWNER
#include "includes.h"

/**********************************************************/
/*  Name        : delay_ms                                */
/*  Parameters  : number of 10ms                          */
/*  Returns     : none                                    */
/*  Scope       :                                         */
/*  Function    : to delay for n x 10ms                   */
/*--------------------------------------------------------*/
void delay_ms(unsigned char ms10)
{
t10ms_1=0;
while (t10ms_1 < ms10){};
}
/*--------------------------------------------------------*/
/* End of Function: delay_ms                              */
/**********************************************************/

/**********************************************************/
/* END OF FILE mischard.c                                 */
/**********************************************************/

