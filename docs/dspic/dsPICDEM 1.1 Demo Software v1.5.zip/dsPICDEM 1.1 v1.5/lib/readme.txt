dsPICDEM(TM) v1.1 Demo Software Read Me File
--------------------------------------------

This folder contains Library (archived) files which are included in the Demonstration
Software  MPLAB project.

Specifically, this folder contains the following file:

- Diagnostics.a

This file is an archive of source code used for performing diagnostic tests on a 
dsPICDEM(TM) v1.1 board.

Diagnostic tests may be invoked by keeping the S1 switch depressed while performing a 
device reset while the device is plugged into the dsPICDEM(TM) board.

This archive file was built using the MPLAB C30 C-compiler, version 1.30.

--------------------------
File Revision History
--------------------------

 $Log: readme.txt,v $
 Revision 1.2  2005/04/04 23:46:20  VasukiH
 Updates to comments in file header

 Revision 1.1.1.1  2003/08/23 00:38:33  VasukiH
 First import of demo source into CVS Repository

