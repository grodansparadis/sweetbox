Note :
-------

This folder contains a C source file, "sub_typeconversions.c" 
used to build the object file, "..\sub_typeconversions.o".

Unlimited licenses of the MPLAB IDE, assembler and linker are freely 
available on the Microchip corporate website or FTP site. A time-limited 
version of the MPLAB C30 C-compileris also available there. In case, the
compiler license expires, we provide the object files for the C source
files in this folder. 

If your MPLAB C30 C-compiler license has expired, you could include the
object files, ..\sub_typeconversions.o and ..\crt0.o, in your project.
The object file, "crt0.o" and it's corresponding source code, "crt0.s" 
can also be found in your MPLAB installation folder. "crt0.o" contains a
run-time start-up routine used to initialize data section variables.

If you do have the MPLAB C30 C-compiler, you may copy the source file,
sub_typeconversions.c, in this folder to your demo project folder. 
Additionally, you should include the library archive file, libpic30.a from 
"pic30_tools\lib\" into your project.

--------------------------
File Revision History
--------------------------

 $Log: readme_C_source.txt,v $
 Revision 1.2  2005/04/04 23:46:35  VasukiH
 Updates to comments in file header

 Revision 1.1.1.1  2003/08/23 00:38:33  VasukiH
 First import of demo source into CVS Repository







