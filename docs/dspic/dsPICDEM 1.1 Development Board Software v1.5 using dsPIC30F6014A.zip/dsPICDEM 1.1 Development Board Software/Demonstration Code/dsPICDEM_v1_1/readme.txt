              dsPICDEM(TM) 1.1 Demo Software Read Me File
              --------------------------------------------

-------------------
1. Folder Contents
-------------------
This folder contains source files required to build the dsPICDEM(TM) v1.1 
demonstration software.

Sub folders within this project folder also contain files relevant 
to the project. Please see ReadMe files within the respective folder
for a description of each folder.

MPLAB v7.0 Project and Workspace files have also been provided in this folder.
In the event, that these files are lost or corrupted, a new project may
be constructed using the following guidelines:

1. Create a new project in MPLAB v7.21.
2. Select the dsPIC30F6014A device
3. Add all source and header files present in this folder into
   the new project.
4. Add lib\Diagnostics.a archive into the project.
5. Add obj\crt0.o and obj\sub_typeconversions.o into the project.
6. Define __ICD2RAM=1 in the Project>>Build Options.
7. Define the Assembler Include Path in the Project>>Build Options
8. Select ICD2 Debugger or Programmer.
9. Ensure that configuration bits have been set as follows:
   - Clock Switching and Clock Monitoring is Off
   - XT by PLL4x mode is selected in the Oscillator settings.
   - Watch Dog Timer is disabled
   - MCLR is enabled
   - BOR is disabled
   - If Debug Mode is set, ensure the debug lines selected are PGC/EMUC and
     PGD/EMUD.
10. Build the project using MPLAB C30 v1.30.
11. Program upto location 0x600f in Program Memory.

---------------------------
2. Using XT by PLL 8x Mode
---------------------------
If you intend to use the source provided in this folder while running the dsPIC30F 
target device using a 8x PLL mode or 16x mode, then several elements need to be considered.

Specifically, source code related to the following topics need to be 
modified:

1. Software Bounce Delay within INTx pins interrupt.
2. UART Baud Rate
3. DCI Baud Rate
4. SPI Clock Rate
5. Timer 1, Timer 2 and Timer3 Peroid Registers.
6. A/D sampling time


--------------------------
3. File Revision History
--------------------------

 $Log: readme.txt,v $
 Revision 1.6  2005/09/06 07:14:17  C11300
 Changes for 30F6014A device

 Revision 1.5  2005/04/04 23:42:54  VasukiH
 Corrected Product Name

 Revision 1.4  2005/04/04 23:41:56  VasukiH
 Comments added for MPLAB C30 v1.30 compatiblity

 Revision 1.3  2005/04/04 23:41:32  VasukiH
 Comments added for MPLAB 7.0 compatiblity

 Revision 1.2  2003/11/04 02:52:29  VasukiH
 This demo now works on 30F6014 device rather than 30F6001.

 Revision 1.1.1.1  2003/08/23 00:38:32  VasukiH
 First import of demo source into CVS Repository




