//START_HEADER
/*
; dsPIC30F6014 Demo Source File
; (c) Copyright 2005 Microchip Technology, All rights reserved
;
; --------------------------------------------------------------------------
; File Revision History:
; --------------------------------------------------------------------------
;
; $Log: sub_typeconversions.c,v $
; Revision 1.4  2005/04/04 23:46:31  VasukiH
; Updates to comments in file header
;
; Revision 1.3  2005/04/04 23:25:20  VasukiH
; Updates for MPLAB C30 v1.30 compatiblity
;
; Revision 1.1  2005/04/04 23:19:06  VasukiH
; Updates for MPLAB C30 v1.30 compatiblity
;
; Revision 1.1.1.1  2003/08/23 00:38:33  VasukiH
; First import of demo source into CVS Repository
;
;
;
; --------------------------------------------------------------------------
;
; Software and Development Tools Info:
; --------------------------------------------------------------------------
; Tool				Version
; --------------------------------------------------------------------------
; MPLAB IDE			7.0
; MPLAB C30 Toolsuite		1.30
; dsPICDEM QFP Processor Board  1.10
; --------------------------------------------------------------------------
;
; File Notes:
; 1. This file contains routines to convert binary data to ascii decimal
;    data.
;
*/
//END_HEADER



char adones=0;
char adtenths=0;
char adhundredths=0;

char freq1000 = 0;					
char freq100 = 0;
char freq10 = 0;
char freq1 = 0;

char time100000 = 0;
char time10000 = 0;
char time1000 = 0;					
char time100 = 0;
char time10 = 0;
char time1 = 0;

void adcvolt(unsigned int ADRES)
{
	 adones = 0;					//reset values
	 adtenths = 0;
	 adhundredths = 0;
	 while (ADRES > 0x8)
	 {
	  	if(ADRES > 0x333)		//test for 1 volt or greater
		{
			adones++;			//increment 1 volt counter
			ADRES -= 0x334;			//subtract 1 volt
		}
		else if(ADRES > 0x51 && ADRES <= 0x333)		
		{
			if (adtenths < 9)
		   	{
			  adtenths++;			//increment tenths
			}
			else 
			{
			  adones++;			//tenths has rolled over
			  adtenths = 0;			//so increment ones and reset tenths
			}
			ADRES -=0x52;
		}
		else if(ADRES > 0x8 && ADRES <= 0x51)		
		{
			if (adhundredths < 9)
			{
				adhundredths++;		//increment hundreths
			}
			else 
			{
				
				adhundredths = 0;	//reset hundredths
				if (adtenths < 9)
		   		{
			  		adtenths++;			//and increment tenths
				}
				else 
				{
			 	 	adones++;			//unless tenths has rolled over
			  		adtenths = 0;			//so increment ones and reset tenths
				}
			}
			ADRES -= 0x9;
		}

		
		
	 }
	adones += 0x30;
	adtenths += 0x30;
	adhundredths += 0x30;
	
} 



void hextodec(unsigned int ADRES)
{
	 freq1000 = 0;					//reset values
	 freq100 = 0;
	 freq10 = 0;
	 freq1 = 0;
	 while (ADRES > 0x0)
	 {
	  	if(ADRES > 0x03E7)		//test for 1 volt or greater
		{
			freq1000++;			//increment 1 volt counter
			ADRES -= 0x3E8;			//subtract 1 volt
		}
		else if(ADRES > 0x63 && ADRES <= 0x3E7)		
		{
			if (freq100 < 9)
		   	{
			  freq100++;			//increment tenths
			}
			else 
			{
			  freq1000++;			//tenths has rolled over
			  freq100 = 0;			//so increment ones and reset tenths
			}
			ADRES -=0x64;
		}
		else if(ADRES > 0x9 && ADRES <= 0x63)		
		{
			if (freq10 < 9)
			{
				freq10++;		//increment hundreths
			}
			else 
			{
				
				freq10 = 0;	//reset hundredths
				if (freq100 < 9)
		   		{
			  		freq100++;			//and increment tenths
				}
				else 
				{
			 	 	freq1000++;			//unless tenths has rolled over
			  		freq100 = 0;			//so increment ones and reset tenths
				}
			}
			ADRES -= 0xA;
		}
		else if(ADRES >= 0x1 && ADRES <= 0x9)		
		{
			if (freq1 < 9)
			{
				freq1++;		//increment thousandths
			}
			else
			{
				freq1 = 0;
				if (freq10 < 9)
				{
					freq10++;		//increment hundreths
				}
				else 
				{
					freq10 = 0;	//reset hundredths
					if (freq100 < 9)
		   			{
			  			freq100++;			//and increment tenths
					}
					else 
					{
			 	 		freq1000++;			//unless tenths has rolled over
			  			freq100 = 0;			//so increment ones and reset tenths
					}
				}
			}
			ADRES -= 1;
		}
		
	 }
	freq1000 += 0x30;
	freq100 += 0x30;
	freq10 += 0x30;
	freq1 += 0x30;
	
} 

void hextolong(unsigned long int ADRES)
{
	 time100000 = 0;
	 time10000 = 0;
	 time1000 = 0;					//reset values
	 time100 = 0;
	 time10 = 0;
	 time1 = 0;
	 while (ADRES > 0x0)
	 {
	  	if (ADRES > 0x0001869F)
	  	{
	  		time100000++;
	  		ADRES -= 0x186A0;
	  	}
	  	else if (ADRES > 0x270F && ADRES <= 0x0001869F)
	  	{
	  		if (time10000 < 9)
			{
				time10000++;			//increment 1 volt counter
			}
			else
			{
				time100000++;
				time10000=0;
			}
			ADRES -= 0x2710;			//subtract 1 volt
	  	}
	  	else if(ADRES > 0x03E7 && ADRES <= 0x270F)	//test for 1 volt or greater
		{
			if (time1000 < 9)
			{
				time1000++;			//increment 1 volt counter
			}
			else
			{
				time1000=0;
				if (time10000 < 9)
				{
					time10000++;			//increment 1 volt counter
				}
				else
				{
					time100000++;
					time10000=0;
				}
			}
			ADRES -= 0x3E8;			//subtract 1 volt
		}
		else if(ADRES > 0x63 && ADRES <= 0x3E7)		
		{
			if (time100 < 9)
		   	{
			  	time100++;			//increment tenths
			}
			else 
			{
			  	time100 = 0;			//so increment ones and reset tenths
			  	if (time1000 < 9)
				{
					time1000++;			//increment 1 volt counter
				}
				else
				{
					time1000=0;
					if (time10000 < 9)
					{
						time10000++;			//increment 1 volt counter
					}
					else
					{
						time100000++;
						time10000=0;
					}
				}
			}
			ADRES -=0x64;
		}
		else if(ADRES > 0x9 && ADRES <= 0x63)		
		{
			if (time10 < 9)
			{
				time10++;		//increment hundreths
			}
			else 
			{			
				time10 = 0;	//reset hundredths
				if (time100 < 9)
		   		{
			  		time100++;			//and increment tenths
				}
				else 
				{
			  		time100 = 0;			//so increment ones and reset tenths
			  		if (time1000 < 9)
					{
						time1000++;			//increment 1 volt counter
					}
					else
					{
						time1000=0;
						if (time10000 < 9)
						{
							time10000++;			//increment 1 volt counter
						}
						else
						{
							time100000++;
							time10000=0;
						}
					}	
				}
			}
			ADRES -= 0xA;
		}
		else if(ADRES >= 0x1 && ADRES <= 0x9)		
		{
			if (time1 < 9)
			{
				time1++;		//increment thousandths
			}
			else
			{
				time1 = 0;
				if (time10 < 9)
				{
					time10++;		//increment hundreths
				}
				else 
				{
					time10 = 0;	//reset hundredths
					if (time100 < 9)
		   			{
			  			time100++;			//and increment tenths
					}
					else 
					{
			  			time100 = 0;			//so increment ones and reset tenths
			  			if (time1000 < 9)
						{
							time1000++;			//increment 1 volt counter
						}
						else
						{
							time1000=0;
							if (time10000 < 9)
							{
								time10000++;			//increment 1 volt counter
							}
							else
							{
								time100000++;
								time10000=0;
							}
						}
					}
				}
			}
			ADRES -= 1;
		}
		
	 }
	time100000 += 0x30;
	time10000 += 0x30;
	time1000 += 0x30;
	time100 += 0x30;
	time10 += 0x30;
	time1 += 0x30;
	
} 
