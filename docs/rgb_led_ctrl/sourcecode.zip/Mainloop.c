//*************************************************************************
//
//                  P H I L I P S   P R O P R I E T A R Y
//
//           COPYRIGHT (c)   2003 BY PHILIPS SEMICONDUCTORS
//                     --  ALL RIGHTS RESERVED  --
//
// File Name:	mainloop.c
// Created:		June 2, 2003
// Modified:	November 07, 2003
// Revision: 	1.00
//
//*************************************************************************

#include <REG51RX.H>
#include "i2cexprt.h"
#include "PCA9564sys.h"
#include "I2C_Routines.h"

idata BYTE  Buffer1[32];
idata BYTE  Buffer2[32];
idata BYTE  Buffer3[16];
idata BYTE  Buffer4[16];

idata I2C_MESSAGE	Message1;
idata I2C_MESSAGE	Message2;
idata I2C_MESSAGE	Message3;
idata I2C_MESSAGE	Message4;

static short int ProgramCounter = 0;

//****************************************************************************
// Initialization Functions at power up, Reset or program change      
//****************************************************************************

static void Init_PCA9564(void)
{
	PCA9564_Reset = 1;
	PCA9564_Reset = 0;
	InsertDelay(2);						// PCA9564 reset time = 2 ms
	PCA9564_Reset = 1;
	
	AUXR = 2;								// External memory space
	I2C_InitializeMaster(0x00);		// 330 kHz
}
 
void Init_White(void)
{  
	Message1.buf     = Buffer1;
	Message1.nrBytes = 6;  	
	Message1.address = PCA9533_W_WR;
	Buffer1[0]		  = 0x11;			// autoincrement + register 1
	Buffer1[1]		  = 0x00;			// default prescaler pwm0
   Buffer1[2]		  = 0x10;			// default duty cycle for pwm0
   Buffer1[3]		  = 0x00;			// default prescaler pwm1
   Buffer1[4]		  = 0x10;			// default duty cycle for pwm1
   Buffer1[5]		  = 0xAA;			// LD1-LD4 on at BR0 (White LEDs)
   I2C_Write(&Message1);
}
 
void Init_RGB(void)
{ 
   Message1.buf     = Buffer1;
   Message1.nrBytes = 7;
   Message1.address = PCA9531_R_WR;
	Buffer1[0]		  = 0x11;			// autoincrement + register 1
	Buffer1[1]		  = 0x00;			// default prescaler pwm0
   Buffer1[2]		  = 0x6B;			// default duty cycle for pwm0
   Buffer1[3]		  = 0x00;			// default prescaler pwm1
   Buffer1[4]		  = 0x6B;			// default duty cycle for pwm1
   Buffer1[5]		  = 0x00;			// Red RGB LED's = off
   Buffer1[6]		  = 0x00;			// Red RGB LED's = off
   I2C_Write(&Message1);
   Message1.address = PCA9531_G_WR;
	Buffer1[0]		  = 0x11;			// autoincrement + register 1
	Buffer1[1]		  = 0x00;			// default prescaler pwm0
   Buffer1[2]		  = 0x00;			// default duty cycle for pwm0
   Buffer1[3]		  = 0x00;			// default prescaler pwm1
   Buffer1[4]		  = 0x00;			// default duty cycle for pwm1
   Buffer1[5]		  = 0x00;			// Green RGB LED's = off
   Buffer1[6]		  = 0x00;			// Green RGB LED's = off
   I2C_Write(&Message1);   
   Message1.address = PCA9531_B_WR;
	Buffer1[0]		  = 0x11;			// autoincrement + register 1
	Buffer1[1]		  = 0x00;			// default prescaler pwm0
   Buffer1[2]		  = 0x25;			// default duty cycle for pwm0
   Buffer1[3]		  = 0x00;			// default prescaler pwm1
   Buffer1[4]		  = 0x25;			// default duty cycle for pwm1
   Buffer1[5]		  = 0x00;			// Blue RGB LED's = off
   Buffer1[6]		  = 0x00;			// Blue RGB LED's = off
   I2C_Write(&Message1);
}

void Init_Misc(void)
{ 
   Message1.buf     = Buffer1;
	Message1.nrBytes = 7;
   Message1.address = PCA9531_M_WR;
	Buffer1[0]		  = 0x11;			// autoincrement + register 1
	Buffer1[1]		  = 0x97;			// default prescaler pwm0
   Buffer1[2]		  = 0x80;			// default duty cycle for pwm0
   Buffer1[3]		  = 0x97;			// default prescaler pwm1 = 1 Hz
   Buffer1[4]		  = 0x08;			// default duty cycle for pwm1 = 50%
   Buffer1[5]		  = 0x00;			// Misc LED's = off
   Buffer1[6]		  = 0x00;			// Misc LED's = off
   I2C_Write(&Message1);    			
}
 
void Init_GPIO(void)
{  
   Message2.address = PCA9555_WR;
	Message2.buf     = Buffer2;
	Message2.nrBytes = 1;
	Buffer2[0] 		  = 0;  				// subaddress = 0
	
	Message3.address = PCA9555_RD;
	Message3.buf     = Buffer3;
	Message3.nrBytes = 2;  				// read 2 bytes
	Buffer3[0] = 0xFF;
	Buffer3[1] = 0xFF;
}


//****************************************************************************
// Delay time in milliseconds							
// Insert a wait into the program flow				
// Use Timer 1											 	
// Do not use an interrupt								
// Oscillator running at 11.0592 MHz				
// 6 clock cycles per clock tick						
// Therefore, we need 1843 cycles for 1msec		
//****************************************************************************

void InsertDelay(unsigned char delayTime)
{
	unsigned char i;

	TMOD = (TMOD & 0x0F) | 0x01;	// 16-bit timer
	TR1 = 0;
	for (i=0;i<delayTime;i++)
	{
		TF1 = 0;
		TH1 = 0xF8;		// set timer1 to 1843
		TL1 = 0xCD;		// since it's an up-timer, use  (65536-1843) = 63693 = F8CD
		TR1 = 1;			// Start timer
		while(TF1==0);	// wait until Timer1 overflows
	}
}

//****************************************************************************
// Toggles pushbutton S8 in order to determine which 
// program the user wants to run  
//****************************************************************************

static void Function_Select(void)
{
	if (Buffer3[1] == 0xBF)							// Push on F1 detected - enter LED programming mode
	{
   	Message1.address 	= PCA9531_M_WR;		// PCA9531 Misc to indicate LED programming mode 
		Message1.nrBytes 	= 2;
		Buffer1[0]			= 0x16;					// subaddress = 0x06
		Buffer1[1] 			= 0xC0;					// LD12 blinking at BR1 --> Indicate LED programming mode active
		I2C_Write(&Message1);						// Program PCA9531 (2 bytes)
   	while (Buffer3[1] != 0xDF)					// Loop as long as END button not pushed (programming mode active)
		{                                	
			Buffer3[1] = 0xFF;						// Clear Key F1 pushed
			GPIO_Interrupt_Handler();				// Check if a new key has been pushed (sub mode - function to be programmed)
			if (Buffer3[0] == 0xFE | Buffer3[0] == 0xFD | Buffer3[0] == 0xFB)		// Key pushed = 1, 2, or 3 --> Fun pattern programming
			{
				Fun_Pattern_Programming();
			}
			if (Buffer3[0] == 0xF7)					// Key pushed = 4 --> Backlight programming
			{
				Backlight_Programming();
			}	
		}
		Buffer3[1] = 0xFF;							// Clear Key END pushed - leave programming mode
		Message1.address 	= PCA9531_M_WR;		// PCA9531 Misc 
		Message1.nrBytes 	= 2;
		Buffer1[0]			= 0x16;					// subaddress = 0x16
		Buffer1[1] 			= 0x00;					// Misc Green LED = off --> Indicate LED programming mode left
		I2C_Write(&Message1);						// Program PCA9531 (2 bytes)
	}
	if (Buffer3[1] == 0x7F)							// Push on F2 detected - enter simulation mode
	{
		Message1.address 	= PCA9531_M_WR;		// PCA9531 Misc to indicate simulation mode 
		Message1.nrBytes 	= 2;
		Buffer1[0]			= 0x16;					// subaddress = 0x06
		Buffer1[1] 			= 0x30;					// LD11 blinking at BR1 --> Indicate simulation mode active
		I2C_Write(&Message1);						// Program PCA9531 (2 bytes)
		while (Buffer3[1] != 0xDF)					// Loop as long as END button not pushed (programming mode active)
		{                                	
			Buffer3[1] = 0xFF;						// Clear Key F2 pushed
			GPIO_Interrupt_Handler();				// Check if a new key has been pushed (sub mode - function to be programmed)	
			if (Buffer3[0] == 0xFE)					// Key pushed = 1 --> Battery discharge emulation
			{
				Battery_Status();
			}
			if (Buffer3[0] == 0xF7)					// Key 4 pushed
			{
				Auto_Demo();
			}
		}
		Buffer3[1] = 0xFF;							// Clear Key END pushed - leave simulation mode
		Message1.address 	= PCA9531_M_WR;		// PCA9531 Misc to indicate LED programming mode 
		Message1.nrBytes 	= 2;
		Buffer1[0]			= 0x16;					// subaddress = 0x06
		Buffer1[1] 			= 0x00;					// LD11 blinking at BR1 --> Indicate LED programming mode active
		I2C_Write(&Message1);						// Program PCA9531 (2 bytes)
	}
	if (Buffer3[0] != 0xFF | Buffer3[1] == 0xFE | Buffer3[1] == 0xFD | Buffer3[1] == 0xFB | Buffer3[1] == 0xF7)
	{
		Dial_Number();
		Buffer3[1] = 0xFF;	// Clear Key END pushed 
	}
	Buffer3[1] = 0xFF;		// Clear Key END pushed
}

//****************************************************************************
// Main program  
//****************************************************************************

void main(void)
{
	Init_PCA9564();						// Initialization PCA9564		
	Init_White();          				// Initialization White LED's
	Init_RGB();								// Initialization RGB LED's
	Init_Misc();							// Initialization Misc LED's
	Init_GPIO();							// Initialization GPIO
	Intro_Patterns();						// Patterns displayed at power up
	
	
	while (1)		
   	{
			GPIO_Interrupt_Handler();
      	Function_Select();				// Enter a specific mode (programming, dial a number ...)
		}
}


