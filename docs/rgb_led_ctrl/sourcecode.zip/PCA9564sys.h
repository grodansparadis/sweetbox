//*************************************************************************
//
//                  P H I L I P S   P R O P R I E T A R Y
//
//           COPYRIGHT (c)   2003 BY PHILIPS SEMICONDUCTORS
//                     --  ALL RIGHTS RESERVED  --
//
// File Name:	PCA9564sys.h
// Created:		June 2, 2003
// Modified:	June 4, 2003
// Revision: 	1.00
//
//*************************************************************************

#ifndef __PCA9564SYS_H__
#define __PCA9564SYS_H__

#define MCU_COMMAND 0xFF	// dummy address
#define I2CSTA 	0x00		// PCA9564 Status Register
#define I2CTO		0x00		// PCA9564 Timeout Register
#define I2CDAT		0x01		// PCA9564 Data Register
#define I2CADR		0x02		// PCA9564 Address Register
#define I2CCON		0x03		// PCA9564 Control Register

// I2CCON = AA + ENSIO + STA + STO + SI + CR2 + CR1 + CR0
#define AA_ENSIO_STA_NOTSTO_NOTSI    	0xE0 // Generate Start
#define AA_ENSIO_NOTSTA_STO_NOTSI    	0xD0 // Generate Stop
#define AA_ENSIO_NOTSTA_NOTSTO_NOTSI	0xC0 // Release bus and Ack + set to slave receiver
#define NOTAA_ENSIO_NOTSTA_NOTSTO_NOTSI	0x40 // Release bus and NOT Ack

void PCA9564_Write(unsigned char Reg, unsigned char val);
unsigned char PCA9564_Read(unsigned char Reg);


#endif
