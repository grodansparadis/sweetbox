//*************************************************************************
//
//                  P H I L I P S   P R O P R I E T A R Y
//
//           COPYRIGHT (c)   2003 BY PHILIPS SEMICONDUCTORS
//                     --  ALL RIGHTS RESERVED  --
//
// File Name:	Interrupts.c
// Created:		June 2, 2003
// Modified:	November 07, 2003
// Revision: 	1.00
//
//*************************************************************************


void ExternalInt0(void) interrupt 0
{

}

void Timer0(void) interrupt 1
{

}

void ExternalInt1(void) interrupt 2
{

}

void Timer1(void) interrupt 3
{

}
 
