//*************************************************************************
//
//                  P H I L I P S   P R O P R I E T A R Y
//
//           COPYRIGHT (c)   2003 BY PHILIPS SEMICONDUCTORS
//                     --  ALL RIGHTS RESERVED  --
//
// File Name:	I2C_Routines.h
// Created:		June 2, 2003
// Modified:	November 07, 2003
// Revision: 	1.00
//
//*************************************************************************

unsigned char Search_Routine(unsigned char min, unsigned char max);
void GPIO_Interrupt_Handler(void);
void Blinker_Up_Down(void);
void ReadEEprom(short int MinEEPtr, short int MaxEEPtr, int Operation_EEprom, int Operation_Function);
void Preset_Patterns_PCA9531(void);
void LV51_LPC932(void);
void I2C_Address_Search(void);

