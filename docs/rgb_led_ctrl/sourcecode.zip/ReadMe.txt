Philips Semiconductors
Interface Products Business Line
Multimarket Semiconductors Business Unit
www.philipslogic.com


Application		:	LED Dimmer Demoboard
Source files for 	: 	P89LV51RD2

Revision:		:	1.0
Date			:	06/02/04


This ZIP file includes the following files:
- pca9564.prj	:	project file to be used with Raisonance IDE development tool
- PCA9564sys.c	:	source file in C language
- I2CDRIVR.c	:	source file in C language
- I2CINTFC.c	:	source file in C language
- I2CMASTR.c	:	source file in C language
- Interrupts.c	:	source file in C language
- Mainloop.c	:	source file in C language
- I2C_Routines.c	:	source file in C language
- PCA9564sys.h	:	source file in C language
- I2CDRIVR.h	:	source file in C language
- I2CEXPRT.h	:	source file in C language
- I2CMASTR.h	:	source file in C language
- I2C_Routines.h	:	source file in C language
- PCA9564.HEX	:	Hex file for the P89LPC932 device (can be used with Flash Magic)

Note: those files are subject to modification. For the latest version, please check at:
www.standardproducts.philips.com/support/i2c
and click on the link refering to the LED Dimmer Demoboard

Please refer any problem you encountered at i2c.support@philips.com	