//*************************************************************************
//
//                  P H I L I P S   P R O P R I E T A R Y
//
//           COPYRIGHT (c)   2003 BY PHILIPS SEMICONDUCTORS
//                     --  ALL RIGHTS RESERVED  --
//
// File Name:	i2cintfc.c
// Created:		June 2, 2003
// Modified:	June 10, 2003
// Revision: 	1.00
//
//*************************************************************************

#include <REG51RX.H>
#include "i2cexprt.h"
#include "i2cdrivr.h"
#include "i2cmastr.h"
#include "PCA9564sys.h"


BYTE drvStatus;                   	// Status returned by driver

static I2C_MESSAGE   *p_iicMsg[2];	// pointer to an array of (2) I2C messages
static I2C_TRANSFER  iicTfr;

/* *************************************************************************
 * Input(s)   : status       Status of the driver at completion time
 *              msgsDone     Number of messages completed by the driver
 * Output(s)  : None.
 * Returns    : None.
 * Description: Signal the completion of an I2C transfer. This function is
 *              passed (as parameter) to the driver and called by the
 *              drivers state handler (!).
 ***************************************************************************/
static void I2cReady(BYTE status, BYTE msgsDone)
{
    drvStatus = status;
}

/* *************************************************************************
 * Input(s)   : None.
 * Output(s)  : statusfield of I2C_TRANSFER contains the driver status:
 *                 I2C_OK          Transfer was successful.
 *                 I2C_TIME_OUT    Timeout occurred
 *                 Otherwise       Some error occurred.
 * Returns    : None.
 * Description: Start I2C transfer and wait (with timeout) until the
 *              driver has completed the transfer(s).
 ***************************************************************************/
 static void StartTransfer(void)
{
LONG timeOut;
BYTE retries = 0;

    do
    {
        drvStatus = I2C_BUSY;
        I2C_Transfer(&iicTfr, I2cReady);
        timeOut = 0;
        while (drvStatus == I2C_BUSY)
        		{
            if (++timeOut > 60000)
            	drvStatus = I2C_TIME_OUT;
               
            if (PCA9564_Read(I2CCON) & 0x08)	// wait until SI bit is set
            	MainStateHandler();
        		}
        if (retries == 6)
        		{
         	drvStatus = I2C_RETRIES;		// too many retries
        		}
        else
            retries++;
		  
    } while ((drvStatus != I2C_OK) & (drvStatus!=I2C_RETRIES));
}

/* *************************************************************************
 * Input(s)   : msg     I2C message
 * Returns    : None.
 * Description: Read a message from a slave device.
 * PROTOCOL   : <S><SlvA><R><A><D1><A> ... <Dnum><N><P>
 ***************************************************************************/
void I2C_Read(I2C_MESSAGE *msg)
{
    iicTfr.nrMessages = 1;
    iicTfr.p_message  = p_iicMsg;
    p_iicMsg[0] 		 = msg;

    StartTransfer();
}

/* *************************************************************************
 * Input(s)   : msg     I2C message
 * Returns    : None.
 * Description: Write a message to a slave device.
 * PROTOCOL   : <S><SlvA><W><A><D1><A> ... <Dnum><N><P>
 ***************************************************************************/
void I2C_Write(I2C_MESSAGE *msg)
{
    iicTfr.nrMessages = 1;
    iicTfr.p_message  = p_iicMsg;
    p_iicMsg[0] = msg;

    StartTransfer();
}

/* *************************************************************************
 * Input(s)   : msg1     first  I2C message
 *              msg2     second I2C message
 * Returns    : None.
 * Description: A message is sent and received to/from two different
 *              slave devices, separated by a repeat start condition.
 * PROTOCOL   : <S><Slv1A><W><A><D1><A>...<Dnum1><A>
 *              <S><Slv2A><R><A><D1><A>...<Dnum2><N><P>
 ***************************************************************************/
void I2C_WriteRepRead(I2C_MESSAGE *msg1, I2C_MESSAGE *msg2)
{
    iicTfr.nrMessages = 2;
    iicTfr.p_message  = p_iicMsg;
    p_iicMsg[0] = msg1;
    p_iicMsg[1] = msg2;

    StartTransfer();
}

/* *************************************************************************
 * Input(s)   : msg1     first I2C message
 *              msg2     second I2C message
 * Returns    : None.
 * Description: Writes two messages to different slave devices separated
 *              by a repeated start condition.
 * PROTOCOL   : <S><Slv1A><W><A><D1><A>...<Dnum1><A>
 *              <S><Slv2A><W><A><D1><A>...<Dnum2><A><P>
 ***************************************************************************/
void I2C_WriteRepWrite(I2C_MESSAGE *msg1, I2C_MESSAGE *msg2)
{
    iicTfr.nrMessages = 2;
    iicTfr.p_message  = p_iicMsg;
    p_iicMsg[0] = msg1;
    p_iicMsg[1] = msg2;

    StartTransfer();
}



