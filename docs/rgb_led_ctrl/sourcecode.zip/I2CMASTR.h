//*************************************************************************
//
//                  P H I L I P S   P R O P R I E T A R Y
//
//           COPYRIGHT (c)   2003 BY PHILIPS SEMICONDUCTORS
//                     --  ALL RIGHTS RESERVED  --
//
// File Name:	i2cmaster.h
// Created:		June 2, 2003
// Modified:	June 9, 2003
// Revision: 	1.00
//
//*************************************************************************

void I2C_Transfer(I2C_TRANSFER *p, void (*proc)(BYTE, BYTE)); 
