//*************************************************************************
//
//                  P H I L I P S   P R O P R I E T A R Y
//
//           COPYRIGHT (c)   2003 BY PHILIPS SEMICONDUCTORS
//                     --  ALL RIGHTS RESERVED  --
//
// File Name:	i2cmaster.c
// Created:		June 2, 2003
// Modified:	June 10, 2003
// Revision: 	1.00
//
//*************************************************************************

#include <REG51RX.H>
#include "i2cexprt.h"
#include "i2cdrivr.h"
#include "i2cmastr.h"
#include "PCA9564sys.h"

extern void (*masterProc)();          					// Handle Master Transfer action
//extern void (*slaveProc)();           				// Handle Slave Transfer action

static I2C_TRANSFER *tfr;             					// Pointer to active transfer block
static I2C_MESSAGE  *msg;             					// Pointer to active message block

static void (code *readyProc)(BYTE status,BYTE);  	// proc. to call if transfer ended
static BYTE msgCount;                					// Number of messages sent
static BYTE dataCount;               					// nr of bytes of current message
static BYTE state;                   					// state of the I2C driver
extern BYTE drvStatus;
unsigned char CRX;											// I2C frequency selector

/***************************************************************************
 * Input(s)    : status	-> status of the driver.
 * Output(s)   : None.
 * Returns     : None.
 * Description : Generate a stop condition.
 ***************************************************************************/
/*static void GenerateStop(BYTE status)
{
    PCA9564_Write(I2CCON,0xD0 | CR);
    master  = FALSE;
    state   = ST_IDLE;
    readyProc(status, msgCount);		// Signal driver is finished
}*/

/***************************************************************************
 * Input(s)    : None.
 * Output(s)   : None.
 * Returns     : None.
 * Description : Master mode state handler for I2C bus.
 ***************************************************************************/
//         +------------------------------------------------+
// I2CCON  | AA | ENSIO | STA | STO | SI | CR2 |  CR1 | CR0 |
//         +------------------------------------------------+ 
static void HandleMasterState(void)          
{
unsigned char PCA9564_Status;

PCA9564_Status = PCA9564_Read(I2CSTA);

switch (PCA9564_Status)
    {
    case 0x08:	// (re)start condition
    case 0x10:	PCA9564_Write(I2CDAT,msg->address);
					PCA9564_Write(I2CCON,0xC0 | CRX); 				// clear SI bit to send address				
      			break;
    case 0x18:	PCA9564_Write(I2CDAT,msg->buf[dataCount++]);	// send next data byte
					PCA9564_Write(I2CCON,0xC0 | CRX); 				// I2CCON=11000xxx
      			break;
    case 0x20:	// no Ack received
    				PCA9564_Write(I2CCON,0xD0 | CRX);				// I2CCON=11010xxx -> Stop condition
      			drvStatus = I2C_ERROR;
      			break;
    case 0x28:	// ack received
    				if (dataCount < msg->nrBytes)
      			{
        			PCA9564_Write(I2CDAT,msg->buf[dataCount++]);
        			PCA9564_Write(I2CCON,0xC0 | CRX);				// I2CCON=11000xxx -> release interrupt
      			}
      			else
      			{
        			if (msgCount < tfr->nrMessages)
        				{
        				dataCount = 0;
        				msg = tfr->p_message[msgCount++];
        				PCA9564_Write(I2CDAT,msg->address);
        				PCA9564_Write(I2CCON,0xE0 | CRX); // I2CCON=11100xxx = start
        				}
        				else
        				{
        				PCA9564_Write(I2CCON,0xD0 | CRX); // I2CCON=11010xxx
        				drvStatus = I2C_OK;
        				}
      			} // if
	     			break;
    case 0x30: // no ACK for data byte
					PCA9564_Write(I2CCON,0xD0 | CRX); // I2CCON=11010xxx -> stop condition
					drvStatus = I2C_ERROR;
					break;
    case 0x38: // arbitration lost -> not addressed as slave
      			PCA9564_Write(I2CCON,0xE0 | CRX); // I2CCON=11100xxx -> send start again
      			drvStatus = I2C_ARBITRATION_LOST;
      			break;

    // MASTER RECEIVER FUNCTIONS
    case 0x40:	// ACK for slave address + R
    				if (msg->nrBytes>1)
      			{
        			PCA9564_Write(I2CCON,0xC0 | CRX); // I2CCON=11000xxx -> acknowledge byte
      			}
     				else
      			{
        			PCA9564_Write(I2CCON,0x40 | CRX); // I2CCON=01000xxx -> return NACK
      			} // if
      			break;
    case 0x48:	// no ACK for slave address + R
      			PCA9564_Write(I2CCON,0xD0 | CRX); // I2CCON=11010xxx -> send stop
      			drvStatus = I2C_ERROR;
      			break;
    case 0x50:	// ACK for data byte
    				msg->buf[dataCount++] = PCA9564_Read(I2CDAT);
      			if (dataCount + 1 < msg->nrBytes)
      				{
      				PCA9564_Write(I2CCON,0xC0 | CRX); // I2CCON=11000xxx
      				}
      				else
      				{
						PCA9564_Write(I2CCON,0x40 | CRX); // I2CCON=01000xxx
						}
      			break;
    case 0x58: // no ACK for data byte
    				msg->buf[dataCount++] = PCA9564_Read(I2CDAT);
      			PCA9564_Write(I2CCON,0xD0 | CRX); // I2CCON=11010xxx -> send Stop
      			drvStatus = I2C_OK;
      			break;
    default:	// undefined error
	     			PCA9564_Write(I2CCON,0xD0 | CRX); // I2CCON=11000xxx -> send stop
	     			drvStatus = I2C_ERROR;
      			break;
	 } // switch - PCA9564_Status
} // i2c_isr

/***************************************************************************
 * Input(s)   : p            address of I2C transfer parameter block.
 *              proc         procedure to call when transfer completed,
 *                           with the driver status passed as parameter.
 * Output(s)  : None.
 * Returns    : None.
 * Description: Start an I2C transfer, containing 1 or more messages. The
 *              application must leave the transfer parameter block 
 *              untouched until the ready procedure is called.
 ***************************************************************************/
void I2C_Transfer(I2C_TRANSFER *p, void (*proc)(BYTE status, BYTE msgsDone))
{
    tfr       = p;
    readyProc = proc;
    msgCount  = 0;
    dataCount = 0;
    master    = TRUE;
    msg = tfr->p_message[msgCount++];

    state     = (msg->address & 1) ? ST_AWAIT_ACK : ST_SENDING;
    PCA9564_Write(I2CCON,0xE0 | CRX);  // 1110 0xxx -> generate Start
}

/* **********************************************************************
   * Input(s)   : speed      clock register value for bus speed.
   * Output(s)  : None.
   * Returns    : None.
   * Description: Initialize the PCA9564 as I2C bus master.
   **********************************************************************/
void I2C_InitializeMaster(BYTE speed)
{
int i;

    state     = ST_IDLE;
    readyProc = 0;								// Null pointer
    masterProc = HandleMasterState;			// Set pointer to correct proc.
    PCA9564_Write(I2CADR,0xFE);				// own slave address
    CRX = speed;									// I2C Frequency = 88KHz
    PCA9564_Write(I2CCON,0xC0 | CRX);		// 1100 0xxx -> Set to slave receiver
    for (i=0;i<1000;i++)	;
    master  = FALSE;
}

