//*************************************************************************
//
//                  P H I L I P S   P R O P R I E T A R Y
//
//           COPYRIGHT (c)   2003 BY PHILIPS SEMICONDUCTORS
//                     --  ALL RIGHTS RESERVED  --
//
// File Name:	PCA9564sys.C
// Created:		June 2, 2003
// Modified:	June 10, 2003
// Revision: 	1.00
//
//*************************************************************************

#include <REG51RX.H>		// special function register declarations
//#include "BasicTyp.h"
#include "PCA9564sys.h"

sbit A0			= P2^0; 
sbit A1			= P2^1;

sbit Reset9564 = P3^4;

// +---------------------------------------------+
// | PCA9564 register commands
// |
// +---------------------------------------------+

void PCA9564_Write(unsigned char Reg, unsigned char val)
{
   A0 = Reg & 0x01;
	A1 = Reg & 0x02;
	AUXR = 0x02;	// Access external memory, emit/don't emit ALE --> emit when using emulator
	*((unsigned char pdata *)MCU_COMMAND) = val;
	AUXR = 0x00;	// Access internal memory, emit ALE when using emulator
}

unsigned char PCA9564_Read(unsigned char Reg)
{
unsigned char RegData;
int i;

   A0 = Reg & 0x01;
   A1 = Reg & 0x02;
	AUXR = 0x02;	// Access external memory, emit ALE when using emulator
	for (i=0;i<10;i++);	// add small delay due to rise time issues on demoboard
	RegData = *((unsigned char pdata *)MCU_COMMAND);
	AUXR = 0x00;	// Access internal memory, emit ALE when using emulator
	return RegData;
}



