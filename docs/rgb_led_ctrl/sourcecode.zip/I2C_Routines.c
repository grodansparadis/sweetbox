//*************************************************************************
//
//                  P H I L I P S   P R O P R I E T A R Y
//
//           COPYRIGHT (c)   2003 BY PHILIPS SEMICONDUCTORS
//                     --  ALL RIGHTS RESERVED  --
//
// File Name:	I2C_Routines.c
// Created:		June 2, 2003
// Modified:	November 07, 2003
// Revision: 	1.00
//
//*************************************************************************

#include <REG51RX.H>
#include "i2cexprt.h"
#include "PCA9564sys.h"


unsigned char Data_Received;

extern unsigned char CRX;

extern idata BYTE  Buffer1[32];
extern idata BYTE  Buffer2[32];
extern idata BYTE  Buffer3[16];
extern idata BYTE  Buffer4[16];

extern idata I2C_MESSAGE	Message1;
extern idata I2C_MESSAGE	Message2;
extern idata I2C_MESSAGE	Message3;
extern idata I2C_MESSAGE	Message4;
 
idata BYTE Snapshot_1_1st_Byte = 0x0F;
idata BYTE Snapshot_1_2nd_Byte = 0x0F;
idata BYTE Snapshot_2_1st_Byte = 0x00;
idata BYTE Snapshot_2_2nd_Byte = 0x00;
int Trigger_GPIO_Polling;
int GPIO_Polling_On = 0; 		// Enable (1) or disable (0) the PCA9555 polling option - default = off
 

void InsertBigDelay(void)
{
	InsertDelay(255);
   InsertDelay(255);
   InsertDelay(255);
   InsertDelay(255);
   InsertDelay(255);
}


//****************************************************************************
// Program the 3 PCA9531 (R/G/B) with the same parameter(s) 
//**************************************************************************** 

void Write_RGB_Controller(void)
{
	Message1.address = PCA9531_R_WR;
   I2C_Write(&Message1);
   Message1.address = PCA9531_G_WR;
   I2C_Write(&Message1);
   Message1.address = PCA9531_B_WR;
   I2C_Write(&Message1);
} 
 
 
//****************************************************************************
// GPIO Interrupt Handling function					
// One shot mode (through /INT) or 
// permanent action detection (then Input PCA9554 Reg# polling) 	     
//****************************************************************************
 
void GPIO_Interrupt_Handler(void)
{
   Message2.address = PCA9555_WR;
	Message2.buf     = Buffer2;
	Message2.nrBytes = 1;
	Buffer2[0] 		  = 0;  										// subaddress = 0
	
	Message3.address = PCA9555_RD;
	Message3.buf     = Buffer3;
	Message3.nrBytes = 2;  										// read 2 bytes

	if (PCA9555_Int==0)											// Action on pushbutton detected
	{
		I2C_WriteRepRead(&Message2,&Message3);				// 1st read the PCA9555
		if (Buffer3[0] ==0xFF & Buffer3[1] ==0xFF);
		else
		{
			Snapshot_1_1st_Byte = Buffer3[0];				// load the 1st read data (Byte 1) in a temp memory
			Snapshot_1_2nd_Byte = Buffer3[1];				// load the 1st read data (Byte 2) in a temp memory	
		}					
		
		InsertDelay(255);
		InsertDelay(255);
		InsertDelay(255);
		I2C_WriteRepRead(&Message2,&Message3);			// 2nd read the PCA9555
		Snapshot_2_1st_Byte = Buffer3[0];				// load the 2nd read data (Byte 1) in a temp memory
		Snapshot_2_2nd_Byte = Buffer3[1];				// load the 2nd read data (Byte 2) in a temp memory
		if (Snapshot_1_1st_Byte == Snapshot_2_1st_Byte & Snapshot_1_2nd_Byte == Snapshot_2_2nd_Byte & GPIO_Polling_On == 1)	// Compare the 2 read data in the temp memories
		{
			Trigger_GPIO_Polling = 1; 							// permanent push detected when 1st and 2nd readings equal
		}
		else
		{
			Trigger_GPIO_Polling = 0;							// single shot action when 1st and 2nd readings different
			Buffer3[0] = Snapshot_1_1st_Byte;				// Buffer loaded again with the initial push value
			Buffer3[1] = Snapshot_1_2nd_Byte;				// Buffer loaded again with the initial push value
		}		
	}
	if (Trigger_GPIO_Polling == 1)							// Start Polling PCA9554 when permanent push detected
	{
		I2C_WriteRepRead(&Message2,&Message3);	
	}		
}


//****************************************************************************
// Pattern displayed at power up or after a reset				     
//****************************************************************************

void Intro_Patterns(void)
{
	Message1.nrBytes 	= 7;
	Buffer1[0]		  = 0x11;			// autoincrement + register 1
	Buffer1[1]		  = 0x00;			// default prescaler pwm0
  	Buffer1[2]		  = 0x3B;			// default duty cycle for pwm0
  	Buffer1[3]		  = 0x00;			// default prescaler pwm1
  	Buffer1[4]		  = 0x01;			// default duty cycle for pwm1
 	Buffer1[5]		  = 0x00;			// Green RGB LED's = off
  	Buffer1[6]		  = 0x00;			// Green RGB LED's = off  				
  	Message1.address = PCA9531_R_WR;
  	I2C_Write(&Message1); 
  	Message1.address = PCA9531_G_WR;
  	I2C_Write(&Message1);
  	Message1.address = PCA9531_B_WR;
  	I2C_Write(&Message1);
  	Message1.nrBytes 	= 3; 
	Buffer1[0]		  = 0x15; 
  	Buffer1[1]		  = 0x02;			// LD13 @ BR0			
   Buffer1[2]		  = 0x00;			
   Write_RGB_Controller();
   InsertDelay(250);	  
   Buffer1[1]		  = 0x0A;			// LD14 @ BR0			
   Buffer1[2]		  = 0x00;			
   Write_RGB_Controller();
   InsertDelay(250);	   
   Buffer1[1]		  = 0x20;			// LD15 @ BR0			
   Buffer1[2]		  = 0x00;			
   Write_RGB_Controller();
   InsertDelay(250);	
   Buffer1[1]		  = 0xA0;			// LD16 @ BR0			
   Buffer1[2]		  = 0x00;			
   Write_RGB_Controller();
   InsertDelay(250);	 
   Buffer1[1]		  = 0x00;						
   Buffer1[2]		  = 0x02;			// LD17 @ BR0
   Write_RGB_Controller();
   InsertDelay(250);	 
   Buffer1[1]		  = 0x00;						
   Buffer1[2]		  = 0x0A;			// LD18 @ BR0
   Write_RGB_Controller();
   InsertDelay(250);	
   Buffer1[1]		  = 0x00;						
   Buffer1[2]		  = 0x20;			// LD19 @ BR0
   Write_RGB_Controller();
   InsertDelay(250);
   Buffer1[1]		  = 0x00;						
   Buffer1[2]		  = 0xA0;			// LD20 @ BR0
   Write_RGB_Controller();
   InsertDelay(250);
   Buffer1[1]		  = 0x02;			// LD13 @ BR0			
   Buffer1[2]		  = 0x00;			
   Write_RGB_Controller();
   InsertDelay(250);	
   Buffer1[1]		  = 0x00;			// off			
   Buffer1[2]		  = 0x00;			// off
   Write_RGB_Controller();
}


//****************************************************************************
// Function controlling number dial                              
// Number = 10 digits : xxx-xxx-xxxx                          
// Once dialed, SND button is pushed 
//****************************************************************************

idata BYTE Key_Pushed;
short int Call				= 0;
	
void Dial_Number(void)
{
	int Nb_Key_Pressed 	= 0;
	int One_To_Eight 		= 0;
	int Nine_Zero 			= 0;
	
	Call++;											// When Call = even number, line is busy - When Call = odd number, line is not busy 
	Message1.address 	= PCA9531_M_WR;		// PCA9531 Misc 
	Message1.nrBytes 	= 6;						// Reset the PCA9531 to its default programmed values
	Message1.buf     	= Buffer1;
	Buffer1[0]			= 0x11;					// subaddress = 0x01
	Buffer1[1] 			= 0x97;					// BR0 = 1 Hz
   Buffer1[2] 			= 0x80;					// BR0 duty cycle = 50%
   Buffer1[3] 			= 0x97;					// BR1 = 1 Hz
   Buffer1[4] 			= 0x08;					// duty cycle BR1 = 50%
   Buffer1[5] 			= 0x00;					// All 4 LEDs off
	I2C_Write(&Message1);						// Program PCA9531 (6 bytes)
	
	Message1.nrBytes 	= 2;			
	while (Buffer3[1] != 0xDF)					// Loop as long as END button not pushed (call not ended)
	{
		if (Buffer3[0] != 0xFF & Nb_Key_Pressed < 11 & Buffer3[1] != 0xEF)		// Key pushed = 1, 2, 3, 4, 5, 6, 7, 8 and != SND
		{
			Key_Pushed = Buffer3[0];
			Nb_Key_Pressed++;
			One_To_Eight = 1;
			Nine_Zero = 0;
		}
		if (Buffer3[1] != 0xFF & Nb_Key_Pressed < 11 & Buffer3[1] != 0xEF)		// Key pushed = 9, 0 and != SND
		{
			Key_Pushed = Buffer3[1];
			Nb_Key_Pressed++;	
			One_To_Eight = 0;
			Nine_Zero = 1;	
		} 
		if (Nb_Key_Pressed < 11 & Buffer3[1] != 0xEF & (Buffer3[0] != 0xFF | Buffer3[1] != 0xFF))
		{
			Buffer3[0] = 0xFF;				// Clear key pushed
			Buffer3[1] = 0xFF;				// Clear key pushed
			Buffer1[0]	= 0x15;				// subaddress PCA9531_M= 0x05
			switch (Key_Pushed)
			{
				case 0xFE:	if (One_To_Eight == 1)				// 1 pushed
								{
									Buffer1[1]	= 0x40;				// LD8 = on
									I2C_Write(&Message1);			// Program PCA9531 (2 bytes)
								}
								if (Nine_Zero == 1)					// 9 pushed
								{
									Buffer1[1]	= 0x41;				// LD5 and LD8 = on
									I2C_Write(&Message1);			// Program PCA9531 (2 bytes)
								}
								break;
				case 0xFD:	if (One_To_Eight == 1)				// 2 pushed
								{
									Buffer1[1]	= 0x10;				// LD7 = on
									I2C_Write(&Message1);			// Program PCA9531 (2 bytes)
								}
								if (Nine_Zero ==1)					// 0 pushed
								{
									Buffer1[1]	= 0x00;				// LD5 to LD8 = off
									I2C_Write(&Message1);			// Program PCA9531 (2 bytes)
								}
								break;
				case 0xFB:												// 3 pushed
								Buffer1[1]	= 0x50;					// LD7 and LD8 = on
								I2C_Write(&Message1);				// Program PCA9531 (2 bytes)
								break;
				case 0xF7:												// 4 pushed
								Buffer1[1]	= 0x04;					// LD6 = on
								I2C_Write(&Message1);				// Program PCA9531 (2 bytes)
								break;
				case 0xEF:												// 5 pushed
								Buffer1[1]	= 0x44;					// LD6 and LD8 = on
								I2C_Write(&Message1);				// Program PCA9531 (2 bytes)
								break;
				case 0xDF:												// 6 pushed
								Buffer1[1]	= 0x14;					// LD6 and LD7 = on
								I2C_Write(&Message1);				// Program PCA9531 (2 bytes)
								break;
				case 0xBF:												// 7 pushed
								Buffer1[1]	= 0x54;					// LD6, LD7 and LD8 = on
								I2C_Write(&Message1);				// Program PCA9531 (2 bytes)
								break;
				case 0x7F:												// 8 pushed
								Buffer1[1]	= 0x01;					// LD5 = on
								I2C_Write(&Message1);				// Program PCA9531 (2 bytes)
								break;
			}
		}
		if (Nb_Key_Pressed == 11 & Buffer3[1] != 0xEF)		// more than 10 keys pushed and SND not pushed yet
		{
			Buffer3[0] 			= 0xFF;								// Clear key pushed
			Buffer3[1] 			= 0xFF;								// Clear key pushed
			Buffer1[1] 			= 0xAA;								// LD5 to LD8 = BR0 to indicate that the 10 numbers have been dialed
			I2C_Write(&Message1);									// Program PCA9531 (2 bytes)
			Nb_Key_Pressed++;	
		}
		if (Buffer3[1] == 0xEF)									// SND pushed: Send a call  
		{			
			Buffer1[1] 			= 0x00;							// LD5 to LD8 = off (dial number = done)
			I2C_Write(&Message1);								// Program PCA9531  (2 bytes)
			Message1.nrBytes 	= 7;							
			Buffer1[0]			= 0x11;							// subaddress = 0x01 
			Buffer1[1] 			= 0x97;							// BR0 = 1 Hz
   		Buffer1[2] 			= 0x80;							// duty cycle BR0 = 50%
   		Buffer1[3] 			= 0x00;							// max freq BR1
   		Buffer1[4] 			= 0xFF;							// max duty cycle BR1
   		Buffer1[5] 			= 0xAA;							// All 4 RGB LEDs blinking red
   		Buffer1[6] 			= 0xAA;							// All 4 RGB LEDs blinking red
			if (Call & 0x01)										// Busy signal
			{
				Message1.address 	= PCA9531_R_WR;			// PCA9531 Red 
				I2C_Write(&Message1);							// Program PCA9531 (7 bytes)
			}
			else														// Non Busy signal						 
			{
				Message1.address 	= PCA9531_G_WR;			// PCA9531 Green 
				I2C_Write(&Message1);							// Program PCA9531 (7 bytes)
			}
		}
		Buffer3[0] = 0xFF;
		Buffer3[1] = 0xFF;
		GPIO_Interrupt_Handler();				// Check if a key has been pushed
	}
	Message1.address 	= PCA9531_M_WR;		// PCA9531 Misc
	Message1.nrBytes 	= 2;
	Buffer1[1] 			= 0x00;					// LD5 to LD8 = off (dial number = done) 
	I2C_Write(&Message1);						// Program PCA9531  (2 bytes)
	Message1.nrBytes 	= 3;
	Buffer1[2] 			= 0x00;					// All RGB LEDs = off
	Message1.address 	= PCA9531_R_WR;		// PCA9531 Red to switch off Red LEDs 
	I2C_Write(&Message1);						// Program PCA9531 (3 bytes)
	Message1.address 	= PCA9531_G_WR;		// PCA9531 Red to switch off Green LEDs
	I2C_Write(&Message1);						// Program PCA9531 (3 bytes)
}


//****************************************************************************
// Function controlling the Duty Cycle for a specific device
// inputs 	= Key "-", Key "+", I2C address
// output	= new Duty Cycle value                          
//****************************************************************************

	short int  Duty_Cycle_Control(short int  Operation, short int I2C_Address, short int  Duty_Cycle_Value)
{
	Message1.address 	= I2C_Address;
	Message1.nrBytes = 2;
	if (Operation == Decrement & Duty_Cycle_Value > 0x00)	// Key pushed = 2  - decrease brightness
	{
		Buffer1[0] = 0x02;											// subaddress = 0x02
		Duty_Cycle_Value--;											// decrement pwm 0
		Buffer1[1] = Duty_Cycle_Value;
		I2C_Write(&Message1);										// send new data to PCA9531 (2 bytes)
	}
	if (Operation == Increment & Duty_Cycle_Value < 0xFF)	// Key pushed = 3 pushed - increase brightness
	{
		Buffer1[0] = 0x02;											// subaddress = 0x02
		Duty_Cycle_Value++;											// increment pwm 0
		Buffer1[1] = Duty_Cycle_Value;
		I2C_Write(&Message1);										// send new data to PCA9531 (2 bytes)
	} 
	Buffer3[0] = 0xFF;												// Clear Key Plus pushed
	Buffer3[1] = 0xFF;												// Clear Key Plus pushed (Key 9 only)
	return Duty_Cycle_Value;
}


//****************************************************************************
// Function controlling the Backlight programming
// Entered by pushing 1
// Key 2 = decrease brightness
// Key 3 = Increase brightness       
// Leave the mode by pushing END                         
//****************************************************************************

idata BYTE Duty_Cycle_White;

void Backlight_Programming (void)
{
	Buffer3[0] = 0xFF;								// Clear Key 1 pushed
	Message1.address 	= PCA9531_M_WR;			// PCA9531 Misc to indicate backlight programming mode 
	Message1.nrBytes 	= 2;              	
	Buffer1[0]			= 0x15;						// subaddress = 0x15
	Buffer1[1] 			= 0x40;						// LD8 on --> backlight programming mode active
	I2C_Write(&Message1);
	GPIO_Polling_On = 1;								// Enable PCA9555 polling option (see GPIO_Interrupt_Handler function)
	Message2.address = PCA9533_W_WR;				// Read the current brightness value from the PCA9533
	Message2.buf     = Buffer2;
	Message2.nrBytes = 1;
	Buffer2[0] 		  = 0x02;  						// subaddress = 12	
	Message3.address = PCA9533_W_RD;
	Message3.buf     = Buffer3;
	Message3.nrBytes = 1;  							// read 1 byte
	I2C_WriteRepRead(&Message2,&Message3);		// read PWM0 of the PCA9531
	Duty_Cycle_White = Buffer3[0];
	while (Buffer3[1] != 0xDF)
	{
		GPIO_Interrupt_Handler();
		InsertDelay(100);
		if (Buffer3[0] == 0xFD) Duty_Cycle_White = Duty_Cycle_Control(Decrement, PCA9533_W_WR, Duty_Cycle_White); // "-" Red (Key 2)
		if (Buffer3[0] == 0xFB) Duty_Cycle_White = Duty_Cycle_Control(Increment, PCA9533_W_WR, Duty_Cycle_White); // "+" Red (Key 3)
	}	
	Buffer3[1] = 0xFF;								// Clear Key END pushed
	GPIO_Polling_On = 0;								// Disable PCA9555 GPIO option
	Message1.address 	= PCA9531_M_WR;			// PCA9531 Misc to indicate LED programming mode 
	Message1.nrBytes 	= 2;              	
	Buffer1[0]			= 0x15;						// subaddress = 0x15
	Buffer1[1] 			= 0x00;						// LD8 off --> backlight programming mode left
	I2C_Write(&Message1);
}


//****************************************************************************
// Function displaying a selected Fun Pattern
// Inputs = Amount of Red, Green and Blue, Rotating Speed 
//****************************************************************************

int Fun_Loop_Counter = 1;
int Speed_Prog_On		= 0;

void Fun_Pattern_Display( short int Red_Value, short int Green_Value, short int Blue_Value, short int Speed_Value)
{
	Message1.buf     = Buffer1;
	Message1.nrBytes 	= 2;
	Buffer1[0] 			= 0x12;					// subaddress = 12
	Message1.address 	= PCA9531_R_WR;		// PCA9531 Red 						
	Buffer1[1] 			= Red_Value;			// Programming Red
	I2C_Write(&Message1);						// Program PCA9531 Red (2 bytes)
	Message1.address 	= PCA9531_G_WR;		// PCA9531 Green 						
	Buffer1[1] 			= Green_Value;			// Programming Green
	I2C_Write(&Message1);						// Program PCA9531 Green (2 bytes)
	Message1.address 	= PCA9531_B_WR;		// PCA9531 Blue 						
	Buffer1[1] 			= Blue_Value;			// Programming Blue
	I2C_Write(&Message1);						// Program PCA9531 Blue (2 bytes)
	
	Message1.nrBytes 	= 3;	
	Buffer1[0] 			= 0x15;					// subaddress = 15
	
	while (((Buffer3[0]==0xFF & Buffer3[1]==0xFF) | Buffer3[1] == 0xFD | Buffer3[1] == 0xF7) & Speed_Prog_On ==0) 							// Loop as long as a pushbutton not pressed
	{ 	                                          				
		if (Fun_Loop_Counter < 8)
		{
			Fun_Loop_Counter++;
		}
		else
		{
			Fun_Loop_Counter = 1;
		}
		switch (Fun_Loop_Counter)
		{
			case 1:	Buffer1[1] 			= 0x02;					// Programming LD13  blinking at BR0
		   			Buffer1[2] 			= 0x00;					// LED's off
						break;
			case 2:	Buffer1[1] 			= 0x08;					// Programming LD14  blinking at BR0
	   				Buffer1[2] 			= 0x00;					// LED's off
						break;
			case 3:	Buffer1[1] 			= 0x20;					// Programming LD15  blinking at BR0
	   				Buffer1[2] 			= 0x00;					// LED's off
						break;
			case 4:	Buffer1[1] 			= 0x80;					// Programming LD16  blinking at BR0
	   				Buffer1[2] 			= 0x00;					// LED's off
						break;
			case 5:	Buffer1[1] 			= 0x00;					// LED's off
	   				Buffer1[2] 			= 0x02;					// Programming LD17  blinking at BR0
						break;
			case 6:	Buffer1[1] 			= 0x00;					// Programming LD18  blinking at BR0
	   				Buffer1[2] 			= 0x08;					// LED's off
						break;
			case 7:	Buffer1[1] 			= 0x00;					// LED's off
	   				Buffer1[2] 			= 0x20;					// Programming LD19  blinking at BR0
						break;
			case 8:	Buffer1[1] 			= 0x00;					// LED's off
	   				Buffer1[2] 			= 0x80;					// Programming LD20  blinking at BR0
						break;
		}
		Message1.address 	= PCA9531_R_WR;		// PCA9531 Green 						 
		I2C_Write(&Message1);						// Program PCA9531 Red (3 bytes)
		Message1.address 	= PCA9531_G_WR;		// PCA9531 Green 					
		I2C_Write(&Message1);						// Program PCA9531 Green (3 bytes)
		Message1.address 	= PCA9531_B_WR;		// PCA9531 Blue 				
		I2C_Write(&Message1);						// Program PCA9531 Blue (3 bytes)
		InsertDelay(Speed_Value);					// Programmable delay
		InsertDelay(Speed_Value);
		InsertDelay(Speed_Value);
		GPIO_Interrupt_Handler();
		if (Buffer3[1] == 0xFD | Buffer3[1] == 0xF7)	Speed_Prog_On = 1;			
	}
	if ((Buffer3[0]!=0xFF | Buffer3[1]!=0xFF) & Buffer3[1] != 0xFD & Buffer3[1] != 0xF7)	// All the LEDs blinking at BR0
	{
		Message1.nrBytes 	= 3;
		Buffer1[0] 			= 0x15;					// subaddress = 15
	  	Buffer1[1] 			= 0xAA;					// Programming All  LED's blinking at BR0
	  	Buffer1[2] 			= 0xAA;					// Programming All  LED's blinking at BR0
		Message1.address 	= PCA9531_R_WR;		// PCA9531 Green 								
		I2C_Write(&Message1);						// Program PCA9531 Red (3 bytes)
		Message1.address 	= PCA9531_G_WR;		// PCA9531 Green 					
		I2C_Write(&Message1);						// Program PCA9531 Green (3 bytes)
		Message1.address 	= PCA9531_B_WR;		// PCA9531 Blue 				
		I2C_Write(&Message1);						// Program PCA9531 Blue (3 bytes)
	}
}


//****************************************************************************
// Function controlling the Fun Pattern programming
// 3 programmable patterns: color and speed
// Entered by pushing 4
// Key 1 = select pattern 1
// Key 4 = select pattern 2
// Key 7 = select pattern 3      
// Key 2 = decrease red of selected pattern
// Key 3 = increase red of selected pattern
// Key 5 = decrease green of selected pattern
// Key 6 = increase green of selected pattern
// Key 8 = decrease blue of selected pattern
// Key 9 = increase blue of selected pattern
// Key 0 = decrease speed of selected pattern
// Key # = increase speed of selected pattern                        
//****************************************************************************

idata BYTE Duty_Cycle_R_One		= 0x6B;
idata BYTE Duty_Cycle_G_One		= 0x01;
idata BYTE Duty_Cycle_B_One		= 0x25;

idata BYTE Duty_Cycle_R_Two		= 0x01;
idata BYTE Duty_Cycle_G_Two		= 0x6B;
idata BYTE Duty_Cycle_B_Two		= 0x25;

idata BYTE Duty_Cycle_R_Three		= 0x26;
idata BYTE Duty_Cycle_G_Three		= 0x6B;
idata BYTE Duty_Cycle_B_Three		= 0x01;

int Speed_One		= 255;
int Speed_Two		= 25;
int Speed_Three	= 100;

void Fun_Pattern_Programming (void)
{
	Init_RGB();
	GPIO_Interrupt_Handler();  					// Check if an action on pushbutton happened 
	if (Buffer3[0] == 0xFE)							// Pattern 1 selected - Key 1 pushed		
	{
		Buffer3[0] = 0xFF;							// Clear Key 1 pushed
		Message1.address 	= PCA9531_M_WR;		// PCA9531 Misc to indicate backlight programming mode 
		Message1.nrBytes 	= 2;              	 
		Buffer1[0]			= 0x15;					// subaddress = 0x15
		Buffer1[1] 			= 0x01;					// LD5 on --> Pattern 1 programming active
		I2C_Write(&Message1);		
		while (Buffer3[1]!=0xDF)					// Loop as long as END button not pushed (Fun pattern 1 programming active)
  		{ 	                                          	
			Buffer3[1] = 0xFF;
			GPIO_Interrupt_Handler();  			// Check if an action on pushbutton happened
			GPIO_Polling_On = 1;						// Enable PCA9555 polling option (see GPIO_Interrupt_Handler function)
			Fun_Pattern_Display(Duty_Cycle_R_One, Duty_Cycle_G_One, Duty_Cycle_B_One, Speed_One);			
			if (Buffer3[0] == 0xFD) Duty_Cycle_R_One = Duty_Cycle_Control(Decrement, PCA9531_R_WR, Duty_Cycle_R_One); // "-" Red (Key 2)
			if (Buffer3[0] == 0xFB) Duty_Cycle_R_One = Duty_Cycle_Control(Increment, PCA9531_R_WR, Duty_Cycle_R_One); // "+" Red (Key 3)
			if (Buffer3[0] == 0xEF) Duty_Cycle_G_One = Duty_Cycle_Control(Decrement, PCA9531_G_WR, Duty_Cycle_G_One); // "-" Green (Key 5)
			if (Buffer3[0] == 0xDF) Duty_Cycle_G_One = Duty_Cycle_Control(Increment, PCA9531_G_WR, Duty_Cycle_G_One); // "+" Green (Key 6)
			if (Buffer3[0] == 0x7F) Duty_Cycle_B_One = Duty_Cycle_Control(Decrement, PCA9531_B_WR, Duty_Cycle_B_One); // "-" Blue (Key 8)
			if (Buffer3[1] == 0xFE) Duty_Cycle_B_One = Duty_Cycle_Control(Increment, PCA9531_B_WR, Duty_Cycle_B_One); // "+" Blue (Key 9)
			if (Buffer3[1] == 0xFD & Speed_One > 0) 
			{
				Speed_One--;
			}
			if (Buffer3[1] == 0xF7 & Speed_One < 255) 
			{
				Speed_One++;
			}
			Speed_Prog_On = 0;
			GPIO_Polling_On = 0;						// Disable PCA9555 GPIO Polling option	
			
		}
		Buffer3[0] = 0xFF;
		Buffer3[1] = 0xFF;
		Message1.address 	= PCA9531_M_WR;		// PCA9531 Misc to indicate backlight programming mode 
		Message1.nrBytes 	= 2;              	
		Buffer1[0]			= 0x15;					// subaddress = 0x15
		Buffer1[1] 			= 0x00;					// LD5 off --> Pattern 1 programming left
		I2C_Write(&Message1);
			
	}
	
	if (Buffer3[0] == 0xFD)							// Pattern 2 selected - Key 2 pushed		
	{ 
		Buffer3[0] = 0xFF;							// Clear Key 2 pushed
		Message1.address 	= PCA9531_M_WR;		// PCA9531 Misc to indicate backlight programming mode 
		Message1.nrBytes 	= 2;              	
		Buffer1[0]			= 0x15;					// subaddress = 0x15
		Buffer1[1] 			= 0x04;					// LD6 on --> Pattern 2 programming active
		I2C_Write(&Message1);
		while (Buffer3[1]!=0xDF)					// Loop as long as END button not pushed (Fun pattern 2 programming active)
  		{ 	                                        
			Buffer3[1] = 0xFF;
			GPIO_Interrupt_Handler();  			// Check if an action on pushbutton happened
			GPIO_Polling_On = 1;						// Enable PCA9555 polling option (see GPIO_Interrupt_Handler function)
			Fun_Pattern_Display(Duty_Cycle_R_Two, Duty_Cycle_G_Two, Duty_Cycle_B_Two, Speed_Two);	
			if (Buffer3[0] == 0xFD) Duty_Cycle_R_Two = Duty_Cycle_Control(Decrement, PCA9531_R_WR, Duty_Cycle_R_Two); // "-" Red (Key 2)
			if (Buffer3[0] == 0xFB) Duty_Cycle_R_Two = Duty_Cycle_Control(Increment, PCA9531_R_WR, Duty_Cycle_R_Two); // "+" Red (Key 3)
			if (Buffer3[0] == 0xEF) Duty_Cycle_G_Two = Duty_Cycle_Control(Decrement, PCA9531_G_WR, Duty_Cycle_G_Two); // "-" Green (Key 5)
			if (Buffer3[0] == 0xDF) Duty_Cycle_G_Two = Duty_Cycle_Control(Increment, PCA9531_G_WR, Duty_Cycle_G_Two); // "+" Green (Key 6)
			if (Buffer3[0] == 0x7F) Duty_Cycle_B_Two = Duty_Cycle_Control(Decrement, PCA9531_B_WR, Duty_Cycle_B_Two); // "-" Blue (Key 8)
			if (Buffer3[1] == 0xFE) Duty_Cycle_B_Two = Duty_Cycle_Control(Increment, PCA9531_B_WR, Duty_Cycle_B_Two); // "+" Blue (Key 9)
			if (Buffer3[1] == 0xFD & Speed_Two > 0) 
			{
				Speed_Two--;
			}
			if (Buffer3[1] == 0xF7 & Speed_Two < 255) 
			{
				Speed_Two++;
			}
			Speed_Prog_On = 0;
			GPIO_Polling_On = 0;						// Disable PCA9555 GPIO Polling option	
		}
		Buffer3[1] = 0xFF;
		Message1.address 	= PCA9531_M_WR;		// PCA9531 Misc to indicate backlight programming mode 
		Message1.nrBytes 	= 2;              	
		Buffer1[0]			= 0x15;					// subaddress = 0x15
		Buffer1[1] 			= 0x00;					// LD6 off --> Pattern 2 programming left
		I2C_Write(&Message1);
	}
	
	if (Buffer3[0] == 0xFB)							// Pattern 3 selected - Key 3 pushed		
	{
		Buffer3[0] = 0xFF;							// Clear Key 3 pushed
		Message1.address 	= PCA9531_M_WR;		// PCA9531 Misc to indicate backlight programming mode 
		Message1.nrBytes 	= 2;              	
		Buffer1[0]			= 0x15;					// subaddress = 0x15
		Buffer1[1] 			= 0x10;					// LD7 on --> Pattern 3 programming active
		I2C_Write(&Message1);
		
		while (Buffer3[1]!=0xDF)					// Loop as long as END button not pushed (Fun pattern 1 programming active)
  		{ 	                                        
			Buffer3[1] = 0xFF;
			GPIO_Interrupt_Handler();  			// Check if an action on pushbutton happened
			GPIO_Polling_On = 1;						// Enable PCA9555 polling option (see GPIO_Interrupt_Handler function)
			Fun_Pattern_Display(Duty_Cycle_R_Three, Duty_Cycle_G_Three, Duty_Cycle_B_Three, Speed_Three);	
			if (Buffer3[0] == 0xFD) Duty_Cycle_R_Three = Duty_Cycle_Control(Decrement, PCA9531_R_WR, Duty_Cycle_R_Three); // "-" Red (Key 2)
			if (Buffer3[0] == 0xFB) Duty_Cycle_R_Three = Duty_Cycle_Control(Increment, PCA9531_R_WR, Duty_Cycle_R_Three); // "+" Red (Key 3)
			if (Buffer3[0] == 0xEF) Duty_Cycle_G_Three = Duty_Cycle_Control(Decrement, PCA9531_G_WR, Duty_Cycle_G_Three); // "-" Green (Key 5)
			if (Buffer3[0] == 0xDF) Duty_Cycle_G_Three = Duty_Cycle_Control(Increment, PCA9531_G_WR, Duty_Cycle_G_Three); // "+" Green (Key 6)
			if (Buffer3[0] == 0x7F) Duty_Cycle_B_Three = Duty_Cycle_Control(Decrement, PCA9531_B_WR, Duty_Cycle_B_Three); // "-" Blue (Key 8)
			if (Buffer3[1] == 0xFE) Duty_Cycle_B_Three = Duty_Cycle_Control(Increment, PCA9531_B_WR, Duty_Cycle_B_Three); // "+" Blue (Key 9)
			if (Buffer3[1] == 0xFD & Speed_Three > 0) 
			{
				Speed_Three--;
			}
			if (Buffer3[1] == 0xF7 & Speed_Three < 255) 
			{
				Speed_Three++;
			}
			Speed_Prog_On = 0;
			GPIO_Polling_On = 0;						// Disable PCA9555 GPIO Polling option	
		} // end programming pattern 3 (END pushed and detected)
		Buffer3[1] = 0xFF;
		Message1.address 	= PCA9531_M_WR;		// PCA9531 Misc to indicate backlight programming mode 
		Message1.nrBytes 	= 2;              
		Buffer1[0]			= 0x15;					// subaddress = 0x15
		Buffer1[1] 			= 0x00;					// LD7 off --> Pattern 1 programming left
		I2C_Write(&Message1);

	} // end if
	Message1.address 	= PCA9531_R_WR;		// PCA9531 Red
	Message1.nrBytes 	= 3; 						
	Buffer1[0] 			= 0x15;					// subaddress = 15
	Buffer1[1] 			= 0x00;					// all Red LED's off
	Buffer1[2] 			= 0x00;					// all Red LED's off	
	I2C_Write(&Message1);
	Message1.address 	= PCA9531_G_WR;		// PCA9531 all Green LED's off 
	I2C_Write(&Message1);
	Message1.address 	= PCA9531_B_WR;		// PCA9531 all Blue LED's off 
	I2C_Write(&Message1);
	Buffer3[1] = 0xFF;							// Clear Key END pushed		
}


//****************************************************************************
// Function emulating a Battery Discharge
// Pushing Key 3 discharges the battery (level can be seen with LD5 to LD8
// Pushing 6 resets the emulation (battery fully charged again
//****************************************************************************


void Battery_Status (void)
{
	int Battery_Level = 0xFF;
	
	Buffer3[0] 			= 0xFF;							// Clear Key 1 pushed
	Message1.address 	= PCA9531_M_WR;				// PCA9531 Misc  
	Message1.nrBytes 	= 7;
	Buffer1[0]			= 0x11;							// subaddress = 0x01
	Buffer1[1]			= 0x97;							// Blinking rate              	
	Buffer1[2]			= 0xF0;							// High Duty Cycle when Battery charge > 50%
	Buffer1[3]		  	= 0x97;							// default prescaler pwm1 = 1 Hz
   Buffer1[4]		  	= 0x08;							// default duty cycle for pwm1 = 50%
	Buffer1[5] 			= 0x55;							// LD5 to LD8 on --> Indicate battery fully charged
	Buffer1[6]			= 0x32;							// RG LED Green blinking at BR0 
	I2C_Write(&Message1);
	while (Buffer3[1]!=0xDF)							// Loop as long as END button not pushed (Fun pattern 2 programming active)
  	{ 
  		InsertDelay(150);
		Buffer3[1] = 0xFF;
		GPIO_Interrupt_Handler();  								// Check if an action on pushbutton happened
		GPIO_Polling_On = 1;											// Enable PCA9555 polling option (see GPIO_Interrupt_Handler function)
		if (Buffer3[0] == 0xFB)										// Key 3 pushed - Battery is discharging when Key 3 pushed (continuous)
		{
			if (Battery_Level != 0x00) Battery_Level--;
			if (Battery_Level == 0xC0)
			{
				Message1.address 	= PCA9531_M_WR;				// PCA9531 Misc 
				Message1.nrBytes 	= 2;              	
				Buffer1[0]			= 0x15;							// subaddress = 0x05
				Buffer1[1] 			= 0x54;							// LD5 now off
				I2C_Write(&Message1);
			}
			if (Battery_Level == 0x80)
			{
				Message1.address 	= PCA9531_M_WR;				// PCA9531 Misc  
				Message1.nrBytes 	= 6;              	
				Buffer1[0]			= 0x12;							// subaddress = 0x02
				Buffer1[1]			= 0x80;							// RG (Orange) LED shorter duty cycle
				Buffer1[2]		  	= 0x97;							// default prescaler pwm1 = 1 Hz
   			Buffer1[3]		  	= 0x08;							// default duty cycle for pwm1 = 50%
				Buffer1[4] 			= 0x50;							// LD5 and LD6 now off
				Buffer1[5]			= 0x3A;							// RG LED Green and Red blinking at BR0 (Orange)
				I2C_Write(&Message1);
			}
			if (Battery_Level == 0x40)
			{
				Message1.address 	= PCA9531_M_WR;				// PCA9531 Misc 
				Message1.nrBytes 	= 6;              	
				Buffer1[0]			= 0x12;							// subaddress = 0x02
				Buffer1[1]			= 0x10;							// RG (Red only) LED even shorter duty cycle
				Buffer1[2]		  	= 0x97;							// default prescaler pwm1 = 1 Hz
   			Buffer1[3]		  	= 0x08;							// default duty cycle for pwm1 = 50%
				Buffer1[4] 			= 0x40;							// LD5, LD6 and LD7 now off
				Buffer1[5]			= 0x38;							// RG LED Green and Red blinking at BR0 
				I2C_Write(&Message1);
			}
			if (Battery_Level == 0x00)
			{
				Message1.address 	= PCA9531_M_WR;				// PCA9531 Misc 
				Message1.nrBytes 	= 6;              			
				Buffer1[0]			= 0x12;							// subaddress = 0x02
				Buffer1[1]			= 0x01;							// Duty Cycle = 0x01 --> Red LED actually almost off
				Buffer1[2]		  	= 0x97;							// default prescaler pwm1 = 1 Hz
   			Buffer1[3]		  	= 0x08;							// default duty cycle for pwm1 = 50%
				Buffer1[4] 			= 0x00;							// LD5, LD6, LD7 and LD8 now off
				Buffer1[5]			= 0x38;							// RG LED Green and Red blinking at BR0
				I2C_Write(&Message1);                  	
			}	
		}
		if (Buffer3[0] == 0xDF)										// Reset the simulation and recharge completly the battery (Key 6 pushed)
		{
			
			Battery_Level = 0xFF;
			Message1.address 	= PCA9531_M_WR;					// PCA9531 Misc  
			Message1.nrBytes 	= 6;              	       	
			Buffer1[0]			= 0x12;								// subaddress = 0x02
			Buffer1[1]			= Battery_Level - 0x10;			// High Duty Cycle when Battery charge > 50%
			Buffer1[2]		  	= 0x97;								// default prescaler pwm1 = 1 Hz
   		Buffer1[3]		  	= 0x08;								// default duty cycle for pwm1 = 50%
			Buffer1[4] 			= 0x55;								// LD5 to LD8 on --> Indicate battery fully charged
			Buffer1[5]			= 0x32;								// RG LED Green blinking at BR0 
			I2C_Write(&Message1);
		}
		Buffer3[0] = 0xFF;											// Clear Key 3 pushed		
	}
	GPIO_Polling_On 	= 0;										// Disable PCA9555 polling option (see GPIO_Interrupt_Handler function)
	Buffer3[1] 			= 0xFF;
	Message1.address 	= PCA9531_M_WR;					// PCA9531 Misc  
	Message1.nrBytes 	= 3;
	Buffer1[0]			= 0x15;
	Buffer1[1] 			= 0x00;								// LD5 to LD8 off
	Buffer1[2]			= 0x30;
	I2C_Write(&Message1);
}



//****************************************************************************
// Auto demo mode
// Reset only allows leaving this mode
//****************************************************************************

void Auto_Demo(void)
{
	int i;
	int j;
	int k;
	
	
	Message1.buf     = Buffer1;
	Message1.nrBytes = 7;
	
	Message1.address = PCA9531_R_WR;
	Buffer1[0]		  = 0x11;			// autoincrement + register 1
	Buffer1[1]		  = 0x00;			// default prescaler pwm0
  	Buffer1[2]		  = 0x6B;			// default duty cycle for pwm0
  	Buffer1[3]		  = 0x00;			// default prescaler pwm1
  	Buffer1[4]		  = 0x01;			// default duty cycle for pwm1
 	Buffer1[5]		  = 0x00;			// Green RGB LED's = off
  	Buffer1[6]		  = 0x00;			// Green RGB LED's = off
  	I2C_Write(&Message1);
  	Message1.address = PCA9531_G_WR;
	Buffer1[0]		  = 0x11;			// autoincrement + register 1
	Buffer1[1]		  = 0x00;			// default prescaler pwm0
  	Buffer1[2]		  = 0x01;			// default duty cycle for pwm0
  	Buffer1[3]		  = 0x00;			// default prescaler pwm1
  	Buffer1[4]		  = 0x6B;			// default duty cycle for pwm1
  	Buffer1[5]		  = 0x00;			// Green RGB LED's = off
  	Buffer1[6]		  = 0x00;			// Green RGB LED's = off
  	I2C_Write(&Message1);
  	Message1.address = PCA9531_B_WR;
	Buffer1[0]		  = 0x11;			// autoincrement + register 1
	Buffer1[1]		  = 0x00;			// default prescaler pwm0
  	Buffer1[2]		  = 0x25;			// default duty cycle for pwm0
  	Buffer1[3]		  = 0x00;			// default prescaler pwm1
  	Buffer1[4]		  = 0x25;			// default duty cycle for pwm1
  	Buffer1[5]		  = 0x00;			// Green RGB LED's = off
  	Buffer1[6]		  = 0x00;			// Green RGB LED's = off
   I2C_Write(&Message1); 
    
   Message1.nrBytes = 3;
   Buffer1[0]		  = 0x15;	
   		
	// Animation 1
	for (i = 0; i < 3; i++)				
	{
		Buffer1[1]		  = 0xEE;		// LD13 and 15 @ BR0 - LD14 and 16 @ BR1
   	Buffer1[2]		  = 0xEE;		// LD17 and 19 @ BR0 - LD18 and 20 @ BR1
   	Write_RGB_Controller();
   	InsertBigDelay();	 			
		Buffer1[1]		  = 0xBB;		// LD13 and 15 @ BR1 - LD14 and 16 @ BR0			
   	Buffer1[2]		  = 0xBB;		// LD17 and 19 @ BR1 - LD18 and 20 @ BR0
   	Write_RGB_Controller();
   	InsertBigDelay();	   
   }
   
   // Animation 2
   Buffer1[1]		  = 0xAA;			// LD13-16 @ BR0			
   Buffer1[2]		  = 0xAA;			// LD17-20 @ BR0
   Write_RGB_Controller();
   InsertBigDelay();	  
   Buffer1[1]		  = 0xAB;			// LD13 @ BR1 - LD14-16 @ BR0			
   Buffer1[2]		  = 0xAA;			// LD17-20 @ BR0
   Write_RGB_Controller();
   InsertBigDelay();	   
   Buffer1[1]		  = 0xAE;			// LD14 @ BR1 - LD13,14,16 @ BR0			
   Buffer1[2]		  = 0xAA;			// LD17-20 @ BR0
   Write_RGB_Controller();
   InsertBigDelay();	
   Buffer1[1]		  = 0xBA;			// LD15 @ BR1 - LD13,14,16 @ BR0			
   Buffer1[2]		  = 0xAA;			// LD17-20 @ BR0
   Write_RGB_Controller();
   InsertBigDelay();	 
   Buffer1[1]		  = 0xEA;			// LD16 @ BR1 - LD13-15 @ BR0			
   Buffer1[2]		  = 0xAA;			// LD17-20 @ BR0
   Write_RGB_Controller();
   InsertBigDelay();	 
   Buffer1[1]		  = 0xAA;			// LD13-16 @ BR0			
   Buffer1[2]		  = 0xAB;			// LD17 @ BR1 - LD18-20 @ BR0
   Write_RGB_Controller();
   InsertBigDelay();	
   Buffer1[1]		  = 0xAA;			// LD13-16 @ BR0			
   Buffer1[2]		  = 0xAE;			// LD18 @ BR1 - LD17,19,20 @ BR0
   Write_RGB_Controller();
   InsertBigDelay();	
   Buffer1[1]		  = 0xAA;			// LD13-16 @ BR0			
   Buffer1[2]		  = 0xBA;			// LD19 @ BR1 - LD17,18,20 @ BR0
   Write_RGB_Controller();
   InsertBigDelay();	
   Buffer1[1]		  = 0xAA;			// LD13-16 @ BR0			
   Buffer1[2]		  = 0xEA;			// LD18 @ BR1 - LD17,19,20 @ BR0
   Write_RGB_Controller();
   InsertBigDelay();
   Buffer1[1]		  = 0xAA;			// LD13-16 @ BR0			
   Buffer1[2]		  = 0xAA;			// LD17-20 @ BR0
   Write_RGB_Controller();
   InsertBigDelay();	  
   
   // Animation 3
   for (i = 0; i < 3; i++)
	{
   	Buffer1[1]		  = 0xAB;		// LD13@BR1, LD14-15-16@BR0			
   	Buffer1[2]		  = 0xAB;		// LD17@BR1, LD18-19-20@BR0
   	Write_RGB_Controller(); 
   	InsertBigDelay();	
   	Buffer1[1]		  = 0xAE;		// LD14@BR1, LD13-15-16@BR0			
   	Buffer1[2]		  = 0xAE;		// LD18@BR1, LD17-19-20@BR0
   	Write_RGB_Controller();
   	InsertBigDelay();
   	Buffer1[1]		  = 0xBA;		// LD15@BR1, LD13-14-16@BR0			
   	Buffer1[2]		  = 0xBA;		// LD19@BR1, LD17-18-20@BR0
   	Write_RGB_Controller();
   	InsertBigDelay();
   	Buffer1[1]		  = 0xEA;		// LD16@BR1, LD13-14-15@BR0			
   	Buffer1[2]		  = 0xEA;		// LD20@BR1, LD17-18-19@BR0
   	Write_RGB_Controller();
   	InsertBigDelay();
   }
   
   // Animation 4
   Buffer1[1]		  = 0x00;			// LD13-16 		= off			
   Buffer1[2]		  = 0x00;			// LD17-20 		= off
   Write_RGB_Controller();
   for (i = 0; i < 3; i++)
	{
   	Message1.address = PCA9531_R_WR;
   	Buffer1[1]		  = 0x41;			// LD13,LD16 	= red			
   	Buffer1[2]		  = 0x10;			// LD19	 		= red
   	I2C_Write(&Message1); 
   	Message1.address = PCA9531_G_WR;
   	Buffer1[1]		  = 0x04;			// LD14		 	= green			
   	Buffer1[2]		  = 0x41;			// LD17,20 		= green
   	I2C_Write(&Message1); 
   	Message1.address = PCA9531_B_WR;
   	Buffer1[1]		  = 0x10;			// LD15		 	= blue			
   	Buffer1[2]		  = 0x04;			// LD18	 		= blue
   	I2C_Write(&Message1);
   	InsertBigDelay();
   	Message1.address = PCA9531_G_WR;
   	Buffer1[1]		  = 0x41;			// LD13,LD16 	= green			
   	Buffer1[2]		  = 0x10;			// LD19	 		= green
   	I2C_Write(&Message1);
   	Message1.address = PCA9531_B_WR;
   	Buffer1[1]		  = 0x04;			// LD14		 	= blue			
   	Buffer1[2]		  = 0x41;			// LD17,20 		= blue
   	I2C_Write(&Message1);
   	Message1.address = PCA9531_R_WR;
   	Buffer1[1]		  = 0x10;			// LD15		 	= red			
   	Buffer1[2]		  = 0x04;			// LD18	 		= red
   	I2C_Write(&Message1);
   	InsertBigDelay();
   	Message1.address = PCA9531_B_WR;
   	Buffer1[1]		  = 0x41;			// LD13,LD16 	= blue			
   	Buffer1[2]		  = 0x10;			// LD19	 		= blue
   	I2C_Write(&Message1);
   	Message1.address = PCA9531_R_WR;
   	Buffer1[1]		  = 0x04;			// LD14		 	= red			
   	Buffer1[2]		  = 0x41;			// LD17,20 		= red
   	I2C_Write(&Message1);
   	Message1.address = PCA9531_G_WR;
   	Buffer1[1]		  = 0x10;			// LD15		 	= green			
   	Buffer1[2]		  = 0x04;			// LD18	 		= green
   	I2C_Write(&Message1);
   	InsertBigDelay();
   }
   
   Message1.nrBytes = 7;
   
   Message1.address = PCA9531_R_WR;
	Buffer1[0]		  = 0x11;			// autoincrement + register 1
	Buffer1[1]		  = 0x00;			// default prescaler pwm0
   Buffer1[2]		  = 0x00;			// default duty cycle for pwm0
   Buffer1[3]		  = 0x00;			// default prescaler pwm1
   Buffer1[4]		  = 0x00;			// default duty cycle for pwm1
   Buffer1[5]		  = 0xAA;			// Green RGB LED's = BR0
   Buffer1[6]		  = 0xAA;			// Green RGB LED's = BR0
   I2C_Write(&Message1);
   Message1.address = PCA9531_G_WR;
	Buffer1[0]		  = 0x11;			// autoincrement + register 1
	Buffer1[1]		  = 0x00;			// default prescaler pwm0
   Buffer1[2]		  = 0x00;			// default duty cycle for pwm0
   Buffer1[3]		  = 0x00;			// default prescaler pwm1
   Buffer1[4]		  = 0x00;			// default duty cycle for pwm1
   Buffer1[5]		  = 0xAA;			// Green RGB LED's = BR0
   Buffer1[6]		  = 0xAA;			// Green RGB LED's = BR0
   I2C_Write(&Message1);
   Message1.address = PCA9531_B_WR;
	Buffer1[0]		  = 0x11;			// autoincrement + register 1
	Buffer1[1]		  = 0x00;			// default prescaler pwm0
   Buffer1[2]		  = 0x00;			// default duty cycle for pwm0
   Buffer1[3]		  = 0x00;			// default prescaler pwm1
   Buffer1[4]		  = 0x00;			// default duty cycle for pwm1
   Buffer1[5]		  = 0xAA;			// Green RGB LED's = BR0
   Buffer1[6]		  = 0xAA;			// Green RGB LED's = BR0
   I2C_Write(&Message1);
   
   Message1.nrBytes = 2;
   Buffer1[0]		  = 0x12;
   
   // Red only from min to max brightness
   Message1.address = PCA9531_R_WR;	
   for (i = 0x00; i < 0xFF; i++)		
   {
   	Buffer1[1] = i;
   	I2C_Write(&Message1);
   	InsertDelay(40);
   };
   Buffer1[1] = 0x00;					// No red
   I2C_Write(&Message1);
   
   // Green only from min to max brightness
   Message1.address = PCA9531_G_WR;
   for (j = 0x00; j < 0xFF; j++)		
   {
   	Buffer1[1] = j;
   	I2C_Write(&Message1);
   	InsertDelay(40);
  	};
  	Buffer1[1] = 0x00;					// No green
   I2C_Write(&Message1);
   
	// Blue only from min to max brightness
	Message1.address = PCA9531_B_WR;
	for (k = 0x00; k < 0xFF; k++)		
	{
		Buffer1[1] = k;
   	I2C_Write(&Message1); 
   	InsertDelay(40);
   };   
   Buffer1[1] = 0x00;					// No blue
   I2C_Write(&Message1);
   
   // Some color mixing 1
   Message1.address = PCA9531_R_WR;	// Program some red
   Buffer1[1] = 0x36;
   I2C_Write(&Message1);
   Message1.address = PCA9531_G_WR;	// Program some green
   Buffer1[1] = 0x2B;
   I2C_Write(&Message1);
   Message1.address = PCA9531_B_WR;
   for (k = 0x00; k < 0xFF; k++)		// Increase amount of blue
   {
   	Buffer1[1] = k;
   	I2C_Write(&Message1);
  	 	InsertDelay(40);	
  	};
   
   // Some color mixing 2
   Buffer1[1] = 0x0A;					// Program some blue
   I2C_Write(&Message1);
   Message1.address = PCA9531_G_WR;
   Buffer1[1] = 0x0A;					// Program some green
   I2C_Write(&Message1);
   Message1.address = PCA9531_R_WR;
   for (i = 0x00; i <0xFF; i++)		// Increase amount of red
   {
   	Buffer1[1] = i;
   	I2C_Write(&Message1);
  	 	InsertDelay(40);		
  	};
  	
  	// Some color mixing 3
  	Buffer1[1] = 0x10;					// Program some red
   I2C_Write(&Message1);
   Message1.address = PCA9531_B_WR;
  	Buffer1[1] = 0x0A;					// Program some blue
   I2C_Write(&Message1);   
   Message1.address = PCA9531_G_WR;
   for (j = 0x00; j < 0xFF; j++)		// Increase amount of green
   {
   	Buffer1[1] = j;
   	I2C_Write(&Message1);
  	 	InsertDelay(40);	
  	};
  	
  	// Some color mixing 4
  	Buffer1[1] = 0x00;						// No color
  	Message1.address = PCA9531_R_WR;
   I2C_Write(&Message1);
   Message1.address = PCA9531_G_WR;
   I2C_Write(&Message1);
   Message1.address = PCA9531_B_WR;
   I2C_Write(&Message1);
   
   Message1.address = PCA9531_R_WR;
   for (i = 0x00; i < 0xFF; i++)			// Increase amount of red		
   {
   	Buffer1[1] = i;					
   	I2C_Write(&Message1);
  	 	InsertDelay(40);	
  	};
  	Message1.address = PCA9531_G_WR;
  	for (j = 0x00; j < 0xFF; j++)			// Increase amount of green		
  	{
  		Buffer1[1] = j;							
  		I2C_Write(&Message1);
  	 	InsertDelay(40);
  	};
  	Buffer1[1] = 0x00;						// Remove Green
  	I2C_Write(&Message1);
  	Message1.address = PCA9531_B_WR;
  	for (k = 0x00; k < 0xFF; k++)			// Increase amount of blue		
   {
   	Buffer1[1] = k;							
   	I2C_Write(&Message1);
  		InsertDelay(40); 		
  	};
  	Message1.address = PCA9531_R_WR;
  	Buffer1[1] = 0x00;						// Remove Red
  	I2C_Write(&Message1);
  	Message1.address = PCA9531_G_WR;
  	for (j = 0x00; j < 0xFF; j++)			// Increase amount of green		
  	{
  		Buffer1[1] = j;							
  		I2C_Write(&Message1);
  	 	InsertDelay(40);
  	};
  	Buffer1[1] = 0x00;						// Remove Green
  	I2C_Write(&Message1);
  	Message1.address = PCA9531_R_WR;
   for (i = 0x00; i < 0xFF; i++)			// Increase amount of red		
   {
   	Buffer1[1] = i;					
   	I2C_Write(&Message1);
  	 	InsertDelay(40);	
  	};
  	Buffer1[1] = 0x00;						// Remove Red
  	I2C_Write(&Message1);
  	Message1.address = PCA9531_G_WR;
  	Buffer1[1] = 0xFF;						// Max Green
  	I2C_Write(&Message1);
  	Message1.address = PCA9531_B_WR;
  	for (k = 0x00; k < 0xFF; k++)			// Increase amount of blue		
   {
   	Buffer1[1] = k;							
   	I2C_Write(&Message1);
  		InsertDelay(40); 		
  	};
  	Buffer1[1] = 0x00;						// Remove Blue
  	I2C_Write(&Message1);
  	Message1.address = PCA9531_R_WR;
   for (i = 0x00; i < 0xFF; i++)			// Increase amount of red		
   {
   	Buffer1[1] = i;					
   	I2C_Write(&Message1);
  	 	InsertDelay(40);	
  	};
  	Message1.address = PCA9531_G_WR;
  	for (j = 0x00; j < 0xFF; j++)			// Increase amount of green		
  	{
  		Buffer1[1] = j;							
  		I2C_Write(&Message1);
  	 	InsertDelay(40);
  	};
}




// END OF THE I2C ROUTINES //




