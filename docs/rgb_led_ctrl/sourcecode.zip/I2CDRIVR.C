//*************************************************************************
//
//                  P H I L I P S   P R O P R I E T A R Y
//
//           COPYRIGHT (c)   2003 BY PHILIPS SEMICONDUCTORS
//                     --  ALL RIGHTS RESERVED  --
//
// File Name:	i2cdriver.c
// Created:		June 2, 2003
// Modified:	June 10, 2003
// Revision: 	1.00
//
//*************************************************************************


#include "i2cexprt.h"
#include "i2cdrivr.h"
#include <REG51RX.H>
#include "PCA9564sys.h"

static void NoInitErrorProc(void);

void (*masterProc)(void) = NoInitErrorProc;
void (*slaveProc)(void)  = NoInitErrorProc;

BYTE master;
BYTE intMask;

static void NoInitErrorProc(void)
/*  ***************************************************************************
    * Input(s)    : none.
    * Output(s)   : none.
    * Returns     : none.
    * Description : ERROR: Master or slave handler called while not initialized
    ***************************************************************************/
{
    PCA9564_Write(I2CCON, 0x40);
}

void MainStateHandler(void)
/**************************
 * Input(s)    : none.
 * Output(s)   : none.
 * Returns     : none.
 * Description : Main event handler for I2C.
 ***************************************************************************/
{
    if (master)
        masterProc();	// Master Mode
    else
        slaveProc();		// Slave Mode
}

void I2C_Interrupt(void) interrupt 5
/* ***************************************************************************
 	* Input(s)    : none.
 	* Output(s)   : none.
 	* Returns     : none.
 	* Description : Interrupt handler for I2C.
 	***************************************************************************/
{
    MainStateHandler();
}

