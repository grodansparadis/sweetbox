// ======================================================
//                     16-dot-16 Library
//                     Header File
//
// Project Registration Number: MT2219 
// Date:    October 2007
//
// The following is an implementation of a 16-dot-16 to and 
// from format converter. It is used to receive and send
// data over the CAN network. 
// ======================================================

// #include "i16dot16.h"            // header file for the library
#include <math.h>                // Math operations


#ifndef I16DOT16_H
#define I16DOT16_H

#define SCALING  65535.0
  
typedef struct {
  long whole;
  unsigned long frac;
}i16dot16;

typedef union{
  int value;
  char bytes[2];
 }myInteger;

typedef union {
  unsigned int value;
  char bytes[2];
 }myUnsignedInteger;
 
 typedef union{
   long value;
   char bytes[4];
 }myLong;
 
 typedef union{
   unsigned long value;
   char bytes[4];
 }myUnsignedLong;
  
extern i16dot16 float_to_16_dot_16(float value);

extern float sixteen_dot_16_to_float(i16dot16 value);

extern int byte2integer (char MSB, char LSB);

extern unsigned int byte2unsignedInteger (char MSB, char LSB);

extern void integer2byte(int value, char* MSB, char* LSB);

extern void unsignedInteger2byte(unsigned int valuem, char* MSB, char* LSB);

extern long byte2long (char MSB, char msb, char lsb, char LSB);

extern unsigned long byte2unsignedLong (char MSB, char msb, char lsb, char LSB);

extern void long2byte(int value, char* MSB, char* msb,char* lsb, char* LSB);

extern void unsignedLong2byte(unsigned int value, char* MSB, char* msb,char* lsb, char* LSB);

#endif
