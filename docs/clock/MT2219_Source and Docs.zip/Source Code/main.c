// ======================================================
//                     CAN Servo Driver
//
// Project Registration Number: MT2219 
// Date:    October 2007
//
// The following is an implementation of a CAN Servo
// driver for a DC motor. It is implemented in a dsPIC
// 30F4011. It is configurable via CAN. It receives 
// commands via a CAN bus configured to work at 250Kbps.
// The QEI has implemented wrap-around so the motor can 
// count up to 256 x 64535 turns.
// The periphereal resources are used as follows:
//    1.- CAN:    The can module is used in Normal mode to 
//                receive commands and configure the PID
//                limits and gains.
//    2.- EEPROM: PID Configuration values are stored in
//                the chip's non-volatile EEPROM
//    3.- PWM:    One coupled PWM module (2 pins) is 
//                used to generate the signal for the 
//                H-Bridge.
//    4.- Timers: Timer 1 is used to implement a delay
//                function for flashing LEDs.
//                Timer 2 is used to clock the sampling
//                time of the control system
//    5.- QEI:    The Quadrature Encoder Interface is 
//                used to read the motor's encoder and
//                update the current position.
//    6.- INTS:   Interrupts are used to detect contact on the
//                motor limit switches RD0 and RD1 (Int1 and 
//                Int2).
//
// General Information:
// dsPIC :  30F4011
// FOSC  :  12 Mhz
// FCY   :   3 MHz
// TSamp :  0.00499199 Sec
// FSamp :  200.32 Hz
//
//  CAN Mesasge Protocol
//  FORMAT:     Only CAN Standard Data Frames are used
//  STRUCTURE:  [Device ID (5)][Command (6)] 
//  COMMANDS:       
//                  RXB0
//              0x00    Emergency Stop      filter 0
//              0x01    Desired Angle       filter 1
//                  RXB1
//              0x10    P Gain              filter 2
//              0x11    I Gain
//              0x12    D Gain
//              0x13    Max PWM
//              0x14    Min PWM
//              0x15    Total Degrees
//              0x16    Center Motor
//              0x17    Device ID
//              0x18    Controller Type
// ======================================================


// ======================================================
//    Inlcude Libraries
// ======================================================
#include <can.h>                // CAN module Library
#include "DataEEPROM.h"         // Data EEPROM library
#include "i16dot16.h"           // 16.16 library
#include <math.h>               // Math library
#include <pwm.h>                // PWM module library
#include <p30f4011.h>           // dsPIC30F4011
#include <ports.h>              // I/O Ports library
#include <qei.h>                // Quadrature Encoder lib
#include <stdio.h>              // Standard I/O library
#include <timer.h>              // Timer modules


// ======================================================
//    Macro Definitions
// ======================================================

// General dsPIC Config
#define ON_LED      _RB0


// PWM Macros

// Note that the Truth table for the TLE5205 is different
// from what common sense would say:
// IN1    IN2   OUT1    OUT2
//  L      L     H        L   CW
//  L      H     L        H   CCW
//  H      L     L        L   BRAKE
//  H      H     Z        Z   HIGH Z

#define IN1   _PEN2L
#define IN2   _PEN2H
#define PIN1  _TRISE2
#define PIN2  _TRISE3
#define OUT1  _RE2
#define OUT2  _RE3

// CW
#define PWM0ON      IN1 = 1; IN2 = 1;\
                    sw_dir = 0;    
// BRAKE
#define PWMOFF      IN1 = 0; IN2 = 0;\
                    OUT1 = 0;PIN1 = 1;\
                    OUT2 = 0;PIN2 = 0;\
                    delay_ms(1);  
// CCW              
#define PWM1ON      IN1 = 1; IN2 = 0;\
                    OUT2=0; PIN2 = 1;\
                    sw_dir = 1;           
                    

// ======================================================
//    Constants
// ======================================================
#define SAMPLE_TIME     0.00499199


// ======================================================
//    Configuration Variables
// ======================================================

// Motor values
float TOTDEGREES;

// PWM
unsigned int PWM_LOW;
unsigned int PWM_HI;


// EEPROM Row 00 @ 7FFC00 
//  | P | I | D | TOTDEGREES|  8 bytes ea
//  | PWM_HI | PWM_LOW |   2,2 bytes
//  | Device ID | Controller Type 1,1 bytes
char pid_config [32];


// CAN Device ID [1-31]
char DEVICE_ID;

// Controller Type
// PID Type: 1->A, 2->B, 3->C (Allen Bradley)
char CONTROLLER_TYPE;   
// 
// =======================================================
//    Global Variable Declarations
// =======================================================

// CAN comms variables 
  unsigned char data_msg0 [8] = {0};
  unsigned char data_msg1 [8] = {0};
  unsigned char id_lo0=0,id_hi0=0, id_lo1=0, id_hi1=0;
  unsigned char sw_rx0 = 0, sw_rx1 = 0; 
  
// Motor variables
  unsigned char sw_dir = 0,sw_calibrate=0;
  unsigned long tot_run = 0;
  float angle_ratio = 0.0;
  unsigned int PWM_val =0, PWM_dif=0;
  int ct_turns = 0;
  
  
// PID varialbes
  // Declare the PID Data structure
  typedef struct {
    // PID Gains
    float Kp;     // P Gain
    float Ki;     // I Gain
    float Kd;     // D Gain
    
    // PID Constants
    float A_pid;  // Kp + TKi + Kd/T
    float B_pid;  // Kp + 2Kd/T
    float C_pid;  // Kd/T
    float D_pid;  // Kp + Kd/T
    float E_pid;  // TKi
    
    // PID Operation variables
    float y_c;    // y_c[k] -> y commanded
    float y_m;    // y_m[k] -> y measured
    float u_k;    // u[k]   -> output at time k
    float e_k;    // e[k]   -> error at time k
    
    // PID History
    float u_km1;  // u[k-1] -> output at time k-1
    float e_km1;  // e[k-1] -> error at time k-1
    float e_km2;  // e[k-2] -> error at time k-2
    float y_mkm1; // y_m[k-1] -> y measured at time k-1
    float y_mkm2; // y_m[k-2] -> y measured at time k-2
    
  }PIDStruct;
  
  PIDStruct thePID;
  
 

// =======================================================
// Function Declarations
// =======================================================

void delay_ms (unsigned int tm_delay){
  TMR1 = 0;
  while (TMR1 < tm_delay); 
}  

void readConfig(void){
  int temp;
  i16dot16 stored;
  
  //Read address 0x7FFC00 and place the result into array pid_config
  temp = ReadEE(0x7F,0xFC00,&pid_config[0], ROW);
  
  // Convert the EEPROM read values to the usable values
  
  // P
  stored.whole = byte2integer(pid_config[0],pid_config[1]);
  stored.frac  = byte2unsignedInteger(pid_config[2],pid_config[3]);
  thePID.Kp = sixteen_dot_16_to_float(stored);
  
  // I
  stored.whole = byte2integer(pid_config[4],pid_config[5]);
  stored.frac  = byte2unsignedInteger(pid_config[6],pid_config[7]);
  thePID.Ki = sixteen_dot_16_to_float(stored);
  
  // D
  stored.whole = byte2integer(pid_config[8],pid_config[9]);
  stored.frac  = byte2unsignedInteger(pid_config[10],pid_config[11]);
  thePID.Kd = sixteen_dot_16_to_float(stored);
  
  // PWM Limits
  PWM_HI  = byte2integer(pid_config[12],pid_config[13]);
  PWM_LOW = byte2integer(pid_config[14],pid_config[15]); 
  
  // Total Degrees
  stored.whole = byte2integer(pid_config[16],pid_config[17]);
  stored.frac  = byte2unsignedInteger(pid_config[18],pid_config[19]);
  TOTDEGREES = sixteen_dot_16_to_float(stored);
  
  // Controller Type
  CONTROLLER_TYPE = pid_config[20];
  
  // Device ID
  DEVICE_ID = pid_config[21];
  
}      
void dsPICInit(void){
  // Configure T1 for the delay rutines
  OpenTimer1(T1_ON &          // Turn on Timer 1
             T1_IDLE_STOP &   // Stop operation on idle
             T1_GATE_OFF &    // Gate time accumulation disabled
             T1_PS_1_256 &    // Set prescaler 1:256
             T1_SYNC_EXT_OFF &// Disable external sync bit
             T1_SOURCE_INT,   // Use the 12Mhz External clock 
             0xFFFF);         // Use the full 16 bits
 
  // Disable T1 interrupts
  DisableIntT1;
  
  // Configure T2 for the control action
  ConfigIntTimer2 (T2_INT_PRIOR_5 &  // Highest Prority Ctrl action
                   T2_INT_OFF);      // Turn off the interrupts until
                                     // boot sequence has finished
 
  OpenTimer2(T2_ON &          // Turn on Timer 2
             T2_IDLE_STOP &   // Stop operation on idle
             T2_GATE_OFF &    // Gate time accumulation disabled
             T2_PS_1_64 &     // Set prescaler 1:64
             T2_SOURCE_INT,   // Use the 12Mhz External clock 
             0x00EA);         // Interrupt when timer reaches 234
                                    
  
  
  // Configure I/O Ports
  ADPCFG = 0xFFFF;       // Disable the A/D pins 1-8
  TRISB = 0xFFFF;
  TRISBbits.TRISB0 = 0;  // Signal LED
  
  // Disable Interrupt Nesting (Errata 80215F)
  INTCON1bits.NSTDIS = 1;
  
  // Configure the Interrupts for the limit switches
  ConfigINT1(RISING_EDGE_INT &          // Trigger on rising edge
             EXT_INT_ENABLE &           // Enable Int 1
             EXT_INT_PRI_5);            // Highest priority
  
  ConfigINT2(RISING_EDGE_INT &          // Trigger on rising edge
             EXT_INT_ENABLE &           // Enable Int 2
             EXT_INT_PRI_5);            // Highest priority
             
  // flash the LED Boot sequence
  ON_LED = 1;
  delay_ms(5859);
  ON_LED = 0;
  delay_ms(5859);
  ON_LED = 1;
  delay_ms(5859);
  ON_LED = 0;
  delay_ms(5859);
  ON_LED = 1;
  
} 


  void PWMInit(void){
  
  // Disable PWM Interrupts
  ConfigIntMCPWM ( PWM_INT_DIS &
                   PWM_INT_PR0 &
                   PWM_FLTA_DIS_INT &
                   PWM_FLTA_INT_PR0);
                   
  // Configure the initial Duty Cycle to be 50% (i.e. Off)
  SetDCMCPWM (2,        // PWM Module 2
              0x02CA
              //0x06CA
              ,   // 0x0167 25% -- 50% 0x2CA
              0);       // Enable changes to duty cycle
              
  
  // Configure and enable the PWM module
  OpenMCPWM (0x0682,              // 1.8 Khz Frequency
             0,                   // SPTime of 0
             PWM_EN &             // Enalbe the PWM module
             PWM_IDLE_STOP &      // Stop when idle
             PWM_OP_SCALE1 &      // Postscale 1:1
             PWM_IPCLK_SCALE1 &   // Prescale 1:1
             PWM_MOD_FREE,        // Operate in Free Mode
             PWM_MOD2_COMP &      // Module 2 in independent
             PWM_PDIS1H &         // Disable PWM 1 and 3
             PWM_PDIS1L &         
             PWM_PDIS3H &         
             PWM_PDIS3L &
             PWM_PEN2H &          // Enable PWM 2 H
             PWM_PEN2L,           // Enable PWM 1 L
             PWM_SEVOPS1 &        // Special Event prescale
             PWM_OSYNC_PWM &      // Output overide PWM
             PWM_UEN);            // Enable updates
             
  
  // Compute the width of the PWM Action           
  PWM_dif = PWM_HI-PWM_LOW; 
}

void QEIInit(void){
  ConfigIntQEI (QEI_INT_ENABLE &  // Enable interrupts
                QEI_INT_PRI_5);   // Set Priority to 5
                
  POSCNT = 0;                     // Set Current Position to 0
  MAXCNT = 0xFFFF;                // Use the full 16bit counter
  
  OpenQEI (QEI_DIR_SEL_CNTRL &    // UPDN bit decides direction count
           QEI_INT_CLK &          // Use FCY for clocking
           QEI_INDEX_RESET_DISABLE &
           QEI_CLK_PRESCALE_1 &    // 1:1 Prescale
           QEI_GATED_ACC_DISABLE &  
           QEI_NORMAL_IO &        // QEI Control state of IO pin
           QEI_INPUTS_NOSWAP &    // Channels A and B are not swapped
           QEI_MODE_x2_MATCH &    // X2 mode with counter reset by match
           QEI_UP_COUNT &         // Read only for this mode
           QEI_IDLE_STOP,         // Stop in idle operation
           MATCH_INDEX_INPUT_PHASEA &
           QEI_QE_CLK_DIVIDE_1_16 &// Filter 1:16 divider 
           QEI_QE_OUT_ENABLE);    // Enable the input digital filter
  
} 

void CANInit(void)
{
  // Set request for configuration mode
  CAN1SetOperationMode(CAN_IDLE_CON  &  
                       CAN_MASTERCLOCK_0 & 
                       CAN_REQ_OPERMODE_CONFIG &
                       CAN_CAPTURE_DIS);
  while(C1CTRLbits.OPMODE <=3);
  
  // Load configuration register
  CAN1Initialize(CAN_SYNC_JUMP_WIDTH1 &  
                 CAN_BAUD_PRE_SCALE(1), 
                 CAN_WAKEUP_BY_FILTER_DIS  & 
                 CAN_PHASE_SEG2_TQ(3) &  
                 CAN_PHASE_SEG1_TQ(4) & 
                 CAN_PROPAGATIONTIME_SEG_TQ(4) &  
                 CAN_SEG2_FREE_PROG &  
                 CAN_SAMPLE1TIME);
                 
  // Set interrupts
  ConfigIntCAN1(CAN_INDI_INVMESS_DIS &  
            CAN_INDI_WAK_DIS &
            CAN_INDI_ERR_DIS &    
            CAN_INDI_TXB2_DIS &  
            CAN_INDI_TXB1_DIS &  
            CAN_INDI_TXB0_DIS & 
            CAN_INDI_RXB1_EN & 
            CAN_INDI_RXB0_EN ,
            CAN_INT_PRI_5 &   
            CAN_INT_ENABLE);
 
  // Set the RX mode
   CAN1SetRXMode(0,CAN_RXFUL_CLEAR & 
                   CAN_BUF0_DBLBUFFER_EN);
  
   CAN1SetRXMode(1,CAN_RXFUL_CLEAR);
   
  // Set the mask for RXB0
  CAN1SetMask(0,                    // Mask 0 Associated with RXB0
              CAN_MASK_SID(0x7FF) & // Check address and first bits of msg
              CAN_MATCH_FILTER_TYPE,// Enable Mask
              CAN_MASK_EID(0x7FF)); // Make the same EID
  
  // Set the mask for RXB1
  CAN1SetMask(1,                    // Mask 1 Associated with RXB1
              CAN_MASK_SID(0x7F0) & // Check address and first bits of msg
              CAN_MATCH_FILTER_TYPE,// Enable Mask
              CAN_MASK_EID(0x7F0)); // Make the same EID
  
              
  // Set filter 0: Emergecy Stop
  unsigned int req_filter = ((unsigned int)DEVICE_ID << 6);
  CAN1SetFilter(0,                  // Filter 0 associated RXBO
                CAN_FILTER_SID(req_filter) &
                CAN_RX_EID_DIS,     // Disable EID
                CAN_FILTER_EID(req_filter));
  
  // Set filter 1: Desired Angle
  req_filter = ((unsigned int)DEVICE_ID << 6) | 0x0001;
  CAN1SetFilter(1,                  // Filter 1 associated RXBO
                CAN_FILTER_SID(req_filter) &
                CAN_RX_EID_DIS,     // Disable EID
                CAN_FILTER_EID(req_filter));
                
  // Set filter 2: PID Config
  req_filter = ((unsigned int)DEVICE_ID << 6) | 0x0010;
  CAN1SetFilter(2,                  // Filter 2 associated RXB1
                CAN_FILTER_SID(req_filter) &
                CAN_RX_EID_DIS,     // Disable EID
                CAN_FILTER_EID(req_filter));
                
  // Set request for Normal mode
  CAN1SetOperationMode(CAN_IDLE_STOP & CAN_CAPTURE_DIS &
                       CAN_MASTERCLOCK_0 & 
                       CAN_REQ_OPERMODE_NOR);
  while(C1CTRLbits.OPMODE != 0);
}

void calibrateMotor(void){
  // Turn on PWM in direction 0
  PWM0ON;
  // Keep it on until it reached the limit switch
  while (sw_calibrate<1);
  // reset POSCNT
  POSCNT = 0;
  ct_turns =0;
  // Turn PWM on direction 1
  PWM1ON;
  // Keep it on until it reached the limit switch
  while (sw_calibrate<2);
  // Get the amount of ticks for total run
  tot_run = ct_turns*65535 + ReadQEI();
  
  // get the angle ratio
  angle_ratio = (float)(TOTDEGREES / tot_run);
  
}

void centerMotor(void){
  // caclulate the midpoint
  unsigned long mid_point = tot_run>>1;
  // set the PWM duty cycle to the lowest possible
  SetDCMCPWM( 2,0x02CA,0);
  
  
  if ((ct_turns*65535+ReadQEI())> mid_point){

    // keep it on until it reaches the midpoint
    while ((ct_turns*65535+ReadQEI()) > mid_point){
      // Turn on PWM in direction 0
      PWM0ON; 
    }
    // turn it off
    PWMOFF;
    //myPID.controlReference = (ticks2fract(mid_point));
    thePID.y_c = (float)(mid_point)*angle_ratio;
  }else{
    // keep it on until it reaches the midpoint
    while ((ct_turns*65535+ReadQEI()) <= mid_point){
      // Turn on PWM in direction 1
      PWM1ON; 
    }
    // turn it off
    PWMOFF;
    //myPID.controlReference = (ticks2fract(mid_point));
    thePID.y_c = (float)(mid_point)*angle_ratio;
  }
  
}

void myPIDInit (void){
  // initialize the constants  
  // A = Kp + TKi + Kd/T
  thePID.A_pid = thePID.Kp + SAMPLE_TIME*thePID.Ki + thePID.Kd/SAMPLE_TIME;
  // B = Kp + 2Kd/T
  thePID.B_pid = thePID.Kp + 2.0*thePID.Kd/SAMPLE_TIME;
  // C = Kd/T
  thePID.C_pid = thePID.Kd/SAMPLE_TIME;
  // D = Kp + Kd/T
  thePID.D_pid = thePID.Kp + thePID.Kd/SAMPLE_TIME;
  // E = TKi
  thePID.E_pid = thePID.Ki*SAMPLE_TIME;
  
  // set all the variables to zero
  thePID.u_k    = 0.0;
  thePID.u_km1  = 0.0;
  thePID.e_k    = 0.0;  
  thePID.e_km1  = 0.0;
  thePID.e_km2  = 0.0;
  thePID.y_c    = 0.0;  
  thePID.y_m    = 0.0;  
  
  // set the initial values for the controller
  thePID.y_c = (float)(ct_turns*65535 + ReadQEI())*angle_ratio;
  thePID.y_m = thePID.y_c;
  thePID.y_mkm1 = thePID.y_m;
  thePID.y_mkm2 = thePID.y_m;
}

void PIDconfig (char byte_rec, float value) {
  unsigned int sw_changed = 0;      
        
  // The 16.16 variable
  i16dot16 stored;
  
  // Accroding to the byte received, set the value        
  switch (byte_rec){
    
    case 0x10:        //P Gain
      // Assign the value
      thePID.Kp = value;  
      
      // A = Kp + TKi + Kd/T
      thePID.A_pid = thePID.Kp + SAMPLE_TIME*thePID.Ki + thePID.Kd/SAMPLE_TIME;
      // B = Kp + 2Kd/T
      thePID.B_pid = thePID.Kp + 2.0*thePID.Kd/SAMPLE_TIME;
      // D = Kp + Kd/T
      thePID.D_pid = thePID.Kp + thePID.Kd/SAMPLE_TIME;
      
      
      // update the pid_config array to stay consistent
      stored = float_to_16_dot_16(thePID.Kp);
      integer2byte(stored.whole,&pid_config[0],&pid_config[1]);
      unsignedInteger2byte(stored.frac,&pid_config[2],&pid_config[3]);        
      // Set the flag that a value was changed    
      sw_changed = 1;
      break;
      
    case 0x11:        //I Gain
      // set the gain value    
      thePID.Ki = value;
      // A = Kp + TKi + Kd/T
      thePID.A_pid = thePID.Kp + SAMPLE_TIME*thePID.Ki + thePID.Kd/SAMPLE_TIME;
      // E = TKi
      thePID.E_pid = thePID.Ki*SAMPLE_TIME;
  
      // update the pid_config array to stay consistent
      stored = float_to_16_dot_16(thePID.Ki);
      integer2byte(stored.whole,&pid_config[4],&pid_config[5]);
      unsignedInteger2byte(stored.frac,&pid_config[6],&pid_config[7]);        
      // set the flag that data has been changed    
      sw_changed = 1;
        break;
        
    case 0x12:      //D Gain
      thePID.Kd = value;
      // A = Kp + TKi + Kd/T
      thePID.A_pid = thePID.Kp + SAMPLE_TIME*thePID.Ki + thePID.Kd/SAMPLE_TIME;
      // B = Kp + 2Kd/T
      thePID.B_pid = thePID.Kp + 2.0*thePID.Kd/SAMPLE_TIME;
      // C = Kd/T
      thePID.C_pid = thePID.Kd/SAMPLE_TIME;
      // D = Kp + Kd/T
      thePID.D_pid = thePID.Kp + thePID.Kd/SAMPLE_TIME;
      
      // update the pid_config array to stay consistent
      stored = float_to_16_dot_16(thePID.Kd);
      integer2byte(stored.whole,&pid_config[8],&pid_config[9]);
      unsignedInteger2byte(stored.frac,&pid_config[10],&pid_config[11]);
      // set the flag that data has been changed    
      sw_changed = 1;
      break;
    
    case 0x13:        //Max PWM
        PWM_HI = (unsigned int)floorf(value);
        // update the pid_config array to stay consistent
        unsignedInteger2byte(PWM_HI,&pid_config[12],&pid_config[13]);
        // set the flag that data has been changed    
        sw_changed = 1;
        break;
        
    case 0x14:      //min PWM
        PWM_LOW = (unsigned int)floorf(value);    
        // update the pid_config array to stay consistent
        unsignedInteger2byte(PWM_LOW,&pid_config[14],&pid_config[15]);
        // set the flag that data has been changed    
        sw_changed = 1;
        break;
        
    case 0x15:      //Total Degrees
        TOTDEGREES = floorf(value);    
        // update the pid_config array to stay consistent
        stored = float_to_16_dot_16(TOTDEGREES);
        integer2byte(stored.whole,&pid_config[16],&pid_config[17]);
        unsignedInteger2byte(stored.frac,&pid_config[18],&pid_config[19]);
        // set the flag that data has been changed    
        sw_changed = 1;
        break;  

    case 0x17:      //Device ID
        DEVICE_ID = (char)floorf(value);    
        // update the pid_config array to stay consistent
        pid_config[21] = (char)floorf(value);
        // Reconfigure the filters in the CAN module
        CANInit();  
        // set the flag that data has been changed  
        sw_changed = 1;
        break;  

    case 0x18:      //Controller Type
        CONTROLLER_TYPE = (char)floorf(value);    
        // update the pid_config array to stay consistent
        pid_config[20] = (char)floorf(value);
        // set the flag that data has been changed    
        sw_changed = 1;
        break;  
    default :
        break;
    }// switch
    
    // if the configuration was changed
    if (sw_changed == 1) {
      // erase the EEPROM line before writting back to it
      EraseEE(0x7F, 0xFC00, ROW);
      
      // modify the EEPROM to store the changes
      WriteEE(&pid_config[0],0x7F,0XFC00, ROW);
    }// if changed

}// function

// =======================================================
// Interrupt Service Routines
// =======================================================
void __attribute__((__interrupt__, no_auto_psv)) _QEIInterrupt(void){
  
  if (ReadQEI() < 0x3FFF){
    ct_turns++;
  } else {
    ct_turns--;
  }
  IFS2bits.QEIIF =0;
}

void __attribute__((__interrupt__, no_auto_psv)) _C1Interrupt (void){
  
  // if the interrupt was for RXBO
  if (C1INTFbits.RX0IF == 1){
    // recieve the message
    CAN1ReceiveMessage(data_msg0,8,0);
    // decode the ID
    id_lo0 = (unsigned char) ((C1RX0SID>>2)  & 0x003F);
    //id_hi0 = (unsigned char) ((C1RX0SID>>10) & 0x0007);
    
    // clear the flags
    C1RX0CONbits.RXFUL = 0;
    C1INTFbits.RX0IF =0;
    IFS1bits.C1IF = 0;
    
    // let the main loop know a new data was received
    sw_rx0=1;
  }
  
  // if the interrupt was for RXB1 
  if (C1INTFbits.RX1IF == 1){
    // recieve the message
    CAN1ReceiveMessage(data_msg1,8,1);
    // decode the ID
    id_lo1 = (unsigned char) ((C1RX1SID>>2)  & 0x003F);
    //id_hi1 = (unsigned char) ((C1RX1SID>>10) & 0x0007);
    
    // clear the flags
    C1RX1CONbits.RXFUL = 0;
    C1INTFbits.RX1IF =0;
    IFS1bits.C1IF = 0;
    
    // let the main loop know a new data was received
    sw_rx1=1;
  }

  
  // Clear the flags for the interrupt
  C1INTF = C1INTF & 0x3F00;
}

void __attribute__((__interrupt__, no_auto_psv)) _INT1Interrupt(void){
  
  // if the limit switch was hit when going on dir 0
  if (sw_dir == 0) {
    // turn off the PWM
    PWMOFF;
    
    // if it was during calibration
    if (sw_calibrate < 2) {
      sw_calibrate ++;
    }
  }
  
  // clear the interrupt flag
  _INT1IF = 0;
}

void __attribute__((__interrupt__, no_auto_psv)) _INT2Interrupt(void){
  // if the limit switch was hit going on dir 1
  if (sw_dir == 1) {
    // turn off the PWM
    PWMOFF;
    
    // if it was during calibration
    if (sw_calibrate < 2) {
      sw_calibrate ++;
    }
  }
  
  // clear the interrupt flag
  _INT2IF = 0;
}

void __attribute__((__interrupt__, no_auto_psv)) _T2Interrupt(void){
  
  // Recall: PWM0ON decreases the tick count
  
  //update the measured Output
  
  switch (CONTROLLER_TYPE){
    case 1:
      // get the measured value
      thePID.y_m = (float)(ct_turns*65535 + ReadQEI())*angle_ratio;
      
      // update the errors
      thePID.e_km2 = thePID.e_km1;
      thePID.e_km1 = thePID.e_k;
      thePID.e_k = thePID.y_c - thePID.y_m;
      
      // Get the control action
      // u[k] = u[k-1] + e[k]*A + e[k-1]*B + e[k-2]*C
      thePID.u_k = thePID.u_km1 + thePID.e_k*thePID.A_pid - 
                   thePID.e_km1*thePID.B_pid + thePID.e_km2*thePID.C_pid;
      
    break;
    case 2:
      // update the measured values
      thePID.y_mkm2 = thePID.y_mkm1;
      thePID.y_mkm1 = thePID.y_m;
      thePID.y_m = (float)(ct_turns*65535 + ReadQEI())*angle_ratio;
      
      // get the error
      thePID.e_km1 = thePID.e_k;
      thePID.e_k = thePID.y_c - thePID.y_m;
      
      // Get the control action
      // u[k] = u[k-1] + Kp(e[k]-e[k-1]) +A(e[k]) - B(ym[k]-2ym[k-1]+ym[k-2])
      thePID.u_k = thePID.u_km1 + thePID.Kp*(thePID.e_k - thePID.e_km1) +
                   thePID.E_pid*thePID.e_k -
                   thePID.C_pid*(thePID.y_m - 2.0*thePID.y_mkm1 + thePID.y_mkm2);
    break;
    case 3:
      // update the measured values
      thePID.y_mkm2 = thePID.y_mkm1;
      thePID.y_mkm1 = thePID.y_m;
      thePID.y_m = (float)(ct_turns*65535 + ReadQEI())*angle_ratio;
      
      // get the error
      thePID.e_k = thePID.y_c - thePID.y_m;
      // Get the control action

      // u[k] = u[k-1] - ym[k]*D + ym[k-1]*B - ym[k-2]*C + e[k]*E
      thePID.u_k = thePID.u_km1 - thePID.y_m*thePID.D_pid +
                   thePID.y_mkm1*thePID.B_pid -
                   thePID.y_mkm2*thePID.C_pid + thePID.e_k*thePID.E_pid;
    break;
    default:
    break;
  } // switch
  
  if (_RD0 != 1 && _RD1 != 1){   
    if (thePID.u_k > 0.35) {
      // Clamping for the anti-windup
      if (((unsigned int)ceilf(thePID.u_k) + PWM_LOW) > PWM_HI) {
        thePID.u_k = (float)(PWM_dif);
      }
      PWM_val = PWM_HI - ((unsigned int)ceilf(thePID.u_k) + PWM_LOW);
      PWMOFF;
      SetDCMCPWM( 2,PWM_val,0);
      PWM1ON;
      sw_dir = 0;
    }else if (thePID.u_k < -0.35){
      // Clamping for the anti-windup
      if (((unsigned int)floorf(fabsf(thePID.u_k)) + PWM_LOW) > PWM_HI) {
        thePID.u_k = -1.0*(float)(PWM_dif);
      }
      PWM_val = PWM_HI - ((unsigned int)floorf(fabsf(thePID.u_k)) + PWM_LOW);
      PWMOFF;
      SetDCMCPWM( 2,PWM_val,0);
      PWM0ON;
      sw_dir = 1;
    }else{
      PWMOFF;
    }
  }
  
  // Update u[k-1]
  thePID.u_km1 = thePID.u_k;
  
  // Clear the interrupt flag
  _T2IF = 0;
}

// =======================================================
// Main body of the program
// =======================================================
int main (void){
  
  // Initialize the device

   dsPICInit(); 
  // Read the configuration from the eeprom
  readConfig();
  // Initialize the PWM 
  PWMInit();
  // Initialize the QEI
  QEIInit();
  // Initialize the CAN
  CANInit();

  PWMOFF;
  
  // Initialize the motor and the motor position
  calibrateMotor();
  centerMotor();
  
  // Enable Interrupts for T2 to start control action
  myPIDInit();
  EnableIntT2;

  
  i16dot16 tmp_theta, tmp_value;
  float pm_value;
  
  while (1){
    // if there is new data in RX0 
    if (sw_rx0 == 1){
      switch (id_lo0){
        case 0x00:           // Emergency stop. REQUIRES RESTART
          CloseMCPWM();
          break;
        case 0x01:           // Desired Angle (Set Point)
          tmp_theta.whole = byte2integer(data_msg0[0], data_msg0[1]);
          tmp_theta.frac  = byte2unsignedInteger(data_msg0[2], data_msg0[3]);
          thePID.y_c = (sixteen_dot_16_to_float(tmp_theta)); 
          if (thePID.y_c < 3.0) {thePID.y_c = 3.0;}
          if (thePID.y_c > (TOTDEGREES - 3.0)) {thePID.y_c = TOTDEGREES - 3.0;}

          break;
        default:
          break;
      } // switch (id_lo0)
      
      // clear the rx0 flag
      sw_rx0 = 0;
    }
     
    // if there is new data in RX1 and the id is 0x301 
    if (sw_rx1 == 1){
       switch (id_lo1){
        case 0x00:           // Emergency stop. REQUIRES RESTART
          CloseMCPWM();
          break;
        case 0x01:           // Desired Angle (Set Point)
          tmp_theta.whole = byte2integer(data_msg0[0], data_msg0[1]);
          tmp_theta.frac  = byte2unsignedInteger(data_msg0[2], data_msg0[3]);
          thePID.y_c = (sixteen_dot_16_to_float(tmp_theta)); 
          if (thePID.y_c < 3.0) {thePID.y_c = 3.0;}
          if (thePID.y_c > (TOTDEGREES - 3.0)) {thePID.y_c = TOTDEGREES - 3.0;}
          //myPID.controlReference = (angle2fract(thePID.y_c));
          break;
        case 0x10:          // P Gain
        case 0x11:          // I Gain
        case 0x12:          // D Gain
        case 0x13:          // MAX PWM
        case 0x14:          // Min PWM
        case 0x15:          // Tot Degrees
        case 0x17:          // Device ID
        case 0x18:          // Controller Type
          tmp_value.whole = byte2integer(data_msg1[0], data_msg1[1]);
          tmp_value.frac  = byte2unsignedInteger(data_msg1[2], data_msg1[3]);
          pm_value = sixteen_dot_16_to_float(tmp_value); 
          PIDconfig(id_lo1,pm_value);
          break;
        case 0x16:          // Center Motor
          centerMotor();
          break;
        default:
          break;  
      } // switch (id_lo1)         

      // clear the rx1 flag
      sw_rx1 = 0;
    }// if rx1    
  }// while
}// main
