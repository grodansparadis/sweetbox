// ======================================================
//                     16-dot-16 Library
//                     Source File
//
// Project Registration Number: MT2219 
// Date:    October 2007
//
// The following is an implementation of a 16-dot-16 to and 
// from format converter. It is used to receive and send
// data over the CAN network. 
// ======================================================

#include "i16dot16.h"            // header file for the library
#include <math.h>                // Math operations

i16dot16 float_to_16_dot_16(float value)
{
  float remove = 0.0;
  i16dot16 myout;
  myout.whole = (int) floorf(value); // get the whole part
  remove = value - (float)myout.whole;
  remove = remove*SCALING;
  myout.frac = (unsigned int) floorf(remove);
  return (myout);
}
float sixteen_dot_16_to_float(i16dot16 value)
{
  float temp, rem;

  temp = (float) value.whole;
  rem = ((float) value.frac) / SCALING;
  return(temp+rem);
}
int byte2integer (char MSB, char LSB){
  myInteger myout;
  myout.bytes[0] = LSB;
  myout.bytes[1] = MSB;
  return myout.value;
}
unsigned int byte2unsignedInteger (char MSB, char LSB){
  myUnsignedInteger myout;
  myout.bytes[0] = LSB;
  myout.bytes[1] = MSB;
  return myout.value;
}
void integer2byte(int value, char* MSB, char* LSB){
  myInteger myout;
  myout.value = value;
  *MSB = myout.bytes[1];
  *LSB = myout.bytes[0];
}
void unsignedInteger2byte(unsigned int value, char* MSB, char* LSB){
  myUnsignedInteger myout;
  myout.value = value;
  *MSB = myout.bytes[1];
  *LSB = myout.bytes[0];
}

long byte2long (char MSB, char msb, char lsb, char LSB){
  myLong myout;
  myout.bytes[0] = MSB;
  myout.bytes[1] = msb;
  myout.bytes[2] = lsb;
  myout.bytes[3] = LSB;
  return myout.value;
}

unsigned long byte2unsignedLong (char MSB, char msb, char lsb, char LSB){
  myUnsignedLong myout;
  myout.bytes[0] = MSB;
  myout.bytes[1] = msb;
  myout.bytes[2] = lsb;
  myout.bytes[3] = LSB;
  return myout.value;
}

void long2byte(int value, char* MSB, char* msb,char* lsb, char* LSB){
  myLong myout;
  myout.value = value;
  *MSB = myout.bytes[0];
  *msb = myout.bytes[1];
  *lsb = myout.bytes[2];
  *LSB = myout.bytes[3];
}
void unsignedLong2byte(unsigned int value, char* MSB, char* msb,char* lsb, char* LSB){
  myUnsignedLong myout;
  myout.value = value;
  *MSB = myout.bytes[0];
  *msb = myout.bytes[1];
  *lsb = myout.bytes[2];
  *LSB = myout.bytes[3];
}
