// dsPIC30f2010 MIDI Laser Show Galvanometer Controller
// Circuit Cellar MicroChip 16-bit Embedded Control Design Contest 2007 
// Project Registration Number MT2163 

/* Include files */
#include "ports.h"
#include "p30fxxxx.h"
#include "p30f2010.h"
#include "spi.h"
#include "math.h"
#include "uart.h"
#include "string.h"
#include "stdio.h"

/* Configuration Bits */
_FOSC(CSW_FSCM_OFF & XT_PLL8);                  // 8MHz Crystal with PLLx8
_FWDT(WDT_OFF);                                 // Watch dog Timer OFF         
_FBORPOR(PBOR_OFF & MCLR_EN);                   // Brown Out OFF, MCLR Enabled  
_FGS(CODE_PROT_OFF);                            // Code Protect OFF             

/* Main definitions */
#define XTFREQ          8000000         		//Crystal frequency 8mhz
#define PLLMODE         8               		//On-chip PLL setting
#define FCY             XTFREQ*PLLMODE/4        //Instruction Cycle Frequency

/* UART definitions */
#define BAUDRATE         57600                   //RS232 baud rate 57600
#define BRGVAL          ((FCY/BAUDRATE)/16)-1 
#define MIDIBAUD         31                     //MIDI baud rate 31250

/* LED anodes tied to VCC */
#define LEDon     0
#define LEDoff    1

/* Define one quadrant of a sine wave as a percentage of maximum */
#define Sin0     0 //sin(00.00 deg) =0.000
#define Sin1    20 //sin(11.25 deg) =0.195
#define Sin2    38 //sin(22.50 deg) =0.383
#define Sin3    56 //sin(33.75 deg) =0.556
#define Sin4    71 //sin(45.00 deg) =0.707
#define Sin5    83 //sin(56.25 deg) =0.831
#define Sin6    92 //sin(67.50 deg) =0.924
#define Sin7    98 //sin(78.75 deg) =0.981
#define Sin8   100 //sin(90.00 deg) =1.000

#define Figure_circle  0
#define Figure_square  1
#define Figure_LX2Y1   2
#define Figure_LX1Y2   3
#define Figure_LX3Y1   4
#define Figure_LX1Y3   5
#define Figure_LX4Y1   6
#define Figure_LX1Y4   7
#define Figure_LX3Y2   8
#define Figure_LX2Y3   9
#define Figure_pulse  10
#define Figure_oscope 11

/* Globals */
int Figure_Type;

/* Configure Uart module for RS232 */
void configUART( void )
{
U1MODE = 0x0400;        // Disable UART
U1BRG  = BRGVAL;        // Set baud rate 
U1MODE = 0x8400; 		// Reset UART to 8-n-1, alt pins, and enable 
U1STA  = 0x8440; 		// Reset status register and enable RX
_U1RXIF=0;				// Clear UART RX Interrupt Flag
_U1TXIF=0;
}

/* Configure Uart module for MIDI */
void configUARTMIDI( void )
{
U1MODE = 0x0400;        // Disable UART
U1BRG  = MIDIBAUD;      // Set baud rate 
U1MODE = 0x8400; 		// Reset UART to 8-n-1, alt pins, and enable 
U1STA  = 0x8440; 		// Reset status register and enable RX
_U1RXIF=0;				// Clear UART RX Interrupt Flag
_U1TXIF=0;
}

/* Configure SPI module for output to the MCP4822 DAC */
void configSPI( void )
{
unsigned int SPICFGValue;
unsigned int SPISTATValue;
/* Turn off SPI module */
CloseSPI1();
/* Configure SPI1 interrupt */
ConfigIntSPI1(SPI_INT_DIS & SPI_INT_PRI_6);
SPI1STATbits.SPIROV = 0;
/* Configure SPI1 module to transmit 16 bit in master mode */
SPICFGValue = FRAME_ENABLE_OFF & FRAME_SYNC_OUTPUT & ENABLE_SDO_PIN & SPI_MODE16_ON
              & SPI_SMP_OFF & SPI_CKE_OFF & SLAVE_ENABLE_OFF & CLK_POL_ACTIVE_LOW 
              & MASTER_ENABLE_ON & SEC_PRESCAL_2_1 & PRI_PRESCAL_1_1;
SPISTATValue = SPI_ENABLE & SPI_IDLE_STOP & SPI_RX_OVFLOW_CLR;
/* Turn on SPI module */
OpenSPI1(SPICFGValue,SPISTATValue);
} 

//   Microchip MCP4822 DAC output via SPI port
//   Port RB0 is used for the DAC chip select pin (CS active low)
//   Port RB1 is used for the DAC chip latch signal (LDAC active low)
//   The CS line must go low before the data is sent, and stay
//   low until all bits are transmitted, then the LDAC line must be
//   pulsed low to latch the new data in the DAC

void DACOut (unsigned int data, int channel)
{
int index;
/* set RB0 = 0 for DAC CS */
LATBbits.LATB0 = 0;
if (channel==1)
  SPI1BUF = ((0x1000 + data));
if (channel==2)
  SPI1BUF = ((0x9000 + data));
/* wait for SPI buffer */
while(SPI1STATbits.SPITBF);
  SPI1STAT = SPI_ENABLE & SPI_IDLE_STOP & SPI_RX_OVFLOW_CLR;
/* wait a bit to make sure all data is transmitted */
for (index=1;index<4;index++){}
/* set RB0 = 1 for DAC not CS */
LATBbits.LATB0 = 1;
/* wait a bit */
for (index=1;index<1;index++){}
/* set RB1 = 0 for DAC LDAC latch */
LATBbits.LATB1 = 0;
/* wait a bit */
for (index=1;index<1;index++){}
/* set RB1 = 1 for DAC LDAC not latch */
LATBbits.LATB1 = 1;
}

/* Draw a circle using math.h library */
void DrawCircle( void )
{
int angle;
for (angle=0;angle<36;angle++)
  {
  DACOut(2000+(500*(sin(angle*20*3.1415/360))),1);
  DACOut(2000+(500*(cos(angle*20*3.1415/360))),2);
  }
}

//   DrawLx2 - Draws faster than using the math.h library
//   This function simulates two sinewaves based on 9 points per quadrant.
//   Then the function outputs the sinewave data to the DAC via the SPI port.
//
//   Function inputs:
//   offset1     = waveform1 zero crossing offset value
//   offset2     = waveform2 zero crossing offset value
//   size        = the overall amplitude of the sinewaves
//   wait        = a value for adding wait loops to lower overall frequencies
//   phase       = an offset value for the start of sinewave1
//   phase2      = an offset value for the start of sinewave2
//   multiplier  = a frequency multiplier for sinewave1
//   multiplier2 = a frequency multiplier for sinewave2

void DrawLx2( int offset1, int offset2, int size, int wait, int phase, int phase2, int multiplier, int multiplier2 )
{
int angle1[41];
int index;
int index1;
int index2;
int index3;
int index4;
int index5;
/* Set up a wave array */
angle1[0] = Sin0;
angle1[1] = Sin1;
angle1[2] = Sin2;
angle1[3] = Sin3;
angle1[4] = Sin4;
angle1[5] = Sin5;
angle1[6] = Sin6;
angle1[7] = Sin7;
angle1[8] = Sin8;
angle1[9] = Sin7;
angle1[10] = Sin6;
angle1[11] = Sin5;
angle1[12] = Sin4;
angle1[13] = Sin3;
angle1[14] = Sin2;
angle1[15] = Sin1;
angle1[16] = Sin0;
angle1[17] = -Sin1;
angle1[18] = -Sin2;
angle1[19] = -Sin3;
angle1[20] = -Sin4;
angle1[21] = -Sin5;
angle1[22] = -Sin6;
angle1[23] = -Sin7;
angle1[24] = -Sin8;
angle1[25] = -Sin7;
angle1[26] = -Sin6;
angle1[27] = -Sin5;
angle1[28] = -Sin4;
angle1[29] = -Sin3;
angle1[30] = -Sin2;
angle1[31] = -Sin1;
angle1[32] = Sin0;
angle1[33] = Sin1;
angle1[34] = Sin2;
angle1[35] = Sin3;
angle1[36] = Sin4;
angle1[37] = Sin5;
angle1[38] = Sin6;
angle1[39] = Sin7;
angle1[40] = Sin8;

index2 = phase;                               //set start point for DAC waveform channel 2
index5 = phase2;                              //set start point for DAC waveform channel 1
for (index=0;index<31;index++)                //loop through one full wavelength
  {
  for (index3=0;index3<multiplier;index3++)   //base frequency loop for waveform 2
    {
    DACOut(offset2+(size*angle1[index2]),2);  //output points to DAC for waveform 2
    index2=index2+1;                          //increment point index
    if (index2>(phase+31))                    //end of one wavelength?  
      index2 = phase;                         //reset pointer to start of waveform 
    }
  for (index4=0;index4<multiplier2;index4++)  //base frequency loop for waveform 1
    {
    DACOut(offset1+(size*angle1[index5]),1);  //output points to DAC for waveform 1
    index5=index5+1;                          //increment point index
    if (index5>(phase2+31))                   //end of one wavelength?
      index5 = phase2;                        //reset pointer to start of waveform
    for (index1=0;index1<wait;index1++){}     //stretch waveforms for lower frequencies
    }
  }
}

void LaserOn( int note )
{
int index;
int index2;
int index3;
int Draw;
Draw = Figure_circle;  //default = circle
switch (note)
  {
  case 0x3C:
    {
    Draw = Figure_circle;
    break;
    }
  case 0x3d:
    {
    Draw = Figure_square;
    break;
    }
  case 0x3e:
    {
    Draw = Figure_LX2Y1;
    break;
    }
  case 0x3f:
    {
    Draw = Figure_LX1Y2;
    break;
    }
  case 0x40:
    {
    Draw = Figure_LX3Y1;
    break;
    }
  case 0x41:
    {
    Draw = Figure_LX1Y3;
    break;
    }
  case 0x42:
    {
    Draw = Figure_LX4Y1;
    break;
    }
  case 0x43:
    {
    Draw = Figure_LX1Y4;
    break;
    }
  case 0x44:
    {
    Draw = Figure_LX3Y2;
    break;
    }
  case 0x45:
    {
    Draw = Figure_LX2Y3;
    break;
    }
  case 0x46:
    {
    Draw = Figure_pulse;
    break;
    }
  case 0x47:
    {
    Draw = Figure_oscope;
    break;
    }
  } //end switch note

switch (Draw)
  {
  case Figure_circle:
    {
    LATEbits.LATE0 = LEDon;
    LATEbits.LATE1 = LEDoff;
    LATEbits.LATE2 = LEDoff;
    for (index=1;index<2;index++)
      {
      DrawLx2(2000,2000,10,1000,8,0,1,1);
      }    
    break;
    }
  case Figure_square:
    {
    LATEbits.LATE0 = LEDoff;
    LATEbits.LATE1 = LEDon;
    LATEbits.LATE2 = LEDoff;
    for (index=1;index<40;index++)
      {
      DACOut((index*100),1);
      } 
    for (index=1;index<40;index++)
      {
      DACOut((index*100),2);
      }
    for (index=1;index<40;index++)
      {
      DACOut((4000-(index*100)),1);
      } 
    for (index=1;index<40;index++)
      {
      DACOut((4000-(index*100)),2);
      } 
    break;
    }
  case Figure_LX2Y1:
    {
    LATEbits.LATE0 = LEDon;
    LATEbits.LATE1 = LEDon;
    LATEbits.LATE2 = LEDoff;
    for (index=1;index<2;index++)
      {
      DrawLx2(2000,2000,10,1000,0,0,2,1);
      }    
    break;
    }
  case Figure_LX1Y2:
    {
    LATEbits.LATE0 = LEDoff;
    LATEbits.LATE1 = LEDoff;
    LATEbits.LATE2 = LEDon;
    for (index=1;index<2;index++)
      {
      DrawLx2(2000,2000,10,1000,8,0,1,2);
      }    
    break;
    }
  case Figure_LX3Y1:
    {
    LATEbits.LATE0 = LEDon;
    LATEbits.LATE1 = LEDoff;
    LATEbits.LATE2 = LEDon;
    for (index=1;index<2;index++)
      {
      DrawLx2(2000,2000,10,1000,8,0,3,1);
      }    
    break;
    }
  case Figure_LX1Y3:
    {
    LATEbits.LATE0 = LEDoff;
    LATEbits.LATE1 = LEDon;
    LATEbits.LATE2 = LEDon;
    for (index=1;index<2;index++)
      {
      DrawLx2(2000,2000,10,1000,8,0,1,3);
      }    
    break;
    }
  case Figure_LX4Y1:
    {
    LATEbits.LATE0 = LEDon;
    LATEbits.LATE1 = LEDon;
    LATEbits.LATE2 = LEDon;
    for (index=1;index<2;index++)
      {
      DrawLx2(2000,2000,10,1000,0,0,4,1);
      }    
    break;
    }
  case Figure_LX1Y4:
    {
    LATEbits.LATE0 = LEDoff;
    LATEbits.LATE1 = LEDoff;
    LATEbits.LATE2 = LEDoff;
    for (index=1;index<2;index++)
      {
      DrawLx2(2000,2000,10,1000,8,0,1,4);
      }    
    break;
    }
  case Figure_LX3Y2:
    {
    LATEbits.LATE0 = LEDon;
    LATEbits.LATE1 = LEDon;
    LATEbits.LATE2 = LEDon;
    for (index=1;index<2;index++)
      {
      DrawLx2(2000,2000,10,1000,0,0,3,2);
      }    
    break;
    }
  case Figure_LX2Y3:
    {
    LATEbits.LATE0 = LEDoff;
    LATEbits.LATE1 = LEDoff;
    LATEbits.LATE2 = LEDoff;
    for (index=1;index<2;index++)
      {
      DrawLx2(2000,2000,10,1000,0,0,2,3);
      }    
    break;
    }
  case Figure_pulse:
    {
    LATEbits.LATE0 = LEDon;
    LATEbits.LATE1 = LEDon;
    LATEbits.LATE2 = LEDon;
      for (index3=1;index3<10;index3++)
        {
        for (index=1;index<2;index++)
          {
          DrawLx2(2000,2000,index3,1000,8,0,1,1);
          }
        }
      for (index3=1;index3<10;index3++)
        {
        for (index=1;index<2;index++)
          {
          DrawLx2(2000,2000,19-index3,1000,8,0,1,1);
          }
        }
    break;
    }
  case Figure_oscope:
    {
      LATEbits.LATE0 = LEDoff;
      LATEbits.LATE1 = LEDoff;
      LATEbits.LATE2 = LEDoff;
      /* Draw some Lissajous */
      for (index3=1;index3<5;index3++)          //change the figure from a 1:1 to 1:4
      {
        for (index2=0;index2<9;index2++)        //change the phase from 0 to 90 deg
          {  
           DrawLx2(2000,2000,10,1000,index2,0,index3,1);   // draw x:1 phase increasing
          }
        for (index2=0;index2<9;index2++)        //change the phase from 90 to 0 deg
          {  
          DrawLx2(2000,2000,10,1000,(8-index2),0,1,index3); //draw 1:x phase decreasing
          }
        }
    break;
    }  
  } //end switch Draw

} //end LaserOn

void LaserOff( void )
{
LATEbits.LATE0 = LEDoff;
LATEbits.LATE1 = LEDoff;
LATEbits.LATE2 = LEDoff;
DACOut(0,1);
DACOut(0,2);
}

void MIDIStart( void )
{
unsigned char MIDIData;
int MIDINoteNumber;
int MIDINoteVelocity;
int MIDIState;
long int error; 
    
configUARTMIDI();
/* Flush UART RX buffer */
while (U1STAbits.URXDA==1)
   MIDIData = U1RXREG;
MIDIState = 0;   //idle state
while (1)
  { 
  if (U1STAbits.OERR==1)
    U1STAbits.OERR=0;
  if (U1STAbits.FERR==1)
    configUARTMIDI();
  if (U1STAbits.PERR==1)
    configUARTMIDI();
  /* Flush UART RX buffer */
  while (U1STAbits.URXDA==1)
    MIDIData = U1RXREG;
  error=0;
  while (_U1RXIF==0)			// Wait and receive one Character
    {
    error++;
    if (error>1000000)          //Stuck playing a note too long
      {
      if (U1STAbits.OERR==1)
        U1STAbits.OERR=0;
      if (U1STAbits.FERR==1)
        configUARTMIDI();
      if (U1STAbits.PERR==1)
        configUARTMIDI();
     
      while (U1STAbits.URXDA==1)
        MIDIData = U1RXREG;
       _U1RXIF=0;
      MIDIState = 3;
      MIDINoteNumber = 0x3c;
      }     
    if (MIDIState==4)
      LaserOn(MIDINoteNumber); //continue to play note
    }
  MIDIData = U1RXREG;
  _U1RXIF=0;					// Clear UART RX Interrupt Flag

  switch (MIDIData)
    {
    case 0xfe :       //system message - ignore 
      break;
    case 0xf8 :       //system message - ignore
      break;
    case 0x90 :       //MIDI channel 1 for Laser data
      {
	  MIDIState = 1;  //note on RX
	  break;
	  }
    case 0x80 :       //MIDI channel 1 for Laser data
	  {
	  MIDIState = 3;  //note off RX
	  break;
      }
	default :
	  {
	  switch (MIDIState)
	    {
         case 1 :    //note on RX
		   {
		   MIDINoteNumber = MIDIData;  //save note number
		   MIDIState = 2;  //next byte is note velocity
		   break;
	       }
         case 2 :   //process velocity byte
		   {
		   if (MIDIData == 0) //zero velocity RX
             {
		     LaserOff();
             MIDIState = 0;  //back to idle
             }
		   else
		     {  
			 LaserOn(MIDINoteNumber); //play note
             MIDIState = 4;  //note in play
        	 }
  	         MIDINoteVelocity = MIDIData; //save velocity
			 break;
			 }
         case 3 :
		   {
		   LaserOff();
		   break; 
		   }
         case 4:
           {
           LaserOn(MIDINoteNumber); //continue to play note
           } //end case 4
		  } //end switch on State
        } //end default 
       } //end switch on RX
     } //end while
   } //end function

/* Main function */
int main (void)
{ 
unsigned char MIDIdata;
/* set LED pins as outputs */
TRISEbits.TRISE0 = 0;   
TRISEbits.TRISE1 = 0; 
TRISEbits.TRISE2 = 0;
/* set DAC control bits as outputs */
ADPCFGbits.PCFG0 = 1;
ADPCFGbits.PCFG1 = 1;
TRISBbits.TRISB0 = 0;
TRISBbits.TRISB1 = 0;
/* Initialize */
configSPI(); 
configUART();
configUARTMIDI();
/* Turn off LEDs */
LATEbits.LATE0 = LEDoff;
LATEbits.LATE1 = LEDoff;
LATEbits.LATE2 = LEDoff;
/* DAC off */
LaserOff();
Figure_Type = Figure_circle;

/* Flush UART RX buffer */
while (U1STAbits.URXDA==1)
  MIDIdata = U1RXREG;

MIDIStart();
/* Main loop */
while (1)
  {
  }
return 0;
}

