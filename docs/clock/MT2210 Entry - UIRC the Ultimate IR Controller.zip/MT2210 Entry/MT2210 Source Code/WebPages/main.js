var monitoring = false;

function initAll()
{
    GetServerFile("version.cgi","txtStackVersion");

    return false;
}

function MonitorCheck()
{
    monitoring = document.getElementById("monitor").checked;
    if (monitoring)
        Monitor();
    else {
        document.getElementById("monitor-out").innerHTML = "activate monitor to display events";
    }
}

function Monitor()
{
    if (monitoring == true) {
        GetServerFile("status.cgi","monitor-out");
        setTimeout("Monitor()", 1000);
    } else {
        document.getElementById("monitor-out").innerHTML = "activate monitor to display events";
    }
}

var ObjArray = new Array;

function GetXmlHttpObject(handler)
{
    var objXmlHttp = null;

    if(navigator.userAgent.indexOf("MSIE")>=0) {
        var ClassName = "Msxml2.XMLHTTP";

        if(navigator.appVersion.indexOf("MSIE 5.5")>=0) {
            ClassName = "Microsoft.XMLHTTP";
        }
        try {
            objXmlHttp = new ActiveXObject(ClassName);
            objXmlHttp.onreadystatechange = handler;
            return objXmlHttp;
        } catch(e) {
            alert("Error: ActiveX scripting may be disabled.");
            return;
        }
    } else {
        try {
            objXmlHttp = new XMLHttpRequest();
            objXmlHttp.onload = handler;
            objXmlHttp.onerror = handler;
            return objXmlHttp;
        } catch(e) {
            alert("Error: Browser may not be supported or browser security restrictions are too high.  XMLHttpRequest() support is required.");
        }
    }
}

function GetServerFile(FileName, AssignTo)
{
    var NiftyObj = new Object();
    NiftyObj.XMLDevice = new GetXmlHttpObject(StateChanged);
    NiftyObj.XMLDevice.open("GET", FileName, true);
    NiftyObj.XMLDevice.send(null);
    NiftyObj.Text = AssignTo;
    ObjArray.push(NiftyObj);
}

function StateChanged()
{
    for(i in ObjArray) {
        if(ObjArray[i].XMLDevice.readyState != "4" && ObjArray[i].XMLDevice.readyState != "complete")
            continue;

        if(ObjArray[i].Text != "") {
                document.getElementById(ObjArray[i].Text).innerHTML=ObjArray[i].XMLDevice.responseText;
        }
    
        if(ObjArray[i].Text == "txtAutoUpdateStatus") {
            if(navigator.userAgent.indexOf("Firefox") >= 0) {
                    ObjArray[i].XMLDevice = new GetXmlHttpObject(StateChanged);
                ObjArray[i].XMLDevice.open("GET", "status.cgi", true);
                ObjArray[i].XMLDevice.send();
            } else {
                ObjArray[i].XMLDevice.onreadystatechange = StateChanged;
                ObjArray[i].XMLDevice.open("GET", "status.cgi", true);
                ObjArray[i].XMLDevice.onreadystatechange = StateChanged;
                ObjArray[i].XMLDevice.send();
            }
        } else {
            delete ObjArray[i].XMLDevice;
            delete ObjArray[i].Text;
            delete ObjArray[i];
        }
    }
}
