//***********************************************************************/
// UIRC: Ultimate IR Controller                                          /
//       (c) 2007 by its author, all rights reserved.                    /
//                                                                       /
// The UIRC is a generic IR sensor for all kinds of modulated IR remote  /
// control protocols.  It learns and replays IR commands controlled by a /
// master microcontroller.                                               /
//                                                                       /
// FILE: UIRC.h                                                          /
//    main header file                                                   /
//                                                                       /
//***********************************************************************/


// command interface

// the sensor is normally waiting a byte with one of the following
// UIRCS_CMD_* commands. The sensor will respond with a URICS_response 
// character, optionally followed by a specific response block

// commands
#define UIRCS_CMD_INIT		0xff			// reset UIRC sensor
#define UIRCS_CMD_NOP		0x00			// no operation
#define UIRCS_CMD_LEARN		0x01			// set to learn mode
#define UIRCS_CMD_STOP		0x02			// set to command mode
#define UIRCS_CMD_RECV		0x03			// set to receive mode
#define UIRCS_CMD_SEND		0x04			// send IR command		
#define UIRCS_CMD_STATUS	0x05			// get sensor status

// the response byte has the following format:
// 8 bits: ESSS RRRR
//    E    = 1 if error
//    SSS  = system status  UIRCS_STA_*
//    RRRR = response code  UIRCS_RES_*

// ok/error macros and constants
#define res_status(c)			((c)&0x80)
#define UIRCS_RES_OK		0x00			// OK, no error
#define UIRCS_RES_ERROR		0x80			// ERROR (bit 7 = 1)

// the normal responses
#define res_code(c)			((c)&0x8f)
#define UIRCS_RES_IREVENT	0x01			// IR event received
#define UIRCS_RES_IRLEARN	0x02			// IR event under learning
#define UIRCS_RES_IRSENT	0x03			// IR command sent
#define UIRCS_RES_INITOK	0x0f			// init OK
#define UIRCS_ERR_ILLEGAL	0x81			// illegal command
#define UIRCS_ERR_FSM		0x82			// FSM illegal state
#define UIRCS_ERR_IRNOTSENT	0x83			// IR not sent

// the system status
#define res_sysstat(c)		((c)&0xf0)
#define UIRCS_STA_IDLE		0x00			// idle mode (low power)
#define UIRCS_STA_RECV		0x10			// in receive mode
#define UIRCS_STA_LEARN		0x20			// in learn mode
#define UIRCS_STA_LRNOK		0x30			// learned IR command

// IR receive event structure
typedef struct {
	unsigned char status;					// UIRCS_RES_IREVENT
	unsigned char proto;					// protocol
	unsigned char freq;						// frequency
	unsigned char nbits;					// number of bits
	unsigned long bits;						// bit encoding
} IRevent;

// IR learn structure
// times are in TSAMPLE units
typedef struct {
	unsigned char status;					// UIRCS_RES_IRLEARN
	unsigned char proto;					// protocol
	unsigned char freq;						// frequency
	unsigned char nbits;					// number of bits
	unsigned long bits;						// bit encoding

	unsigned char flags;					// flags

	unsigned int start_high;				// start high length
	unsigned int start_low;					// start low length

	unsigned int high_max;					// max time in high
	unsigned int high_min;					// min time in high
	unsigned int low_max;					// max time in low
	unsigned int low_min;					// min time in low

	unsigned int gap;						// gap
	
} IRlearn;

// type of encoding
#define IR_ENCODING_MASK	0xF0
#define IR_ENCODING_UNKNOWN	0x00			// unknown encoding
#define IR_ENCODING_PW		0x10			// pulse width encoding
#define IR_ENCODING_PD		0x20			// pulse distance encoding (high pulses constant)
#define IR_ENCODING_BI		0x30			// bi-phase encoding

// protocols constants
#define IR_PROTO_MASK		0x0F
#define IR_PROTO_UNKNOWN	0x00
#define IR_PROTO_SIRC		0x01
#define IR_PROTO_JVCNEC		0x02
#define IR_PROTO_SHARP		0x03
#define IR_PROTO_RCA		0x04
#define IR_PROTO_NRC17		0x05
#define IR_PROTO_RC5		0x06
#define IR_PROTO_RC6		0x07
#define IR_PROTO_PD			0x0e
#define IR_PROTO_PW			0x0f



// sampling constants
#define SAMPLING 			4		// sampling time = 4 us (~4.069)



// EOF: UIRC.h
