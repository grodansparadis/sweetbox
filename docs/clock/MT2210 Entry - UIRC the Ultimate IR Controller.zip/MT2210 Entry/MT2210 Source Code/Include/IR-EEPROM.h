//***********************************************************************/
// UIRC: Ultimate IR Controller                                          /
//       (c) 2007 by its author, all rights reserved.                    /
//                                                                       /
// The UIRC is a generic IR sensor for all kinds of modulated IR remote  /
// control protocols.  It learns and replays IR commands controlled by a /
// master microcontroller.                                               /
//                                                                       /
// FILE: IR-EEPROM.h                                                     /
//    EEPROM routines to write IR learned commmands                      /
//                                                                       /
// version:                                                              /
//    0.01:  09/30/07 - start coding                                     /
//                                                                       /
//***********************************************************************/



// label length
#define IR_LABEL_LEN		16

// execution flags
#define IR_FLAG_LABEL		0x01		// learned command
#define IR_FLAG_REPLY		0x02		// reply command

// null
#define NIL					0x0000

// IR Blocks
typedef struct {
	XEE_ADDR next;						// pointer to next in this list
	XEE_ADDR cmd_next;					// pointer to next command in command list

	unsigned char flags;				// execution flags
	unsigned char sysid;				// system ID
	unsigned char id;					// event ID
	char label[IR_LABEL_LEN+1];			// event label
	union {
		XEE_ADDR saved;					// saved command
		IRlearn	learned;				// learned command
	} ir;
	unsigned int delay;					// delay after command
} ir_entry;

// IR Block Header
typedef struct {
	XEE_ADDR next;						// pointer to next in this list
	XEE_ADDR cmd_next;					// pointer to next command in command list
} ir_entry_header;

// number of blocks in EEPROM
#define N_BLOCKS		MPFS_RESERVE_BLOCK/sizeof(ir_entry)

// EEPROM block allocation structure
typedef struct {
	int free;							// number of free blocks
	unsigned short used[N_BLOCKS/16];	// used block mask
	int last;							// last free block index
	XEE_ADDR evt_list;					// event list start
} ir_list;

// array addresses
typedef unsigned char mem_index_type;



// references
extern void iree_init(void);
extern int iree_event_write(int n, ir_entry *ire_array);
extern mem_index_type iree_event_search(unsigned char proto,
                                        unsigned char freq,
                                        unsigned char nbits, unsigned long bits);
extern mem_index_type iree_id_search(unsigned char sysid, unsigned char id);
extern void iree_event_delete(mem_index_type index);




// EOF: IR-EEPROM.h
