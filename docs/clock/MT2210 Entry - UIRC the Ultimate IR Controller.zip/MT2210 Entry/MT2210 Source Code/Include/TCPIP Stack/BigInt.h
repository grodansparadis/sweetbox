/*********************************************************************
 *
 *					Big Integer Class Headers
 *
 *********************************************************************
 * FileName:        BigInt.h
 * Dependencies:    none
 * Processor:       PIC18, PIC24F, PIC24H, dsPIC30F, dsPIC33F
 * Compiler:        Microchip C18 v3.02 or higher
 *					Microchip C30 v2.01 or higher
 * Company:         Microchip Technology, Inc.
 *
 * Software License Agreement
 *
 * Copyright � 2002-2007 Microchip Technology Inc.  All rights 
 * reserved.
 *
 * Microchip licenses to you the right to use, modify, copy, and 
 * distribute: 
 * (i)  the Software when embedded on a Microchip microcontroller or 
 *      digital signal controller product (�Device�) which is 
 *      integrated into Licensee�s product; or
 * (ii) ONLY the Software driver source files ENC28J60.c and 
 *      ENC28J60.h ported to a non-Microchip device used in 
 *      conjunction with a Microchip ethernet controller for the 
 *      sole purpose of interfacing with the ethernet controller. 
 *
 * You should refer to the license agreement accompanying this 
 * Software for additional information regarding your rights and 
 * obligations.
 *
 * THE SOFTWARE AND DOCUMENTATION ARE PROVIDED �AS IS� WITHOUT 
 * WARRANTY OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT 
 * LIMITATION, ANY WARRANTY OF MERCHANTABILITY, FITNESS FOR A 
 * PARTICULAR PURPOSE, TITLE AND NON-INFRINGEMENT. IN NO EVENT SHALL 
 * MICROCHIP BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR 
 * CONSEQUENTIAL DAMAGES, LOST PROFITS OR LOST DATA, COST OF 
 * PROCUREMENT OF SUBSTITUTE GOODS, TECHNOLOGY OR SERVICES, ANY CLAIMS 
 * BY THIRD PARTIES (INCLUDING BUT NOT LIMITED TO ANY DEFENSE 
 * THEREOF), ANY CLAIMS FOR INDEMNITY OR CONTRIBUTION, OR OTHER 
 * SIMILAR COSTS, WHETHER ASSERTED ON THE BASIS OF CONTRACT, TORT 
 * (INCLUDING NEGLIGENCE), BREACH OF WARRANTY, OR OTHERWISE.
 *
 *
 * Author               Date		Comment
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Elliott Wood	        2/15/07		Original
 ********************************************************************/

#ifndef __BIGINT_H
#define __BIGINT_H

#define BIGINT_DEBUG			0
//#define BIGINT_DEBUG_COMPARE 	0
#define RSAEXP_DEBUG			0

#ifdef __18CXX
	#define BIGINT_DATA_SIZE	8ul	//bits
	#define BIGINT_DATA_TYPE	BYTE
	#define BIGINT_DATA_MAX		0xFFu
	#define BIGINT_DATA_TYPE_2	WORD
#elif defined(__C30__)
	#define BIGINT_DATA_SIZE	16ul	//bits
	#define BIGINT_DATA_TYPE	WORD
	#define BIGINT_DATA_MAX		0xFFFFu
	#define BIGINT_DATA_TYPE_2	DWORD
#endif

typedef struct _BIGINT
{
	BIGINT_DATA_TYPE *data;
	int size;
	BIGINT_DATA_TYPE MSBvalid; 
	BIGINT_DATA_TYPE *ptrMSB;
	BIGINT_DATA_TYPE *ptrLSB;
} BIGINT;

#if defined(__18CXX)
	typedef struct _BIGINT_ROM
	{
		ROM BIGINT_DATA_TYPE *data;
		int size;
		ROM BIGINT_DATA_TYPE *ptrMSB;
		ROM BIGINT_DATA_TYPE *ptrLSB;
	} BIGINT_ROM;
#else
	#define BIGINT_ROM	BIGINT
#endif


void BigInt(BIGINT*, BIGINT_DATA_TYPE*, int);
void BigIntMod(BIGINT*, BIGINT*);
void BigIntMultiply(BIGINT*, BIGINT*, BIGINT*);

void BigIntAdd(BIGINT*, BIGINT*);
void BigIntSubtract(BIGINT*, BIGINT*);
void BigIntSubtractROM(BIGINT*, BIGINT_ROM*);
void BigIntCopy(BIGINT*, BIGINT*);
void BigIntSquare(BIGINT *a, BIGINT *res);

int BigIntMagnitudeDifference(BIGINT *a, BIGINT *b);
int BigIntMagnitudeDifferenceROM(BIGINT *a, BIGINT_ROM *b);
int BigIntCompare(BIGINT*, BIGINT*);
unsigned int BigIntMagnitude(BIGINT*);
int BigIntCompare_helper(BIGINT *a, BIGINT *b, int iA, int iB);

int BigIntMSBi(BIGINT*);
BIGINT_DATA_TYPE* BigIntMSB(BIGINT *n);
BIGINT_DATA_TYPE* BigIntLSBptr(BIGINT *a);
BIGINT_DATA_TYPE* BigIntMSBptr(BIGINT *a);

//extern declarations for assembly helpers
extern BIGINT_DATA_TYPE *_iA, *_iB, *_xA, *_xB, *_iR, _B;
extern void _addBI(void);
extern void _subBI(void);
extern void _zeroBI(void);
extern void _msbBI(void);
extern void _mulBI(void);
extern void _copyBI(void);
extern void _sqrBI(void);
extern void _masBI(void);

void BigIntPrint(BIGINT*);


#if defined(__18CXX)	
	void BigIntROM(BIGINT_ROM*, ROM BIGINT_DATA_TYPE*, int);
	void BigIntModROM(BIGINT*, BIGINT_ROM*);
	void BigIntMultiplyROM(BIGINT*, BIGINT_ROM*, BIGINT*);
	void BigIntAddROM(BIGINT*, BIGINT_ROM*);
	void BigIntCopyROM(BIGINT*, BIGINT_ROM*);
	int BigIntCompareROM(BIGINT*, BIGINT_ROM*);
	unsigned int BigIntMagnitudeROM(BIGINT_ROM*);
	int BigIntCompare_helperROM(BIGINT *a, BIGINT_ROM *b, int iA, int iB);
	
	extern void _addBIROM(void);
	extern void _subBIROM(void);
	extern void _mulBIROM(void);
	extern void _masBIROM(void);
	
	extern ROM BIGINT_DATA_TYPE *_iBr, *_xBr;
	
	void BigIntPrintROM(BIGINT_ROM*);
#else
	#define BigIntROM(a,b,c)			BigInt(a,b,c)
	#define BigIntModROM(a,b)			BigIntMod(a,b)
	#define BigIntMultiplyROM(a,b,c)	BigIntMultiply(a,b,c)
	#define BigIntAddROM(a,b)			BigIntAdd(a,b)
	#define BigIntCopyROM(a,b)			BigIntCopy(a,b)
	#define BigIntCompareROM(a,b)		BigIntCompare(a,b)
	#define BigIntMagnitudeROM(a)		BigIntMagnitude(a)
	#define BigIntCompare_helperROM(a,b,c,d)	BigIntCompare_helper(a,b,c,d)
	
	#define _addBIROM()					_addBI()
	#define _subBIROM()					_subBI()
	#define _mulBIROM()					_mulBI()
	#define _masBIROM()					_masBI()
	
	#define _iBr						_iB
	#define _xBr						_xB
	
	#define BigIntPrintROM(a)			BigIntPrint(a)
#endif


#endif
