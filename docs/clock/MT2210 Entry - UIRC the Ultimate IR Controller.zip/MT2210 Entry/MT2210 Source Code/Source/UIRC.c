// Circuit Cellar Microchip 16-bit Embedded Control Design Contest
// Project: MT2210 - UIRC: The Ultimate IR Controller
// Components: dsPIC30F3010   - UIRC Sensor
//             PIC24FJ64GA002 - UIRC Control
//
// Bonus parts: MCP6022, ENC28J60, 24LC512
//
//***********************************************************************/
// UIRC: Ultimate IR Controller                                          /
//       (c) 2007 by its author, all rights reserved.                    /
//                                                                       /
// The UIRC is a generic IR sensor for all kinds of modulated IR remote  /
// control protocols.  It learns and replays IR commands controlled by a /
// master microcontroller.                                               /
//                                                                       /
// FILE: UIRC.c                                                          /
//    main code                                                          /
//                                                                       /
// version:                                                              /
//    0.01:  06/21/07 - start coding                                     /
//                    - coded ADC routines                               /
//           06/29/07 - debugged ADC capture                             /
//           07/01/07 - programmed interrupt schema for ADC capture      /
//    0.10   07/04/07 - tested IIR filters                               /
//    0.11:  07/13/07 - started IR decoding                              /
//    0.20:  08/12/07 - fixed low pass digital decoding                  /
//    0.21:  08/24/07 - changed to 3.3V and dsPIC30F3010                 /
//    0.22:  08/25/07 - tested SIRC/RCA/JVCNEC/NRC17/SHARP and RC5       /
//                      protocols.                                       /
//                    - finished process_pw and process_pd               /
//    0.23:  08/26/07 - finished process_bi for RC5 and NRC17            /
//    0.30:  09/09/07 - programed UART interface                         /
//                    - programmed IR event FIFO                         /
//    0.31:  09/10/07 - fixed UART receive routines                      /
//    0.40:  09/22/07 - started IR transmit routines                     /
//    0.41:  09/23/07 - tested IR transmit routines                      /
//    0.90:  09/23/07 - first beta release                               /
//    0.91:  09/27/07 - fixed UART transmission routines                 /
//    1.00:  10/14/07 - fixed frequency measuring bug                    /
//                                                                       /
//                                                                       /
//***********************************************************************/



#include <p30F3010.h>
#include <adc10.h>
#include <math.h>
#include <dsp.h>
#include <uart.h>

#include "UIRC.h"


// frequency constants
// define constants for dsPIC configuration
// (remember to change SAMPLING constant in UIRC.h if TSAMPLE changes)
#define XTFREQ			7372800ul			// define on-board frequency
#define PLLMODE			16					// define on-chip PLL setting
#define FCY             XTFREQ*PLLMODE/4	// instruction cycle frequency

// sampling constants
#define SAMP_FREQ		(FCY/5/24)			  // (5 TCY = Tad * 24 = sampling time) ~ 246 KHz
#define TSAMPLE			(1000000ul/SAMP_FREQ) // sampling time = 4 us (~4.069)


// dsPIC configuration
// run through external crystal at 7.3728 MHz with PLL at 16x
_FOSC(CSW_FSCM_OFF & XT_PLL16);				// this gives 7.3728E6*16/4 = 29.4 MIPS ~ 33.9 ns
_FWDT(WDT_OFF);								// turn off the WDT
_FBORPOR(MCLR_EN & PWRT_64);				// enable MCLR and power up timer
_FGS(CODE_PROT_OFF);						// disable Code Protection

// define UART BAUD rate
#define UART_BAUD		(19200ul)
#define	BAUD_FACTOR		FCY/(16*UART_BAUD)-1

// output port
// LED0 = debug LED
#define LED0			(PORTEbits.RE0)
#define DEBUG_OUT		(PORTEbits.RE1)



// get clock period in ns
#define FCY_P				((4E9/XTFREQ)+PLLMODE/2)/PLLMODE

// convert miliseconds to TMR2 ticks (with 1:256 prescaler)
#define TO_TMR2_CLICKS(ms)	((ms)*1E6/(256*FCY_P))

// convert frequency to PWM PTPER/PDC3 value
#define PWM_PTPER(f)		(FCY/2/(f))

// start PWM
#define pwm_start			PDC3 = PTPER

// stop PWM
#define pwm_stop			PDC3 = 0x0

// conversion from TSAMPLE ticks to TMR3 ticks
#define TFACTOR				(FCY/8/SAMP_FREQ)

// power save
#define power_save()		{ asm("pwrsav #1"); }

// threshold level
#define THRESHOLD_LEVEL		((fractional)(0.04*32767+0.5))

// event filter: number of samples that must be zero to consider logic 0
#define EVENT_N				8

// event filter: bit mask for # samples
#define EVENT_MASK			0xfff

// allowed error for measures (in samples)
#define ERROR_FACTOR		(200/TSAMPLE)

// convert from microseconds to sample time
#define FROM_US(u)			((u)/TSAMPLE)

// integer absolute value
#define i_abs(x)			(((x)<0)?-(x):(x))

// integer positive
#define i_pos(x)			(((x)<0)?0:(x))

// macro to check range
#define in_range(v,low,high) (i_abs((int)(v)-(int)(low)) > -ERROR_FACTOR && \
                              i_abs((int)(v)-(int)(high)) < ERROR_FACTOR)

// macro to compare time value with error
//#define compare(v,t) in_range(v,t,t)
#define compare(v,t)		(i_abs((int)(v)-(int)(t)) < ERROR_FACTOR)

// ADC buffers
#define MAX_ADC_BUFFER		16
fractional adc_buffer[MAX_ADC_BUFFER];

// FSM states
#define FSM_STATE_START		0x00			/* start a new IR cycle detection */
#define FSM_STATE_CAPTURE	0x01			/* capture signals from ADC */
#define FSM_STATE_BP_IIR	0x02			/* ready for band-pass IIR filtering */
#define FSM_STATE_GET_RAW	0x03			/* get the raw digital signal */
#define FSM_STATE_IR_DECODE	0x04			/* ready for IR decoding */

// FSM state variable
volatile unsigned char fsm = FSM_STATE_START;

// Band-pass IIR
extern IIRTransposedStruct bp_iirFilter;	/* band-pass IIR filter */
fractional output[MAX_ADC_BUFFER];			/* IIR output buffer */

// debug variable for adc sampling overlap error detection
#define SAMPLING_ON			1
#define SAMPLING_OFF		0
volatile unsigned char sampling;			/* sampling flag */

// mode constants
#define IDLE				UIRCS_STA_IDLE	/* the sensor is in command mode */
#define SENSING				UIRCS_STA_RECV	/* the sensor is in normal mode, detecting IR commands */
#define LEARNING			UIRCS_STA_LEARN	/* the sensor is in learning mode, measuring parameters */
#define LEARNING_OK			UIRCS_STA_LRNOK	/* the sensor has learned a IR command */



// diferent counting flags
#define IR_IDLE				0				/* idle: waiting for IR start */
#define IR_HIGH_DETECTED	1				/* detected a HIGH */
#define IR_LOW_DETECTED		2				/* detected a LOW */
#define IR_MEASURING_GAP	3				/* measuring blank gap - repeat interval between commands */
#define IR_END				4				/* measuring end */

// maximum idle time for command end
#define MAX_TRAILING_BLANK		8000		/* 8 ms */

// maximum gap size
#define MAX_GAP					120000		/* 120 ms */

// constant to signal no gap
#define NO_GAP					0xffff

// global variables for IR decoding */
unsigned char mode = IDLE;					/* mode: IDLE/SENSING/LEARNING */
unsigned char counting = IR_IDLE;			/* flag for IR decoding */
unsigned int count = 0;						/* counts samples at TSAMPLE us each */
unsigned int event_freq;					/* capture of the event for freq. measurement */

// maximum number of transitions
#define MAX_TRANSITIONS 	(72*2)			/* up to 72 bits (transitions) */

// raw buffer for timings
unsigned int raw[MAX_TRANSITIONS];

// event bitmap for low pass filter
unsigned int event = 0;

// count number of zeros to adjust timing
unsigned int zeros = 0;

// current position in raw array
int raw_pos = 0;

// signal transition overflow
unsigned char overflow;

// decoded raw bits
unsigned long bits;

// decoded number of bits
unsigned char nbits;

// maximum/minimum timings of high level and previous
unsigned int high_max, high2_max;
unsigned int high_min, high2_min;

// maximum/minimum timings of low level and previous
unsigned int low_max, low2_max;
unsigned int low_min, low2_min;

// gap time
unsigned int gap;

// start timings
unsigned int start_high;
unsigned int start_low;

// measured frequency (in KHz)
unsigned int freq;

// IR detected protocol
unsigned char protocol = IR_PROTO_UNKNOWN;




// IR event circular buffer
#define IRFIFO_LEN	8
IRevent irfifo[IRFIFO_LEN];
int ir_buf_first = 0;
int ir_buf_last = 0;
int ir_buf_n = 0;

// learn event structure
IRlearn ir_learn_evt;



// forward references

// interface
inline void SendStatus(unsigned char code);
int CommandCheck(void);
void SendLearned(void);
void SendNextIREvent(void);
void TransmitIR(void);

// IR engine
void init(void);
void ADC_read(void);
inline void StartSampling(void);
inline void StopSampling(void);
inline void bp_filter(void);
inline void ResetIRDecoding(void);
void get_raw_signal(void);
inline void count_high(void);
inline void count_low(void);
void decode(void);

// IR analysis routines
void process_pw(void);
void process_pd(void);
void process_bi(void);

// IR send routines
int send_pw(IRlearn *ir);
int send_pd(IRlearn *ir);
int send_bi(IRlearn *ir);

// UART interface routines
void UARTinit(void);
inline char UARTdataRdy(void);
inline unsigned char UARTread(void);
int UARTreadBlock(unsigned char *buffer, int len, int timeout);
int UARTwriteBusy(void);
void UARTwrite(unsigned char c);
void UARTwriteBlock(unsigned char *buffer, int len);
void DelayMs(unsigned int time);

// PWM support routines
void PWMinit(void);
void PWMsetFreq(unsigned int freq);
void IRpulse(unsigned char logic, unsigned int time);



// ----- Main code

int main(void)
{
	/* set mode to idle mode */
	mode = IDLE;

	/* initialize resources */
	init();

	// turn on debug LED
	LED0 = 1;

	/* start FSM */
	while (1) {
		/* check if a command is requested */
		if (CommandCheck()) continue;

		// if learned a command, transmit it
		if (mode == LEARNING_OK) {
			SendLearned();
			mode = IDLE;
			continue;
		}

		// if there is something in the buffer, send it
		if (mode == SENSING && ir_buf_n > 0) {
			if (!UARTwriteBusy())
				SendNextIREvent();
		}

		/* check if in idle mode */
		if (mode == IDLE) {
			// wait for interrupt
			//power_save();				// enter idle state
			continue;
		};

		switch (fsm) {
			/* start IR cycle */
			case FSM_STATE_START:
				/* reset IR decoding */
				ResetIRDecoding();
				// enable sampling
				StartSampling();
				/* start capture process */
				fsm = FSM_STATE_CAPTURE;
				break;

			/* wait for ADC capture */
			case FSM_STATE_CAPTURE:
				// wait for interrupt
				//power_save();					// enter idle state
				break;

			/* process band-pass IIR filtering */
			case FSM_STATE_BP_IIR:
				bp_filter();
				break;

			/* digital-convert the signal */
			case FSM_STATE_GET_RAW:
				get_raw_signal();
				break;

			/* decode the IR signal */
			case FSM_STATE_IR_DECODE:
				decode();
				break;

			/* error */
			default:
				/* loop */
				SendStatus(UIRCS_ERR_FSM);
				fsm = FSM_STATE_START;
				break;

		} /* switch */
	} /* loop forever */

} // main



// ----- Serial Interface

/* get and execute command */
int CommandCheck(void)
{
	unsigned char cmd;

	// get a command from UART
	if (UARTdataRdy()) {
		cmd = UARTread();

		switch (cmd) {
			// reset UIRC sensor
			case UIRCS_CMD_INIT:
				mode = IDLE;
				// turn on debug LED
				LED0 = 1;
				init();
				SendStatus(UIRCS_RES_INITOK);
				break;

			// no operation
			case UIRCS_CMD_NOP:
				SendStatus(UIRCS_RES_OK);
				break;

			// set to learn mode
			case UIRCS_CMD_LEARN:
				mode = LEARNING;				// change mode to LEARNING
				// turn off debug LED
				LED0 = 0;
				SendStatus(UIRCS_RES_OK);
				break;

			// set to command mode
			case UIRCS_CMD_STOP:
				mode = IDLE;					// change mode to IDLE
				// turn on debug LED
				LED0 = 1;
				SendStatus(UIRCS_RES_OK);
				break;

			// set to receive mode
			case UIRCS_CMD_RECV:
				mode = SENSING;					// change mode to SENSING
				// turn off debug LED
				LED0 = 0;
				SendStatus(UIRCS_RES_OK);
				break;

			// send IR command
			case UIRCS_CMD_SEND:
				SendStatus(UIRCS_RES_OK);
				TransmitIR();
				break;

			// get sensor status
			case UIRCS_CMD_STATUS:
				SendStatus(UIRCS_RES_OK);
				break;

			// send error
			default:
				SendStatus(UIRCS_ERR_ILLEGAL);
				break;
		}

		return 1;		// signal command interpreted
	}

	return 0;
}

/* send a learned IR to the master controller */
void SendLearned(void)
{
	int i;
	unsigned char sum, *p;

	// turn on debug LED
	LED0 = 1;

	// get checksum
	p = (unsigned char *)&ir_learn_evt;
	for (i = 0, sum = 0; i < sizeof(IRlearn); ++i)
		sum ^= *p++;

	UARTwriteBlock((unsigned char *)&ir_learn_evt, sizeof(IRlearn));
	UARTwrite(sum); // send checksum

	// turn off debug LED
	LED0 = 0;
}

/* send the next IR event to the master controller */
void SendNextIREvent(void)
{
	int i;
	unsigned char sum, *p;

	if (!ir_buf_n) return;

	// turn on debug LED
	LED0 = 1;

	// get checksum
	p = (unsigned char *)&irfifo[ir_buf_first];
	for (i = 0, sum = 0; i < sizeof(IRevent); ++i)
		sum ^= *p++;

	// send block
	UARTwriteBlock((unsigned char *)&irfifo[ir_buf_first], sizeof(IRevent));
	UARTwrite(sum); // send checksum
	ir_buf_first = (ir_buf_first+1)%IRFIFO_LEN;
	--ir_buf_n;	

	// turn off debug LED
	LED0 = 0;
}

/* return a response status byte */
inline void SendStatus(unsigned char code)
{
	UARTwrite(code | mode);
}

/* transmit an IR command */
void TransmitIR(void)
{
	unsigned char ok;
	IRlearn ir;

	// get the IR structure command
	if (!UARTreadBlock((void *)&ir, sizeof(IRlearn), 500)) {
		SendStatus(UIRCS_ERR_IRNOTSENT);
		return;
	}
	
	// check protocol
	ok = 0;
	switch (ir.proto&IR_ENCODING_MASK) {
		case IR_ENCODING_PW:	ok = send_pw(&ir); break;
		case IR_ENCODING_PD:	ok = send_pd(&ir); break;
		case IR_ENCODING_BI:	ok = send_bi(&ir); break;
		default: break;
	}
	
	SendStatus((ok == 1)?UIRCS_RES_IRSENT:UIRCS_ERR_IRNOTSENT);
}



// ----- Subroutines

/*
 * ADC Interrupt Logic:
 *   AN0 is the analog input.  The system is designed for a 300 KHz sampling rate. The
 *   ADC is configured for a Tad of 5 Tcy (Tad = 169 ns) to satisfy Tad > 154 ns.
 *   The sampling time was set in 12 Tad and with a standard conversion time of 12 Tad 
 *   gives a total ADC time of 24 Tad or 4 us (~240 KHz).
 *
 *   The interrupt routine is programmed for 16 interrupt samples.  Every interrupt
 *   the 16 samples in the ADC buffer (ADCBUF#) are transferred to the ADC Buffer in
 *   four blocks for 64 total bytes.  The system swaps buffers to let the filter
 *   act in the buffer while new data is being captured.  The time between these
 *   interrupts is 16 x 24 Tad = 65.1 us.
 *
 *
 */

// ADC_init: initializes the ADC
//   configure AN0 as ADC input
void ADC_init(void)
{
	// set RB0/AN0 as analog and the rest of PORTB pins as digital
	ADPCFG = 0xFFFE;
	// turn off ADC
	ADCON1bits.ADON = 0;
	// set channel 0, sample A to AN0 referenced to VNREF
	SetChanADC10(ADC_CH0_POS_SAMPLEA_AN0 & ADC_CH0_NEG_SAMPLEA_NVREF &
	             ADC_CH0_POS_SAMPLEB_AN0 & ADC_CH0_NEG_SAMPLEB_NVREF);
	// turn off interrupts
	ConfigIntADC10(ADC_INT_DISABLE);
	// initialize ADC peripheral
	// ADC in automatic sampling, sampling at 12 Tda, 16 samples per int, 5 Tcy (for ~160 ns Tad)
	// with these values conversion time is (12+12) Tad = 4 us ~ 240 KHz
	// interrupts will be at 16 x 4 us = 64 us ~ 15.36 KHz
	OpenADC10(/*ADCON1*/ ADC_MODULE_ON&ADC_IDLE_CONTINUE&ADC_FORMAT_SIGN_FRACT&ADC_CLK_AUTO&
	                     ADC_SAMPLE_INDIVIDUAL&ADC_AUTO_SAMPLING_OFF,
	          /*ADCON2*/ ADC_VREF_AVDD_AVSS&ADC_SCAN_OFF&ADC_ALT_BUF_OFF&ADC_ALT_INPUT_OFF&
	                     ADC_CONVERT_CH0&ADC_SAMPLES_PER_INT_16,
	          /*ADCON3*/ ADC_SAMPLE_TIME_12&ADC_CONV_CLK_SYSTEM&ADC_CONV_CLK_5Tcy,
	          /*configport*/ ENABLE_AN0_ANA,
	          /*configscan*/ SCAN_NONE);

	// enable ADC
	ADCON1bits.ADON = 1;

	// configure ADC interrupt
	ConfigIntADC10(ADC_INT_PRI_7);

} // ADC_init


// init: initializes the dsPIC chip resources
void init(void)
{
	int i;

	// initialize the FSM
	fsm = FSM_STATE_START;

	// reset RCON
	RCON = 0x0000;

	// clear the raw array for debugging
	for (i = 0; i < MAX_TRANSITIONS; ++i)
		raw[i] = 0;	

	// initialize the band-pass IIR filter
	IIRTransposedInit(&bp_iirFilter);

	// configure output port
	PORTE = 0;
	TRISE = ~0x03;							// set RE0 and RE1 as output

	// initializes the PWM3H
	PWMinit();

	// reset FIFO
	ir_buf_first = 0;
	ir_buf_last = 0;
	ir_buf_n = 0;

	// initialize TMR2 for signal timing
	// TMR2 is used for timeouts in input/output functions
	// Tcy is about 34 ns: with the prescaler set at 256x, cycles are about 8.70 us each
	T2CON = 0;
	T2CONbits.TCKPS = 0x3;		/* 1:256 prescaler */
	T2CONbits.TON = 1;			/* start timer */

	// initialize TMR3
	// TMR3 is configured for TSAMPLE clicks to count time for IR signal generation
	// with the prescaler at 8x the cycles are 0.271 us
	// TSAMPLE is 4.069 us, so every TSAMPLE requires 15 TMR3 cycles (TFACTOR)
	T3CON = 0;
	T3CONbits.TCKPS = 0x1;		/* 1:8 prescaler */
	T3CONbits.TON = 1;			/* start timer */

	// initializes the ADC
	ADC_init();

	// initializes the UART
	UARTinit();

} // init

// start sampling process
inline void StartSampling(void)
{
	// set sampling flag
	sampling = SAMPLING_ON;

	// clear the ADC interrupt flag
    IFS0bits.ADIF = 0;

	// enable interrupts
	EnableIntADC;

	// start auto sampling
	ADCON1bits.ASAM = 1;
}

// stop sampling process
inline void StopSampling(void)
{
	// stop auto sampling */
	ADCON1bits.ASAM = 0;

	// disable interrupts
	DisableIntADC;

	// clear the ADC interrupt flag
    IFS0bits.ADIF = 0;

	// clear sampling flag
	sampling = SAMPLING_OFF;
}


// ADC interrupt handler: read the ADC result into the corresponding buffer block
// this requires at least -O1 optimization and loop unroll
void _ISR _ADCInterrupt(void)
{
	int i;
	fractional *dst;

	// if sampling is disabled and an interrupt arrived, signal error
	if (!sampling) {
		StopSampling();
		IFS0bits.ADIF = 0;
		while (1) {
			// turn on debug LED
			LED0 = 1;
			// turn off debug LED
			LED0 = 0;
		}
	}
	
	// read the 16 ADC buffer positions and copy them to the ADC buffer
	dst = adc_buffer;
	for (i = 0; i < 16; ++i)
		*dst++ = *((fractional *)&ADCBUF0+i);

	// ADC block is filled, then signal the IIR process
	fsm = FSM_STATE_BP_IIR;
	sampling = SAMPLING_OFF;			/* this is for security: if the interrupt arrives */
										/* before IIR process is ready, a fault is detected */

	// clear the ADC interrupt flag
    IFS0bits.ADIF = 0;

} // _ADCInterrupt

// bp_filter
// band-pass IIR filter for wideband IR decoding.  This IIR will pass the band from 30 KHz to 80 KHz
inline void bp_filter(void)
{
	// call IIR filter
	IIRTransposed(MAX_ADC_BUFFER, output, adc_buffer, &bp_iirFilter);

	// restart capture
	sampling = SAMPLING_ON;
	fsm = FSM_STATE_GET_RAW;
}

// reset IR decoding
inline void ResetIRDecoding(void)
{
	overflow = 0;						// no buffer overflow
	raw_pos = 0;						// initialize capture index in raw array
	bits = 0;							// initialize decoded bits
	nbits = 0;							// initialize number of bits
	gap = 0;							// set gap time
	count = 0;							// samples counter

	// initialize minimum and maximum timings for 0s and 1s
	high_max = low_max = 0;
	high_min = low_min = 65535;
	high2_max = low2_max = 0;
	high2_min = low2_min = 65535;

	// initialize start timings
	start_high = start_low = 0;

	// set capture state
	counting = IR_IDLE;

	// reset event counter
	event = 0;

	// reset freq measuring
	event_freq = 0;

	// reset protocol
	protocol = 0;
}

// get_raw_signal
// rectify the digital signal and perform the low-high timings on it
void get_raw_signal(void)
{
	unsigned char i;
	unsigned char f;
	
	// continue capturing if the IR signal is not completely received
	fsm = FSM_STATE_CAPTURE;

	// check if energy in the pass band
	// test that two consecutive absolute value of samples exceeds threshold
	for (i = 0; i < MAX_ADC_BUFFER; ++i) {
		// check if threshold exceeded
		f = ((int)output[i] > THRESHOLD_LEVEL)?1:0;
		// count the number of last zero events
		if (f) zeros = 0; else ++zeros;
		// remember number of threshold exceeded, if one event exceeds threshold 
		// in a EVENT_N event window then signal energy (this is like a bitwise low pass filter)
		event = (event << 1 | f);

		if (event & EVENT_MASK) {
			// output signal for debugging
			DEBUG_OUT = 1;

			// count high signal
			count_high();

			// capture event bitmap for frequency detection
			// this capture ocurrs when a 01 transition is detected twice
			if (!event_freq && (event&0xfffc) && (event&0x03) == 0x01)
				event_freq = event;

		} else {
			// output signal for debugging
			DEBUG_OUT = 0;

			// count low signal
			count_low();

		} /* if sum */
	} /* for */
} /* get_raw_signal */


/*
 * count_high: measure samples while in high
 *
 */
inline void count_high(void)
{
	// if this is the start of a IR burst
	if (counting != IR_HIGH_DETECTED) {
		// if detecting gap
		if (counting == IR_MEASURING_GAP) {
			// save gap timing
			gap = count;
			// stop sampling
			StopSampling();
			// mark end in raw buffer
			raw[raw_pos] = 0x7FFF;
			// change couting status
			counting = IR_END;
			// translate command
			fsm = FSM_STATE_IR_DECODE;
			return;

		} else if (counting == IR_LOW_DETECTED){
			// check maximum/minimum if not in the start bit
			if (raw_pos > 1) {
				if (count > low_max) { low2_max = low_max; low_max = count; }
				if (count < low_min) { low2_min = low_min; low_min = count; }
			} else {
				// if it is save the start length
				start_low = count;
			}
			// store low count in array
			if (raw_pos < MAX_TRANSITIONS-1)
				raw[raw_pos++] = count;
			else
				overflow = 1;
		}
			
		// start timing:
		// timing just counts the samples at TSAMPLE us each
		count = 1;
		counting = IR_HIGH_DETECTED;

	} else { /* counting == IR_HIGH_DETECTED */
		// count samples at high
		++count;
	}

} /* count_high */


/*
 * count_low: measure samples while in low
 *
 */
inline void count_low(void)
{
	// if this is the end of a IR burst
	if (counting == IR_HIGH_DETECTED) {
		// compensate for event filter
		count -= zeros;
		// check maximum/minimum if not the start bit
		if (raw_pos > 0) {
			if (count > high_max) { high2_max = high_max; high_max = count; }
			if (count < high_min) { high2_min = high_min; high_min = count; }
		} else {
			// if it is save the start length
			start_high = count;
		}

		// store samples at high
		if (raw_pos < MAX_TRANSITIONS-1)
			raw[raw_pos++] = (0x8000|count);
		else
			overflow = 1;

		// start low timing:
		// timing just counts the samples at TSAMPLE us each
		// adjust for event window
		count = zeros;
		counting = IR_LOW_DETECTED;

	} else if (counting == IR_LOW_DETECTED) {
		// count samples at low
		++count;

		// if too much in low while sensing IR commands (i.e more than 5 ms), end IR detection
		if (count > (MAX_TRAILING_BLANK/TSAMPLE)) {
			// if in learning mode, set flag to measure gap
			if (mode == LEARNING) {
				counting = IR_MEASURING_GAP;
				return;
			}
			// stop sampling
			StopSampling();
			// mark end in raw buffer
			raw[raw_pos] = 0x7FFF;
			// change couting status
			counting = IR_END;
			// translate command
			fsm = FSM_STATE_IR_DECODE;
			return;
		}

	// if gap is too much, this command doesn't repeat
	} else if (counting == IR_MEASURING_GAP) {
		// count samples at low
		++count;

		// exceeded gap?
		if (count > (MAX_GAP/TSAMPLE)) {
			gap = NO_GAP;
			// stop sampling
			StopSampling();
			// mark end in raw buffer
			raw[raw_pos] = 0x7FFF;
			// change couting status
			counting = IR_END;
			// translate command
			fsm = FSM_STATE_IR_DECODE;
			return;
		}
	}
} /* count_low */


/*
 * measure_freq
 *   analyzes the event_freq bitmap and counts the samples between 01 transitions
 *   returns an approximation of the frequency in KHz
 *
 */

int measure_freq(void)
{
	int c, f;
	unsigned int e = event_freq;

	// check 01 transitions and count bits between them
	// each bit is a sample interval (~4 us)
	// at the end c has the period in step of 4 us
	for (c = f = 0; e; ++c, e = e>>1) {
		if ((e & 0x0003) == 0x0001) {
			if (!f) { c = 0; f = 1; }
			else break;
		}
	}

	if (c == 0) return 0;

	// get KHz f = 1000/period = (250*4)/(4*c) = 250/c
	return (250/c);
}

/*
 * decode:
 *   analyzes the timing and decodes the IR signal into an IR command according
 *   to a protocol
 *
 */
void decode(void)
{
	int ok;

	// if # of bits < 3, ignore command
	if (raw_pos < 6) {
		fsm = FSM_STATE_START;
		return;
	}

	// fix second to last high levels
	if (high2_max == 0) high2_max = high_max;
	if (high2_min == 65535) high2_min = high_min;
	if (low2_max == 0) low2_max = low_max;
	if (low2_min == 65535) low2_min = low_min;

	// decode signal
	freq = measure_freq();

	// check IR protocol

	// first, look for biphase protocols
	if (compare(start_high,FROM_US(2666)) && compare(start_low,FROM_US(889)))
		protocol = IR_PROTO_RC6|IR_ENCODING_BI;
	else if (compare(start_high,FROM_US(500)) && 
		     (compare(start_low,FROM_US(2500)) || compare(start_low,FROM_US(3000))))
		protocol = IR_PROTO_NRC17|IR_ENCODING_BI;
	else if (compare(start_high,FROM_US(889)) && compare(start_low,FROM_US(889)))
		protocol = IR_PROTO_RC5|IR_ENCODING_BI;

	// check for PW protocol
	else if (compare(start_high,FROM_US(2400)) && compare(start_low,FROM_US(480)))
		protocol = IR_PROTO_SIRC|IR_ENCODING_PW;
	else if (compare(start_high,FROM_US(4000)) && compare(start_low,FROM_US(4000)))
		protocol = IR_PROTO_RCA|IR_ENCODING_PW;

	// check for PD protocol
	else if (in_range(start_high,FROM_US(8400),FROM_US(9000)) && compare(start_low,FROM_US(4200)))
		protocol = IR_PROTO_JVCNEC|IR_ENCODING_PD;
	else if (compare(start_high,FROM_US(320)) && 
		     (compare(start_low,FROM_US(1680)) || compare(start_low,FROM_US(680))))
		protocol = IR_PROTO_SHARP|IR_ENCODING_PD;

	// if still unknown, check for generic protocols
	else if ((protocol&IR_PROTO_MASK) == IR_PROTO_UNKNOWN) {
		// pulse distance
		if (compare(high2_max,high2_min))
			protocol = IR_PROTO_PD|IR_ENCODING_PD;
		else if (compare((high2_max+low2_min),(high2_min+low2_max)))
			protocol = IR_PROTO_PW|IR_ENCODING_PW;
	}

	// process the corresponding protocol and fill the output structure
	ok = 0;
	switch (protocol&IR_ENCODING_MASK) {
		case IR_ENCODING_PW:	process_pw(); ok = 1; break;
		case IR_ENCODING_PD:	process_pd(); ok = 1; break;
		case IR_ENCODING_BI:	process_bi(); ok = 1; break;
		default: break;
	}

	// if ok then fill structures for output
	if (ok == 1) {
		// if sensing and enough buffer, queue it
		if (mode == SENSING && ir_buf_n < IRFIFO_LEN) {
			IRevent *p = &irfifo[ir_buf_last];
			p->status = UIRCS_RES_IREVENT;
			p->proto = protocol;
			p->freq = freq;
			p->nbits = nbits;
			p->bits = bits;
			ir_buf_last = (ir_buf_last+1)%IRFIFO_LEN;
			++ir_buf_n;
		}

		// if in learn mode, fill learn structure and stop
		if (mode == LEARNING) {
			IRlearn *p = &ir_learn_evt;
			p->status = UIRCS_RES_IRLEARN;
			p->proto = protocol;
			p->freq = freq;
			p->nbits = nbits;
			p->bits = bits;
			p->flags = 0;
			p->start_high = start_high; 
			p->start_low = start_low;
			p->high_max = high2_max;
			p->high_min = high_min;
			p->low_max = low2_max;
			p->low_min = low_min;
			p->gap = gap;

			// set mode to idle to leave time to transmit
			mode = LEARNING_OK;
		}
	}

	// restart
	fsm = FSM_STATE_START;
}

/*
 * process_pw:
 *   analyze the raw IR data and decode a Pulse Width Modulated signal
 *   this is a LSB-MSB protocol (i.e. LSB comes first)
 *      logic 1 is when the IR signal goes high for high2_max
 *      logic 0 is when the IR signal goes high for high2_min
 *
 */
void process_pw(void)
{
	int i;
	unsigned char f;
	unsigned int m;
	unsigned long next;

	bits = 0;
	nbits = 0;
	next = 1;
	// check if error mode: if start bit == high bit there is another start bit in the
	// middle of the stream, in this case protocol repeats at high_max
	f = ((protocol&IR_PROTO_MASK) == IR_PROTO_PW) && compare(start_high, high_max);
	// skip start bit and get data
	for (i = 2; i < raw_pos; ++i) {
		m = raw[i];
		if (m&0x8000) {
			// if two sequences were sent then ignore the second part
			if (f && compare(m&0x7FFF, high_max))
				break;
			// is it a logic 1?
			if (compare(m&0x7FFF, high2_max))
				bits |= next;
			next <<= 1;
			++nbits;
		}
	}
}

/*
 * process_pd:
 *   analyze the raw IR data and decode a Pulse Distance Modulated signal
 *      logic 1 is detected when the low signal is low2_max
 *      logic 0 is detected when the low signal is low2_min
 *
 *   this routine is able to process generic PD or SHARP/RCA protocols.  If
 *   a SHARP protocol is analyzed, the start bit is ignored.  If a RCA protocol
 *   is analyzed, the order of the bits is reversed (RCA is MSB-LSB).  RCA is
 *   also a 12 bits protocol.
 *
 */
void process_pd(void)
{
	int i;
	unsigned char rca;
	unsigned int m;
	unsigned long next;

	bits = 0;
	nbits = 0;
	next = 1;
	// set the start of the analysis
	// if sharp protocol, there is no start bit
	i = ((protocol&IR_PROTO_MASK) == IR_PROTO_SHARP)?0:2;
	// check if rca
	rca = ((protocol&IR_PROTO_MASK) == IR_PROTO_RCA);
	for (; i < raw_pos; ++i) {
		m = raw[i];
		// is it a logic 1?
		if ((m&0x8000) == 0) {
			if (compare(m&0x7FFF, low_max))
				bits |= next;
			if (rca)
				// rca is MSB-LSB
				bits <<= 1;
			else
				// the rest are LSB-MSB
				next <<= 1;
			++nbits;
			if (rca && nbits == 12)
				break;
		}
	}
}

/*
 * process_bi:
 *   analyze the raw IR data and decode a Bi-phase Modulated signal
 *      logic 1 is a high to low transition at the clock cross
 *      logic 0 is a low to high transition at the clock cross
 *
 *   this routine currently processes RC5 and NRC17 only.  RC6 is much more
 *   complicated and it is not currently decoded, only recognized.
 *
 */
void process_bi(void)
{
	int i;
	unsigned long next;
	unsigned int blh;			/* bit length/2 */
	unsigned int st;			/* sample time */
	unsigned int t;				/* the current time */
	char b;						/* the current signal value */
	char b0;					/* the previous signal value */
	unsigned char nrc17;		/* NRC17 protocol */
	unsigned char rc5;			/* RC5 protocol */

	bits = 0;
	nbits = 0;
	next = 1;

	nrc17 = ((protocol&IR_PROTO_MASK) == IR_PROTO_NRC17);
	rc5 = ((protocol&IR_PROTO_MASK) == IR_PROTO_RC5);

	// first, get the clock timing:
	// if rc5 get the first bit size
	if (rc5)
		blh = (start_high+start_low)/2;
	else {
		// sum high_min and low_min. This will result in the bit length, which
		// in turns determines the sample frequency for biphase coding.
		// The blh value is half of the bit length in sample units
		blh = (high_min+low_min)/2;
	}

	// skip start bits if RC-6 or NRC-17
	i = 0;
	if (nrc17 || (protocol&IR_PROTO_MASK) == IR_PROTO_RC6)
		i = 2;

	// start sampling at 1/4 of bit and then every half of bit and compare
	t = (raw[i]&0x7fff);
	st = blh/2;
	b0 = -1;
	if (rc5) b0 = 0;
	b = (raw[i]&0x8000)?1:0;
	while (i <= raw_pos) {
		if (nrc17 && nbits == 17) break;
		if (rc5 && nbits == 14) break;
		if (st < t) {
			if (b0 == -1) {
				b0 = b;
			} else {
				if (nrc17) {
					if (b0 == 1 && b == 0)
						bits |= next;
					next <<= 1;
				} else if (rc5) {
					bits <<= 1;
					if (b0 == 0 && b == 1)
						bits |= 1;
				}
				++nbits;
				b0 = -1;
			}
			st += blh;
		} else {
			t += raw[++i]&0x7FFF;
			b = (raw[i]&0x8000)?1:0;
		}
	}

	// if NRC17 ignore start bit which is always one
	if (nrc17) {
		bits >>= 1;
		--nbits;

	// if RC5 clear start bits
	} else if (rc5) {
		bits &= 0x0fff;			// 12 bits
		nbits -= 2;
	}		
}


/*
 * send_pw
 *   send a Pulse Width IR command
 *
 */
int send_pw(IRlearn *ir)
{
	int nbits;
	unsigned long bits;

	// set the frequency
	PWMsetFreq(ir->freq);

	// send the start bit
	IRpulse(1, ir->start_high);
	IRpulse(0, ir->start_low);

	// send the bits, PW is LSB-MSB
	bits = ir->bits;
	for (nbits = ir->nbits; nbits > 0; --nbits) {
		if (bits&0x0001) {
			// send a PW logic 1
			IRpulse(1, ir->high_max);
			IRpulse(0, ir->low_min);
		} else {
			// send a PW logic 0
			IRpulse(1, ir->high_min);
			IRpulse(0, ir->low_min);
		}
		bits >>= 1;
	}

	// wait for gap
	IRpulse(0, ir->gap);

	return 1;
}


/*
 * send_pd:
 *   send a Pulse Distance IR command
 *
 */
int send_pd(IRlearn *ir)
{
	int nbits;
	unsigned long bits, mask;
	unsigned char rca;

	// set the frequency
	PWMsetFreq(ir->freq);

	// check if RCA protocol
	rca = ((protocol&IR_PROTO_MASK) == IR_PROTO_RCA);

	// send start bit
	if ((ir->proto&IR_PROTO_MASK) != IR_PROTO_SHARP) {
		// send the start bit
		IRpulse(1, ir->start_high);
		IRpulse(0, ir->start_low);
	}

	// send the bits
	bits = ir->bits;
	mask = 1 << (ir->nbits-1);
	for (nbits = ir->nbits; nbits > 0; --nbits) {
		if (rca) {		// RCA is MSB-LSB
			if (bits&mask) {
				// send a PD logic 1
				IRpulse(1, ir->high_min);
				IRpulse(0, ir->low_max);
			} else {
				// send a PD logic 0
				IRpulse(1, ir->high_min);
				IRpulse(0, ir->low_min);
			}
			mask >>= 1;
		} else {
			// LSB-MSB
			if (bits&1) {
				// send a PD logic 1
				IRpulse(1, ir->high_min);
				IRpulse(0, ir->low_max);
			} else {
				// send a PD logic 0
				IRpulse(1, ir->high_min);
				IRpulse(0, ir->low_min);
			}
			bits >>= 1;
		}
	}

	// wait for gap
	IRpulse(0, ir->gap);

	return 1;
}


/*
 * send_bi:
 *   send a Biphase IR command.  Only RC5 and NRC17 are supported at this time
 *
 */
int send_bi(IRlearn *ir)
{
	int nbits;
	unsigned long bits, mask;
	unsigned int blh;			/* bit length/2 */
	unsigned char nrc17;		/* NRC17 protocol */
	unsigned char rc5;			/* RC5 protocol */

	// check the protocol
	nrc17 = ((ir->proto&IR_PROTO_MASK) == IR_PROTO_NRC17);
	rc5 = ((ir->proto&IR_PROTO_MASK) == IR_PROTO_RC5);

	// first, get the clock timing:
	// if rc5 get the first bit size
	if (rc5)
		blh = (ir->start_high+ir->start_low)/2;
	else {
		// sum high_min and low_min. This will result in the bit length, which
		// in turns determines the sample frequency for biphase coding.
		// The blh value is half of the bit length in sample units
		blh = (ir->high_min+ir->low_min)/2;
	}

	// set the frequency
	PWMsetFreq(ir->freq);

	// send start bit if NRC-17
	if (nrc17) {
		// send the pre-pulse
		IRpulse(1, ir->start_high);
		IRpulse(0, ir->start_low);
		// send the start pulse
		IRpulse(1, blh);
		IRpulse(0, blh);
	}

	// send the bits
	bits = ir->bits;
	mask = 1 << (ir->nbits-1);
	for (nbits = ir->nbits; nbits > 0; --nbits) {
		if (rc5) {		// RC5 is MSB-LSB
			if (bits&mask) {
				// send a manchester logic 1
				IRpulse(0, blh);
				IRpulse(1, blh);
			} else {
				// send a manchester logic 0
				IRpulse(1, blh);
				IRpulse(0, blh);
			}
			mask >>= 1;
		} else {
			// NRC17 is LSB-MSB
			if (bits&1) {
				// send a NRC17 manchester logic 1
				IRpulse(1, blh);
				IRpulse(0, blh);
			} else {
				// send a NRC17 manchester logic 0
				IRpulse(0, blh);
				IRpulse(1, blh);
			}
			bits >>= 1;
		}
	}

	// wait for gap
	IRpulse(0, ir->gap);

	return 1;
}



// ----- UART Support Routines -------------------------------------------

#define UART_RX_BUF_LEN		32				// receive circular buffer

volatile int rx_nbytes;						// number of bytes in rx buffer
volatile int tx_nbytes;						// number of bytes to transmit

unsigned char rx_buffer[UART_RX_BUF_LEN];	// receive circular buffer
volatile int rx_enter, rx_exit;				// rx circular buffer pointers
volatile unsigned char *tx_pos;				// UART transmit buffer pointer



/* initialize UART port */
void UARTinit(void)
{
	// initialize UART1
	// configure it (enable, alternate I/O, wake up, 8N1)
	OpenUART1(UART_EN & UART_IDLE_CON & UART_ALTRX_ALTTX & UART_DIS_WAKE &
	             UART_DIS_LOOPBACK & UART_EN_ABAUD & UART_NO_PAR_8BIT & UART_1STOPBIT,
	          UART_INT_TX_BUF_EMPTY & UART_TX_PIN_NORMAL & UART_TX_ENABLE &
	             UART_INT_RX_CHAR & UART_ADR_DETECT_DIS & UART_RX_OVERRUN_CLEAR,
	          BAUD_FACTOR);
	ConfigIntUART1(UART_RX_INT_EN & UART_RX_INT_PR1 & UART_TX_INT_EN & UART_TX_INT_PR1);

	// reset number of bytes in counters
	rx_nbytes = tx_nbytes = 0;

	// reset circular buffer pointers
	rx_enter = rx_exit = 0;

	// clear interrupt flags
	IFS0bits.U1RXIF = 0;
	IFS0bits.U1TXIF = 0;
}

/* check if byte ready */
inline char UARTdataRdy(void)
{
	return (rx_nbytes > 0);	
}

/* read UART byte: blocks until data is ready */
inline unsigned char UARTread(void)
{
	unsigned char c;

	while (!rx_nbytes);
	DisableIntU1RX;
	c = rx_buffer[rx_exit];
	rx_exit = (rx_exit+1)%UART_RX_BUF_LEN;
	--rx_nbytes;
	EnableIntU1RX;

	return c;
}

/*
 * read a block from UART
 *   timeout is in milliseconds.  Set to zero if timeout not required
 */
int UARTreadBlock(unsigned char *buffer, int len, int timeout)
{
	int i;
	unsigned int t;

	// convert milliseconds to clicks
	t = TO_TMR2_CLICKS(timeout);

	// read bytes with timeout
	TMR2 = 0;
	for (i = 0; i < len && (timeout == 0 || TMR2 < t); ++i)
		buffer[i] = UARTread();

	return (i == len)?1:0;
}

/* check if writing */
int UARTwriteBusy(void)
{
	int rc = 0;

	DisableIntU1TX;
	if (tx_nbytes || BusyUART1())
		rc = 1;
	EnableIntU1TX;

	return rc;
}

/* write byte to UART */
void UARTwrite(unsigned char c)
{
	// wait for last transmission
	while (tx_nbytes || BusyUART1());

	WriteUART1((int)c);
}

/* write a block to UART */
void UARTwriteBlock(unsigned char *buffer, int len)
{
	// wait for last transmission
	while (tx_nbytes || BusyUART1());

	// disable TX interrupts
	DisableIntU1TX;

	// set transmit variables
	tx_pos = buffer;
	tx_nbytes = len-1;

	// enable TX interrupts
	EnableIntU1TX;

	// start transmission
	WriteUART1(*tx_pos++);
}

/* UART receive interrupt routine */
void _ISR _U1RXInterrupt(void)
{
	// received byte into the circular buffer
	if (rx_nbytes < UART_RX_BUF_LEN) {
		rx_buffer[rx_enter] = (U1RXREG&0xff);
		rx_enter = (rx_enter+1)%UART_RX_BUF_LEN;
		++rx_nbytes;
	}

	// clear UART receive interrupt flag
	IFS0bits.U1RXIF = 0;
}

/* UART transmit interrupt routine */
void _ISR _U1TXInterrupt(void)
{
	if (tx_nbytes) {
		WriteUART1(*tx_pos++);
		--tx_nbytes;
	}

	// clear UART transmit interrupt flag
	IFS0bits.U1TXIF = 0;
}

// Delay routine
// time is in ms
void DelayMs(unsigned int time)
{
	// convert the time to TMR2 clicks
	time = TO_TMR2_CLICKS(time);

	// reset TMR2
	TMR2 = 0;

	// wait required time
	while (TMR2 < time);
}



// ----- PWM Support Routines --------------------------------------------

/* initialize the PWM3 */
void PWMinit(void)
{
	PWMCON1 = 0;							// all PORTE ports as digital
	PWMCON1bits.PMOD3 = 1;					// set PWM3 to independent mode
	PTCONbits.PTMOD = 2;					// set timebase in a continous up/down counting mode
}

/* set PWM3 frequency (freq is in KHz) */
void PWMsetFreq(unsigned int freq)
{
	PTPER = PWM_PTPER(freq*1000);			// set timebase frequency
	PDC3  = 0;								// stop PWM3
	PTMR  = 0;								// reset counter
	PTCONbits.PTEN = 1;						// enable time base
	PWMCON1bits.PEN3H = 1;					// enable PWM3H
}

/*
 * send an PWM IR pulse
 *    logic, if 1 the pulse is actually sent
 *    time is in TSAMPLE units 
 */
void IRpulse(unsigned char logic, unsigned int time)
{
	// convert the time to TMR3 clicks
	time *= TFACTOR;

	// reset TMR3
	TMR3 = 0;

	// start PWM
	if (logic) pwm_start;

	// wait required time
	while (TMR3 < time);

	// stop PWM
	pwm_stop;
}


// EOF: UIRC.c
