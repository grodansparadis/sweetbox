// Circuit Cellar Microchip 16-bit Embedded Control Design Contest
// Project: MT2210 - UIRC: The Ultimate IR Controller
// Components:  dsPIC30F3010   - UIRC Sensor
//              PIC24FJ64GA002 - UIRC Control
//
// Bonus parts: MCP6022, ENC28J60, 24LC512
//
//***********************************************************************/
// UIRC: Ultimate IR Controller                                          /
//       (c) 2007 by its author, all rights reserved.                    /
//                                                                       /
// The UIRC is a generic IR sensor for all kinds of modulated IR remote  /
// control protocols.  It learns and replays IR commands controlled by a /
// master microcontroller.                                               /
//                                                                       /
// FILE: UIRC-Eth.c                                                      /
//    Ethernet interface for UIRC (PIC24FJ)                              /
//                                                                       /
// version:                                                              /
//    0.01:  08/27/07 - start coding                                     /
//    0.02:  09/02/07 - merged TCP/IP stack                              /
//    0.03:  09/03/07 - tested ICMP ok                                   /
//    0.04:  09/03/07 - fixed I2CEEPROM.c for I2C communication          /
//                      (TCP IP stack version 4.02)                      /
//                    - successfully started HTTP and FTP from/to EEPROM /
//    0.10:  09/10/07 - configured UART for UIRC Sensor communication    /
//    0.80:  09/23/07 - started interface with UIRC Sensor               /
//    0.90   10/06/07 - finished new UART interrupt routines             /
//    0.91   10/07/07 - programmed IR event queue                        /
//    1.00   10/08/07 - interfaced with UIRC complete                    /
//           10/09/07 - started ethernet interface                       /
//                                                                       /
//***********************************************************************/
//
// Pinout Mapping:
//   (configured in HardwareProfile.h and Init())
//
//   ENC28J60 (SPI1)
//		SDI1    -> RP9		SPI 1 Data Input
//		SDO1    -> RP8		SPI 1 Data Output
//		SCK1OUT -> RP7		SPI 1 Clock Output
//      CS      -> RB12		ENC28J60 Chip Select 
//
//   24LC512 (I2C1)
//		SDA2	-> RB2		I2C SDA (alternate)
//		SCL2	-> RB3		I2C SCL (alternate)		
//
//   UIRC Sensor (UART2)
//      U2ATX   -> RP5		UART2 Transmit
//      U2ARX   -> RP6      UART2 Receive
//      RESET   -> RP15		UIRC Sensor Reset (0 for 100 ms and tristate)
//


#include <p24FJ64GA002.h>

#include "UIRC.h"
#include <string.h>
#include <stdlib.h>

// PIC configuration
// enable JTAG, configure ICS for PGx2 (same as ICP) and disable WDT
_CONFIG1(JTAGEN_OFF & GCP_OFF & GWRP_OFF & BKBUG_OFF & COE_OFF & ICS_PGx2 & FWDTEN_OFF);
// run through internal oscillator at 8 MHz and activate PLLx4 for 32 MHz
// configure I2C1 to secondary pins (14 & 15)
_CONFIG2(IESO_OFF & FNOSC_FRCPLL & FCKSM_CSDCMD & OSCIOFNC_OFF & IOL1WAY_ON & I2C1SEL_SEC & POSCMOD_NONE);

// define constants for PIC24 configuration
#define XTFREQ			8000000ul				// define internal clock frequency
#define PLLMODE			4					// define on-chip PLL setting
#define FCY             XTFREQ*PLLMODE/2	// instruction cycle frequency

// define UART BAUD rate
#define UART_BAUD		(19200ul)
#define	BAUD_FACTOR		((FCY)/(16*UART_BAUD)-1)


// ----- TCP/IP stack configuration begin
/*
 * Following define uniquely defines this file as main
 * entry/application In whole project, there should only be one such
 * definition and application file must define AppConfig variable as
 * described below.
 */
#define THIS_IS_STACK_APPLICATION

#define BAUD_RATE       UART_BAUD	// bps


// These headers must be included for required defs.
#include "TCPIP Stack/TCPIP.h"

// This is used by other stack elements.
// Main application must define this and initialize it with proper values.
APP_CONFIG AppConfig;
BYTE AN0String[8];

// ----- TCP/IP stack configuration end

//#include "IR-EEPROM.h"

// forward references
static void Init(void);
static void InitAppConfig(void);
static void FormatNetBIOSName(BYTE Name[]);
static void ConnectionTask(void);
static void ProcessIO(void);
static int process_command(char *cmd);
#if defined(MPFS_USE_EEPROM) && defined (STACK_USE_MPFS)
static void SaveAppConfig(void);
#endif

// Serial Support
static void SerInit(void);
static int SerDataReady(void);
static unsigned char SerRead(void);
static void SerWrite(unsigned char *buffer, int nbytes);
static int SerReadBlock(unsigned char *buffer, int len);

// UIRCS
static void ResetUIRC(void);
static void ReleaseUIRC(void);
static void UIRCSinit(void);
static unsigned char UIRCctl(unsigned char cmd);
static void ReadIREvent(void);



// ----- Constants

// debug LED (one second tick)
#define LED0_IO		(PORTAbits.RA0)



// ----- IR system variables

#define MAX_IR_EVENTS			8			// IR event circular buffer size

IRevent ir_array[MAX_IR_EVENTS];			// IR event circular buffer
unsigned char ir_n_events;					// number of IR events in buffer
unsigned char ir_pos_enter;					// enter pointer for ir
unsigned char ir_pos_exit;					// exit pointer for ir

IRlearn irlrn;								// IR learn event





// ----- Main code

// main
int main(void)
{
	static TICK t = 0;

	// initializes clock and I/O
	Init();

	// initizalize UIRCS communications
	UIRCSinit();

	// Initialize all stack related components.
	TickInit();

#if defined(STACK_USE_MPFS)
	// Initialize Microchip File System module
	MPFSInit();
#endif

	// Initialize Stack and application related NV variables into AppConfig.
	InitAppConfig();

	// Initialize core stack layers (MAC, ARP, TCP, UDP)
	StackInit();

#if defined(STACK_USE_HTTP_SERVER)
	HTTPInit();
#endif

#if defined(STACK_USE_FTP_SERVER) && defined(MPFS_USE_EEPROM) && defined(STACK_USE_MPFS)
	FTPInit();
#endif

#if defined(STACK_USE_DHCP_CLIENT) || defined(STACK_USE_IP_GLEANING)
	if(!AppConfig.Flags.bIsDHCPEnabled) {
#if defined(STACK_USE_DHCP_CLIENT)
		DHCPDisable();
#endif
	}
#endif

	// Once all items are initialized, go into infinite loop and let
	// stack items execute their tasks.
	// If application needs to perform its own task, it should be
	// done at the end of while loop.
	// Note that this is a "co-operative mult-tasking" mechanism
	// where every task performs its tasks (whether all in one shot
	// or part of it) and returns so that other tasks can do their
	// job.
	// If a task needs very long time to do its job, it must be broken
	// down into smaller pieces so that other tasks can have CPU time.
	while(1) {
		// Blink LED0 (right most one) every second.
		if(TickGet() - t >= TICK_SECOND/2) {
			t = TickGet();
			LED0_IO ^= 1;
		}
		// This task performs normal stack task including checking
		// for incoming packet, type of packet and calling
		// appropriate stack entity to process it.
		StackTask();

#if defined(STACK_USE_HTTP_SERVER)
		// This is a TCP application.  It listens to TCP port 80
		// with one or more sockets and responds to remote requests.
		HTTPServer();
#endif

#if defined(STACK_USE_FTP_SERVER) && defined(MPFS_USE_EEPROM) && defined(STACK_USE_MPFS)
		FTPServer();
#endif

#if defined(STACK_USE_ANNOUNCE)
		DiscoveryTask();
#endif

#if defined(STACK_USE_NBNS)
		NBNSTask();
#endif

#if defined(STACK_USE_DHCP_SERVER)
		DHCPServerTask();
#endif

#if defined(STACK_USE_GENERIC_TCP_CLIENT_EXAMPLE)
		GenericTCPClient();
#endif

#if defined(STACK_USE_GENERIC_TCP_SERVER_EXAMPLE)
		GenericTCPServer();
#endif

#if defined(STACK_USE_TELNET_SERVER)
		TelnetTask();
#endif

#if defined(STACK_USE_SMTP_CLIENT)
		SMTPTask();
		SMTPDemo();
#endif

#if defined(STACK_USE_ICMP_CLIENT)
		PingDemo();
#endif

		// Process IR events:
		ProcessIO();

		// Invoke TCP connection task
		ConnectionTask();
	}
}

#define SERVER_PORT	10000

/*
 * ConnectionTask
 *   process a TCP connection task.  This code is a modified version 
 *   from GenericTCPServer.c
 *
 */
void ConnectionTask(void)
{
	BYTE i;
	WORD w2;
	BYTE input_buffer[64], output_buffer[64];
	WORD wMaxGet, wMaxPut, wCurrentChunk;
	static TCP_SOCKET MySocket;
	static enum _TCPServerState
	{
		SM_HOME = 0,
		SM_LISTENING,
	} TCPServerState = SM_HOME;
	IRevent *ire;

	switch(TCPServerState)
	{
		case SM_HOME:
			// Allocate a socket for this server to listen and accept connections on
			MySocket = TCPListen(SERVER_PORT);
			if(MySocket == INVALID_SOCKET)
				return;

			TCPServerState = SM_LISTENING;
			break;

		case SM_LISTENING:
			// See if anyone is connected to us
			if(!TCPIsConnected(MySocket)) {
				// no one connected, clear last event
				if (ir_n_events > 0) {
					ir_pos_exit = (ir_pos_exit+1)%MAX_IR_EVENTS;
					--ir_n_events;
				}
				return;
			}

			// clean output_buffer
			input_buffer[0] = '\0';

			// connected, check if a IR event is pending
			if (ir_n_events > 0) {
				// transfer next event to socket
				// format E:PROTO:FREQ:NBITS:BITS
				ir_pos_exit = (ir_pos_exit+1)%MAX_IR_EVENTS;
				ire = &ir_array[ir_pos_exit];
				sprintf(output_buffer, "E:%02x:%02d:%02d:%08lx\n", ire->proto,
				        ire->freq, ire->nbits, ire->bits);
				--ir_n_events;

				// send to socket
				TCPPutArray(MySocket, output_buffer, strlen(output_buffer));
			}

			// send command to IR sensor?
			
			// Figure out how many bytes have been received
			wMaxGet = TCPIsGetReady(MySocket);	// Get TCP RX FIFO byte count
			wMaxPut = TCPIsPutReady(MySocket);	// Get TCP TX FIFO free space

			if (wMaxGet > 0) {
				// read the available bytes into the input_buffer
				wCurrentChunk = sizeof(input_buffer)-1;
				if (wMaxGet < wCurrentChunk) wCurrentChunk = wMaxGet;
				
				// Transfer the data out of the TCP RX FIFO and into our local processing buffer.
				TCPGetArray(MySocket, input_buffer, wCurrentChunk);
				// finish array
				input_buffer[wCurrentChunk] = '\0';
				
				// Perform the "ToUpper" operation on each data byte
				for(w2 = 0; w2 < wCurrentChunk; w2++) {
					i = input_buffer[w2];
					if(i >= 'a' && i <= 'z') {
						i -= ('a' - 'A');
						input_buffer[w2] = i;
					}
				}
		
				// process command
				wCurrentChunk = process_command(input_buffer);
	
				// Transfer the data out of our local processing buffer as echo/error
				TCPPutArray(MySocket, input_buffer, wCurrentChunk);
			}
	
			// flush
			TCPFlush(MySocket);
			break;
	}
}


/*
 * ProcessIO
 *   process local tasks.  This code checks the UIRC and receives any
 *   pending event
 */
void ProcessIO(void)
{
	unsigned char res;

	// check if there is a pending IR event
	if (SerDataReady()) {
		// read status
		res = SerRead();

		// check status
		if (res_code(res) == UIRCS_RES_IREVENT) {
			// read event into circular buffer
			ReadIREvent();
		}
	}
}

/*
 * Process a command
 *
 */
int process_command(char *cmd)
{
	unsigned char c;

	// the only command recognized is C:PROTO:FREQ:NBITS:COMMAND
	// and it must has the format C:##:##:##:########

	// parse command`
	if (cmd[0] != 'C' || cmd[1] != ':') {
		strcpy(cmd, "command not recognized\n");
		return strlen(cmd);
	}

	// get protocol

	// fill the IR learn structure
	irlrn.status = UIRCS_RES_IRLEARN;
	irlrn.proto = IR_ENCODING_PW|IR_PROTO_SIRC;
	irlrn.freq = 40;
	irlrn.nbits = 12;
	irlrn.bits = 0x0000004A;
	irlrn.start_high = 600;
	irlrn.start_low = 150;
	irlrn.high_max = 600;
	irlrn.high_min = 600;
	irlrn.low_max = 150;
	irlrn.low_min = 150;
	irlrn.gap = 11250;

	// send IR command
	UIRCctl(UIRCS_CMD_SEND);
	// send irlrn structure
	SerWrite((unsigned char *)&irlrn, sizeof(irlrn));
	c = SerRead();
	
	return strlen(cmd);
}

/*
 * init:
 *   initializes PIC24F
 *
 */
static void Init(void)
{
	// program the clock divider to 8 MHz for maximum speed	
	_RCDIV = 0;
	// tune fast RC oscillator frequency (adjust to 16 MHz)
	OSCTUN = 3;

	// set outputs
	AD1PCFG = 0x1FFF;						// set all pins as digital
	TRISA = ~0x01;							// set RA0 as output (LED output)

	// configure ENC28J60 pins
	RPINR20bits.SDI1R =  9;					// RP9: SPI1 Data Input
	RPOR4bits.RP8R    =  7;					// assign RP8 as SPI1 Data Output (function 7)
	RPOR3bits.RP7R    =  8;					// assign RP7 as SPI1 Clock Output (function 8)

	// configure UART2 pins
	RPINR19bits.U2RXR =  6;					// RP6: UART2 Receive
	RPOR2bits.RP5R    =  5;					// RP5: UART2 Transmit (function 5)

	// initialize IR event cirular buffer
	ir_n_events = 0;
	ir_pos_enter = ir_pos_exit = 0;
	ir_array[0].proto = 0;
	ir_array[0].freq  = 0;
	ir_array[0].nbits = 0;
	ir_array[0].bits  = 0;

	// enable UART
	SerInit();

} /* init */


// ----- TCP/IP routines -------------------------------------------------

/*********************************************************************
 * Function:        void InitAppConfig(void)
 *
 * PreCondition:    MPFSInit() is already called.
 *
 * Input:           None
 *
 * Output:          Write/Read non-volatile config variables.
 *
 * Side Effects:    None
 *
 * Overview:        None
 *
 * Note:            None
 ********************************************************************/
static void InitAppConfig(void)
{
#if defined(MPFS_USE_EEPROM) && defined(STACK_USE_MPFS)
	BYTE c;
	BYTE *p;
#endif

	AppConfig.Flags.bIsDHCPEnabled = TRUE;
	AppConfig.Flags.bInConfigMode = TRUE;
	AppConfig.MyMACAddr.v[0] = MY_DEFAULT_MAC_BYTE1;
	AppConfig.MyMACAddr.v[1] = MY_DEFAULT_MAC_BYTE2;
	AppConfig.MyMACAddr.v[2] = MY_DEFAULT_MAC_BYTE3;
	AppConfig.MyMACAddr.v[3] = MY_DEFAULT_MAC_BYTE4;
	AppConfig.MyMACAddr.v[4] = MY_DEFAULT_MAC_BYTE5;
	AppConfig.MyMACAddr.v[5] = MY_DEFAULT_MAC_BYTE6;
	AppConfig.MyIPAddr.Val = MY_DEFAULT_IP_ADDR_BYTE1 | MY_DEFAULT_IP_ADDR_BYTE2<<8ul | MY_DEFAULT_IP_ADDR_BYTE3<<16ul | MY_DEFAULT_IP_ADDR_BYTE4<<24ul;
	AppConfig.DefaultIPAddr.Val = AppConfig.MyIPAddr.Val;
	AppConfig.MyMask.Val = MY_DEFAULT_MASK_BYTE1 | MY_DEFAULT_MASK_BYTE2<<8ul | MY_DEFAULT_MASK_BYTE3<<16ul | MY_DEFAULT_MASK_BYTE4<<24ul;
	AppConfig.DefaultMask.Val = AppConfig.MyMask.Val;
	AppConfig.MyGateway.Val = MY_DEFAULT_GATE_BYTE1 | MY_DEFAULT_GATE_BYTE2<<8ul | MY_DEFAULT_GATE_BYTE3<<16ul | MY_DEFAULT_GATE_BYTE4<<24ul;
	AppConfig.PrimaryDNSServer.Val = MY_DEFAULT_PRIMARY_DNS_BYTE1 | MY_DEFAULT_PRIMARY_DNS_BYTE2<<8ul  | MY_DEFAULT_PRIMARY_DNS_BYTE3<<16ul  | MY_DEFAULT_PRIMARY_DNS_BYTE4<<24ul;
	AppConfig.SecondaryDNSServer.Val = MY_DEFAULT_SECONDARY_DNS_BYTE1 | MY_DEFAULT_SECONDARY_DNS_BYTE2<<8ul  | MY_DEFAULT_SECONDARY_DNS_BYTE3<<16ul  | MY_DEFAULT_SECONDARY_DNS_BYTE4<<24ul;

	// Load the default NetBIOS Host Name
	memcpypgm2ram(AppConfig.NetBIOSName, (ROM void*)MY_DEFAULT_HOST_NAME, 16);
	FormatNetBIOSName(AppConfig.NetBIOSName);

#if defined(MPFS_USE_EEPROM) && defined(STACK_USE_MPFS)
	p = (BYTE*)&AppConfig;

	XEEBeginRead(0x0000);
	c = XEERead();
	XEEEndRead();

	// When a record is saved, first byte is written as 0x57 to indicate
	// that a valid record was saved.  Note that older stack versions 
	// used 0x55.  This change has been made to so old EEPROM contents 
	// will get overwritten.  The AppConfig() structure has been changed,
	// resulting in parameter misalignment if still using old EEPROM 
	// contents.
	if(c == 0x60u) {
		XEEBeginRead(0x0001);
		for (c = 0; c < sizeof(AppConfig); c++)
			*p++ = XEERead();
		XEEEndRead();
	} else
		SaveAppConfig();
#endif
}

#if defined(MPFS_USE_EEPROM) && defined (STACK_USE_MPFS)
static void SaveAppConfig(void)
{
	BYTE c;
	BYTE *p;

	p = (BYTE*)&AppConfig;
	XEEBeginWrite(0x0000);
	XEEWrite(0x60);
	for (c = 0; c < sizeof(AppConfig); c++)
		XEEWrite(*p++);

	XEEEndWrite();
}
#endif



// NOTE: Name[] must be at least 16 characters long.
// It should be exactly 16 characters, as defined by NetBIOS spec.
static void FormatNetBIOSName(BYTE Name[])
{
	BYTE i;

	Name[15] = '\0';
	strupr((char*)Name);
	i = 0;
	while(i < 15u) {
		if(Name[i] == '\0') {
			while(i < 15u)
				Name[i++] = ' ';
			break;
		}
		i++;
	}
}


// ----- HTTP Routines

// CGI Command Codes
#define CGI_CMD_DIGOUT      (0)
#define CGI_CMD_LCDOUT      (1)
#define CGI_CMD_RECONFIG	(2)

// CGI Variable codes. - There could be 00h-FFh variables.
// NOTE: When specifying variables in your dynamic pages (.cgi),
//       use the hexadecimal numbering scheme and always zero pad it
//       to be exactly two characters.  Eg: "%04", "%2C"; not "%4" or "%02C"
#define VAR_IR_PROTO		(0x00)	// protocol (for IR monitor)
#define VAR_IR_FREQ			(0x01)	// frequency (for IR monitor)
#define VAR_IR_NBITS		(0x02)	// number of bits (for IR monitor)
#define VAR_IR_BITS			(0x03)	// bits (for IR monitor)

#define VAR_STACK_VERSION	(0x16)	// Stack constants
#define VAR_STACK_DATE		(0x17)

#define VAR_MAC_ADDRESS     (0x06)	// Stack configuration variables
#define VAR_SERIAL_NUMBER   (0x07)
#define VAR_IP_ADDRESS      (0x08)
#define VAR_SUBNET_MASK     (0x09)
#define VAR_GATEWAY_ADDRESS (0x0A)

#define VAR_DHCP	        (0x0B)	// Use this variable when the web page is updating us
#define VAR_DHCP_TRUE       (0x0B)	// Use this variable when we are generating the web page
#define VAR_DHCP_FALSE      (0x0C)	// Use this variable when we are generating the web page


// CGI Command codes (CGI_CMD_DIGOUT).
// Should be a one digit numerical value
#define CMD_LED1			(0x0)
#define CMD_LED2			(0x1)


/*********************************************************************
 * Function:        void HTTPExecCmd(BYTE** argv, BYTE argc)
 *
 * PreCondition:    None
 *
 * Input:           argv        - List of arguments
 *                  argc        - Argument count.
 *
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        This function is a "callback" from HTTPServer
 *                  task.  Whenever a remote node performs
 *                  interactive task on page that was served,
 *                  HTTPServer calls this functions with action
 *                  arguments info.
 *                  Main application should interpret this argument
 *                  and act accordingly.
 *
 *                  Following is the format of argv:
 *                  If HTTP action was : thank.htm?name=Joe&age=25
 *                      argv[0] => thank.htm
 *                      argv[1] => name
 *                      argv[2] => Joe
 *                      argv[3] => age
 *                      argv[4] => 25
 *
 *                  Use argv[0] as a command identifier and rests
 *                  of the items as command arguments.
 *
 * Note:            THIS IS AN EXAMPLE CALLBACK.
 ********************************************************************/
#if defined(STACK_USE_HTTP_SERVER)

ROM char COMMANDS_OK_PAGE[] = "INDEX.CGI";
ROM char CONFIG_UPDATE_PAGE[] = "CONFIG.CGI";
ROM char CMD_UNKNOWN_PAGE[] = "INDEX.CGI";

// Copy string with NULL termination.
#define COMMANDS_OK_PAGE_LEN  	(sizeof(COMMANDS_OK_PAGE))
#define CONFIG_UPDATE_PAGE_LEN  (sizeof(CONFIG_UPDATE_PAGE))
#define CMD_UNKNOWN_PAGE_LEN    (sizeof(CMD_UNKNOWN_PAGE))

void HTTPExecCmd(BYTE** argv, BYTE argc)
{
	BYTE command;
	BYTE var;

	/*
	 * Design your pages such that they contain command code
	 * as a one character numerical value.
	 * Being a one character numerical value greatly simplifies
	 * the job.
	 */
	command = argv[0][0] - '0';

	/*
	 * Find out the cgi file name and interpret parameters
	 * accordingly
	 */
	switch(command) {
		case CGI_CMD_DIGOUT:	// ACTION=0
			/*
			 * Identify the parameters.
			 * Compare it in upper case format.
			 */
			var = argv[1][0] - '0';

			switch(var) {
				case CMD_LED1:	// NAME=0
					break;

				case CMD_LED2:	// NAME=1
					break;
         	}

			memcpypgm2ram((void*)argv[0], (ROM void*)COMMANDS_OK_PAGE, COMMANDS_OK_PAGE_LEN);
			break;

		default:
			memcpypgm2ram((void*)argv[0], (ROM void*)COMMANDS_OK_PAGE, COMMANDS_OK_PAGE_LEN);
			break;
	}
}
#endif


/*********************************************************************
 * Function:        WORD HTTPGetVar(BYTE var, WORD ref, BYTE* val)
 *
 * PreCondition:    None
 *
 * Input:           var         - Variable Identifier
 *                  ref         - Current callback reference with
 *                                respect to 'var' variable.
 *                  val         - Buffer for value storage.
 *
 * Output:          Variable reference as required by application.
 *
 * Side Effects:    None
 *
 * Overview:        This is a callback function from HTTPServer() to
 *                  main application.
 *                  Whenever a variable substitution is required
 *                  on any html pages, HTTPServer calls this function
 *                  8-bit variable identifier, variable reference,
 *                  which indicates whether this is a first call or
 *                  not.  Application should return one character
 *                  at a time as a variable value.
 *
 * Note:            Since this function only allows one character
 *                  to be returned at a time as part of variable
 *                  value, HTTPServer() calls this function
 *                  multiple times until main application indicates
 *                  that there is no more value left for this
 *                  variable.
 *                  On begining, HTTPGetVar() is called with
 *                  ref = HTTP_START_OF_VAR to indicate that
 *                  this is a first call.  Application should
 *                  use this reference to start the variable value
 *                  extraction and return updated reference.  If
 *                  there is no more values left for this variable
 *                  application should send HTTP_END_OF_VAR.  If
 *                  there are any bytes to send, application should
 *                  return other than HTTP_START_OF_VAR and
 *                  HTTP_END_OF_VAR reference.
 *
 *                  THIS IS AN EXAMPLE CALLBACK.
 *                  MODIFY THIS AS PER YOUR REQUIREMENTS.
 ********************************************************************/
#if defined(STACK_USE_HTTP_SERVER)
WORD HTTPGetVar(BYTE var, WORD ref, BYTE* val)
{
	// Temporary variables designated for storage of a whole return 
	// result to simplify logic needed since one byte must be returned
	// at a time.
	static BYTE VarString[25];
	
	// Identify variable
	switch(var) {
		// show the protocol of the top IR command
		case VAR_IR_PROTO:
			if(ref == HTTP_START_OF_VAR)
				sprintf((char*)VarString, "%02x", ir_array[ir_pos_enter].proto);
			*val = VarString[(BYTE)ref];
			if(VarString[(BYTE)ref] == '\0')
				return HTTP_END_OF_VAR;
			else if(VarString[(BYTE)++ref] == '\0' )
				return HTTP_END_OF_VAR;
			return ref;
			break;
	
		// show the frequency of the top IR command
		case VAR_IR_FREQ:
			if(ref == HTTP_START_OF_VAR)
				uitoa(ir_array[ir_pos_enter].freq, (char*)VarString);
			*val = VarString[(BYTE)ref];
			if(VarString[(BYTE)ref] == '\0')
				return HTTP_END_OF_VAR;
			else if(VarString[(BYTE)++ref] == '\0' )
				return HTTP_END_OF_VAR;
			return ref;
			break;
	
		// show the number of bits of the top IR command
		case VAR_IR_NBITS:
			if(ref == HTTP_START_OF_VAR)
				uitoa(ir_array[ir_pos_enter].nbits, (char*)VarString);
			*val = VarString[(BYTE)ref];
			if(VarString[(BYTE)ref] == '\0')
				return HTTP_END_OF_VAR;
			else if(VarString[(BYTE)++ref] == '\0' )
				return HTTP_END_OF_VAR;
			return ref;
			break;
	
		// show the bits of the top IR command
		case VAR_IR_BITS:
			if(ref == HTTP_START_OF_VAR)
				sprintf((char*)VarString, "%08lx", ir_array[ir_pos_enter].bits);
			*val = VarString[(BYTE)ref];
			if(VarString[(BYTE)ref] == '\0')
				return HTTP_END_OF_VAR;
			else if(VarString[(BYTE)++ref] == '\0' )
				return HTTP_END_OF_VAR;
			return ref;
			break;
	
		case VAR_STACK_VERSION:
			if(ref == HTTP_START_OF_VAR) {
				strncpypgm2ram((char*)VarString, VERSION, sizeof(VarString));
			}
			*val = VarString[(BYTE)ref];
			if(VarString[(BYTE)ref] == '\0')
				return HTTP_END_OF_VAR;
			else if(VarString[(BYTE)++ref] == '\0' )
				return HTTP_END_OF_VAR;
			return ref;

		case VAR_STACK_DATE:
			if(ref == HTTP_START_OF_VAR) {
				strncpypgm2ram((char*)VarString, __DATE__ " " __TIME__, sizeof(VarString));
			}
			*val = VarString[(BYTE)ref];
			if(VarString[(BYTE)ref] == '\0')
				return HTTP_END_OF_VAR;
			else if(VarString[(BYTE)++ref] == '\0' )
				return HTTP_END_OF_VAR;
			return ref;
    }

    return HTTP_END_OF_VAR;
}
#endif


// ----- FTP Firmware Update
// this routine only support the firmware update through a put of the MPFS.BIN image
// username is root, password is firmware

#if defined(STACK_USE_FTP_SERVER) && defined(MPFS_USE_EEPROM) && defined(STACK_USE_MPFS)
ROM char FTP_USER_NAME[]    = "root";
ROM char FTP_USER_PASS[]    = "firmware";
#undef FTP_USER_NAME_LEN
#define FTP_USER_NAME_LEN   (sizeof(FTP_USER_NAME)-1)
#define FTP_USER_PASS_LEN   (sizeof(FTP_USER_PASS)-1)

BOOL FTPVerify(BYTE *login, BYTE *password)
{
    if ( !memcmppgm2ram(login, (ROM void*)FTP_USER_NAME, FTP_USER_NAME_LEN) )
    {
        if ( !memcmppgm2ram(password, (ROM void*)FTP_USER_PASS, FTP_USER_PASS_LEN) )
            return TRUE;
    }
    return FALSE;
}
#endif


// ----- UART support routines

#define UART_RX_BUF_LEN		256				// receive circular buffer
#define UART_TX_BUF_LEN		128				// transmit circular buffer

volatile int rx_nbytes;						// number of bytes in rx buffer
volatile int tx_nbytes;						// number of bytes to transmit

unsigned char rx_buffer[UART_RX_BUF_LEN];	// receive circular buffer
volatile int rx_enter, rx_exit;				// rx circular buffer pointers

unsigned char *tx_buffer;					// transmit buffer start pointer


/*
 * serial_init
 *   initializes the UART2
 */
void SerInit(void)
{
	// initialize UART buffers and pointers
	rx_nbytes = 0; rx_enter = rx_exit = 0;
	tx_nbytes = 0;

	// configure UART2
	U2BRG  = BAUD_FACTOR;
	U2STA  = 0x0000;
	U2MODE = 0x8000;						// UART_EN | UART_NO_PAR_8BIT | UART_1STOPBIT;
	U2STA  = 0x0400;						// UART_TX_ENABLE
	U2BRG  = BAUD_FACTOR;

	// configure UART2 interrupts
	IPC7bits.U2RXIP = 4;					// UART2 int receive priority
	IPC7bits.U2TXIP = 2;					// UART2 int transmit priority
	IEC1bits.U2RXIE = 1;					// enable RX interrupt
	IEC1bits.U2TXIE = 0;					// disable TX interrupt

	// clear UART receive interrupt flag
	IFS1bits.U2RXIF = 0;
}

/* UART receive interrupt routine */
void _ISR _U2RXInterrupt(void)
{
	// received byte into the circular buffer
	if (rx_nbytes < UART_RX_BUF_LEN) {
		rx_buffer[rx_enter] = (U2RXREG&0xff);
		rx_enter = (rx_enter+1)%UART_RX_BUF_LEN;
		++rx_nbytes;
	}

	// clear UART receive interrupt flag
	IFS1bits.U2RXIF = 0;
}

/* UART transmit interrupt routine */
void _ISR _U2TXInterrupt(void)
{
	if (tx_nbytes) {
		U2TXREG = *tx_buffer++;
		--tx_nbytes;
	}

	// clear UART transmit interrupt flag
	IFS1bits.U2TXIF = 0;
}

/* UART receive ready data */
int SerDataReady(void)
{
	return (rx_nbytes > 0);
}

/* UART read byte */
unsigned char SerRead(void)
{
	unsigned int timeout;
	unsigned char c;

	for (timeout = 0; !rx_nbytes && timeout < 100; ++timeout);
		DelayMs(1);
	if (!rx_nbytes) return 0xff;

	IEC1bits.U2RXIE = 0;					// disable RX interrupt
	c = rx_buffer[rx_exit];
	rx_exit = (rx_exit+1)%UART_RX_BUF_LEN;
	--rx_nbytes;
	IEC1bits.U2RXIE = 1;					// enable RX interrupt	

	return c;
}

/* UART transmit data */
void SerWrite(unsigned char *buffer, int nbytes)
{
	if (nbytes == 0) return;

	// wait for previous transmission
	while (tx_nbytes);
	while (!U2STAbits.TRMT);
	IEC1bits.U2TXIE = 0;					// disable TX interrupt
	tx_nbytes = nbytes;
	tx_buffer = buffer;
	IFS1bits.U2TXIF = 0;					// clear transmit interrupt flag

	// transmit first byte
	U2TXREG = *tx_buffer++;
	--tx_nbytes;

	IEC1bits.U2TXIE = 1;					// enable TX interrupt	
}

/*
 * read a block from UART
 */
int SerReadBlock(unsigned char *buffer, int len)
{
	int i;

	// read bytes with timeout
	for (i = 0; i < len; ++i) {
		buffer[i] = SerRead();
	}

	return (i == len)?1:0;
}

// ----- UIRC Sensor interface routines

/* resets the UIRC sensor (UIRCS) */
void ResetUIRC(void)
{
	PORTBbits.RB15 = 0;						// prepare to output 0 in RB15
	TRISBbits.TRISB15 = 0;					// set RB15 as output
}

/* releases the UIRC sensor reset signal */
void ReleaseUIRC(void)
{
	TRISBbits.TRISB15 = 1;					// set RB15 as input (tristate it)
}

/*
 * UIRCSinit
 *   Initialize UIRC sensor communications
 */
void UIRCSinit(void)
{
	unsigned char response;

	// Hold UIRC sensor reset
	ResetUIRC();
	DelayMs(500);
	// Release UIRC sensor reset
	ReleaseUIRC();
	DelayMs(500);

	// clean FIFO
	while (SerDataReady())
		SerRead();

	// initialize until acknowledged
	do {
		response = UIRCctl(UIRCS_CMD_INIT);
	} while (response == 0xff || res_code(response) != UIRCS_RES_INITOK);
	
	// Enable UIRCS to send commands
	do {
		response = UIRCctl(UIRCS_CMD_RECV);
	} while (response == 0xff || res_code(response) != UIRCS_RES_OK);
}

/*
 * UIRCctl
 *   Send a mode command to the UIRCS
 *
 */
unsigned char UIRCctl(unsigned char cmd)
{
	unsigned char c;

	// send command and receive status
	SerWrite(&cmd, 1);
	c = SerRead();

	return c;
}

/*
 * read a IR event
 *   and store it in the circular buffer
 */
void ReadIREvent(void)
{
	int i;
	unsigned char *p, *d, cs, sum;
	IRevent ir;

	ir.status = UIRCS_RES_IREVENT;
	// read IR event block
	SerReadBlock(&ir.proto, sizeof(IRevent)-1);
	// read checksum
	cs = SerRead();

	// calculate checksum
	for (i = 0, sum = 0, p = (unsigned char *)&ir; i < sizeof(IRevent); ++i)
		sum ^= *p++;

	// if checksum ok and there is space in the circular buffer -> store it
	if (cs == sum && ir_n_events < MAX_IR_EVENTS) {
		ir_pos_enter = (ir_pos_enter+1)%MAX_IR_EVENTS;
		d = (unsigned char *)&ir_array[ir_pos_enter];
		p = (unsigned char *)&ir;
		for (i = 0; i < sizeof(IRevent); ++i)
			*d++ = *p++;
		++ir_n_events;
	}
}



// EOF: UIRC.c
