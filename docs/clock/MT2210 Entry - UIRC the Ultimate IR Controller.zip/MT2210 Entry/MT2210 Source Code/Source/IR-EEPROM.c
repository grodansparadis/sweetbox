//***********************************************************************/
// UIRC: Ultimate IR Controller                                          /
//       (c) 2007 by its author, all rights reserved.                    /
//                                                                       /
// The UIRC is a generic IR sensor for all kinds of modulated IR remote  /
// control protocols.  It learns and replays IR commands controlled by a /
// master microcontroller.                                               /
//                                                                       /
// FILE: IR-EEPROM.c                                                     /
//    EEPROM routines to write IR learned commmands                      /
//                                                                       /
// version:                                                              /
//    0.01:  09/30/07 - start coding                                     /
//    0.10:  10/04/07 - finished main support routines                   /
//    0.90:  10/06/07 - finished interface routines                      /
//                                                                       /
//***********************************************************************/
//
// These routines read and write lists in the reserved EEPROM area.  The structure
// is as follows:
//
// Offset EEIR_START		        ir-list structure
//        EEIR_ENTRIES				ir-entry #1
//        ...
//
// For speed, there is a memory list for the pointers of the EEPROM list:



#include "TCPIP Stack/TCPIP.h"
#include "UIRC.h"
#include "IR-EEPROM.h"



// magic number for EEPROM reset
#define MAGIC_NUMBER	0xEE01			// EEPROM magic number + version

// offsets
#define EEIR_START		(XEE_ADDR)(sizeof(APP_CONFIG)+1)	// skip TCP-IP configuration
#define EEIR_HEADER		(EEIR_START+2)						// start of header
#define EEIR_ENTRIES	(EEIR_HEADER+sizeof(ir_list))		// start of entries

// maximum number of entries in EEPROM
#define MAX_EE_ENTRIES		((MPFS_RESERVE_BLOCK-EEIR_ENTRIES)/sizeof(ir_entry))

// maximum number of entries for the memory list
#define MAX_MEM_EVENTS		128

// end of the entry array
#define EE_EOL				0xff

// fill EEPROM memory
#define fill_block(b,m)		iree_write((b),(unsigned char *)(m), sizeof(ir_entry))

// read a EEPROM block
#define read_block(b,m)		iree_read((b),(unsigned char *)(m), sizeof(ir_entry))

// a list of the main events (heads)
typedef struct mem_ir_entry_s {
	unsigned char next;					// next element in the list

	unsigned char sysid;				// system ID
	unsigned char id;					// event ID
	unsigned char proto;				// protocol
	unsigned char freq;					// frequency
	unsigned char nbits;				// number of bits
	unsigned long bits;					// bits

	XEE_ADDR this;						// this block
	XEE_ADDR cmd_next;					// command list for this IR event
} mem_ir_entry;

// the header in memory
ir_list mem_ir_list;

// event array
mem_ir_entry event_list[MAX_MEM_EVENTS];

// memory list
mem_index_type evt_list = EE_EOL;

// the free list
mem_index_type event_free;


// forward references
static mem_index_type get_free(void);
static void release(mem_index_type item);
static void iree_load_list(mem_index_type *l, XEE_ADDR ee_list);
static void iree_fill_mem(mem_ir_entry *irl, ir_entry *ire, XEE_ADDR ee_addr);
static void iree_free_list(mem_index_type last, mem_index_type item);
static void iree_write(XEE_ADDR address, unsigned char *buffer, int len);
static void iree_read(XEE_ADDR address, unsigned char *buffer, int len);
static void iree_write_header(void);
static void iree_read_header(void);
static int iree_check_magic(void);
static void iree_init_eeprom();
static XEE_ADDR iree_get_block(void);
static void iree_release_block(XEE_ADDR block);




/* ----- ROUTINES ----------------------------------------------------- */

/*
 * iree_init
 *    initializes the IR-EEPROM structure
 *    this routine checks the EEPROM, read the header into memory,
 *    and build the event lists in memory.
 *
 */
void iree_init(void)
{
	int i;

	/* check magic number and initializes EEPROM if needed */
	iree_check_magic();

	/* read header into memory */
	iree_read_header();

	/* initializes the memory list */
	for (i = 0; i < MAX_MEM_EVENTS-1; ++i) {
		event_list[i].next = i+1;
	}
	event_list[i].next = EE_EOL;
	event_free = 0;		// all the elements are free

	/* initialize lists */
	evt_list = EE_EOL;

	/* read event list into memory */
	iree_load_list(&evt_list, mem_ir_list.evt_list);
}

/*
 * iree_event_write
 *   write a new event into the corresponding list
 *   this method writes a ir_entry array into the EEPROM and updates
 *   the memory list
 *
 *   returns 0 if error, 1 if sucessful
 */
int iree_event_write(int n, ir_entry *ire_array)
{
	int i;
	unsigned char proto;
	XEE_ADDR b, last;	
	mem_index_type this;
	mem_ir_entry *irl;

	// check that there is enough memory
	if (free - n <= 0) return 0;
	if (event_free == EE_EOL) return 0;

	// check that the protocol is supported
	proto = ire_array[0].ir.learned.proto&IR_ENCODING_MASK;
	if (proto == IR_PROTO_UNKNOWN) return 0;

	// construct the command list in reverse order
	last = NIL;
	for (i = n-1; i > 0; ++i) {
		// get a block
		b = iree_get_block();
		// link it
		ire_array[i].cmd_next = last;
		// fill it
		fill_block(b, &ire_array[i]);
		// update last block
		last = b;
	}

	// build the header
	b = iree_get_block();
	ire_array[0].cmd_next = last;		/* link to the command list */
	ire_array[0].next = NIL;
	fill_block(b, &ire_array[0]);

	// add event to the EEPROM list
	if (mem_ir_list.evt_list == NIL)
		mem_ir_list.evt_list = b;
	else {
		ire_array[0].next = mem_ir_list.evt_list;
		mem_ir_list.evt_list = b;
	}

	// add event to the memory list
	this = get_free();
	irl = &event_list[this];
	iree_fill_mem(irl, &ire_array[0], b);
	
	/* append element to the corresponding list in memory */
	if (evt_list == EE_EOL) {
		evt_list = this;
	} else {
		irl->next = evt_list;
		evt_list = this;
	}
	
	// update header in EEPROM
	iree_write_header();

	return 1;
}


/*
 * iree_event_search
 *   Search an event in the corresponding list
 *
 *   returns a index handler
 */
mem_index_type iree_event_search(unsigned char proto, 
                                 unsigned char freq,
                                 unsigned char nbits, unsigned long bits)
{
	mem_index_type mlist;
	mem_ir_entry *irl;

	/* look up the element in the event list in memory */
	mlist = evt_list;
	while (mlist != EE_EOL) {
		irl = &event_list[mlist];
		if (irl->freq == freq && irl->nbits == nbits && irl->bits == bits) {
			return mlist;
		}
		mlist = irl->next;
	}

	return EE_EOL;
}

/*
 * iree_id_search
 *   Search an event by id in the corresponding list
 *
 *   returns a pointer to the event in memory
 */
mem_index_type iree_id_search(unsigned char sysid, unsigned char id)
{
	mem_index_type mlist;
	mem_ir_entry *irl;

	/* look up the element in the corresponding list */
	mlist = evt_list;
	while (mlist != EE_EOL) {
		irl = &event_list[mlist];
		if (irl->sysid == sysid && irl->id == id) {
			return mlist;
		}
		mlist = irl->next;
	}

	return EE_EOL;
}

/*
 * iree_event_delete
 *   Delete an event from the corresponding list
 *
 */
void iree_event_delete(mem_index_type index)
{
	mem_index_type mlist, last;
	mem_ir_entry *irl;

	/* look up the element in the list */
	last = EE_EOL;
	mlist = evt_list;
	while (mlist != index) {
		irl = &event_list[mlist];
		last = mlist;
		mlist = irl->next;
	}

	/* delete the element if found */
	if (mlist == index) {
		/* free the EEPROM */
		iree_free_list(last, index);

		/* unlink from the list */
		irl = &event_list[index];
		if (last == EE_EOL) {
			evt_list = irl->next;
		} else {
			event_list[last].next = irl->next;
		}

		/* add item to the free list */
		release(index);

		/* write header */
		iree_write_header();
	}
}



/* ----- INTERNAL ROUTINES -------------------------------------------- */

/*
 * get_free
 *  return a free element from the array list or EE_EOL if there is no
 *  free element
 *
 */
mem_index_type get_free(void)
{
	mem_index_type this;

	this = event_free;
	event_free = event_list[this].next;
	event_list[this].next = EE_EOL;

	return this;
}

/*
 * release
 *   return an entry to the array list
 */
void release(mem_index_type item)
{
	event_list[item].this = NIL;
	event_list[item].cmd_next = NIL;
	event_list[item].next = event_free;
	event_free = item;
}

/*
 * iree_load_list
 *   load a EEPROM list into memory
 *
 */
void iree_load_list(mem_index_type *l, XEE_ADDR ee_list)
{
	XEE_ADDR eeprom_addr;
	mem_index_type this;
	mem_ir_entry *irl;
	ir_entry ire;

	/* loop through the EEPROM List */
	for (eeprom_addr = ee_list; ee_list != NIL; eeprom_addr = ire.next) {
		/* read EEPROM block */
		read_block(ire.next, (unsigned char *)&ire);

		/* get new element */
		this = get_free();
		irl = &event_list[this];
	
		/* transfer to memory entry */
		iree_fill_mem(irl, &ire, eeprom_addr);
	
		/* append element to the list */
		if (*l == EE_EOL) {
			*l = this;
		} else {
			irl->next = *l;
			*l = this;
		}
	}
}

/*
 * iree_fill_mem
 *   fill a event memory element
 *
 */
void iree_fill_mem(mem_ir_entry *irl, ir_entry *ire, XEE_ADDR ee_addr)
{
	irl->sysid = ire->sysid;
	irl->id = ire->id;
	irl->proto = ire->ir.learned.proto;
	irl->freq = ire->ir.learned.freq;
	irl->nbits = ire->ir.learned.nbits;
	irl->bits = ire->ir.learned.bits;
	irl->this = ee_addr;
	irl->cmd_next = ire->cmd_next;
	irl->next = EE_EOL;
}

/*
 * iree_free_list
 *   frees a event list from the EEPROM
 *
 */
void iree_free_list(mem_index_type last, mem_index_type item)
{
	XEE_ADDR b, p, this;
	mem_ir_entry *irl;
	ir_entry_header irh;

	/* free the command list */
	irl = &event_list[item];
	for (b = irl->cmd_next; b != NIL; b = p) {
		// read the block header
		iree_read(b, (unsigned char *)&irh, sizeof(ir_entry_header));
		// get next command
		p = irh.cmd_next;
		// release current block
		iree_release_block(b);
	}

	/* get the parent block header and point it to the next block */
	this = irl->this;
	iree_read(this, (unsigned char *)&irh, sizeof(ir_entry_header));
	if (last == EE_EOL) {
		/* must delete first position */
		mem_ir_list.evt_list = irh.next;
	} else {
		/* irh already has next pointer, just overwrite first entry of the previous block */
		irl = &event_list[last];
		iree_write(irl->this, (unsigned char *)&irh, sizeof(XEE_ADDR));
	}

	/* free the entry block */
	iree_release_block(this);
}

/*
 * iree_write
 *   write a block to the EEPROM
 *
 */
void iree_write(XEE_ADDR address, unsigned char *buffer, int len)
{
	int i;

	XEEBeginWrite(EEIR_START);
	for (i = 0; i < len; ++i)
		XEEWrite(buffer[i]);
	XEEEndWrite();
	while (XEEIsBusy());
}

/*
 * iree_read
 *   read a block from the EEPROM
 *
 */
void iree_read(XEE_ADDR address, unsigned char *buffer, int len)
{
	int i;

	XEEBeginRead(address);
	for (i = 0; i < len; ++i)
		buffer[i] = XEERead();
	XEEEndRead();
}

/*
 * iree_write_header
 *   write the memory header to the EEPROM
 *
 */
void iree_write_header(void)
{
	iree_write(EEIR_HEADER, (unsigned char *)&mem_ir_list, sizeof(mem_ir_list));
}

/*
 * iree_read_header
 *   read the EEPROM header to the memory structure
 *
 */
void iree_read_header(void)
{
	iree_read(EEIR_HEADER, (unsigned char *)&mem_ir_list, sizeof(mem_ir_list));
}

/*
 * iree_check_magic
 *    checks magic number and reset EEPROM
 *
 */
int iree_check_magic(void)
{
	unsigned char m1, m2;
	unsigned short magic;

	// read magic number
	XEEBeginRead(EEIR_START);
	m1 = XEERead();
	m2 = XEERead();
	XEEEndRead();
	magic = ((unsigned short)m1 << 8) | m2;

	// compare
	if (magic == MAGIC_NUMBER)
		return 1;

	// initialize EEPROM
	iree_init_eeprom();

	return 0;
}

/*
 * iree_init_eeprom
 *   initializes the EEPROM
 *
 */
void iree_init_eeprom()
{
	int i;

	/* initialize magic numer */
	XEEBeginWrite(EEIR_START);
	XEEWrite(MAGIC_NUMBER&0xff00 >> 8);
	XEEWrite(MAGIC_NUMBER&0x00ff);
	XEEEndWrite();

	/* initialize header in memory */
	mem_ir_list.free = MAX_EE_ENTRIES;
	for (i = 0; i < N_BLOCKS/16; ++i)
		mem_ir_list.used[i] = 0x0000;
	mem_ir_list.last = 0;
	mem_ir_list.evt_list = NIL;

	/* write to EEPROM */
	while (XEEIsBusy());
	iree_write_header();
}

/*
 * iree_get_free_block
 *   return a free block from the EEPROM
 */
XEE_ADDR iree_get_block(void)
{
	int search, l, i;
	unsigned short n, m;

	// check that there is enough memory
	if (mem_ir_list.free == 0) return NIL;

	search = mem_ir_list.last;
	for (i = 0; i < MAX_EE_ENTRIES/16; ++i) {
		n = mem_ir_list.used[search];
		// a bit in 0 signal a free block
		if (~n) {
			mem_ir_list.last = search;

			// search free block in bitmap (a 0)
			for (m = n, l = 0; l < 16 && m&0x0001; ++l, m >>= 1);
			n |= (1 << l);
			mem_ir_list.used[search] = n;
			
			// update free count
			--mem_ir_list.free;

			// return address
			return EEIR_ENTRIES+sizeof(ir_entry)*((search<<4)+m);
		}
		search = (search+1)%MAX_EE_ENTRIES;
	}

	return NIL;
}

/*
 * iree_release_block
 *  return a EEPROM block to the free list
 */
void iree_release_block(XEE_ADDR block)
{
	unsigned short n;

	// get # of block
	n = (block - EEIR_ENTRIES)/sizeof(ir_entry);
	
	// unmark bit
	mem_ir_list.used[n/16] &= ~(1 << (n%16));

	// update free count
	++mem_ir_list.free;
}


// EOF: IR-EEPROM.c
