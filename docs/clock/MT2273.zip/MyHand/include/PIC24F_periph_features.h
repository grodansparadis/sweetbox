#ifndef __PIC24F_PERIPH_FEATURES_H
#define __PIC24F_PERIPH_FEATURES_H
/******************************************************************************
 *
 *                  PERIPHERAL SELECT HEADER FILE
 *
 ******************************************************************************
 * FileName:        pic24f_periph_features.h
 * Dependencies:    See include below
 * Processor:       PIC24
 * Compiler:        MPLAB C30
 * Company:         Microchip Technology, Inc.
 *
 * Software License Agreement
 * The software supplied herewith by Microchip Technology Incorporated
 * (the �Company�) for its PICmicro� Microcontroller is intended and
 * supplied to you, the Company�s customer, for use solely and
 * exclusively on Microchip PICmicro Microcontroller products. The
 * software is owned by the Company and/or its supplier, and is
 * protected under applicable copyright laws. All rights are reserved.
 * Any use in violation of the foregoing restrictions may subject the
 * user to criminal sanctions under applicable laws, as well as to
 * civil liability for the breach of the terms and conditions of this
 * license.
 *
 * THIS SOFTWARE IS PROVIDED IN AN �AS IS� CONDITION. NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
 * TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
 * IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
 * CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *
 *****************************************************************************/

#if defined(__PIC24F__)
#include <p24Fxxxx.h>
#endif

/*********************** Peripheral Inclusion Macros **************************/

#define _I2C_V2_1  /* I2C Module 1 */
#define _I2C_V2_2  /* I2C Module 2 */

#define _TIMER1
#define _TIMER2
#define _TIMER3
#define _TIMER4
#define _TIMER5

#define _UART_IRDA_V1_1 /* UART Module 1 */ 
#define _UART_IRDA_V1_2 /* UART Module 2 */ 

#define _SPI_V2_1  /* SPI Module 1 */
#define _SPI_V2_2  /* SPI Module 2 */

#define _INT0
#define _INT1
#define _INT2

#if defined(__PIC24FJ32GA002__) || defined(__PIC24FJ32GA004__) || defined(__PIC24FJ64GA002__) || defined(__PIC24FJ64GA004__)
      /* These variants dosen't have external interrupt 3 & 4 */
#else

#define _INT3
#define _INT4

#endif

#define _PORTA  /* Port A Module */
#define _PORTB  /* Port B Module */
#define _PORTC  /* Port C Module */
#define _PORTD  /* Port D Module */
#define _PORTE  /* Port E Module */
#define _PORTF  /* Port F Module */

#define _PPI_PMP_V1  /* PMP Module*/

#define _ADC_10B_V3  /* ADC Module */

#define _WDT

#define _CRC_PROG_V1  /* Programmable CRC Generator */

#define _PWRMGNT

#define _TMR_RTCC_V1  /* Real time Clock */

#define _ICAP1
#define _ICAP2
#define _ICAP3
#define _ICAP4
#define _ICAP5

#define _OCMP1
#define _OCMP2
#define _OCMP3
#define _OCMP4
#define _OCMP5

#define _CMP_DUAL_V3

#endif /* __PIC24F_PERIPH_FEATURES_H */
