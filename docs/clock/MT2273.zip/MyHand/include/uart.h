#ifndef __UART_H
#define __UART_H
/******************************************************************************
 *
 *                  UART PERIPHERAL LIBRARY HEADER FILE
 *
 ******************************************************************************
 * FileName:        uart.h
 * Dependencies:    See include below
 * Processor:       PIC24
 * Compiler:        MPLAB C30
 * Company:         Microchip Technology, Inc.
 *
 * Software License Agreement
 * The software supplied herewith by Microchip Technology Incorporated
 * (the �Company�) for its PICmicro� Microcontroller is intended and
 * supplied to you, the Company�s customer, for use solely and
 * exclusively on Microchip PICmicro Microcontroller products. The
 * software is owned by the Company and/or its supplier, and is
 * protected under applicable copyright laws. All rights are reserved.
 * Any use in violation of the foregoing restrictions may subject the
 * user to criminal sanctions under applicable laws, as well as to
 * civil liability for the breach of the terms and conditions of this
 * license.
 *
 * THIS SOFTWARE IS PROVIDED IN AN �AS IS� CONDITION. NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
 * TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
 * IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
 * CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *
 *****************************************************************************/
#include "Generic.h"
#include "PIC24F_periph_features.h"

/* List of SFRs for UART */
/* This list contains the SFRs with default (POR) values to be used for configuring UART */
/* The user can modify this based on the requirement */
#define UxMODE_VALUE            0x0000
#define UxSTA_VALUE             0x0110
#define UxTXREG_VALUE           0x0000
#define UxRXREG_VALUE           0x0000
#define UxBRG_VALUE             0x0000

#ifdef USE_AND_OR /* Format for AND_OR based bit setting */

/* defines for UxMODE register */
#define UART_EN                 0x8000              /* Module enable */
#define UART_DIS                0x0000              /* Module disable */
#define UART_EN_DIS_MASK        (~UART_EN)

#define UART_IDLE_STOP          0x2000              /* Stop all functions in IDLE mode*/
#define UART_IDLE_CON           0x0000              /* Work in IDLE mode */
#define UART_IDLE_MASK          (~UART_IDLE_STOP)

#define UART_IrDA_ENABLE        0x1000  /* IrDA encoder and decoder enabled*/
#define UART_IrDA_DISABLE       0x0000  /* IrDA encoder and decoder disabled */
#define UART_IrDA_MASK          (~UART_IrDA_ENABLE)

#define UART_MODE_SIMPLEX       0x0800  /* UxRTS pin in Simplex mode */
#define UART_MODE_FLOW          0x0000  /* UxRTS pin in Flow Control mode*/
#define UART_MODE_MASK          (~UART_MODE_SIMPLEX)

#define UART_UEN_11             0x0300 /*UxTX,UxRX and BCLK pins are enabled and used; UxCTS pin controlled by port latches*/
#define UART_UEN_10             0x0200 /*UxTX,UxRX, UxCTS and UxRTS pins are enabled and used*/
#define UART_UEN_01             0x0100 /*UxTX,UxRX and UxRTS pins are enabled and used; UxCTS pin controlled by port latches*/
#define UART_UEN_00             0x0000 /*UxTX and UxRX pins are enabled and used; UxCTS and UxRTS/BCLK pins controlled by port latches*/
#define UART_UEN_MASK           (~UART_UEN_11)

#define UART_EN_WAKE            0x0080 /*Enable Wake-up on START bit Detect during SLEEP Mode bit*/
#define UART_DIS_WAKE           0x0000 /*Disable Wake-up on START bit Detect during SLEEP Mode bit*/
#define UART_WAKE_MASK          (~UART_EN_WAKE)

#define UART_EN_LOOPBACK        0x0040 /*Loop back enabled*/
#define UART_DIS_LOOPBACK       0x0000 /*Loop back disabled*/
#define UART_LOOPBACK_MASK      (~UART_DIS_LOOPBACK)

#define UART_EN_ABAUD           0x0020 /*Enable baud rate measurement on the next character*/
#define UART_DIS_ABAUD          0x0000 /*Baud rate measurement disabled or completed*/
#define UART_ABAUD_MASK         (~UART_EN_ABAUD

#define UART_UXRX_IDLE_ZERO     0x0010 /* UxRX Idle state is zero */
#define UART_UXRX_IDLE_ONE      0x0000 /* UxRx Idle state is one */
#define UART_UXRX_IDLE_MASK     (~UART_UXRX_IDLE_ZERO)

#define UART_BRGH_FOUR          0x0008 /* BRG generates 4 clocks per bit period */
#define UART_BRGH_SIXTEEN       0x0000 /* BRG generates 16 clocks per bit period */
#define UART_BRGH_MASK          (~UART_BRGH_FOUR)

#define UART_NO_PAR_9BIT        0x0006 /*No parity 9 bit*/
#define UART_ODD_PAR_8BIT       0x0004 /*odd parity 8 bit*/
#define UART_EVEN_PAR_8BIT      0x0002 /*even parity 8 bit*/
#define UART_NO_PAR_8BIT        0x0000 /*no parity 8 bit*/
#define UART_PARITY_MASK        (~UART_NO_PAR_9BIT)

#define UART_2STOPBITS          0x0001              /*2 stop bits*/
#define UART_1STOPBIT           0x0000              /*1 stop bit*/
#define UART_STOPBIT_MASK       (~UART_2STOPBITS)

/* defines for UART Status register */

#define UART_INT_TX_BUF_EMPTY   0x0000  /* Interrupt on TXBUF becoming empty */
#define UART_INT_TX_LAST_CH     0x2000  /* Interrupt when last character shifted out*/
#define UART_INT_TX_EACH_CHAR   0x8000  /* Interrupt on transfer of every character to TSR */
#define UART_INT_TX_MASK        (~(UART_INT_TX_EACH_CHAR | UART_INT_TX_LAST_CH))

#define UART_IrDA_POL_INV_ONE   0x4000  /*IrDA encoded, UxTX Idle state is '1' */
#define UART_IrDA_POL_INV_ZERO  0x0000  /* IrDA encoded, UxTX Idel state is '0' */
#define UART_IrDA_POL_INV_MASK  (~UART_IrDA_POL_INV_ONE)

#define UART_SYNC_BREAK_ENABLED   0x0800  /* Send sync break on next transmission */
#define UART_SYNC_BREAK_DISABLED  0x0000  /* Sync break transmission disabled or completed */
#define UART_SYNC_BREAK_MASK      (~UART_SYNC_BREAK_ENABLED)

#define UART_TX_ENABLE          0x0400  /* Transmit enable */
#define UART_TX_DISABLE         0x0000  /* Transmit disable */
#define UART_TX_MASK            (~UART_TX_ENABLE)

#define UART_INT_RX_BUF_FUL     0x00C0  /* Interrupt on RXBUF full */
#define UART_INT_RX_3_4_FUL     0x0080  /* Interrupt on RXBUF 3/4 full */
#define UART_INT_RX_CHAR        0x0000  /* Interrupt on every char received */
#define UART_INT_RX_MASK        (~UART_INT_RX_BUF_FUL)

#define UART_ADR_DETECT_EN      0x0020  /* address detect enable */
#define UART_ADR_DETECT_DIS     0x0000  /* address detect disable */
#define UART_ADR_DETECT_MASK    (~UART_ADR_DETECT_EN)

#define UART_RX_OVERRUN_BIT        0x0002
#define UART_RX_OVERRUN_CLR_MASK   (~UART_RX_OVERRUN_BIT) /* Rx buffer Over run status bit clear */

/* defines for UART Interrupt configuartion */
#define UART_RX_INT_EN          0x0008  /*Receive interrupt enabled*/
#define UART_RX_INT_DIS         0x0000  /*Receive interrupt disabled*/

#define UART_RX_INT_PR0         0x0000  /*Priority RX interrupt 0*/
#define UART_RX_INT_PR1         0x0001  /*Priority RX interrupt 1*/
#define UART_RX_INT_PR2         0x0002  /*Priority RX interrupt 2*/
#define UART_RX_INT_PR3         0x0003  /*Priority RX interrupt 3*/
#define UART_RX_INT_PR4         0x0004  /*Priority RX interrupt 4*/
#define UART_RX_INT_PR5         0x0005  /*Priority RX interrupt 5*/
#define UART_RX_INT_PR6         0x0006  /*Priority RX interrupt 6*/
#define UART_RX_INT_PR7         0x0007  /*Priority RX interrupt 7*/

#define UART_TX_INT_EN          0x0080  /*transmit interrupt enabled*/
#define UART_TX_INT_DIS         0x0000 /*transmit interrupt disabled*/

#define UART_TX_INT_PR0         0x0000  /*Priority TX interrupt 0*/
#define UART_TX_INT_PR1         0x0010  /*Priority TX interrupt 1*/
#define UART_TX_INT_PR2         0x0020  /*Priority TX interrupt 2*/
#define UART_TX_INT_PR3         0x0030  /*Priority TX interrupt 3*/
#define UART_TX_INT_PR4         0x0040  /*Priority TX interrupt 4*/
#define UART_TX_INT_PR5         0x0050  /*Priority TX interrupt 5*/
#define UART_TX_INT_PR6         0x0060  /*Priority TX interrupt 6*/
#define UART_TX_INT_PR7         0x0070  /*Priority TX interrupt 7*/

#else /* Format for backward compatibility (AND based bit setting). */

/* defines for UxMODE register */
#define UART_EN                 0xFFFF  /* Module enable */
#define UART_DIS                0x7FFF  /* Module disable */

#define UART_IDLE_CON           0xDFFF  /* Work in IDLE mode */
#define UART_IDLE_STOP          0xFFFF  /* Stop all functions in IDLE mode*/

#define UART_IrDA_ENABLE    0xFFFF  /* IrDA encoder and decoder enabled*/
#define UART_IrDA_DISABLE   0xEFFF  /* IrDA encoder and decoder disabled */

#define UART_MODE_SIMPLEX   0xFFFF  /* UxRTS pin in Simplex mode */
#define UART_MODE_FLOW      0xF7FF  /* UxRTS pin in Flow Control mode*/

#define UART_UEN_11     0xFFFF  /*UxTX,UxRX and BCLK pins are enabled and used; UxCTS pin controlled by port latches*/
#define UART_UEN_10     0xFEFF  /*UxTX,UxRX, UxCTS and UxRTS pins are enabled and used*/
#define UART_UEN_01     0xFDFF  /*UxTX,UxRX and UxRTS pins are enabled and used; UxCTS pin controlled by port latches*/
#define UART_UEN_00     0xFCFF  /*UxTX and UxRX pins are enabled and used; UxCTS and UxRTS/BCLK pins controlled by port latches*/

#define UART_EN_WAKE            0xFFFF  /*Enable Wake-up on START bit Detect during SLEEP Mode bit*/
#define UART_DIS_WAKE           0xFF7F  /*Disable Wake-up on START bit Detect during SLEEP Mode bit*/

#define UART_EN_LOOPBACK        0xFFFF  /*Loop back enabled*/
#define UART_DIS_LOOPBACK       0xFFBF  /*Loop back disabled*/

#define UART_EN_ABAUD           0xFFFF  /*Enable baud rate measurement on the next character*/
#define UART_DIS_ABAUD          0xFFDF  /*Baud rate measurement disabled or completed*/

#define UART_UXRX_IDLE_ZERO 0xFFFF  /* UxRX Idle state is zero */
#define UART_UXRX_IDLE_ONE  0xFFEF  /* UxRx Idle state is one */

#define UART_BRGH_FOUR      0xFFFF  /* BRG generates 4 clocks per bit period */
#define UART_BRGH_SIXTEEN   0xFFF7  /* BRG generates 16 clocks per bit period */

#define UART_NO_PAR_9BIT        0xFFFF  /*No parity 9 bit*/
#define UART_ODD_PAR_8BIT       0xFFFE  /*odd parity 8 bit*/
#define UART_EVEN_PAR_8BIT      0xFFFD  /*even parity 8 bit*/
#define UART_NO_PAR_8BIT        0xFFFC  /*no parity 8 bit*/

#define UART_2STOPBITS          0xFFFF  /*2 stop bits*/
#define UART_1STOPBIT           0xFFFE  /*1 stop bit*/

/* defines for UART Status register */


#define UART_INT_TX_BUF_EMPTY   0xDFFF  /* Interrupt on TXBUF becoming empty */
#define UART_INT_TX_LAST_CH     0x7FFF  /* Interrupt when last character shifted out*/
#define UART_INT_TX             0x5FFF  /* Interrupt on transfer of every character to TSR */

#define UART_IrDA_POL_INV_ONE   0xDFFF  /*IrDA encoded, UxTX Idle state is '1' */
#define UART_IrDA_POL_INV_ZERO  0x9FFF  /* IrDA encoded, UxTX Idel state is '0' */


#define UART_SYNC_BREAK_ENABLED      0xDFFF  /* Send sync break on next transmission */
#define UART_SYNC_BREAK_DISABLED     0xD7FF  /* Sync break transmission disabled or completed */

#define UART_TX_ENABLE          0xDFFF  /* Transmit enable */
#define UART_TX_DISABLE         0xDBFF  /* Transmit disable */

#define UART_TX_BUF_FUL     0xDFFF  /* Transmit buffer is full */
#define UART_TX_BUF_NOT_FUL 0xDDFF  /* Transmit buffer is not full */

#define UART_INT_RX_BUF_FUL     0xDFFF  /* Interrupt on RXBUF full */
#define UART_INT_RX_3_4_FUL     0xDFBF  /* Interrupt on RXBUF 3/4 full */
#define UART_INT_RX_CHAR        0xFF7F  /* Interrupt on every char received */\

#define UART_ADR_DETECT_EN      0xDFFF  /* address detect enable */
#define UART_ADR_DETECT_DIS     0xDFDF  /* address detect disable */

#define UART_RX_OVERRUN_CLEAR   0xDFFD  /* Rx buffer Over run status bit clear */

/* defines for UART Interrupt configuartion */
#define UART_RX_INT_EN          0xFFFF  /*Receive interrupt enabled*/
#define UART_RX_INT_DIS         0xFFF7  /*Receive interrupt disabled*/

#define UART_RX_INT_PR0         0xFFF8  /*Priority RX interrupt 0*/
#define UART_RX_INT_PR1         0xFFF9  /*Priority RX interrupt 1*/
#define UART_RX_INT_PR2         0xFFFA  /*Priority RX interrupt 2*/
#define UART_RX_INT_PR3         0xFFFB  /*Priority RX interrupt 3*/
#define UART_RX_INT_PR4         0xFFFC  /*Priority RX interrupt 4*/
#define UART_RX_INT_PR5         0xFFFD  /*Priority RX interrupt 5*/
#define UART_RX_INT_PR6         0xFFFE  /*Priority RX interrupt 6*/
#define UART_RX_INT_PR7         0xFFFF  /*Priority RX interrupt 7*/

#define UART_TX_INT_EN          0xFFFF  /*transmit interrupt enabled*/
#define UART_TX_INT_DIS         0xFF7F  /*transmit interrupt disabled*/

#define UART_TX_INT_PR0         0xFF8F  /*Priority TX interrupt 0*/
#define UART_TX_INT_PR1         0xFF9F  /*Priority TX interrupt 1*/
#define UART_TX_INT_PR2         0xFFAF  /*Priority TX interrupt 2*/
#define UART_TX_INT_PR3         0xFFBF  /*Priority TX interrupt 3*/
#define UART_TX_INT_PR4         0xFFCF  /*Priority TX interrupt 4*/
#define UART_TX_INT_PR5         0xFFDF  /*Priority TX interrupt 5*/
#define UART_TX_INT_PR6         0xFFEF  /*Priority TX interrupt 6*/
#define UART_TX_INT_PR7         0xFFFF  /*Priority TX interrupt 7*/

#endif /* USE_AND_OR */

#ifdef _UART_IRDA_V1_1

/* Macros to  Enable/Disable interrupts and set Interrupt priority of UART1 */
#define EnableIntU1RX                    asm("BSET IEC0,#11")
#define EnableIntU1TX                    asm("BSET IEC0,#12")

#define DisableIntU1RX                   asm("BCLR IEC0,#11")
#define DisableIntU1TX                   asm("BCLR IEC0,#12")

#define SetPriorityIntU1RX(priority)     (IPC2bits.U1RXIP = priority)
#define SetPriorityIntU1TX(priority)     (IPC3bits.U1TXIP = priority)

#define getcUART1               ReadUART1
#define putcUART1               WriteUART1

void putsUART1(unsigned int *buffer) __attribute__ ((section (".libperi")));

void WriteUART1(unsigned int data) __attribute__ ((section (".libperi")));

void CloseUART1(void) __attribute__ ((section (".libperi")));

void ConfigIntUART1(unsigned int config) __attribute__ ((section (".libperi")));

char DataRdyUART1(void) __attribute__ ((section (".libperi")));

unsigned int getsUART1(unsigned int length,unsigned int *buffer, 
                   unsigned int uart_data_wait) __attribute__ ((section (".libperi")));

void OpenUART1(unsigned int config1,unsigned int config2, unsigned int ubrg) __attribute__ ((section (".libperi")));

unsigned int ReadUART1(void) __attribute__ ((section (".libperi")));

char BusyUART1(void) __attribute__ ((section (".libperi")));

#else
#warning "Does not build for _UART_IRDA_V1_1"
#endif /* _UART_IRDA_V1_1 */

#ifdef _UART_IRDA_V1_2

/* Macros to  Enable/Disable interrupts and set Interrupt priority of UART2 */
#define EnableIntU2RX                    asm("BSET IEC1,#14")
#define EnableIntU2TX                    asm("BSET IEC1,#15")

#define DisableIntU2RX                   asm("BCLR IEC1,#14")
#define DisableIntU2TX                   asm("BCLR IEC1,#15")

#define SetPriorityIntU2RX(priority)     (IPC7bits.U2RXIP = priority)
#define SetPriorityIntU2TX(priority)     (IPC7bits.U2TXIP = priority)

#define getcUART2               ReadUART2
#define putcUART2               WriteUART2

void putsUART2(unsigned int *buffer) __attribute__ ((section (".libperi")));

void WriteUART2(unsigned int data) __attribute__ ((section (".libperi")));

void CloseUART2(void) __attribute__ ((section (".libperi")));

void ConfigIntUART2(unsigned int config) __attribute__ ((section (".libperi")));

char DataRdyUART2(void) __attribute__ ((section (".libperi")));

unsigned int getsUART2(unsigned int length,unsigned int *buffer, 
                   unsigned int uart_data_wait) __attribute__ ((section (".libperi")));

void OpenUART2(unsigned int config1,unsigned int config2, unsigned int ubrg) __attribute__ ((section (".libperi")));

unsigned int ReadUART2(void) __attribute__ ((section (".libperi")));

char BusyUART2(void) __attribute__ ((section (".libperi")));

#else
#warning "Does not build for _UART_IRDA_V1_2"
#endif /* _UART_IRDA_V1_2 */

#endif /*__UART_H */
