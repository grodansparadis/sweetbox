#ifndef __COMPARATOR_H /* COMPARATOR_H */
#define __COMPARATOR_H
/******************************************************************************
 *
 *                  COMPARATOR PERIPHERAL LIBRARY HEADER FILE
 *
 ******************************************************************************
 * FileName:        comparator.h
 * Dependencies:    See include below
 * Processor:       PIC24
 * Compiler:        MPLAB C30
 * Company:         Microchip Technology, Inc.
 *
 * Software License Agreement
 * The software supplied herewith by Microchip Technology Incorporated
 * (the �Company�) for its PICmicro� Microcontroller is intended and
 * supplied to you, the Company�s customer, for use solely and
 * exclusively on Microchip PICmicro Microcontroller products. The
 * software is owned by the Company and/or its supplier, and is
 * protected under applicable copyright laws. All rights are reserved.
 * Any use in violation of the foregoing restrictions may subject the
 * user to criminal sanctions under applicable laws, as well as to
 * civil liability for the breach of the terms and conditions of this
 * license.
 *
 * THIS SOFTWARE IS PROVIDED IN AN �AS IS� CONDITION. NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
 * TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
 * IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
 * CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *
 *****************************************************************************/
#include "Generic.h"
#include "PIC24F_periph_features.h"

/* List of SFRs for COMPARATOR Module */
/* This list contains the SFRs with default (POR) values to be used for configuring COMPARATOR */
/* The user can modify this based on the requirement */

#define COMP_CVRCOM_VAL    0x0000
#define COMP_CMCOM_VAL     0x0000

/* CMCON : COMPARATOR CONTROL REGISTER */
/* Comparator Stop in Idle mode Bit defines */
#define CMP_IDLE_STOP               0x8000 /* When device enters Idle mode, module does not 
                                             generate interrupts. Module is still enabled. */
#define CMP_IDLE_CON                0x0000 /* continue operation in idle mode */
#define CMP_IDLE_MASK               (~CMP_IDLE_STOP)

/* C2EVT: Comparator 2 Event */
#define CMP2_CHANGE_STATE           0x2000 /* Comparator output changed states */
#define CMP2_NO_CHANGE              0x0000 /* Comparator output did not change states */
#define CMP2_STATE_MASK             (~CMP2_CHANGE_STATE )

/* C1EVT: Comparator 1 Event */
#define CMP1_CHANGE_STATE           0x1000 /* Comparator output changed states */
#define CMP1_NO_CHANGE              0x0000 /* Comparator output did not change states */
#define CMP1_ENBL_DSBL_MASK         (~CMP1_CHANGE_STATE )

/* C2EN: Comparator 2 Enable */
#define CMP2_ENABLE                 0x0800 /* Comparator is enabled */
#define CMP2_DISABLE                0x0000 /* Comparator is disabled */
#define CMP2_ENBL_DSBL_MASK         (~CMP2_ENABLE)

/* C1EN: Comparator 1 Enable */
#define CMP1_ENABLE                 0x0400 /* Comparator is enabled */
#define CMP1_DISABLE                0x0000 /* Comparator is disabled */
#define CMP1_STATE_MASK             (~CMP1_ENABLE)

/* C2OUTEN: Comparator 2 Output Enable */
#define CMP2_OUTPUT_ENABLE          0x0200 /* Comparator output driven on the output pad */
#define CMP2_OUTPUT_DISABLE         0x0000 /* Comparator output is not driven on the output pad */
#define CMP2_OUTPUT_MASK            (~CMP2_OUTPUT_ENABLE)

/* C1OUTEN: Comparator 1 Output Enable */
#define CMP1_OUTPUT_ENABLE          0x0100 /* Comparator output driven on the output pad */
#define CMP1_OUTPUT_DISABLE         0x0000 /* Comparator output is not driven on the output pad */
#define CMP1_OUTPUT_MASK            (~CMP1_OUTPUT_ENABLE)

/* C2INV: Comparator 2 Output Inversion bit */
#define CMP2_INV_OUTPUT             0x0020 /* C2 output inverted */
#define CMP2_NORMAL_OUTPUT          0x0000 /* C2 output not inverted */
#define CMP2_INV_OUTPUT_MASK        (~CMP2_INV_OUTPUT)

/* C1INV: Comparator 1 Output Inversion bit */
#define CMP1_INV_OUTPUT             0x0010 /* C1 output inverted */
#define CMP1_NORMAL_OUTPUT          0x0000 /* C1 output not inverted */
#define CMP1_INV_OUTPUT_MASK        (~CMP1_INV_OUTPUT)

/* C2NEG: Comparator 2 Negative Input Configure bit */
#define CMP2_NEG_IP_Vin_Pos        0x0008 /* Input is connected to Vin+ */
#define CMP2_NEG_IP_Vin_Neg        0x0000 /* Input is connected to Vin- */
#define CMP2_NEG_IP_MASK           (~CMP2_NEG_IP_Vin_Pos)

/* C2POS: Comparator 2 Positive Input Configure bit */
#define CMP2_POS_IP_Vin_Pos        0x0004 /* Input is connected to Vin+ */
#define CMP2_POS_IP_CV_Ref         0x0000 /* Input is connected to Vin- */
#define CMP2_POS_IP_MASK           (~CMP2_POS_IP_Vin_Pos)

/* C1NEG: Comparator 1 Negative Input Configure bit */
#define CMP1_NEG_IP_Vin_Pos        0x0002 /* Input is connected to Vin+ */
#define CMP1_NEG_IP_Vin_Neg        0x0000 /* Input is connected to Vin- */
#define CMP1_NEG_IP_MASK           (~CMP1_NEG_IP_Vin_Pos)

/* C1POS: Comparator 1 Positive Input Configure bit */
#define CMP1_POS_IP_Vin_Pos        0x0004 /* Input is connected to Vin+ */
#define CMP1_POS_IP_CV_Ref         0x0000 /* Input is connected to Vin- */
#define CMP1_POS_IP_MASK           (~CMP1_POS_IP_Vin_Pos)


/* CVRCON: COMPARATOR VOLTAGE REFERENCE CONTROL REGISTER */
/* CVREN: Comparator Voltage Reference Enable bit */
#define CMP_VRef_Enable            0x0080 /* CVREF circuit powered on */
#define CMP_VRef_Disable           0x0000 /* CVREF circuit powered down */
#define CMP1_VRef_MASK             (~CMP_VRef_Enable)

/* CVROE: Comparator VREF Output Enable bit */
#define CMP_VRef_OUTPUT_Enable     0x0040 /* CVREF voltage level is output on CVREF pin */
#define CMP_VRef_OUTPUT_Disable    0x0000 /* CVREF voltage level is disconnected from CVREF pin */
#define CMP_VRef_OUTPUT_MASK      (~CMP_VRef_OUTPUT_Enable)

/* CVRR: Comparator VREF Range Selection bit */
#define CMP_VRef_SELECT_24_STEPS   0x0020 /* 0 to 0.67 CVRSRC, with CVRSRC/24 step size */
#define CMP_VRef_SELECT_32_STEPS   0x0000 /* 0.25 CVRSRC to 0.75 CVRSRC, with CVRSRC/32 step size */
#define CMP_VRef_STEP_SELECT_MASK  (~CMP_VRef_SELECT_24_STEPS) /* 0 to 0.67 CVRSRC, with CVRSRC/24 step size */

/* CVRSS: Comparator VREF Source Selection bit */
#define CMP_Vrsrc_Vref_Vref        0x0010 /* Comparator reference source CVRSRC = VREF+ � VREF- */
#define CMP_Vrsrc_AVDD_AVSS        0x0000 /* Comparator reference source CVRSRC = AVDD � AVSS */
#define CMP_Vrsrc_MASK             (~CMP_Vrsrc_Vref_Vref)

/* Comparator VREF Value Selection 0 = CVR3:CVR0 = 15 bits */
#define CMP_0p0CVrsrc_OR_0p25CVrsrc      0x0000
#define CMP_0p04CVrsrc_OR_0p28CVrsrc     0x0001
#define CMP_0p08CVrsrc_OR_0p31CVrsrc     0x0002
#define CMP_0p12CVrsrc_OR_0p34CVrsrc     0x0003
#define CMP_0p16CVrsrc_OR_0p37CVrsrc     0x0004
#define CMP_0p20CVrsrc_OR_0p40CVrsrc     0x0005
#define CMP_0p25CVrsrc_OR_0p43CVrsrc     0x0006
#define CMP_0p29CVrsrc_OR_0p46CVrsrc     0x0007
#define CMP_0p33CVrsrc_OR_0p50CVrsrc     0x0008
#define CMP_0p37CVrsrc_OR_0p53CVrsrc     0x0009
#define CMP_0p41CVrsrc_OR_0p56CVrsrc     0x000A
#define CMP_0p45CVrsrc_OR_0p59CVrsrc     0x000B
#define CMP_0p50CVrsrc_OR_0p62CVrsrc     0x000C
#define CMP_0p54CVrsrc_OR_0p65CVrsrc     0x000D
#define CMP_0p58CVrsrc_OR_0p68CVrsrc     0x000E
#define CMP_0p62CVrsrc_OR_0p71CVrsrc     0x000F
#define CMP_VRef_SELECT_MASK             (~CMP_0p62CVrsrc_OR_0p71CVrsrc)

#ifdef _CMP_DUAL_V3
/**************************************************************************
* Function Name  :  Config_CMP(UINT16 config1 , UINT16 config2)           *
* Description    :  This routine configures Reference Voltage level and   *
*                   Comparator module.                                    *
* Parameter      :  config1 This contains the parameters to be configured *
*                           in the CVRCON Register                        *
                    config2 This contains the parameters to be configured *
*                           in the CMCON Register                         *
                             Register                                     *
* Return Value   :  None                                                  *
**************************************************************************/

extern void Config_CMP(UINT16 config1 , UINT16 config2);


/******************************************************************************
 * Macro:           mCMP2_EnblDsbl(state)
 *
 * PreCondition:    None
 *
 * Input:           state  1 Comparator is enabled
 *                         0 Comparator is disabled
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        Macro Enables/Disables the Comparator 2
 *
 * Note:            
 *****************************************************************************/
#define mCMP2_EnblDsbl(state)      (CMCONbits.C2EN = state)

/******************************************************************************
 * Macro:           mCMP1_EnblDsbl(state)
 *
 * PreCondition:    None
 *
 * Input:           state  1 Comparator is enabled
 *                         0 Comparator is disabled
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        Macro Enables/Disables the Comparator 1
 *
 * Note:            
 *****************************************************************************/
#define mCMP1_EnblDsbl(state)      (CMCONbits.C1EN = state)

/******************************************************************************
 * Macro:           mCMP2_Output_EnblDsbl(state)
 *
 * PreCondition:    None
 *
 * Input:           state  1 Comparator output driven on the output pad 
 *                         0 Comparator output is not driven on the output pad
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        Macro Enables/Disables Comparator 2 output on the output pad
 *
 * Note:            
 *****************************************************************************/
#define mCMP2_Output_EnblDsbl(state)      (CMCONbits.C2OUTEN = state)

/******************************************************************************
 * Macro:           mCMP1_Output_EnblDsbl(state)
 *
 * PreCondition:    None
 *
 * Input:           state  1 Comparator output driven on the output pad 
 *                         0 Comparator output is not driven on the output pad
 * Output:          None
 *
 * Side Effects:    None
 *
 * Overview:        Macro Enables/Disables Comparator 1 output on the output pad
 *
 * Note:            
 *****************************************************************************/
#define mCMP1_Output_EnblDsbl(state)      (CMCONbits.C1OUTEN = state)

/******************************************************************************
 * Macro:           mCMP2_Get_STATE(state)
 *
 * PreCondition:    None
 *
 * Input:           None
 * Output:          Returns When C2INV = 0:
                                1 = C2 VIN+ > C2 VIN-
                                0 = C2 VIN+ < C2 VINWhen
                                 C2INV = 1:
                                0 = C2 VIN+ > C2 VIN-
                                1 = C2 VIN+ < C2 VIN-
 *
 * Side Effects:    None
 *
 * Overview:        Macro Returns state of Comparator output
 *
 * Note:            State of Comparator depends on Inverse selection  bit in 
 *                  control register
 *****************************************************************************/
#define mCMP2_Get_STATE()      (CMCONbits.C2OUT)

/******************************************************************************
 * Macro:           mCMP1_Get_STATE(state)
 *
 * PreCondition:    None
 *
 * Input:           None
 * Output:          Returns When C1INV = 0:
                                1 = C1 VIN+ > C1 VIN-
                                0 = C1 VIN+ < C1 VINWhen
                                 C1INV = 1:
                                0 = C1 VIN+ > C1 VIN-
                                1 = C1 VIN+ < C1 VIN-
 *
 * Side Effects:    None
 *
 * Overview:        Macro Returns state of Comparator output
 *
 * Note:            State of Comparator depends on Inverse selection  bit in 
 *                  control register
 *****************************************************************************/
#define mCMP1_Get_STATE()      (CMCONbits.C1OUT)

#else
#warning "Does not build for _CMP_DUAL_V3"
#endif /* _CMP_DUAL_V3 */


#endif  /* __COMPARATOR_H */
