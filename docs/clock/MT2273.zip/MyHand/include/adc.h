#ifndef __ADC_H
#define __ADC_H
/******************************************************************************
 *
 *                  ADC PERIPHERAL LIBRARY HEADER FILE
 *
 ******************************************************************************
 * FileName:        adc.h
 * Dependencies:    See include below
 * Processor:       PIC24
 * Compiler:        MPLAB C30
 * Company:         Microchip Technology, Inc.
 *
 * Software License Agreement
 * The software supplied herewith by Microchip Technology Incorporated
 * (the �Company�) for its PICmicro� Microcontroller is intended and
 * supplied to you, the Company�s customer, for use solely and
 * exclusively on Microchip PICmicro Microcontroller products. The
 * software is owned by the Company and/or its supplier, and is
 * protected under applicable copyright laws. All rights are reserved.
 * Any use in violation of the foregoing restrictions may subject the
 * user to criminal sanctions under applicable laws, as well as to
 * civil liability for the breach of the terms and conditions of this
 * license.
 *
 * THIS SOFTWARE IS PROVIDED IN AN �AS IS� CONDITION. NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
 * TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
 * IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
 * CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *
 *****************************************************************************/
#include "Generic.h"
#include "PIC24F_periph_features.h"

/* List of SFRs for ADC */
/* This list contains the SFRs with default (POR) values to be used for configuring ADC */
/* The user can modify this based on the requirement */


#define AD1CON1_VALUE                0x0000
#define AD1CON2_VALUE                0x0000
#define AD1CON3_VALUE                0x0000
#define AD1CHS123_VALUE              0x0000
#define AD1CH0_VALUE                 0x0000
#define AD1CHSS_VALUE                0x0000
#define AD1CSSL_VALUE                0x0000
#define AD1PCFGH_VALUE               0x0000
#define AD1PCFGL_VALUE               0x0000

#ifdef USE_AND_OR /* Format for AND_OR based bit setting */

/* AD1CON1 Configuration Bit Definitions */

#define ADC_MODULE_ON               0x8000 /* A/D Converter on */
#define ADC_MODULE_OFF              0x0000 /* A/D Converter off */
#define ADC_MODULE_MASK             (~ADC_MODULE_ON) 

#define ADC_IDLE_CONTINUE           0x2000 /* A/D Operate in Idle mode */
#define ADC_IDLE_STOP               0x0000 /* A/D Stop in Idle mode */
#define ADC_IDLE_MASK               (~ADC_IDLE_CONTINUE)

#define ADC_FORMAT_SIGN_FRACT       0x0300 /* A/D data format signed fractional */
#define ADC_FORMAT_FRACT            0x0200 /* A/D data format fractional */
#define ADC_FORMAT_SIGN_INT         0x0100 /* A/D data format signed integer */
#define ADC_FORMAT_INTG             0x0000 /* A/D data format integer */
#define ADC_FORMAT_MASK             (~ADC_FORMAT_SIGN_FRACT)

#define ADC_CLK_AUTO                0x00E0  /* Internal counter ends sampling and starts conversion (Auto convert) */
#define ADC_CLK_MPWM                0x0060  /* MPWM interval ends sampling and starts conversion */
#define ADC_CLK_TMR                 0x0040  /* GP Timer compare ends sampling and starts conversion */
#define ADC_CLK_INT0                0x0020  /* Active transition on INTx ends sampling and starts conversion */
#define ADC_CLK_MANUAL              0x0000  /* Clearing sample (SAMP) bit ends sampling and starts conversion */
#define ADC_CLK_MASK                (~ADC_CLK_AUTO)

#define ADC_AUTO_SAMPLING_ON        0x0004  /* Sampling begins immediately after last conversion */
#define ADC_AUTO_SAMPLING_OFF       0x0000  /* Sampling begins when SAMP bit is set */
#define ADC_AUTO_SAMPLING_MASK      (~ADC_AUTO_SAMPLING_ON)

#define ADC_SAMP_ON                 0x0002  /* sample / hold amplifiers are sampling */
#define ADC_SAMP_OFF                0x0000 /* sample / hold amplifiers are holding */
#define ADC_SAMP_MASK               (~ADC_SAMP_ON)


/* defines for the ADCON2 register */

#define ADC_VREF_EXT_AVSS           0x2000  /* A/D Voltage reference configuration Vref+ external and Vref- is AVss */
#define ADC_VREF_AVDD_EXT           0x4000  /* A/D Voltage reference configuration Vref+ AVdd and Vref- external */
#define ADC_VREF_EXT_EXT            0x6000  /* A/D Voltage reference configuration both Vref+ and Vref- are external */
#define ADC_VREF_AVDD_AVSS          0x8000  /* A/D Voltage reference configuration Vref+ is AVdd and Vref- is AVss */
#define ADC_VREF_MASK               (~(ADC_VREF_AVDD_AVSS | ADC_VREF_EXT_EXT))/* A/D Voltage reference configuration Vref+ is AVdd and Vref- is AVss */


#define ADC_SCAN_ON                 0x0400  /* A/D Scan Input Selections for CH0 during SAMPLE A */
#define ADC_SCAN_OFF                0x0000  /* A/D Do notScan Input Selections for CH0+ during SAMPLE A */
#define ADC_SCAN_MASK               (~ADC_SCAN_ON)

#define ADC_INTR_EACH_CONV          0x0000  /* Interrupts at the completion of conversion of each sample */
#define ADC_INTR_2_CONV             0x0004  /* Interrupts at the completion of conversion of 2 samples */
#define ADC_INTR_3_CONV             0x0008  /* Interrupts at the completion of conversion of 3 samples */
#define ADC_INTR_4_CONV             0x000C  /* Interrupts at the completion of conversion of 4 samples */
#define ADC_INTR_5_CONV             0x0010  /* Interrupts at the completion of conversion of 5 samples */
#define ADC_INTR_6_CONV             0x0014  /* Interrupts at the completion of conversion of 6 samples */
#define ADC_INTR_7_CONV             0x0018  /* Interrupts at the completion of conversion of 7 samples */
#define ADC_INTR_8_CONV             0x001C  /* Interrupts at the completion of conversion of 8 samples */
#define ADC_INTR_9_CONV             0x0020  /* Interrupts at the completion of conversion of 9 samples */
#define ADC_INTR_10_CONV            0x0024  /* Interrupts at the completion of conversion of 10 samples */
#define ADC_INTR_11_CONV            0x0028  /* Interrupts at the completion of conversion of 11 samples */
#define ADC_INTR_12_CONV            0x002C  /* Interrupts at the completion of conversion of 12 samples */
#define ADC_INTR_13_CONV            0x0030  /* Interrupts at the completion of conversion of 13 samples */
#define ADC_INTR_14_CONV            0x0034  /* Interrupts at the completion of conversion of 14 samples */
#define ADC_INTR_15_CONV            0x0038  /* Interrupts at the completion of conversion of 15 samples */
#define ADC_INTR_16_CONV            0x003C  /* Interrupts at the completion of conversion of 16 samples */
#define ADC_INTR_MASK               (~ADC_INTR_16_CONV)

/* BUFM bit defines */

#define ADC_ALT_BUF_ON              0x0002 /* Buffer configured as 2 8-word buffers */
#define ADC_ALT_BUF_OFF             0x0000 /* Buffer configured as 1 16-word buffer */
#define ADC_ALT_BUF_MASK            (~ADC_ALT_BUF_ON)

/* A/D Uses channel input selects for SAMPLE A on first sample and SAMPLE B on next sample */
#define ADC_ALT_INPUT_ON            0x0001 /* alternate between MUXA and MUXB */
/* A/D Always uses channel input selects for SAMPLE A */
#define ADC_ALT_INPUT_OFF           0x0000 /* use MUXA only */
#define ADC_ALT_MASK                (~ADC_ALT_INPUT_ON)

/* defines for ADCON3 register */

#define ADC_CONV_CLK_INTERNAL_RC    0x8000 /* A/D internal RC clock */
#define ADC_CONV_CLK_SYSTEM         0x0000 /* Clock derived from system clock */
#define ADC_CONV_CLK_SOURCE_MASK    (~ADC_CONV_CLK_INTERNAL_RC)

#define ADC_SAMPLE_TIME_0           0x0000 /* A/D Auto Sample Time 0 Tad */
#define ADC_SAMPLE_TIME_1           0x0100 /* A/D Auto Sample Time 1 Tad */
#define ADC_SAMPLE_TIME_2           0x0200 /* A/D Auto Sample Time 2 Tad */
#define ADC_SAMPLE_TIME_3           0x0300 /* A/D Auto Sample Time 3 Tad */
#define ADC_SAMPLE_TIME_4           0x0400 /* A/D Auto Sample Time 4 Tad */
#define ADC_SAMPLE_TIME_5           0x0500 /* A/D Auto Sample Time 5 Tad */
#define ADC_SAMPLE_TIME_6           0x0600 /* A/D Auto Sample Time 6 Tad */
#define ADC_SAMPLE_TIME_7           0x0700 /* A/D Auto Sample Time 7 Tad */
#define ADC_SAMPLE_TIME_8           0x0800 /* A/D Auto Sample Time 8 Tad */
#define ADC_SAMPLE_TIME_9           0x0900 /* A/D Auto Sample Time 9 Tad */
#define ADC_SAMPLE_TIME_10          0x0A00 /* A/D Auto Sample Time 10 Tad */
#define ADC_SAMPLE_TIME_11          0x0B00 /* A/D Auto Sample Time 11 Tad */
#define ADC_SAMPLE_TIME_12          0x0C00 /* A/D Auto Sample Time 12 Tad */
#define ADC_SAMPLE_TIME_13          0x0D00 /* A/D Auto Sample Time 13 Tad */
#define ADC_SAMPLE_TIME_14          0x0E00 /* A/D Auto Sample Time 14 Tad */
#define ADC_SAMPLE_TIME_15          0x0F00 /* A/D Auto Sample Time 15 Tad */
#define ADC_SAMPLE_TIME_16          0x1000 /* A/D Auto Sample Time 16 Tad */
#define ADC_SAMPLE_TIME_17          0x1100 /* A/D Auto Sample Time 17 Tad */
#define ADC_SAMPLE_TIME_18          0x1200 /* A/D Auto Sample Time 18 Tad */
#define ADC_SAMPLE_TIME_19          0x1300 /* A/D Auto Sample Time 19 Tad */
#define ADC_SAMPLE_TIME_20          0x1400 /* A/D Auto Sample Time 20 Tad */
#define ADC_SAMPLE_TIME_21          0x1500 /* A/D Auto Sample Time 21 Tad */
#define ADC_SAMPLE_TIME_22          0x1600 /* A/D Auto Sample Time 22 Tad */
#define ADC_SAMPLE_TIME_23          0x1700 /* A/D Auto Sample Time 23 Tad */
#define ADC_SAMPLE_TIME_24          0x1800 /* A/D Auto Sample Time 24 Tad */
#define ADC_SAMPLE_TIME_25          0x1900 /* A/D Auto Sample Time 25 Tad */
#define ADC_SAMPLE_TIME_26          0x1A00 /* A/D Auto Sample Time 26 Tad */
#define ADC_SAMPLE_TIME_27          0x1B00 /* A/D Auto Sample Time 27 Tad */
#define ADC_SAMPLE_TIME_28          0x1C00 /* A/D Auto Sample Time 28 Tad */
#define ADC_SAMPLE_TIME_29          0x1D00 /* A/D Auto Sample Time 29 Tad */
#define ADC_SAMPLE_TIME_30          0x1E00 /* A/D Auto Sample Time 30 Tad */
#define ADC_SAMPLE_TIME_31          0x1F00 /* A/D Auto Sample Time 31 Tad */
#define ADC_SAMPLE_TIME_MASK        (~ADC_SAMPLE_TIME_31)

/* A/D conversion clock select bit ADCS<7:0>*/
#define ADC_CONV_CLK_1Tcy2          0x0000      /* A/D Conversion Clock is Tcy/2 */
#define ADC_CONV_CLK_1Tcy           0x0001     /* A/D Conversion Clock is 2*Tcy/2 */
#define ADC_CONV_CLK_3Tcy2          0x0002     /* A/D Conversion Clock is 3*Tcy/2 */
#define ADC_CONV_CLK_2Tcy           0x0003     /* A/D Conversion Clock is 4*Tcy/2 */
#define ADC_CONV_CLK_5Tcy2          0x0004     /* A/D Conversion Clock is 5*Tcy/2 */
#define ADC_CONV_CLK_3Tcy           0x0005     /* ... */
#define ADC_CONV_CLK_7Tcy2          0x0006
#define ADC_CONV_CLK_4Tcy           0x0007
#define ADC_CONV_CLK_9Tcy2          0x0008
#define ADC_CONV_CLK_5Tcy           0x0009
#define ADC_CONV_CLK_11Tcy2         0x000A
#define ADC_CONV_CLK_6Tcy           0x000B
#define ADC_CONV_CLK_13Tcy2         0x000C
#define ADC_CONV_CLK_7Tcy           0x000D
#define ADC_CONV_CLK_15Tcy2         0x000E
#define ADC_CONV_CLK_8Tcy           0x000F
#define ADC_CONV_CLK_17Tcy2         0x0010
#define ADC_CONV_CLK_9Tcy           0x0011
#define ADC_CONV_CLK_19Tcy2         0x0012
#define ADC_CONV_CLK_10Tcy          0x0013
#define ADC_CONV_CLK_21Tcy2         0x0014
#define ADC_CONV_CLK_11Tcy          0x0015
#define ADC_CONV_CLK_23Tcy2         0x0016
#define ADC_CONV_CLK_12Tcy          0x0017
#define ADC_CONV_CLK_25Tcy2         0x0018
#define ADC_CONV_CLK_13Tcy          0x0019
#define ADC_CONV_CLK_27Tcy2         0x001A
#define ADC_CONV_CLK_14Tcy          0x001B
#define ADC_CONV_CLK_29Tcy2         0x001C
#define ADC_CONV_CLK_15Tcy          0x001D
#define ADC_CONV_CLK_31Tcy2         0x001E
#define ADC_CONV_CLK_16Tcy          0x001F
#define ADC_CONV_CLK_33Tcy2         0x0020
#define ADC_CONV_CLK_17Tcy          0x0021
#define ADC_CONV_CLK_35Tcy2         0x0022
#define ADC_CONV_CLK_18Tcy          0x0023
#define ADC_CONV_CLK_37Tcy2         0x0024
#define ADC_CONV_CLK_19Tcy          0x0025
#define ADC_CONV_CLK_39Tcy2         0x0026
#define ADC_CONV_CLK_20Tcy          0x0027
#define ADC_CONV_CLK_41Tcy2         0x0028
#define ADC_CONV_CLK_21Tcy          0x0029
#define ADC_CONV_CLK_43Tcy2         0x002A
#define ADC_CONV_CLK_22Tcy          0x002B
#define ADC_CONV_CLK_45Tcy2         0x002C
#define ADC_CONV_CLK_23Tcy          0x002D
#define ADC_CONV_CLK_47Tcy2         0x002E
#define ADC_CONV_CLK_24Tcy          0x002F
#define ADC_CONV_CLK_49Tcy2         0x0030
#define ADC_CONV_CLK_25Tcy          0x0031
#define ADC_CONV_CLK_51Tcy2         0x0032
#define ADC_CONV_CLK_26Tcy          0x0033
#define ADC_CONV_CLK_53Tcy2         0x0034
#define ADC_CONV_CLK_27Tcy          0x0035
#define ADC_CONV_CLK_55Tcy2         0x0036
#define ADC_CONV_CLK_28Tcy          0x0037
#define ADC_CONV_CLK_57Tcy2         0x0038
#define ADC_CONV_CLK_29Tcy          0x0039
#define ADC_CONV_CLK_59Tcy2         0x003A
#define ADC_CONV_CLK_30Tcy          0x003B
#define ADC_CONV_CLK_61Tcy2         0x003C
#define ADC_CONV_CLK_31Tcy          0x003D
#define ADC_CONV_CLK_63Tcy2         0x003E
#define ADC_CONV_CLK_32Tcy          0x003F
#define ADC_CONV_CLK_65Tcy2         0x0040
#define ADC_CONV_CLK_33Tcy          0x0041
#define ADC_CONV_CLK_67Tcy2         0x0042
#define ADC_CONV_CLK_34Tcy          0x0043
#define ADC_CONV_CLK_69Tcy2         0x0044
#define ADC_CONV_CLK_35Tcy          0x0045
#define ADC_CONV_CLK_71Tcy2         0x0046
#define ADC_CONV_CLK_36Tcy          0x0047
#define ADC_CONV_CLK_73Tcy2         0x0048
#define ADC_CONV_CLK_37Tcy          0x0049
#define ADC_CONV_CLK_75Tcy2         0x004A
#define ADC_CONV_CLK_38Tcy          0x004B
#define ADC_CONV_CLK_77Tcy2         0x004C
#define ADC_CONV_CLK_39Tcy          0x004D
#define ADC_CONV_CLK_79Tcy2         0x004E
#define ADC_CONV_CLK_40Tcy          0x004F
#define ADC_CONV_CLK_81Tcy2         0x0050
#define ADC_CONV_CLK_41Tcy          0x0051
#define ADC_CONV_CLK_83Tcy2         0x0052
#define ADC_CONV_CLK_42Tcy          0x0053
#define ADC_CONV_CLK_85Tcy2         0x0054
#define ADC_CONV_CLK_43Tcy          0x0055
#define ADC_CONV_CLK_87Tcy2         0x0056
#define ADC_CONV_CLK_44Tcy          0x0057
#define ADC_CONV_CLK_89Tcy2         0x0058
#define ADC_CONV_CLK_45Tcy          0x0059
#define ADC_CONV_CLK_91Tcy2         0x005A
#define ADC_CONV_CLK_46Tcy          0x005B
#define ADC_CONV_CLK_93Tcy2         0x005C
#define ADC_CONV_CLK_47Tcy          0x005D
#define ADC_CONV_CLK_95Tcy2         0x005E
#define ADC_CONV_CLK_48Tcy          0x005F
#define ADC_CONV_CLK_97Tcy2         0x0060
#define ADC_CONV_CLK_49Tcy          0x0061
#define ADC_CONV_CLK_99Tcy2         0x0062
#define ADC_CONV_CLK_50Tcy          0x0063
#define ADC_CONV_CLK_101Tcy2        0x0064
#define ADC_CONV_CLK_51Tcy          0x0065
#define ADC_CONV_CLK_103Tcy2        0x0066
#define ADC_CONV_CLK_52Tcy          0x0067
#define ADC_CONV_CLK_105Tcy2        0x0068
#define ADC_CONV_CLK_53Tcy          0x0069
#define ADC_CONV_CLK_107Tcy2        0x006A
#define ADC_CONV_CLK_54Tcy          0x006B
#define ADC_CONV_CLK_109Tcy2        0x006C
#define ADC_CONV_CLK_55Tcy          0x006D
#define ADC_CONV_CLK_111Tcy2        0x006E
#define ADC_CONV_CLK_56Tcy          0x006F
#define ADC_CONV_CLK_113Tcy2        0x0070
#define ADC_CONV_CLK_57Tcy          0x0071
#define ADC_CONV_CLK_115Tcy2        0x0072
#define ADC_CONV_CLK_58Tcy          0x0073
#define ADC_CONV_CLK_117Tcy2        0x0074
#define ADC_CONV_CLK_59Tcy          0x0075
#define ADC_CONV_CLK_119Tcy2        0x0076
#define ADC_CONV_CLK_60Tcy          0x0077
#define ADC_CONV_CLK_121Tcy2        0x0078
#define ADC_CONV_CLK_61Tcy          0x0079
#define ADC_CONV_CLK_123Tcy2        0x007A
#define ADC_CONV_CLK_62Tcy          0x007B
#define ADC_CONV_CLK_125Tcy2        0x007C
#define ADC_CONV_CLK_63Tcy          0x007D
#define ADC_CONV_CLK_127Tcy2        0x007E
#define ADC_CONV_CLK_64Tcy          0x007F
#define ADC_CONV_CLK_129Tcy2        0x0080
#define ADC_CONV_CLK_65Tcy          0x0081
#define ADC_CONV_CLK_131Tcy2        0x0082
#define ADC_CONV_CLK_66Tcy          0x0083
#define ADC_CONV_CLK_133Tcy2        0x0084
#define ADC_CONV_CLK_67Tcy          0x0085
#define ADC_CONV_CLK_135Tcy2        0x0086
#define ADC_CONV_CLK_68Tcy          0x0087
#define ADC_CONV_CLK_137Tcy2        0x0088
#define ADC_CONV_CLK_69Tcy          0x0089
#define ADC_CONV_CLK_139Tcy2        0x008A
#define ADC_CONV_CLK_70Tcy          0x008B
#define ADC_CONV_CLK_141Tcy2        0x008C
#define ADC_CONV_CLK_71Tcy          0x008D
#define ADC_CONV_CLK_143Tcy2        0x008E
#define ADC_CONV_CLK_72Tcy          0x008F
#define ADC_CONV_CLK_145Tcy2        0x0090
#define ADC_CONV_CLK_73Tcy          0x0091
#define ADC_CONV_CLK_147Tcy2        0x0092
#define ADC_CONV_CLK_74Tcy          0x0093
#define ADC_CONV_CLK_149Tcy2        0x0094
#define ADC_CONV_CLK_75Tcy          0x0095
#define ADC_CONV_CLK_151Tcy2        0x0096
#define ADC_CONV_CLK_76Tcy          0x0097
#define ADC_CONV_CLK_153Tcy2        0x0098
#define ADC_CONV_CLK_77Tcy          0x0099
#define ADC_CONV_CLK_155Tcy2        0x009A
#define ADC_CONV_CLK_78Tcy          0x009B
#define ADC_CONV_CLK_157Tcy2        0x009C
#define ADC_CONV_CLK_79Tcy          0x009D
#define ADC_CONV_CLK_159Tcy2        0x009E
#define ADC_CONV_CLK_80Tcy          0x009F
#define ADC_CONV_CLK_161Tcy2        0x00A0
#define ADC_CONV_CLK_81Tcy          0x00A1
#define ADC_CONV_CLK_163Tcy2        0x00A2
#define ADC_CONV_CLK_82Tcy          0x00A3
#define ADC_CONV_CLK_165Tcy2        0x00A4
#define ADC_CONV_CLK_83Tcy          0x00A5
#define ADC_CONV_CLK_167Tcy2        0x00A6
#define ADC_CONV_CLK_84Tcy          0x00A7
#define ADC_CONV_CLK_169Tcy2        0x00A8
#define ADC_CONV_CLK_85Tcy          0x00A9
#define ADC_CONV_CLK_171Tcy2        0x00AA
#define ADC_CONV_CLK_86Tcy          0x00AB
#define ADC_CONV_CLK_173Tcy2        0x00AC
#define ADC_CONV_CLK_87Tcy          0x00AD
#define ADC_CONV_CLK_175Tcy2        0x00AE
#define ADC_CONV_CLK_88Tcy          0x00AF
#define ADC_CONV_CLK_177Tcy2        0x00B0
#define ADC_CONV_CLK_89Tcy          0x00B1
#define ADC_CONV_CLK_179Tcy2        0x00B2
#define ADC_CONV_CLK_90Tcy          0x00B3
#define ADC_CONV_CLK_181Tcy2        0x00B4
#define ADC_CONV_CLK_91Tcy          0x00B5
#define ADC_CONV_CLK_183Tcy2        0x00B6
#define ADC_CONV_CLK_92Tcy          0x00B7
#define ADC_CONV_CLK_185Tcy2        0x00B8
#define ADC_CONV_CLK_93Tcy          0x00B9
#define ADC_CONV_CLK_187Tcy2        0x00BA
#define ADC_CONV_CLK_94Tcy          0x00BB
#define ADC_CONV_CLK_189Tcy2        0x00BC
#define ADC_CONV_CLK_95Tcy          0x00BD
#define ADC_CONV_CLK_191Tcy2        0x00BE
#define ADC_CONV_CLK_96Tcy          0x00BF
#define ADC_CONV_CLK_193Tcy2        0x00C0
#define ADC_CONV_CLK_97Tcy          0x00C1
#define ADC_CONV_CLK_195Tcy2        0x00C2
#define ADC_CONV_CLK_98Tcy          0x00C3
#define ADC_CONV_CLK_197Tcy2        0x00C4
#define ADC_CONV_CLK_99Tcy          0x00C5
#define ADC_CONV_CLK_199Tcy2        0x00C6
#define ADC_CONV_CLK_100Tcy         0x00C7
#define ADC_CONV_CLK_201Tcy2        0x00C8
#define ADC_CONV_CLK_101Tcy         0x00C9
#define ADC_CONV_CLK_203Tcy2        0x00CA
#define ADC_CONV_CLK_102Tcy         0x00CB
#define ADC_CONV_CLK_205Tcy2        0x00CC
#define ADC_CONV_CLK_103Tcy         0x00CD
#define ADC_CONV_CLK_207Tcy2        0x00CE
#define ADC_CONV_CLK_104Tcy         0x00CF
#define ADC_CONV_CLK_209Tcy2        0x00D0
#define ADC_CONV_CLK_105Tcy         0x00D1
#define ADC_CONV_CLK_211Tcy2        0x00D2
#define ADC_CONV_CLK_106Tcy         0x00D3
#define ADC_CONV_CLK_213Tcy2        0x00D4
#define ADC_CONV_CLK_107Tcy         0x00D5
#define ADC_CONV_CLK_215Tcy2        0x00D6
#define ADC_CONV_CLK_108Tcy         0x00D7
#define ADC_CONV_CLK_217Tcy2        0x00D8
#define ADC_CONV_CLK_109Tcy         0x00D9
#define ADC_CONV_CLK_219Tcy2        0x00DA
#define ADC_CONV_CLK_110Tcy         0x00DB
#define ADC_CONV_CLK_221Tcy2        0x00DC
#define ADC_CONV_CLK_111Tcy         0x00DD
#define ADC_CONV_CLK_223Tcy2        0x00DE
#define ADC_CONV_CLK_112Tcy         0x00DF
#define ADC_CONV_CLK_225Tcy2        0x00E0
#define ADC_CONV_CLK_113Tcy         0x00E1
#define ADC_CONV_CLK_227Tcy2        0x00E2
#define ADC_CONV_CLK_114Tcy         0x00E3
#define ADC_CONV_CLK_229Tcy2        0x00E4
#define ADC_CONV_CLK_115Tcy         0x00E5
#define ADC_CONV_CLK_231Tcy2        0x00E6
#define ADC_CONV_CLK_116Tcy         0x00E7
#define ADC_CONV_CLK_233Tcy2        0x00E8
#define ADC_CONV_CLK_117Tcy         0x00E9
#define ADC_CONV_CLK_235Tcy2        0x00EA
#define ADC_CONV_CLK_118Tcy         0x00EB
#define ADC_CONV_CLK_237Tcy2        0x00EC
#define ADC_CONV_CLK_119Tcy         0x00ED
#define ADC_CONV_CLK_239Tcy2        0x00EE
#define ADC_CONV_CLK_120Tcy         0x00EF
#define ADC_CONV_CLK_241Tcy2        0x00F0
#define ADC_CONV_CLK_121Tcy         0x00F1
#define ADC_CONV_CLK_243Tcy2        0x00F2
#define ADC_CONV_CLK_122Tcy         0x00F3
#define ADC_CONV_CLK_245Tcy2        0x00F4
#define ADC_CONV_CLK_123Tcy         0x00F5
#define ADC_CONV_CLK_247Tcy2        0x00F6
#define ADC_CONV_CLK_124Tcy         0x00F7
#define ADC_CONV_CLK_249Tcy2        0x00F8
#define ADC_CONV_CLK_125Tcy         0x00F9
#define ADC_CONV_CLK_251Tcy2        0x00FA
#define ADC_CONV_CLK_126Tcy         0x00FB
#define ADC_CONV_CLK_253Tcy2        0x00FC
#define ADC_CONV_CLK_127Tcy         0x00FD
#define ADC_CONV_CLK_255Tcy2        0x00FE    /* ... */
#define ADC_CONV_CLK_128Tcy         0x00FF    /* A/D Conversion Clock is 256*Tcy/2 */
#define ADC_CONV_CLK_MASK           (~ADC_CONV_CLK_256Tcy2)

/* ADC1 Input channel 0 select register */

#define ADC_CH0_NEG_SAMPLEB_AN1     0x8000  /* CH0 negative input is AN1 */
#define ADC_CH0_NEG_SAMPLEB_VREFN   0x0000  /* CH0 negative input is VREF- */
#define ADC_CH0_NEG_SAMPLEB_MASK    (~ADC_CH0_NEG_SAMPLEB_AN1)

#define ADC_CH0_POS_SAMPLEB_AN15    0x0F00  /* A/D CH0 pos i/p sel for SAMPLE B is AN15 */
#define ADC_CH0_POS_SAMPLEB_AN14    0x0E00  /* A/D CH0 pos i/p sel for SAMPLE B is AN14 */
#define ADC_CH0_POS_SAMPLEB_AN13    0x0D00  /* A/D CH0 pos i/p sel for SAMPLE B is AN13 */
#define ADC_CH0_POS_SAMPLEB_AN12    0x0C00  /* A/D CH0 pos i/p sel for SAMPLE B is AN12 */
#define ADC_CH0_POS_SAMPLEB_AN11    0x0B00  /* A/D CH0 pos i/p sel for SAMPLE B is AN11 */
#define ADC_CH0_POS_SAMPLEB_AN10    0x0A00  /* A/D CH0 pos i/p sel for SAMPLE B is AN10 */
#define ADC_CH0_POS_SAMPLEB_AN9     0x0900  /* A/D CH0 pos i/p sel for SAMPLE B is AN9 */
#define ADC_CH0_POS_SAMPLEB_AN8     0x0800  /* A/D CH0 pos i/p sel for SAMPLE B is AN8 */
#define ADC_CH0_POS_SAMPLEB_AN7     0x0700  /* A/D CH0 pos i/p sel for SAMPLE B is AN7 */
#define ADC_CH0_POS_SAMPLEB_AN6     0x0600  /* A/D CH0 pos i/p sel for SAMPLE B is AN6 */
#define ADC_CH0_POS_SAMPLEB_AN5     0x0500  /* A/D CH0 pos i/p sel for SAMPLE B is AN5 */
#define ADC_CH0_POS_SAMPLEB_AN4     0x0400  /* A/D CH0 pos i/p sel for SAMPLE B is AN4 */
#define ADC_CH0_POS_SAMPLEB_AN3     0x0300  /* A/D CH0 pos i/p sel for SAMPLE B is AN3 */
#define ADC_CH0_POS_SAMPLEB_AN2     0x0200  /* A/D CH0 pos i/p sel for SAMPLE B is AN2 */
#define ADC_CH0_POS_SAMPLEB_AN1     0x0100  /* A/D CH0 pos i/p sel for SAMPLE B is AN1 */
#define ADC_CH0_POS_SAMPLEB_AN0     0x0F00 /* A/D CH0 pos i/p sel for SAMPLE B is AN0 */
#define ADC_CH0_POS_SAMPLEB_MASK    (~ADC_CH0_POS_SAMPLEB_AN0)

#define ADC_CH0_NEG_SAMPLEA_AN1     0x0080  /*A/D CH0 neg I/P sel for SAMPLE A is AN1 */
#define ADC_CH0_NEG_SAMPLEA_VREFN   0x0000  /*A/D CH0 neg I/P sel for SAMPLE A is Vrefn */
#define ADC_CH0_NEG_SAMPLEA_MASK    (~ADC_CH0_NEG_SAMPLEA_AN1)

#define ADC_CH0_POS_SAMPLEA_AN15    0x000F  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN15 */
#define ADC_CH0_POS_SAMPLEA_AN14    0x000E  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN14 */
#define ADC_CH0_POS_SAMPLEA_AN13    0x000D  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN13 */
#define ADC_CH0_POS_SAMPLEA_AN12    0x000C  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN12 */
#define ADC_CH0_POS_SAMPLEA_AN11    0x000B  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN11 */
#define ADC_CH0_POS_SAMPLEA_AN10    0x000A  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN10 */
#define ADC_CH0_POS_SAMPLEA_AN9     0x0009  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN9 */   
#define ADC_CH0_POS_SAMPLEA_AN8     0x0008  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN8 */   
#define ADC_CH0_POS_SAMPLEA_AN7     0x0007  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN7 */ 
#define ADC_CH0_POS_SAMPLEA_AN6     0x0006  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN6 */   
#define ADC_CH0_POS_SAMPLEA_AN5     0x0005  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN5 */   
#define ADC_CH0_POS_SAMPLEA_AN4     0x0004  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN4 */   
#define ADC_CH0_POS_SAMPLEA_AN3     0x0003  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN3 */   
#define ADC_CH0_POS_SAMPLEA_AN2     0x0002  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN2 */   
#define ADC_CH0_POS_SAMPLEA_AN1     0x0001  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN1 */   
#define ADC_CH0_POS_SAMPLEA_AN0     0x0000  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN0 */   
#define ADC_CH0_POS_SAMPLEA_MASK    (~ADC_CH0_POS_SAMPLEA_AN0)

/*defines for ADxPCFGL register */

#define ENABLE_AN0_ANA              0x0001 /*Enable AN0 in analog mode */
#define ENABLE_AN1_ANA              0x0002 /*Enable AN1 in analog mode */
#define ENABLE_AN2_ANA              0x0004 /*Enable AN2 in analog mode */
#define ENABLE_AN3_ANA              0x0008 /*Enable AN3 in analog mode */
#define ENABLE_AN4_ANA              0x0010 /*Enable AN4 in analog mode */
#define ENABLE_AN5_ANA              0x0020 /*Enable AN5 in analog mode */
#define ENABLE_AN6_ANA              0x0040 /*Enable AN6 in analog mode */
#define ENABLE_AN7_ANA              0x0080 /*Enable AN7 in analog mode */
#define ENABLE_AN8_ANA              0x0100 /*Enable AN8 in analog mode */
#define ENABLE_AN9_ANA              0x0200 /*Enable AN9 in analog mode */
#define ENABLE_AN10_ANA             0x0400 /*Enable AN10 in analog mode */
#define ENABLE_AN11_ANA             0x0800 /*Enable AN11 in analog mode */
#define ENABLE_AN12_ANA             0x1000 /*Enable AN12 in analog mode */
#define ENABLE_AN13_ANA             0x2000 /*Enable AN13 in analog mode */
#define ENABLE_AN14_ANA             0x4000 /*Enable AN14 in analog mode */
#define ENABLE_AN15_ANA             0x8000 /*Enable AN15 in analog mode */

#define ENABLE_ALL_ANA_0_15         0xFFFF /*Enable AN0-AN15 in analog mode */
#define ENABLE_ALL_DIG_0_15         0x0000 /*Enable AN0-AN15 in Digital mode */

/*defines for ADxCSSL register */

#define ADC_SCAN_AN0      0x0001 /*Enable Input Scan AN0 */
#define ADC_SCAN_AN1      0x0002 /*Enable Input Scan AN1 */
#define ADC_SCAN_AN2      0x0004 /*Enable Input Scan AN2 */
#define ADC_SCAN_AN3      0x0008 /*Enable Input Scan AN3 */
#define ADC_SCAN_AN4      0x0010 /*Enable Input Scan AN4 */
#define ADC_SCAN_AN5      0x0020 /*Enable Input Scan AN5 */
#define ADC_SCAN_AN6      0x0040 /*Enable Input Scan AN6 */
#define ADC_SCAN_AN7      0x0080 /*Enable Input Scan AN7 */
#define ADC_SCAN_AN8      0x0100 /*Enable Input Scan AN8 */
#define ADC_SCAN_AN9      0x0200 /*Enable Input Scan AN9 */
#define ADC_SCAN_AN10     0x0400 /*Enable Input Scan AN10 */
#define ADC_SCAN_AN11     0x0800 /*Enable Input Scan AN11 */
#define ADC_SCAN_AN12     0x1000 /*Enable Input Scan AN12 */
#define ADC_SCAN_AN13     0x2000 /*Enable Input Scan AN13 */
#define ADC_SCAN_AN14     0x4000 /*Enable Input Scan AN14 */
#define ADC_SCAN_AN15     0x8000 /*Enable Input Scan AN15 */

#define ENABLE_ALL_INPUT_SCAN       0xFFFF /*Enable Input Scan AN0-AN15 */
#define DISABLE_ALL_INPU_SCAN       0x0000 /*Disable Input Scan AN0-AN15 */

/* Setting the priority of adc interrupt */
#define ADC_INT_PRI_0               0x0000
#define ADC_INT_PRI_1               0x0001
#define ADC_INT_PRI_2               0x0002
#define ADC_INT_PRI_3               0x0003
#define ADC_INT_PRI_4               0x0004
#define ADC_INT_PRI_5               0x0005
#define ADC_INT_PRI_6               0x0006
#define ADC_INT_PRI_7               0x0007

/* enable / disable interrupts */

#define ADC_INT_ENABLE              0x0008
#define ADC_INT_DISABLE             ~ADC_INT_ENABLE

#else /* Format for backward compatibility (AND based bit setting). */

/* AD1CON1 Configuration Bit Definitions */

#define ADC_MODULE_ON               0xFFFF /* A/D Converter on */
#define ADC_MODULE_OFF              0x7FFF /* A/D Converter off */

#define ADC_IDLE_CONTINUE           0xDFFF /* A/D Operate in Idle mode */
#define ADC_IDLE_STOP               0xFFFF /* A/D Stop in Idle mode */

#define ADC_FORMAT_SIGN_FRACT       0xFFFF /* A/D data format signed fractional */
#define ADC_FORMAT_FRACT            0xFEFF /* A/D data format fractional */
#define ADC_FORMAT_SIGN_INT         0xFDFF /* A/D data format signed integer */
#define ADC_FORMAT_INTG             0xFCFF /* A/D data format integer */

/* SSRC<2:0> bit defines */

#define ADC_CLK_AUTO                0xFFFF  /* Internal counter ends sampling and starts conversion (Auto convert) */
#define ADC_CLK_MPWM                0xFF7F  /* MPWM interval ends sampling and starts conversion */
#define ADC_CLK_TMR                 0xFF5F  /* GP Timer compare ends sampling and starts conversion */
#define ADC_CLK_INT0                0xFF3F  /* Active transition on INTx ends sampling and starts conversion */
#define ADC_CLK_MANUAL              0xFF1F  /* Clearing sample (SAMP) bit ends sampling and starts conversion */

#define ADC_AUTO_SAMPLING_ON        0xFFFF  /* Sampling begins immediately after last conversion */
#define ADC_AUTO_SAMPLING_OFF       0xFFFB  /* Sampling begins when SAMP bit is set */

#define ADC_SAMP_ON                 0xFFFF  /* sample / hold amplifiers are sampling */
#define ADC_SAMP_OFF                0xFFFD  /* sample / hold amplifiers are holding */


/* defines for the ADCON2 register */


#define ADC_VREF_AVDD_AVSS          0x0FFF  /* A/D Voltage reference configuration Vref+ is AVdd and Vref- is AVss */
#define ADC_VREF_EXT_AVSS           0x2FFF  /* A/D Voltage reference configuration Vref+ external and Vref- is AVss */
#define ADC_VREF_AVDD_EXT           0x4FFF  /* A/D Voltage reference configuration Vref+ AVdd and Vref- external */
#define ADC_VREF_EXT_EXT            0x6FFF  /* A/D Voltage reference configuration both Vref+ and Vref- are external */

#define ADC_SCAN_ON                 0xEFFF  /* A/D Scan Input Selections for CH0 during SAMPLE A */
#define ADC_SCAN_OFF                0xEBFF  /* A/D Do notScan Input Selections for CH0+ during SAMPLE A */

#define ADC_INTR_EACH_CONV         0xEFC3  /* Interrupts at the completion of conversion of each sample */
#define ADC_INTR_2_CONV            0xEFC7  /* Interrupts at the completion of conversion of 2 samples */
#define ADC_INTR_3_CONV            0xEFCB  /* Interrupts at the completion of conversion of 3 samples */
#define ADC_INTR_4_CONV            0xEFCF  /* Interrupts at the completion of conversion of 4 samples */
#define ADC_INTR_5_CONV            0xEFD3  /* Interrupts at the completion of conversion of 5 samples */
#define ADC_INTR_6_CONV            0xEFD7  /* Interrupts at the completion of conversion of 6 samples */
#define ADC_INTR_7_CONV            0xEFDB  /* Interrupts at the completion of conversion of 7 samples */
#define ADC_INTR_8_CONV            0xEFDF  /* Interrupts at the completion of conversion of 8 samples */
#define ADC_INTR_9_CONV            0xEFE3  /* Interrupts at the completion of conversion of 9 samples */
#define ADC_INTR_10_CONV           0xEFE7  /* Interrupts at the completion of conversion of 10 samples */
#define ADC_INTR_11_CONV           0xEFEB  /* Interrupts at the completion of conversion of 11 samples */
#define ADC_INTR_12_CONV           0xEFEF  /* Interrupts at the completion of conversion of 12 samples */
#define ADC_INTR_13_CONV           0xEFF3  /* Interrupts at the completion of conversion of 13 samples */
#define ADC_INTR_14_CONV           0xEFF7  /* Interrupts at the completion of conversion of 14 samples */
#define ADC_INTR_15_CONV           0xEFFB  /* Interrupts at the completion of conversion of 15 samples */
#define ADC_INTR_16_CONV           0xEFFF  /* Interrupts at the completion of conversion of 16 samples */

/* BUFM bit defines */

#define ADC_ALT_BUF_ON              0xEFFF /* Buffer configured as 2 8-word buffers */
#define ADC_ALT_BUF_OFF             0xEFFD /* Buffer configured as 1 16-word buffer */

/* A/D Uses channel input selects for SAMPLE A on first sample and SAMPLE B on next sample */
#define ADC_ALT_INPUT_ON            0xEFFF /* alternate between MUXA and MUXB */

/* A/D Always uses channel input selects for SAMPLE A */
#define ADC_ALT_INPUT_OFF           0xEFFE /* use MUXA only */


/* defines for ADCON3 register */
#define ADC_SAMPLE_TIME_0           0xE0FF /* A/D Auto Sample Time 0 Tad */
#define ADC_SAMPLE_TIME_1           0xE1FF /* A/D Auto Sample Time 1 Tad */
#define ADC_SAMPLE_TIME_2           0xE2FF /* A/D Auto Sample Time 2 Tad */
#define ADC_SAMPLE_TIME_3           0xE3FF /* A/D Auto Sample Time 3 Tad */
#define ADC_SAMPLE_TIME_4           0xE4FF /* A/D Auto Sample Time 4 Tad */
#define ADC_SAMPLE_TIME_5           0xE5FF /* A/D Auto Sample Time 5 Tad */
#define ADC_SAMPLE_TIME_6           0xE6FF /* A/D Auto Sample Time 6 Tad */
#define ADC_SAMPLE_TIME_7           0xE7FF /* A/D Auto Sample Time 7 Tad */
#define ADC_SAMPLE_TIME_8           0xE8FF /* A/D Auto Sample Time 8 Tad */
#define ADC_SAMPLE_TIME_9           0xE9FF /* A/D Auto Sample Time 9 Tad */
#define ADC_SAMPLE_TIME_10          0xEAFF /* A/D Auto Sample Time 10 Tad */
#define ADC_SAMPLE_TIME_11          0xEBFF /* A/D Auto Sample Time 11 Tad */
#define ADC_SAMPLE_TIME_12          0xECFF /* A/D Auto Sample Time 12 Tad */
#define ADC_SAMPLE_TIME_13          0xEDFF /* A/D Auto Sample Time 13 Tad */
#define ADC_SAMPLE_TIME_14          0xEEFF /* A/D Auto Sample Time 14 Tad */
#define ADC_SAMPLE_TIME_15          0xEFFF /* A/D Auto Sample Time 15 Tad */
#define ADC_SAMPLE_TIME_16          0xF0FF /* A/D Auto Sample Time 16 Tad */
#define ADC_SAMPLE_TIME_17          0xF1FF /* A/D Auto Sample Time 17 Tad */
#define ADC_SAMPLE_TIME_18          0xF2FF /* A/D Auto Sample Time 18 Tad */
#define ADC_SAMPLE_TIME_19          0xF3FF /* A/D Auto Sample Time 19 Tad */
#define ADC_SAMPLE_TIME_20          0xF4FF /* A/D Auto Sample Time 20 Tad */
#define ADC_SAMPLE_TIME_21          0xF5FF /* A/D Auto Sample Time 21 Tad */
#define ADC_SAMPLE_TIME_22          0xF6FF /* A/D Auto Sample Time 22 Tad */
#define ADC_SAMPLE_TIME_23          0xF7FF /* A/D Auto Sample Time 23 Tad */
#define ADC_SAMPLE_TIME_24          0xF8FF /* A/D Auto Sample Time 24 Tad */
#define ADC_SAMPLE_TIME_25          0xF9FF /* A/D Auto Sample Time 25 Tad */
#define ADC_SAMPLE_TIME_26          0xFAFF /* A/D Auto Sample Time 26 Tad */
#define ADC_SAMPLE_TIME_27          0xFBFF /* A/D Auto Sample Time 27 Tad */
#define ADC_SAMPLE_TIME_28          0xFCFF /* A/D Auto Sample Time 28 Tad */
#define ADC_SAMPLE_TIME_29          0xFDFF /* A/D Auto Sample Time 29 Tad */
#define ADC_SAMPLE_TIME_30          0xFEFF /* A/D Auto Sample Time 30 Tad */
#define ADC_SAMPLE_TIME_31          0xFFFF /* A/D Auto Sample Time 31 Tad */

/* A/D Conversion Clock Source internal RC Clock */
#define ADC_CONV_CLK_INTERNAL_RC    0xFFFF
/* A/D Conversion Clock Source Clock derived from system clock */
#define ADC_CONV_CLK_SYSTEM         0xFF7F

/* A/D conversion clock select bit ADCS<5:0>*/
#define ADC_CONV_CLK_1Tcy2          0xFF00      /* A/D Conversion Clock is Tcy/2 */
#define ADC_CONV_CLK_1Tcy           0xFF01     /* A/D Conversion Clock is 2*Tcy/2 */
#define ADC_CONV_CLK_3Tcy2          0xFF02     /* A/D Conversion Clock is 3*Tcy/2 */
#define ADC_CONV_CLK_2Tcy           0xFF03     /* A/D Conversion Clock is 4*Tcy/2 */
#define ADC_CONV_CLK_5Tcy2          0xFF04     /* A/D Conversion Clock is 5*Tcy/2 */
#define ADC_CONV_CLK_3Tcy           0xFF05     /* ... */
#define ADC_CONV_CLK_7Tcy2          0xFF06
#define ADC_CONV_CLK_4Tcy           0xFF07
#define ADC_CONV_CLK_9Tcy2          0xFF08
#define ADC_CONV_CLK_5Tcy           0xFF09
#define ADC_CONV_CLK_11Tcy2         0xFF0A
#define ADC_CONV_CLK_6Tcy           0xFF0B
#define ADC_CONV_CLK_13Tcy2         0xFF0C
#define ADC_CONV_CLK_7Tcy           0xFF0D
#define ADC_CONV_CLK_15Tcy2         0xFF0E
#define ADC_CONV_CLK_8Tcy           0xFF0F
#define ADC_CONV_CLK_17Tcy2         0xFF10
#define ADC_CONV_CLK_9Tcy           0xFF11
#define ADC_CONV_CLK_19Tcy2         0xFF12
#define ADC_CONV_CLK_10Tcy          0xFF13
#define ADC_CONV_CLK_21Tcy2         0xFF14
#define ADC_CONV_CLK_11Tcy          0xFF15
#define ADC_CONV_CLK_23Tcy2         0xFF16
#define ADC_CONV_CLK_12Tcy          0xFF17
#define ADC_CONV_CLK_25Tcy2         0xFF18
#define ADC_CONV_CLK_13Tcy          0xFF19
#define ADC_CONV_CLK_27Tcy2         0xFF1A
#define ADC_CONV_CLK_14Tcy          0xFF1B
#define ADC_CONV_CLK_29Tcy2         0xFF1C
#define ADC_CONV_CLK_15Tcy          0xFF1D
#define ADC_CONV_CLK_31Tcy2         0xFF1E
#define ADC_CONV_CLK_16Tcy          0xFF1F
#define ADC_CONV_CLK_33Tcy2         0xFF20
#define ADC_CONV_CLK_17Tcy          0xFF21
#define ADC_CONV_CLK_35Tcy2         0xFF22
#define ADC_CONV_CLK_18Tcy          0xFF23
#define ADC_CONV_CLK_37Tcy2         0xFF24
#define ADC_CONV_CLK_19Tcy          0xFF25
#define ADC_CONV_CLK_39Tcy2         0xFF26
#define ADC_CONV_CLK_20Tcy          0xFF27
#define ADC_CONV_CLK_41Tcy2         0xFF28
#define ADC_CONV_CLK_21Tcy          0xFF29
#define ADC_CONV_CLK_43Tcy2         0xFF2A
#define ADC_CONV_CLK_22Tcy          0xFF2B
#define ADC_CONV_CLK_45Tcy2         0xFF2C
#define ADC_CONV_CLK_23Tcy          0xFF2D
#define ADC_CONV_CLK_47Tcy2         0xFF2E
#define ADC_CONV_CLK_24Tcy          0xFF2F
#define ADC_CONV_CLK_49Tcy2         0xFF30
#define ADC_CONV_CLK_25Tcy          0xFF31
#define ADC_CONV_CLK_51Tcy2         0xFF32
#define ADC_CONV_CLK_26Tcy          0xFF33
#define ADC_CONV_CLK_53Tcy2         0xFF34
#define ADC_CONV_CLK_27Tcy          0xFF35
#define ADC_CONV_CLK_55Tcy2         0xFF36
#define ADC_CONV_CLK_28Tcy          0xFF37
#define ADC_CONV_CLK_57Tcy2         0xFF38
#define ADC_CONV_CLK_29Tcy          0xFF39
#define ADC_CONV_CLK_59Tcy2         0xFF3A
#define ADC_CONV_CLK_30Tcy          0xFF3B
#define ADC_CONV_CLK_61Tcy2         0xFF3C
#define ADC_CONV_CLK_31Tcy          0xFF3D
#define ADC_CONV_CLK_63Tcy2         0xFF3E
#define ADC_CONV_CLK_32Tcy          0xFF3F
#define ADC_CONV_CLK_65Tcy2         0xFF40
#define ADC_CONV_CLK_33Tcy          0xFF41
#define ADC_CONV_CLK_67Tcy2         0xFF42
#define ADC_CONV_CLK_34Tcy          0xFF43
#define ADC_CONV_CLK_69Tcy2         0xFF44
#define ADC_CONV_CLK_35Tcy          0xFF45
#define ADC_CONV_CLK_71Tcy2         0xFF46
#define ADC_CONV_CLK_36Tcy          0xFF47
#define ADC_CONV_CLK_73Tcy2         0xFF48
#define ADC_CONV_CLK_37Tcy          0xFF49
#define ADC_CONV_CLK_75Tcy2         0xFF4A
#define ADC_CONV_CLK_38Tcy          0xFF4B
#define ADC_CONV_CLK_77Tcy2         0xFF4C
#define ADC_CONV_CLK_39Tcy          0xFF4D
#define ADC_CONV_CLK_79Tcy2         0xFF4E
#define ADC_CONV_CLK_40Tcy          0xFF4F
#define ADC_CONV_CLK_81Tcy2         0xFF50
#define ADC_CONV_CLK_41Tcy          0xFF51
#define ADC_CONV_CLK_83Tcy2         0xFF52
#define ADC_CONV_CLK_42Tcy          0xFF53
#define ADC_CONV_CLK_85Tcy2         0xFF54
#define ADC_CONV_CLK_43Tcy          0xFF55
#define ADC_CONV_CLK_87Tcy2         0xFF56
#define ADC_CONV_CLK_44Tcy          0xFF57
#define ADC_CONV_CLK_89Tcy2         0xFF58
#define ADC_CONV_CLK_45Tcy          0xFF59
#define ADC_CONV_CLK_91Tcy2         0xFF5A
#define ADC_CONV_CLK_46Tcy          0xFF5B
#define ADC_CONV_CLK_93Tcy2         0xFF5C
#define ADC_CONV_CLK_47Tcy          0xFF5D
#define ADC_CONV_CLK_95Tcy2         0xFF5E
#define ADC_CONV_CLK_48Tcy          0xFF5F
#define ADC_CONV_CLK_97Tcy2         0xFF60
#define ADC_CONV_CLK_49Tcy          0xFF61
#define ADC_CONV_CLK_99Tcy2         0xFF62
#define ADC_CONV_CLK_50Tcy          0xFF63
#define ADC_CONV_CLK_101Tcy2        0xFF64
#define ADC_CONV_CLK_51Tcy          0xFF65
#define ADC_CONV_CLK_103Tcy2        0xFF66
#define ADC_CONV_CLK_52Tcy          0xFF67
#define ADC_CONV_CLK_105Tcy2        0xFF68
#define ADC_CONV_CLK_53Tcy          0xFF69
#define ADC_CONV_CLK_107Tcy2        0xFF6A
#define ADC_CONV_CLK_54Tcy          0xFF6B
#define ADC_CONV_CLK_109Tcy2        0xFF6C
#define ADC_CONV_CLK_55Tcy          0xFF6D
#define ADC_CONV_CLK_111Tcy2        0xFF6E
#define ADC_CONV_CLK_56Tcy          0xFF6F
#define ADC_CONV_CLK_113Tcy2        0xFF70
#define ADC_CONV_CLK_57Tcy          0xFF71
#define ADC_CONV_CLK_115Tcy2        0xFF72
#define ADC_CONV_CLK_58Tcy          0xFF73
#define ADC_CONV_CLK_117Tcy2        0xFF74
#define ADC_CONV_CLK_59Tcy          0xFF75
#define ADC_CONV_CLK_119Tcy2        0xFF76
#define ADC_CONV_CLK_60Tcy          0xFF77
#define ADC_CONV_CLK_121Tcy2        0xFF78
#define ADC_CONV_CLK_61Tcy          0xFF79
#define ADC_CONV_CLK_123Tcy2        0xFF7A
#define ADC_CONV_CLK_62Tcy          0xFF7B
#define ADC_CONV_CLK_125Tcy2        0xFF7C
#define ADC_CONV_CLK_63Tcy          0xFF7D
#define ADC_CONV_CLK_127Tcy2        0xFF7E
#define ADC_CONV_CLK_64Tcy          0xFF7F
#define ADC_CONV_CLK_129Tcy2        0xFF80
#define ADC_CONV_CLK_65Tcy          0xFF81
#define ADC_CONV_CLK_131Tcy2        0xFF82
#define ADC_CONV_CLK_66Tcy          0xFF83
#define ADC_CONV_CLK_133Tcy2        0xFF84
#define ADC_CONV_CLK_67Tcy          0xFF85
#define ADC_CONV_CLK_135Tcy2        0xFF86
#define ADC_CONV_CLK_68Tcy          0xFF87
#define ADC_CONV_CLK_137Tcy2        0xFF88
#define ADC_CONV_CLK_69Tcy          0xFF89
#define ADC_CONV_CLK_139Tcy2        0xFF8A
#define ADC_CONV_CLK_70Tcy          0xFF8B
#define ADC_CONV_CLK_141Tcy2        0xFF8C
#define ADC_CONV_CLK_71Tcy          0xFF8D
#define ADC_CONV_CLK_143Tcy2        0xFF8E
#define ADC_CONV_CLK_72Tcy          0xFF8F
#define ADC_CONV_CLK_145Tcy2        0xFF90
#define ADC_CONV_CLK_73Tcy          0xFF91
#define ADC_CONV_CLK_147Tcy2        0xFF92
#define ADC_CONV_CLK_74Tcy          0xFF93
#define ADC_CONV_CLK_149Tcy2        0xFF94
#define ADC_CONV_CLK_75Tcy          0xFF95
#define ADC_CONV_CLK_151Tcy2        0xFF96
#define ADC_CONV_CLK_76Tcy          0xFF97
#define ADC_CONV_CLK_153Tcy2        0xFF98
#define ADC_CONV_CLK_77Tcy          0xFF99
#define ADC_CONV_CLK_155Tcy2        0xFF9A
#define ADC_CONV_CLK_78Tcy          0xFF9B
#define ADC_CONV_CLK_157Tcy2        0xFF9C
#define ADC_CONV_CLK_79Tcy          0xFF9D
#define ADC_CONV_CLK_159Tcy2        0xFF9E
#define ADC_CONV_CLK_80Tcy          0xFF9F
#define ADC_CONV_CLK_161Tcy2        0xFFA0
#define ADC_CONV_CLK_81Tcy          0xFFA1
#define ADC_CONV_CLK_163Tcy2        0xFFA2
#define ADC_CONV_CLK_82Tcy          0xFFA3
#define ADC_CONV_CLK_165Tcy2        0xFFA4
#define ADC_CONV_CLK_83Tcy          0xFFA5
#define ADC_CONV_CLK_167Tcy2        0xFFA6
#define ADC_CONV_CLK_84Tcy          0xFFA7
#define ADC_CONV_CLK_169Tcy2        0xFFA8
#define ADC_CONV_CLK_85Tcy          0xFFA9
#define ADC_CONV_CLK_171Tcy2        0xFFAA
#define ADC_CONV_CLK_86Tcy          0xFFAB
#define ADC_CONV_CLK_173Tcy2        0xFFAC
#define ADC_CONV_CLK_87Tcy          0xFFAD
#define ADC_CONV_CLK_175Tcy2        0xFFAE
#define ADC_CONV_CLK_88Tcy          0xFFAF
#define ADC_CONV_CLK_177Tcy2        0xFFB0
#define ADC_CONV_CLK_89Tcy          0xFFB1
#define ADC_CONV_CLK_179Tcy2        0xFFB2
#define ADC_CONV_CLK_90Tcy          0xFFB3
#define ADC_CONV_CLK_181Tcy2        0xFFB4
#define ADC_CONV_CLK_91Tcy          0xFFB5
#define ADC_CONV_CLK_183Tcy2        0xFFB6
#define ADC_CONV_CLK_92Tcy          0xFFB7
#define ADC_CONV_CLK_185Tcy2        0xFFB8
#define ADC_CONV_CLK_93Tcy          0xFFB9
#define ADC_CONV_CLK_187Tcy2        0xFFBA
#define ADC_CONV_CLK_94Tcy          0xFFBB
#define ADC_CONV_CLK_189Tcy2        0xFFBC
#define ADC_CONV_CLK_95Tcy          0xFFBD
#define ADC_CONV_CLK_191Tcy2        0xFFBE
#define ADC_CONV_CLK_96Tcy          0xFFBF
#define ADC_CONV_CLK_193Tcy2        0xFFC0
#define ADC_CONV_CLK_97Tcy          0xFFC1
#define ADC_CONV_CLK_195Tcy2        0xFFC2
#define ADC_CONV_CLK_98Tcy          0xFFC3
#define ADC_CONV_CLK_197Tcy2        0xFFC4
#define ADC_CONV_CLK_99Tcy          0xFFC5
#define ADC_CONV_CLK_199Tcy2        0xFFC6
#define ADC_CONV_CLK_100Tcy         0xFFC7
#define ADC_CONV_CLK_201Tcy2        0xFFC8
#define ADC_CONV_CLK_101Tcy         0xFFC9
#define ADC_CONV_CLK_203Tcy2        0xFFCA
#define ADC_CONV_CLK_102Tcy         0xFFCB
#define ADC_CONV_CLK_205Tcy2        0xFFCC
#define ADC_CONV_CLK_103Tcy         0xFFCD
#define ADC_CONV_CLK_207Tcy2        0xFFCE
#define ADC_CONV_CLK_104Tcy         0xFFCF
#define ADC_CONV_CLK_209Tcy2        0xFFD0
#define ADC_CONV_CLK_105Tcy         0xFFD1
#define ADC_CONV_CLK_211Tcy2        0xFFD2
#define ADC_CONV_CLK_106Tcy         0xFFD3
#define ADC_CONV_CLK_213Tcy2        0xFFD4
#define ADC_CONV_CLK_107Tcy         0xFFD5
#define ADC_CONV_CLK_215Tcy2        0xFFD6
#define ADC_CONV_CLK_108Tcy         0xFFD7
#define ADC_CONV_CLK_217Tcy2        0xFFD8
#define ADC_CONV_CLK_109Tcy         0xFFD9
#define ADC_CONV_CLK_219Tcy2        0xFFDA
#define ADC_CONV_CLK_110Tcy         0xFFDB
#define ADC_CONV_CLK_221Tcy2        0xFFDC
#define ADC_CONV_CLK_111Tcy         0xFFDD
#define ADC_CONV_CLK_223Tcy2        0xFFDE
#define ADC_CONV_CLK_112Tcy         0xFFDF
#define ADC_CONV_CLK_225Tcy2        0xFFE0
#define ADC_CONV_CLK_113Tcy         0xFFE1
#define ADC_CONV_CLK_227Tcy2        0xFFE2
#define ADC_CONV_CLK_114Tcy         0xFFE3
#define ADC_CONV_CLK_229Tcy2        0xFFE4
#define ADC_CONV_CLK_115Tcy         0xFFE5
#define ADC_CONV_CLK_231Tcy2        0xFFE6
#define ADC_CONV_CLK_116Tcy         0xFFE7
#define ADC_CONV_CLK_233Tcy2        0xFFE8
#define ADC_CONV_CLK_117Tcy         0xFFE9
#define ADC_CONV_CLK_235Tcy2        0xFFEA
#define ADC_CONV_CLK_118Tcy         0xFFEB
#define ADC_CONV_CLK_237Tcy2        0xFFEC
#define ADC_CONV_CLK_119Tcy         0xFFED
#define ADC_CONV_CLK_239Tcy2        0xFFEE
#define ADC_CONV_CLK_120Tcy         0xFFEF
#define ADC_CONV_CLK_241Tcy2        0xFFF0
#define ADC_CONV_CLK_121Tcy         0xFFF1
#define ADC_CONV_CLK_243Tcy2        0xFFF2
#define ADC_CONV_CLK_122Tcy         0xFFF3
#define ADC_CONV_CLK_245Tcy2        0xFFF4
#define ADC_CONV_CLK_123Tcy         0xFFF5
#define ADC_CONV_CLK_247Tcy2        0xFFF6
#define ADC_CONV_CLK_124Tcy         0xFFF7
#define ADC_CONV_CLK_249Tcy2        0xFFF8
#define ADC_CONV_CLK_125Tcy         0xFFF9
#define ADC_CONV_CLK_251Tcy2        0xFFFA
#define ADC_CONV_CLK_126Tcy         0xFFFB
#define ADC_CONV_CLK_253Tcy2        0xFFFC
#define ADC_CONV_CLK_127Tcy         0xFFFD
#define ADC_CONV_CLK_255Tcy2        0xFFFE    /* ... */
#define ADC_CONV_CLK_128Tcy         0xFFFF    /* A/D Conversion Clock is 256*Tcy/2 */

/* ADCx Input channel 0 select register */

#define ADC_CH0_NEG_SAMPLEB_AN1     0xFFFF  /* CH0 negative input is AN1 */
#define ADC_CH0_NEG_SAMPLEB_NREFN   0x7FFF  /* CH0 negative input is VREF- */

#define ADC_CH0_POS_SAMPLEB_AN15    0xFFFF  /* A/D CH0 pos i/p sel for SAMPLE B is AN15 */
#define ADC_CH0_POS_SAMPLEB_AN14    0xFEFF  /* A/D CH0 pos i/p sel for SAMPLE B is AN14 */
#define ADC_CH0_POS_SAMPLEB_AN13    0xFDFF  /* A/D CH0 pos i/p sel for SAMPLE B is AN13 */
#define ADC_CH0_POS_SAMPLEB_AN12    0xFCFF  /* A/D CH0 pos i/p sel for SAMPLE B is AN12 */
#define ADC_CH0_POS_SAMPLEB_AN11    0xFBFF  /* A/D CH0 pos i/p sel for SAMPLE B is AN11 */
#define ADC_CH0_POS_SAMPLEB_AN10    0xFAFF  /* A/D CH0 pos i/p sel for SAMPLE B is AN10 */
#define ADC_CH0_POS_SAMPLEB_AN9     0xF9FF  /* A/D CH0 pos i/p sel for SAMPLE B is AN9 */
#define ADC_CH0_POS_SAMPLEB_AN8     0xF8FF  /* A/D CH0 pos i/p sel for SAMPLE B is AN8 */
#define ADC_CH0_POS_SAMPLEB_AN7     0xF7FF  /* A/D CH0 pos i/p sel for SAMPLE B is AN7 */
#define ADC_CH0_POS_SAMPLEB_AN6     0xF6FF  /* A/D CH0 pos i/p sel for SAMPLE B is AN6 */
#define ADC_CH0_POS_SAMPLEB_AN5     0xF5FF  /* A/D CH0 pos i/p sel for SAMPLE B is AN5 */
#define ADC_CH0_POS_SAMPLEB_AN4     0xF4FF  /* A/D CH0 pos i/p sel for SAMPLE B is AN4 */
#define ADC_CH0_POS_SAMPLEB_AN3     0xF3FF  /* A/D CH0 pos i/p sel for SAMPLE B is AN3 */
#define ADC_CH0_POS_SAMPLEB_AN2     0xF2FF  /* A/D CH0 pos i/p sel for SAMPLE B is AN2 */
#define ADC_CH0_POS_SAMPLEB_AN1     0xF1FF  /* A/D CH0 pos i/p sel for SAMPLE B is AN1 */
#define ADC_CH0_POS_SAMPLEB_AN0     0xF0FF  /* A/D CH0 pos i/p sel for SAMPLE B is AN0 */

#define ADC_CH0_NEG_SAMPLEA_AN1     0xFFFF  /*A/D CH0 neg I/P sel for SAMPLE A is AN1 */
#define ADC_CH0_NEG_SAMPLEA_NVREF   0xFF7F  /*A/D CH0 neg I/P sel for SAMPLE A is Vrefn */

#define ADC_CH0_POS_SAMPLEA_AN15    0xFFFF  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN15 */
#define ADC_CH0_POS_SAMPLEA_AN14    0xFFFE  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN14 */
#define ADC_CH0_POS_SAMPLEA_AN13    0xFFFD  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN13 */
#define ADC_CH0_POS_SAMPLEA_AN12    0xFFFC  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN12 */
#define ADC_CH0_POS_SAMPLEA_AN11    0xFFFB  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN11 */
#define ADC_CH0_POS_SAMPLEA_AN10    0xFFFA  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN10 */
#define ADC_CH0_POS_SAMPLEA_AN9     0xFFF9  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN9 */   
#define ADC_CH0_POS_SAMPLEA_AN8     0xFFF8  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN8 */   
#define ADC_CH0_POS_SAMPLEA_AN7     0xFFF7  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN7 */ 
#define ADC_CH0_POS_SAMPLEA_AN6     0xFFF6  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN6 */   
#define ADC_CH0_POS_SAMPLEA_AN5     0xFFF5  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN5 */   
#define ADC_CH0_POS_SAMPLEA_AN4     0xFFF4  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN4 */   
#define ADC_CH0_POS_SAMPLEA_AN3     0xFFF3  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN3 */   
#define ADC_CH0_POS_SAMPLEA_AN2     0xFFF2  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN2 */   
#define ADC_CH0_POS_SAMPLEA_AN1     0xFFF1  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN1 */   
#define ADC_CH0_POS_SAMPLEA_AN0     0xFFF0  /* A/D Chan 0 pos i/p sel for SAMPLE A is AN0 */   


/* ADC read buffer starting point defines */
#define ADC_RESULT_FIRST                0x0000  /* A/D read results from 00h address */
#define ADC_RESULT_SECOND               0x0008  /* A/D read results from the 08h address */

/*defines for ADxPCFGL register */

#define ENABLE_AN0_ANA                  0xFFFE /*Enable AN0 in analog mode */
#define ENABLE_AN1_ANA                  0xFFFD /*Enable AN1 in analog mode */
#define ENABLE_AN2_ANA                  0xFFFB /*Enable AN2 in analog mode */
#define ENABLE_AN3_ANA                  0xFFF7 /*Enable AN3 in analog mode */
#define ENABLE_AN4_ANA                  0xFFEF /*Enable AN4 in analog mode */
#define ENABLE_AN5_ANA                  0xFFDF /*Enable AN5 in analog mode */
#define ENABLE_AN6_ANA                  0xFFBF /*Enable AN6 in analog mode */
#define ENABLE_AN7_ANA                  0xFF7F /*Enable AN7 in analog mode */
#define ENABLE_AN8_ANA                  0xFEFF /*Enable AN8 in analog mode */
#define ENABLE_AN9_ANA                  0xFDFF /*Enable AN9 in analog mode */
#define ENABLE_AN10_ANA                 0xFBFF /*Enable AN10 in analog mode */
#define ENABLE_AN11_ANA                 0xF7FF /*Enable AN11 in analog mode */
#define ENABLE_AN12_ANA                 0xEFFF /*Enable AN12 in analog mode */
#define ENABLE_AN13_ANA                 0xDFFF /*Enable AN13 in analog mode */
#define ENABLE_AN14_ANA                 0xBFFF /*Enable AN14 in analog mode */
#define ENABLE_AN15_ANA                 0x7FFF /*Enable AN15 in analog mode */

#define ENABLE_ALL_ANA_0_15             0x0000 /*Enable AN0-AN15 in analog mode */
#define ENABLE_ALL_DIG_0_15             0xFFFF /*Enable AN0-AN15 in Digital mode */

/*defines for ADxCSSL register */

#define ADC_SKIP_SCAN_AN0      0xFFFE /* Disable Input Scan AN0 */
#define ADC_SKIP_SCAN_AN1      0xFFFD /* Disable Input Scan AN1 */
#define ADC_SKIP_SCAN_AN2      0xFFFB /* Disable Input Scan AN2 */
#define ADC_SKIP_SCAN_AN3      0xFFF7 /* Disable Input Scan AN3 */
#define ADC_SKIP_SCAN_AN4      0xFFEF /* Disable Input Scan AN4 */
#define ADC_SKIP_SCAN_AN5      0xFFDF /* Disable Input Scan AN5 */
#define ADC_SKIP_SCAN_AN6      0xFFBF /* Disable Input Scan AN6 */
#define ADC_SKIP_SCAN_AN7      0xFF7F /* Disable Input Scan AN7 */
#define ADC_SKIP_SCAN_AN8      0xFEFF /* Disable Input Scan AN8 */
#define ADC_SKIP_SCAN_AN9      0xFDFF /* Disable Input Scan AN9 */
#define ADC_SKIP_SCAN_AN10     0xFBFF /* Disable Input Scan AN10 */
#define ADC_SKIP_SCAN_AN11     0xF7FF /* Disable Input Scan AN11 */
#define ADC_SKIP_SCAN_AN12     0xEFFF /* Disable Input Scan AN12 */
#define ADC_SKIP_SCAN_AN13     0xDFFF /* Disable Input Scan AN13 */
#define ADC_SKIP_SCAN_AN14     0xBFFF /* Disable Input Scan AN14 */
#define ADC_SKIP_SCAN_AN15     0x7FFF /* Disable Input Scan AN15 */

#define ENABLE_ALL_INPUT_SCAN       0xFFFF /*Enable Input Scan AN0-AN15 */
#define DISABLE_ALL_INPU_SCAN       0x0000 /*Disable Input Scan AN0-AN15 */


/* Setting the priority of adc interrupt */
#define ADC_INT_PRI_0                   0xFFF8
#define ADC_INT_PRI_1                   0xFFF9
#define ADC_INT_PRI_2                   0xFFFA
#define ADC_INT_PRI_3                   0xFFFB
#define ADC_INT_PRI_4                   0xFFFC
#define ADC_INT_PRI_5                   0xFFFD
#define ADC_INT_PRI_6                   0xFFFE
#define ADC_INT_PRI_7                   0xFFFF

/* enable / disable interrupts */

#define ADC_INT_ENABLE                  0xFFFF
#define ADC_INT_DISABLE                 0xFFF7

#endif /* USE_AND_OR */

/* Macros to  Enable/Disable interrupts and set Interrupt priority */

#define EnableIntADC1                    asm("BSET IEC0,#13")
#define DisableIntADC1                   asm("BCLR IEC0,#13")
#define SetPriorityIntADC1(priority)     (IPC3bits.AD1IP = priority)

#define EnableIntADC2                    asm("BSET IEC1,#5")
#define DisableIntADC2                   asm("BCLR IEC1,#5")
#define SetPriorityIntADC2(priority)     (IPC5bits.AD2IP = priority)


/* A/D Converter Function Prototypes */
#define StopSampADC10   ConvertADC10


#ifdef _ADC_10B_V3

void OpenADC10(unsigned int config1, unsigned int config2, unsigned int
               config3, unsigned int configport,unsigned int configscan) __attribute__ ((section (".libperi"))); /* config ADC */

void ConvertADC10(void) __attribute__ ((section (".libperi")));                      /* Start an A/D conversion */

void SetChanADC10(unsigned int channel0)__attribute__ ((section (".libperi")));              /* Set A/D to specified channel */

unsigned int ReadADC10(unsigned char bufIndex)__attribute__ ((section (".libperi")));        /* Read A/D result */

void CloseADC10(void) __attribute__ ((section (".libperi")));                        /* Turn off A/D */

char BusyADC10(void) __attribute__ ((section (".libperi")));                         /* Check status of A/D conversion */

void ConfigIntADC10(unsigned int config)__attribute__ ((section (".libperi")));

#else
#warning "Does not build for _ADC_10B_V3"
#endif /* _ADC_10B_V3 */

#endif

