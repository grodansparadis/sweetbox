#ifndef TIMER_H
#define TIMER_H
/******************************************************************************
 *
 *                  TIMER PERIPHERAL LIBRARY HEADER FILE
 *
 ******************************************************************************
 * FileName:        timer.h
 * Dependencies:    See include below
 * Processor:       PIC24
 * Compiler:        MPLAB C30
 * Company:         Microchip Technology, Inc.
 *
 * Software License Agreement
 * The software supplied herewith by Microchip Technology Incorporated
 * (the �Company�) for its PICmicro� Microcontroller is intended and
 * supplied to you, the Company�s customer, for use solely and
 * exclusively on Microchip PICmicro Microcontroller products. The
 * software is owned by the Company and/or its supplier, and is
 * protected under applicable copyright laws. All rights are reserved.
 * Any use in violation of the foregoing restrictions may subject the
 * user to criminal sanctions under applicable laws, as well as to
 * civil liability for the breach of the terms and conditions of this
 * license.
 *
 * THIS SOFTWARE IS PROVIDED IN AN �AS IS� CONDITION. NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
 * TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
 * IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
 * CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *
 *****************************************************************************/
#include "Generic.h"
#include "PIC24F_periph_features.h"

#ifdef _TIMER1
/* List of SFRs for Timer 1 */
/* This list contains the SFRs with default (POR) values to be used for configuring Timer 1 */
/* The user can modify this based on the requirement */
#define TMR1_VALUE          0x0000
#define PR1_VALUE           0xFFFF
#define T1CON_VALUE         0x0000

#ifdef USE_AND_OR /* Format for AND_OR based bit setting */

   /* T1CON: TIMER1 CONTROL REGISTER */
#define T1_ON               0x8000 /* Timer1 ON */
#define T1_OFF              0x0000 /* Timer1 OFF */
#define T1_OFF_ON_MASK      (~T1_ON)

#define T1_IDLE_STOP        0x2000 /* operate during sleep */
#define T1_IDLE_CON         0x0000 /* stop operation during sleep */
#define T1_IDLE_MASK        (~T1_IDLE_STOP)

#define T1_GATE_ON          0x0040 /* Timer Gate time accumulation enabled */
#define T1_GATE_OFF         0x0000 /* Timer Gate time accumulation disabled */
#define T1_GATE_MASK        (~T1_GATE_ON)

#define T1_PS_1_1           0x0000 /* Prescaler 1:1 */
#define T1_PS_1_8           0x0010 /*           1:8 */
#define T1_PS_1_64          0x0020 /*          1:64 */
#define T1_PS_1_256         0x0030 /*         1:256 */
#define T1_PS_MASK          (~T1_PS_1_256)

#define T1_SYNC_EXT_ON      0x0004 /* Synch external clk input */
#define T1_SYNC_EXT_OFF     0x0000 /* Do not synch external clk input */
#define T1_SYNC_EXT_MASK    (~T1_SYNC_EXT_ON)

#define T1_SOURCE_EXT       0x0002 /* External clock source */
#define T1_SOURCE_INT       0x0000 /* Internal clock source */
#define T1_SOURCE_MASK      (~T1_SOURCE_EXT)

/* defines for Timer Interrupts */

#define T1_INT_PRIOR_0      0x0000 /* 000 = Interrupt is priority 0 */
#define T1_INT_PRIOR_1      0x0001 /* 001 = Interrupt is priority 1 */
#define T1_INT_PRIOR_2      0x0002 /* 010 = Interrupt is priority 2 */
#define T1_INT_PRIOR_3      0x0003 /* 011 = Interrupt is priority 3 */
#define T1_INT_PRIOR_4      0x0004 /* 100 = Interrupt is priority 4 */
#define T1_INT_PRIOR_5      0x0005 /* 101 = Interrupt is priority 5 */
#define T1_INT_PRIOR_6      0x0006 /* 110 = Interrupt is priority 6 */
#define T1_INT_PRIOR_7      0x0007 /* 111 = Interrupt is priority 7 */

#define T1_INT_ON           0x0008 /* Interrupt Enable */
#define T1_INT_OFF          0x0000 /* Interrupt Disable */


#else /* Format for backward compatibility (AND based bit setting). */

/* Timer1 Control Register (T1CON) Bit Defines */

#define T1_ON               0xffff      /* Timer1 ON */
#define T1_OFF              0x7fff      /* Timer1 OFF */

#define T1_IDLE_CON         0xdfff      /* operate during sleep */
#define T1_IDLE_STOP        0xffff      /* stop operation during sleep */

#define T1_GATE_ON          0xffff      /* Timer Gate time accumulation enabled */
#define T1_GATE_OFF         0xffbf      /* Timer Gate time accumulation disabled */

#define T1_PS_1_1           0xffcf      /* Prescaler 1:1 */
#define T1_PS_1_8           0xffdf      /*           1:8 */
#define T1_PS_1_64          0xffef      /*          1:64 */
#define T1_PS_1_256         0xffff      /*         1:256 */

#define T1_SYNC_EXT_ON      0xffff      /* Synch external clk input */
#define T1_SYNC_EXT_OFF     0xfffb      /* Do not synch external clk input */

#define T1_SOURCE_EXT       0xffff      /* External clock source */
#define T1_SOURCE_INT       0xfffd      /* Internal clock source */

/* defines for Timer Interrupts */

#define T1_INT_PRIOR_7      0xffff      /* 111 = Interrupt is priority 7 */
#define T1_INT_PRIOR_6      0xfffe      /* 110 = Interrupt is priority 6 */
#define T1_INT_PRIOR_5      0xfffd      /* 101 = Interrupt is priority 5 */
#define T1_INT_PRIOR_4      0xfffc      /* 100 = Interrupt is priority 4 */
#define T1_INT_PRIOR_3      0xfffb      /* 011 = Interrupt is priority 3 */
#define T1_INT_PRIOR_2      0xfffa      /* 010 = Interrupt is priority 2 */
#define T1_INT_PRIOR_1      0xfff9      /* 001 = Interrupt is priority 1 */
#define T1_INT_PRIOR_0      0xfff8      /* 000 = Interrupt is priority 0 */

#define T1_INT_ON           0xffff      /* Interrupt Enable */
#define T1_INT_OFF          0xfff7      /* Interrupt Disable */

#endif /* USE_AND_OR */

/* Macros to  Enable/Disable interrupts and set Interrupt priority of Timers 1*/
#define EnableIntT1                    asm("BSET IEC0,#3")
#define DisableIntT1                   asm("BCLR IEC0,#3")
#define SetPriorityIntT1(priority)     (IPC0bits.T1IP = priority)

/* Timer1 Function Prototypes */

/* OpenTimer1 */
void OpenTimer1( unsigned int config, unsigned int period) __attribute__ ((section
(".libperi")));

/* CloseTimer1 */
void CloseTimer1(void) __attribute__ ((section (".libperi")));

/* ReadTimer1 */
unsigned int ReadTimer1(void) __attribute__ ((section (".libperi")));

/* WriteTimer1 */
void WriteTimer1( unsigned int timer) __attribute__ ((section (".libperi")));

/* Config Int Timer1 */
void ConfigIntTimer1(unsigned int config) __attribute__ ((section (".libperi")));

#else
#warning "Does not build for _TIMER1"
#endif /* _TIMER1 */

#ifdef _TIMER2
/* List of SFRs for Timer 2 */
/* This list contains the SFRs with default (POR) values to be used for configuring Timer 2 */
/* The user can modify this based on the requirement */
#define TMR2_VALUE          0x0000
#define PR2_VALUE           0xFFFF
#define T2CON_VALUE         0x0000

#ifdef USE_AND_OR /* Format for AND_OR based bit setting */

   /* T2CON: TIMER2 CONTROL REGISTER */
#define T2_ON               0x8000      /* Timer2 ON */
#define T2_OFF              0x0000      /* Timer2 OFF */
#define T2_OFF_ON_MASK      (~T2_ON)

#define T2_IDLE_STOP        0x2000 /* operate during sleep */
#define T2_IDLE_CON         0x0000 /* stop operation during sleep */
#define T2_IDLE_MASK        (~T2_IDLE_STOP)

#define T2_GATE_ON          0x0040 /* Timer Gate time accumulation enabled */
#define T2_GATE_OFF         0x0000 /* Timer Gate time accumulation disabled */
#define T2_GATE_MASK        (~T2_GATE_ON)

#define T2_PS_1_1           0x0000      /* Prescaler 1:1 */
#define T2_PS_1_8           0x0010      /*           1:8 */
#define T2_PS_1_64          0x0020      /*          1:64 */
#define T2_PS_1_256         0x0030      /*         1:256 */
#define T2_PS_MASK          (~T2_PS_1_256)

#define T2_32BIT_MODE_ON    0x0008      /* Timer 2 and Timer 3 form a 32 bit Timer */
#define T2_32BIT_MODE_OFF   0x0000
#define T2_32BIT_MODE_MASK   (~T2_32BIT_MODE_ON)

#define T2_SOURCE_EXT       0x0002 /* External clock source */
#define T2_SOURCE_INT       0x0000 /* Internal clock source */
#define T2_SOURCE_MASK      (~T2_SOURCE_EXT)

/* defines for Timer Interrupts */

#define T2_INT_PRIOR_0      0x0000      /* 000 = Interrupt is priority 0 */
#define T2_INT_PRIOR_1      0x0001      /* 001 = Interrupt is priority 1 */
#define T2_INT_PRIOR_2      0x0002      /* 010 = Interrupt is priority 2 */
#define T2_INT_PRIOR_3      0x0003      /* 011 = Interrupt is priority 3 */
#define T2_INT_PRIOR_4      0x0004      /* 100 = Interrupt is priority 4 */
#define T2_INT_PRIOR_5      0x0005      /* 101 = Interrupt is priority 5 */
#define T2_INT_PRIOR_6      0x0006      /* 110 = Interrupt is priority 6 */
#define T2_INT_PRIOR_7      0x0007      /* 111 = Interrupt is priority 7 */

#define T2_INT_ON           0x0008      /* Interrupt Enable */
#define T2_INT_OFF          0x0000      /* Interrupt Disable */


#else /* Format for backward compatibility (AND based bit setting). */

/* Timer2 Control Register (T2CON) Bit Defines */

#define T2_ON               0xffff      /* Timer2 ON */
#define T2_OFF              0x7fff      /* Timer2 OFF */

#define T2_IDLE_CON         0xdfff      /* operate during sleep */
#define T2_IDLE_STOP        0xffff      /* stop operation during sleep */

#define T2_GATE_ON          0xffff      /* Timer2 Gate time accumulation enabled  */
#define T2_GATE_OFF         0xffbf      /* Timer2 Gate time accumulation disabled */

#define T2_PS_1_1           0xffcf      /* Prescaler 1:1   */
#define T2_PS_1_8           0xffdf      /*           1:8   */
#define T2_PS_1_64          0xffef      /*           1:64  */
#define T2_PS_1_256         0xffff      /*           1:256 */

#define T2_32BIT_MODE_ON    0xffff      /* Timer 2 and Timer 3 form a 32 bit Timer */
#define T2_32BIT_MODE_OFF   0xfff7      

#define T2_SOURCE_EXT       0xffff      /* External clock source */
#define T2_SOURCE_INT       0xfffd      /* Internal clock source */

/* defines for Timer Interrupts */
#define T2_INT_PRIOR_7      0xffff      /* 111 = Interrupt is priority 7 */ 
#define T2_INT_PRIOR_6      0xfffe      /* 110 = Interrupt is priority 6 */
#define T2_INT_PRIOR_5      0xfffd      /* 101 = Interrupt is priority 5 */
#define T2_INT_PRIOR_4      0xfffc      /* 100 = Interrupt is priority 4 */
#define T2_INT_PRIOR_3      0xfffb      /* 011 = Interrupt is priority 3 */
#define T2_INT_PRIOR_2      0xfffa      /* 010 = Interrupt is priority 2 */
#define T2_INT_PRIOR_1      0xfff9      /* 001 = Interrupt is priority 1 */
#define T2_INT_PRIOR_0      0xfff8      /* 000 = Interrupt is priority 0 */

#define T2_INT_ON           0xffff      /* Interrupt Enable */  
#define T2_INT_OFF          0xfff7      /* Interrupt Disable */

#endif /* USE_AND_OR */

/* Macros to  Enable/Disable interrupts and set Interrupt priority of Timers 2*/
#define EnableIntT2                    asm("BSET IEC0,#6")
#define DisableIntT2                   asm("BCLR IEC0,#6")
#define SetPriorityIntT2(priority)     (IPC1bits.T2IP = priority)

/* Timer2 Function Prototypes */

/* OpenTimer2 */
void OpenTimer2(unsigned int config, unsigned int period) __attribute__ ((section
(".libperi")));

/* CloseTimer2 */
void CloseTimer2(void) __attribute__ ((section (".libperi")));

/* ReadTimer2 */
unsigned int ReadTimer2(void) __attribute__ ((section (".libperi")));

/* WriteTimer2 */
void WriteTimer2( unsigned int timer) __attribute__ ((section (".libperi")));

/* ConfigIntTimer2 */
void ConfigIntTimer2(unsigned int ) __attribute__ ((section (".libperi")));

#else
#warning "Does not build for _TIMER2"
#endif /* _TIMER2 */

#ifdef _TIMER3
/* List of SFRs for Timer 3 */
/* This list contains the SFRs with default (POR) values to be used for configuring Timer 3 */
/* The user can modify this based on the requirement */
#define TMR3_VALUE          0x0000
#define PR3_VALUE           0xFFFF
#define T3CON_VALUE         0x0000


#ifdef USE_AND_OR /* Format for AND_OR based bit setting */

   /* T3CON: TIMER3 CONTROL REGISTER */
#define T3_ON               0x8000      /* Timer3 ON */
#define T3_OFF              0x0000      /* Timer3 OFF */
#define T3_OFF_ON_MASK      (~T3_ON)

#define T3_IDLE_STOP        0x2000 /* operate during sleep */
#define T3_IDLE_CON         0x0000 /* stop operation during sleep */
#define T3_IDLE_MASK        (~T3_IDLE_STOP)

#define T3_GATE_ON          0x0040 /* Timer Gate time accumulation enabled */
#define T3_GATE_OFF         0x0000 /* Timer Gate time accumulation disabled */
#define T3_GATE_MASK        (~T3_GATE_ON)

#define T3_PS_1_1           0x0000      /* Prescaler 1:1 */
#define T3_PS_1_8           0x0010      /*           1:8 */
#define T3_PS_1_64          0x0020      /*          1:64 */
#define T3_PS_1_256         0x0030      /*         1:256 */
#define T3_PS_MASK          (~T3_PS_1_256)

#define T3_SOURCE_EXT       0x0002 /* External clock source */
#define T3_SOURCE_INT       0x0000 /* Internal clock source */
#define T3_SOURCE_MASK      (~T3_SOURCE_EXT)

/* defines for Timer Interrupts */

#define T3_INT_PRIOR_0      0x0000      /* 000 = Interrupt is priority 0 */
#define T3_INT_PRIOR_1      0x0001      /* 001 = Interrupt is priority 1 */
#define T3_INT_PRIOR_2      0x0002      /* 010 = Interrupt is priority 2 */
#define T3_INT_PRIOR_3      0x0003      /* 011 = Interrupt is priority 3 */
#define T3_INT_PRIOR_4      0x0004      /* 100 = Interrupt is priority 4 */
#define T3_INT_PRIOR_5      0x0005      /* 101 = Interrupt is priority 5 */
#define T3_INT_PRIOR_6      0x0006      /* 110 = Interrupt is priority 6 */
#define T3_INT_PRIOR_7      0x0007      /* 111 = Interrupt is priority 7 */

#define T3_INT_ON           0x0008      /* Interrupt Enable */
#define T3_INT_OFF          0x0000      /* Interrupt Disable */


#else /* Format for backward compatibility (AND based bit setting). */


/* Timer3 Control Register (T3CON) Bit Defines */

#define T3_ON               0xffff      /* Timer3 ON */
#define T3_OFF              0x7fff      /* Timer3 OFF */

#define T3_IDLE_CON         0xdfff      /* operate during sleep */
#define T3_IDLE_STOP        0xffff      /* stop operation during sleep */

#define T3_GATE_ON          0xffff      /* Timer3 Gate  time accumulation enabled  */
#define T3_GATE_OFF         0xffbf      /* Timer Gate time accumulation disabled */

#define T3_PS_1_1           0xffcf      /* Prescaler 1:1   */
#define T3_PS_1_8           0xffdf      /*           1:8   */
#define T3_PS_1_64          0xffef      /*           1:64  */
#define T3_PS_1_256         0xffff      /*           1:256 */

#define T3_SOURCE_EXT       0xffff      /* External clock source */
#define T3_SOURCE_INT       0xfffd      /* Internal clock source */

/* defines for Timer Interrupts */
#define T3_INT_PRIOR_7      0xffff      /* 111 = Interrupt is priority 7 */ 
#define T3_INT_PRIOR_6      0xfffe      /* 110 = Interrupt is priority 6 */
#define T3_INT_PRIOR_5      0xfffd      /* 101 = Interrupt is priority 5 */
#define T3_INT_PRIOR_4      0xfffc      /* 100 = Interrupt is priority 4 */
#define T3_INT_PRIOR_3      0xfffb      /* 011 = Interrupt is priority 3 */
#define T3_INT_PRIOR_2      0xfffa      /* 010 = Interrupt is priority 2 */
#define T3_INT_PRIOR_1      0xfff9      /* 001 = Interrupt is priority 1 */
#define T3_INT_PRIOR_0      0xfff8      /* 000 = Interrupt is priority 0 */

#define T3_INT_ON           0xffff      /* Interrupt Enable */  
#define T3_INT_OFF          0xfff7      /* Interrupt Disable */

#endif /* USE_AND_OR */

/* Macros to  Enable/Disable interrupts and set Interrupt priority of Timers 3*/
#define EnableIntT3                    asm("BSET IEC0,#7")
#define DisableIntT3                   asm("BCLR IEC0,#7")
#define SetPriorityIntT3(priority)     (IPC1bits.T3IP = priority)

/* Timer3 Function Prototypes */

/* OpenTimer3 */
void OpenTimer3(unsigned int config, unsigned int timer)  __attribute__ ((section
(".libperi")));

/* CloseTimer3 */
void CloseTimer3(void)  __attribute__ ((section (".libperi")));

/* ReadTimer3 */
unsigned int ReadTimer3(void)  __attribute__ ((section (".libperi")));

/* WriteTimer3 */
void WriteTimer3( unsigned int timer)  __attribute__ ((section (".libperi")));

/* ConfigIntTimer3  */
void  ConfigIntTimer3(unsigned int config)  __attribute__ ((section (".libperi")));

#else
#warning "Does not build for _TIMER3"
#endif /* _TIMER3 */

#ifdef _TIMER2
#ifdef _TIMER3

/* Timer 32 mode using Timer 2 and Timer3*/

/*Timer 32 bit mode Prototypes*/

/* OpenTimer23 */
void OpenTimer23(unsigned int config, unsigned long period)  __attribute__ ((section
(".libperi")));

/* CloseTimer23 */
void CloseTimer23(void)  __attribute__ ((section (".libperi")));

/* ReadTimer23 */
unsigned long ReadTimer23(void)  __attribute__ ((section (".libperi")));

/* WriteTimer23 */
void WriteTimer23(unsigned long timer)  __attribute__ ((section (".libperi")));

/* Config Int Timer 23*/
void ConfigIntTimer23(unsigned int config)  __attribute__ ((section (".libperi")));

#endif /* _TIMER2 */
#endif /* _TIMER3 */


#ifdef _TIMER4
/* List of SFRs for Timer 4 */
/* This list contains the SFRs with default (POR) values to be used for configuring Timer 4 */
/* The user can modify this based on the requirement */
#define TMR4_VALUE          0x0000
#define PR4_VALUE           0xFFFF
#define T4CON_VALUE         0x0000

#ifdef USE_AND_OR /* Format for AND_OR based bit setting */

   /* T4CON: TIMER4 CONTROL REGISTER */
#define T4_ON               0x8000      /* Timer4 ON */
#define T4_OFF              0x0000      /* Timer4 OFF */
#define T4_OFF_ON_MASK      (~T4_ON)

#define T4_IDLE_STOP        0x2000 /* operate during sleep */
#define T4_IDLE_CON         0x0000 /* stop operation during sleep */
#define T4_IDLE_MASK        (~T4_IDLE_STOP)

#define T4_GATE_ON          0x0040 /* Timer Gate time accumulation enabled */
#define T4_GATE_OFF         0x0000 /* Timer Gate time accumulation disabled */
#define T4_GATE_MASK        (~T4_GATE_ON)

#define T4_PS_1_1           0x0000      /* Prescaler 1:1 */
#define T4_PS_1_8           0x0010      /*           1:8 */
#define T4_PS_1_64          0x0020      /*          1:64 */
#define T4_PS_1_256         0x0030      /*         1:256 */
#define T4_PS_MASK          (~T4_PS_1_256)

#define T4_32BIT_MODE_ON    0x0008      /* Timer 2 and Timer 3 form a 32 bit Timer */
#define T4_32BIT_MODE_OFF   0x0000
#define T4_32BIT_MODE_MASK   (~T4_32BIT_MODE_ON)

#define T4_SOURCE_EXT       0x0002 /* External clock source */
#define T4_SOURCE_INT       0x0000 /* Internal clock source */
#define T4_SOURCE_MASK      (~T4_SOURCE_EXT)

/* defines for Timer Interrupts */

#define T4_INT_PRIOR_0      0x0000      /* 000 = Interrupt is priority 0 */
#define T4_INT_PRIOR_1      0x0001      /* 001 = Interrupt is priority 1 */
#define T4_INT_PRIOR_2      0x0002      /* 010 = Interrupt is priority 2 */
#define T4_INT_PRIOR_3      0x0003      /* 011 = Interrupt is priority 3 */
#define T4_INT_PRIOR_4      0x0004      /* 100 = Interrupt is priority 4 */
#define T4_INT_PRIOR_5      0x0005      /* 101 = Interrupt is priority 5 */
#define T4_INT_PRIOR_6      0x0006      /* 110 = Interrupt is priority 6 */
#define T4_INT_PRIOR_7      0x0007      /* 111 = Interrupt is priority 7 */

#define T4_INT_ON           0x0008      /* Interrupt Enable */
#define T4_INT_OFF          0x0000      /* Interrupt Disable */


#else /* Format for backward compatibility (AND based bit setting). */

/* Timer4 Control Register (T4CON) Bit Defines */
#define T4_ON               0xffff      /* Timer4 ON */
#define T4_OFF              0x7fff      /* Timer4 OFF */

#define T4_IDLE_CON         0xdfff      /* operate during sleep */
#define T4_IDLE_STOP        0xffff      /* stop operation during sleep */

#define T4_GATE_ON          0xffff      /* Timer Gate time accumulation enabled */
#define T4_GATE_OFF         0xffbf      /* Timer Gate time accumulation disabled */

#define T4_PS_1_1           0xffcf      /* Prescaler 1:1   */
#define T4_PS_1_8           0xffdf      /*           1:8   */
#define T4_PS_1_64          0xffef      /*           1:64  */
#define T4_PS_1_256         0xffff      /*           1:256 */

#define T4_SOURCE_EXT       0xffff      /* External clock source */
#define T4_SOURCE_INT       0xfffd      /* Internal clock source */

#define T4_32BIT_MODE_ON    0xffff /* Timer 4 and Timer 5 form a 32 bit Timer */
#define T4_32BIT_MODE_OFF   0xfff7 

/* defines for Timer Interrupts */
#define T4_INT_PRIOR_7      0xffff      /* 111 = Interrupt is priority 7 */ 
#define T4_INT_PRIOR_6      0xfffe      /* 110 = Interrupt is priority 6 */
#define T4_INT_PRIOR_5      0xfffd      /* 101 = Interrupt is priority 5 */
#define T4_INT_PRIOR_4      0xfffc      /* 100 = Interrupt is priority 4 */
#define T4_INT_PRIOR_3      0xfffb      /* 011 = Interrupt is priority 3 */
#define T4_INT_PRIOR_2      0xfffa      /* 010 = Interrupt is priority 2 */
#define T4_INT_PRIOR_1      0xfff9      /* 001 = Interrupt is priority 1 */
#define T4_INT_PRIOR_0      0xfff8      /* 000 = Interrupt is priority 0 */

#define T4_INT_ON           0xffff      /* Interrupt Enable */  
#define T4_INT_OFF          0xfff7      /* Interrupt Disable */

#endif 

/* Macros to  Enable/Disable interrupts and set Interrupt priority of Timer 4 */
#define EnableIntT4                    asm("BSET IEC1,#5")
#define DisableIntT4                   asm("BCLR IEC1,#5")
#define SetPriorityIntT4(priority)     (IPC5bits.T4IP = priority)

/* Timer4 Function Declarations */

/* OpenTimer4
 * Configures Timer4
 */
void OpenTimer4(unsigned int config , unsigned int timer )  __attribute__ ((section
(".libperi")));

/* CloseTimer4
 * Disables Timer4
 */
void CloseTimer4(void)  __attribute__ ((section (".libperi")));

/* ReadTimer4
 * Reads Timer4
 */
unsigned int ReadTimer4(void)  __attribute__ ((section (".libperi")));

/* WriteTimer4
 * Writes Timer4
 */
void WriteTimer4(unsigned int timer )  __attribute__ ((section (".libperi")));

/* Config Int Timer 4*/
void ConfigIntTimer4(unsigned int config)  __attribute__ ((section (".libperi")));

#else
#warning "Does not build for _TIMER4"
#endif /* _TIMER4 */


#ifdef _TIMER5
/* List of SFRs for Timer 5 */
/* This list contains the SFRs with default (POR) values to be used for configuring Timer 5 */
/* The user can modify this based on the requirement */
#define TMR5_VALUE          0x0000
#define PR5_VALUE           0xFFFF
#define T5CON_VALUE         0x0000

#ifdef USE_AND_OR /* Format for AND_OR based bit setting */

   /* T5CON: TIMER5 CONTROL REGISTER */
#define T5_ON               0x8000      /* Timer5 ON */
#define T5_OFF              0x0000      /* Timer5 OFF */
#define T5_OFF_ON_MASK      (~T5_ON)

#define T5_IDLE_STOP        0x2000 /* operate during sleep */
#define T5_IDLE_CON         0x0000 /* stop operation during sleep */
#define T5_IDLE_MASK        (~T5_IDLE_STOP)

#define T5_GATE_ON          0x0040 /* Timer Gate time accumulation enabled */
#define T5_GATE_OFF         0x0000 /* Timer Gate time accumulation disabled */
#define T5_GATE_MASK        (~T5_GATE_ON)

#define T5_PS_1_1           0x0000      /* Prescaler 1:1 */
#define T5_PS_1_8           0x0010      /*           1:8 */
#define T5_PS_1_64          0x0020      /*          1:64 */
#define T5_PS_1_256         0x0030      /*         1:256 */
#define T5_PS_MASK          (~T5_PS_1_256)

#define T5_SOURCE_EXT       0x0002 /* External clock source */
#define T5_SOURCE_INT       0x0000 /* Internal clock source */
#define T5_SOURCE_MASK      (~T5_SOURCE_EXT)

/* defines for Timer Interrupts */

#define T5_INT_PRIOR_0      0x0000      /* 000 = Interrupt is priority 0 */
#define T5_INT_PRIOR_1      0x0001      /* 001 = Interrupt is priority 1 */
#define T5_INT_PRIOR_2      0x0002      /* 010 = Interrupt is priority 2 */
#define T5_INT_PRIOR_3      0x0003      /* 011 = Interrupt is priority 3 */
#define T5_INT_PRIOR_4      0x0004      /* 100 = Interrupt is priority 4 */
#define T5_INT_PRIOR_5      0x0005      /* 101 = Interrupt is priority 5 */
#define T5_INT_PRIOR_6      0x0006      /* 110 = Interrupt is priority 6 */
#define T5_INT_PRIOR_7      0x0007      /* 111 = Interrupt is priority 7 */

#define T5_INT_ON           0x0008      /* Interrupt Enable */
#define T5_INT_OFF          0x0000      /* Interrupt Disable */


#else /* Format for backward compatibility (AND based bit setting). */

#define T5_ON               0xffff      /* Timer5 ON */
#define T5_OFF              0x7fff      /* Timer5 OFF */

#define T5_IDLE_CON         0xdfff      /* operate during sleep */
#define T5_IDLE_STOP        0xffff      /* stop operation during sleep */

#define T5_GATE_ON          0xffff      /* Timer Gate time accumulation enabled */
#define T5_GATE_OFF         0xffbf      /* Timer Gate time accumulation disabled */

#define T5_PS_1_1           0xffcf      /* Prescaler 1:1   */
#define T5_PS_1_8           0xffdf      /*           1:8   */
#define T5_PS_1_64          0xffef      /*           1:64  */
#define T5_PS_1_256         0xffff      /*           1:256 */

#define T5_SOURCE_EXT       0xffff      /* External clock source */
#define T5_SOURCE_INT       0xfffd      /* Internal clock source */

/* defines for Timer Interrupts */
#define T5_INT_PRIOR_7      0xffff      /* 111 = Interrupt is priority 7 */
#define T5_INT_PRIOR_6      0xfffe      /* 110 = Interrupt is priority 6 */
#define T5_INT_PRIOR_5      0xfffd      /* 101 = Interrupt is priority 5 */
#define T5_INT_PRIOR_4      0xfffc      /* 100 = Interrupt is priority 4 */
#define T5_INT_PRIOR_3      0xfffb      /* 011 = Interrupt is priority 3 */
#define T5_INT_PRIOR_2      0xfffa      /* 010 = Interrupt is priority 2 */
#define T5_INT_PRIOR_1      0xfff9      /* 001 = Interrupt is priority 1 */
#define T5_INT_PRIOR_0      0xfff8      /* 000 = Interrupt is priority 0 */

#define T5_INT_ON           0xffff      /* Interrupt Enable */
#define T5_INT_OFF          0xfff7      /* Interrupt Disable */

#endif

/* Macros to  Enable/Disable interrupts and set Interrupt priority of Timer 5 */
#define EnableIntT5                    asm("BSET IEC1,#6")
#define DisableIntT5                   asm("BCLR IEC1,#6")
#define SetPriorityIntT5(priority)     (IPC5bits.T5IP = priority)

/* Timer5 Function Declarations */

/* OpenTimer5
 * Configures Timer5
 */
void OpenTimer5(unsigned int config, unsigned int timer)  __attribute__ ((section
(".libperi")));

/* CloseTimer5
 * Disables Timer5
 */
void CloseTimer5(void)  __attribute__ ((section (".libperi")));

/* ReadTimer5
 * Reads Timer5
 */
unsigned int ReadTimer5(void)  __attribute__ ((section (".libperi")));

/* WriteTimer5
 * Writes Timer5
 */
void WriteTimer5(unsigned int timer)  __attribute__ ((section (".libperi")));

/* Config Int Timer 5*/
void ConfigIntTimer5(unsigned int config)  __attribute__ ((section (".libperi")));

#else
#warning "Does not build for _TIMER5"
#endif /* _TIMER5 */


#ifdef _TIMER4
#ifdef _TIMER5

/* Timer 45 mode using Timer 4 and Timer 5 */

/* OpenTimer45 */
void OpenTimer45(unsigned int config , unsigned long timer)  __attribute__ ((section
(".libperi")));

/* CloseTimer45 */
void CloseTimer45(void)  __attribute__ ((section (".libperi")));

/* ReadTimer45 */
unsigned long ReadTimer45(void)  __attribute__ ((section (".libperi")));

/* WriteTimer45 */
void WriteTimer45(unsigned long timer)  __attribute__ ((section (".libperi")));

/* Config Int Timer 45*/
void ConfigIntTimer45(unsigned int config)  __attribute__ ((section (".libperi")));

#endif /* _TIMER4 */
#endif /* _TIMER5 */

#endif
