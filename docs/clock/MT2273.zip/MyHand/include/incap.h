#ifndef __INCAP_H
#define __INCAP_H
/******************************************************************************
 *
 *                  INPUT CAPTURE PERIPHERAL LIBRARY HEADER FILE
 *
 ******************************************************************************
 * FileName:        timer.h
 * Dependencies:    See include below
 * Processor:       PIC24
 * Compiler:        MPLAB C30
 * Company:         Microchip Technology, Inc.
 *
 * Software License Agreement
 * The software supplied herewith by Microchip Technology Incorporated
 * (the �Company�) for its PICmicro� Microcontroller is intended and
 * supplied to you, the Company�s customer, for use solely and
 * exclusively on Microchip PICmicro Microcontroller products. The
 * software is owned by the Company and/or its supplier, and is
 * protected under applicable copyright laws. All rights are reserved.
 * Any use in violation of the foregoing restrictions may subject the
 * user to criminal sanctions under applicable laws, as well as to
 * civil liability for the breach of the terms and conditions of this
 * license.
 *
 * THIS SOFTWARE IS PROVIDED IN AN �AS IS� CONDITION. NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
 * TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
 * IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
 * CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *
 *****************************************************************************/
#include "Generic.h"
#include "PIC24F_periph_features.h"

#ifdef USE_AND_OR /* Format for AND_OR based bit setting */

#define IC_IDLE_CON             0x2000 /* IC operate in sleep mode */
#define IC_IDLE_STOP            0x0000 /* IC stop in sleep mode */
#define IC_IDLE_MASK            (~IC_IDLE_CON)

#define IC_TIMER2_SRC           0x0080 /* Timer2 is the clock source 
                                                        for Capture */
#define IC_TIMER3_SRC           0x0000 /* Timer3 is the clock source 
                                                        for Capture */
#define IC_TIMER_SRC_MASK       (~IC_TIMER2_SRC)

#define IC_INT_4CAPTURE         0x0060  /* Interrupt on fourth Capture*/
#define IC_INT_3CAPTURE         0x0040  /* Interrupt on third Capture */
#define IC_INT_2CAPTURE         0x0020  /* Interrupt on second Capture*/
#define IC_INT_1CAPTURE         0x0000  /* Interrupt on first Capture */
#define IC_INT_CAPTURE_MASK     (~IC_INT_4CAPTURE)

#define IC_INTERRUPT            0x0007  /* Interrupt pin only in CPU 
                                            sleep and idle mode */
#define IC_EVERY_16_RISE_EDGE   0x0005  /* Every 16th rising edge */
#define IC_EVERY_4_RISE_EDGE    0x0004  /* Every 4th rising edge  */
#define IC_EVERY_RISE_EDGE      0x0003  /* Every rising edge      */
#define IC_EVERY_FALL_EDGE      0x0002  /* Every falling edge      */
#define IC_EVERY_EDGE           0x0001  /* Every rising/falling edge */
#define IC_INPUTCAP_OFF         0x0000  /* Input Capture Off      */
#define IC_CAPTURE_MODE_MASK    (~IC_INTERRUPT)

/* defines for IC interrupts */
#define IC_INT_ON               0x0008 /* Input Capture Int Enable  */
#define IC_INT_OFF              0x0000 /* Input Capture Int Disable */

#define IC_INT_PRIOR_0          0x0000  /* Input Capture PriorityLevel 0 */
#define IC_INT_PRIOR_1          0x0001  /* Input Capture PriorityLevel 1 */
#define IC_INT_PRIOR_2          0x0002  /* Input Capture PriorityLevel 2 */
#define IC_INT_PRIOR_3          0x0003  /* Input Capture PriorityLevel 3 */
#define IC_INT_PRIOR_4          0x0004  /* Input Capture PriorityLevel 4 */
#define IC_INT_PRIOR_5          0x0005  /* Input Capture PriorityLevel 5 */
#define IC_INT_PRIOR_6          0x0006  /* Input Capture PriorityLevel 6 */
#define IC_INT_PRIOR_7          0x0007  /* Input Capture PriorityLevel 7 */

#else /* Format for backward compatibility (AND based bit setting). */

/* Input Capture Config (ICxCON Reg) Bit defines */

#define IC_IDLE_CON             0xdfff  /* IC operate in sleep mode */
#define IC_IDLE_STOP            0xffff  /* IC stop in sleep mode */

#define IC_TIMER2_SRC           0xffff  /* Timer2 is the clock source 
                                                        for Capture */
#define IC_TIMER3_SRC           0xff7f  /* Timer3 is the clock source 
                                                        for Capture */
#define IC_INT_4CAPTURE         0xffff  /* Interrupt on fourth Capture*/
#define IC_INT_3CAPTURE         0xffdf  /* Interrupt on third Capture */
#define IC_INT_2CAPTURE         0xffbf  /* Interrupt on second Capture*/
#define IC_INT_1CAPTURE         0xff9f  /* Interrupt on first Capture */

#define IC_INTERRUPT            0xffff  /* Interrupt pin only in CPU 
                                            sleep and idle mode */

#define IC_EVERY_16_RISE_EDGE   0xfffd  /* Every 16th rising edge */
#define IC_EVERY_4_RISE_EDGE    0xfffc  /* Every 4th rising edge  */
#define IC_EVERY_RISE_EDGE      0xfffb  /* Every rising edge      */
#define IC_EVERY_FALL_EDGE      0xfffa  /* Every falling edge      */
#define IC_EVERY_EDGE           0xfff9  /* Every rising/falling edge */
#define IC_INPUTCAP_OFF         0xfff8  /* Input Capture Off      */

/* defines for IC interrupts */
#define IC_INT_ON               0xffff  /* Input Capture Int Enable  */
#define IC_INT_OFF              0xfff7  /* Input Capture Int Disable */

#define IC_INT_PRIOR_0          0xfff8  /* Input Capture PriorityLevel 0 */
#define IC_INT_PRIOR_1          0xfff9  /* Input Capture PriorityLevel 1 */
#define IC_INT_PRIOR_2          0xfffa  /* Input Capture PriorityLevel 2 */
#define IC_INT_PRIOR_3          0xfffb  /* Input Capture PriorityLevel 3 */
#define IC_INT_PRIOR_4          0xfffc  /* Input Capture PriorityLevel 4 */
#define IC_INT_PRIOR_5          0xfffd  /* Input Capture PriorityLevel 5 */
#define IC_INT_PRIOR_6          0xfffe  /* Input Capture PriorityLevel 6 */
#define IC_INT_PRIOR_7          0xffff  /* Input Capture PriorityLevel 7 */

#endif /* USE_AND_OR */

#ifdef _ICAP1 //////////////////////////

/* List of SFRs for Input Capture modules */
/* This list contains the SFRs with default (POR) values to be used for configuring Input capture modules */
/* The user can modify this based on the requirement */
#define IC1CON_VALUE            0x0000
#define IC1BUF_VALUE            0x0000

/* Macros to  Enable/Disable interrupts and set Interrupt priority */
#define EnableIntIC1                    asm("BSET IEC0,#1")
#define DisableIntIC1                   asm("BCLR IEC0,#1")
#define SetPriorityIntIC1(priority)     (IPC0bits.IC1IP = priority)

/*******************************************************************************
* Function Name:  OpenCapture1                                                 *
* Description:    This routine include configuring clock ,                     *
*                 number of capture per interrupt ,capture mode                *
* Parameters:     unsigned int config                                          *
*                 bit[15:14] Unused                                            *
*                 bit[13]    ICSIDL : Input Capture x Stop in Idle Control bit *
*                 bit[12:8]  Unused                                            *
*                 bit[7]     ICTMR: Input Capture x Timer Select bit(1)        *
*                            1 = TMR2 contents are captured on capture event   *
*                            0 = TMR3 contents are captured on capture event   *
*                 bit[6:5]   ICI<1:0>: Select Number of Captures per Interrupt *
*                            11 = Interrupt on every fourth capture event      *
*                            10 = Interrupt on every third capture event       *
*                            01 = Interrupt on every second capture event      *
*                            00 = Interrupt on every capture event             *
*                 bit[4]     ICOV: Input Capture x Overflow Status Flag bit    *
*                                 (read-only)                                  *
*                            1 = Input capture overflow occurred               *
*                            0 = No input capture overflow occurred            *
*                 bit[3]     ICBNE: Input Capture x Buffer Empty Status bit    *
*                                   (read-only)                                *
*                            1 = Input capture buffer is not empty, at least   *
*                                one more capture value can be read            *
*                            0 = Input capture buffer is empty                 *
*                 bit[2:0]   ICM<2:0>: Input Capture x Mode Select bits        *
*                            111 = Input capture functions as interrupt pin    *
*                                  only when device is in Sleep or Idle mode   *
*                            110 = Unused (module disabled)                    *
*                            101 = Capture mode, every 16th rising edge        *
*                            100 = Capture mode, every 4th rising edge         *
*                            011 = Capture mode, every rising edge             *
*                            010 = Capture mode, every falling edge            *
*                            001 = Capture mode, every edge � rising and       *
*                                  falling (the ICI<1:0> bits do not control   *
*                                  interrupt generation for this mode)         *
*                            000 = Input capture module turned off             *
* Return Value:   None                                                         *
********************************************************************************/
void OpenCapture1(unsigned int) __attribute__ ((section (".libperi")));

/********************************************************************
*    Function Name:  CloseCapture1                                  *
*    Description:    This routine disable the inputcapture and its  *
*                    interrupt bits.                                *
*    Parameters:     None                                           *
*    Return Value:   None                                           *
********************************************************************/
void CloseCapture1() __attribute__ ((section (".libperi")));

/********************************************************************
*    Function Name:  ConfigIntCapture1                              *
*    Description:    Set the Enable Interrupts and Interrupt        *
*                    Priorites  to the Interrupt Control and        *
*                    Interrupt Priority Register respectively       *
*    Parameters:     unsigned int config                            *
*                    config[0:2]  -> priority setting               *
*                    config[3]    -> Interrupt Enable/Disable       *
*                    config[4:15] -> unsused                        *
*    Return Value:   None                                           *
********************************************************************/
void ConfigIntCapture1(unsigned int ) __attribute__ ((section (".libperi")));

/********************************************************************
*    Function Name:  ReadCapture1                                   *
*    Description:    This routine reads all pending InputCapture    *
*                    Buffers and stores in the locations specified  *
*    Parameters:     address of locations where buffer data to be   *
*                    stored                                         *
*    Return Value:   None                                           *
********************************************************************/
void ReadCapture1(unsigned int * buffer) __attribute__ ((section (".libperi")));

#else
#warning "Does not build for _ICAP1"
#endif


#ifdef _ICAP2 //////////////////////////

/* List of SFRs for Input Capture modules */
/* This list contains the SFRs with default (POR) values to be used for configuring Input capture modules */
/* The user can modify this based on the requirement */
#define IC2CON_VALUE            0x0000
#define IC2BUF_VALUE            0x0000

/* Macros to  Enable/Disable interrupts and set Interrupt priority */
#define EnableIntIC2                    asm("BSET IEC0,#4")
#define DisableIntIC2                   asm("BCLR IEC0,#4")
#define SetPriorityIntIC2(priority)     (IPC1bits.IC2IP = priority)

/*******************************************************************************
* Function Name:  OpenCapture2                                                 *
* Description:    This routine include configuring clock ,                     *
*                 number of capture per interrupt ,capture mode                *
* Parameters:     unsigned int config                                          *
*                 bit[15:14] Unused                                            *
*                 bit[13]    ICSIDL : Input Capture x Stop in Idle Control bit *
*                 bit[12:8]  Unused                                            *
*                 bit[7]     ICTMR: Input Capture x Timer Select bit(1)        *
*                            1 = TMR2 contents are captured on capture event   *
*                            0 = TMR3 contents are captured on capture event   *
*                 bit[6:5]   ICI<1:0>: Select Number of Captures per Interrupt *
*                            11 = Interrupt on every fourth capture event      *
*                            10 = Interrupt on every third capture event       *
*                            01 = Interrupt on every second capture event      *
*                            00 = Interrupt on every capture event             *
*                 bit[4]     ICOV: Input Capture x Overflow Status Flag bit    *
*                                 (read-only)                                  *
*                            1 = Input capture overflow occurred               *
*                            0 = No input capture overflow occurred            *
*                 bit[3]     ICBNE: Input Capture x Buffer Empty Status bit    *
*                                   (read-only)                                *
*                            1 = Input capture buffer is not empty, at least   *
*                                one more capture value can be read            *
*                            0 = Input capture buffer is empty                 *
*                 bit[2:0]   ICM<2:0>: Input Capture x Mode Select bits        *
*                            111 = Input capture functions as interrupt pin    *
*                                  only when device is in Sleep or Idle mode   *
*                            110 = Unused (module disabled)                    *
*                            101 = Capture mode, every 16th rising edge        *
*                            100 = Capture mode, every 4th rising edge         *
*                            011 = Capture mode, every rising edge             *
*                            010 = Capture mode, every falling edge            *
*                            001 = Capture mode, every edge � rising and       *
*                                  falling (the ICI<1:0> bits do not control   *
*                                  interrupt generation for this mode)         *
*                            000 = Input capture module turned off             *
* Return Value:   None                                                         *
********************************************************************************/
void OpenCapture2(unsigned int  );

/********************************************************************
*    Function Name:  CloseCapture2                                  *
*    Description:    This routine disable the inputcapture and its  *
*                    interrupt bits.                                *
*    Parameters:     None                                           *
*    Return Value:   None                                           *
********************************************************************/
void CloseCapture2();

/********************************************************************
*    Function Name:  ConfigIntCapture2                              *
*    Description:    Set the Enable Interrupts and Interrupt        *
*                    Priorites  to the Interrupt Control and        *
*                    Interrupt Priority Register respectively       *
*    Parameters:     unsigned int config                            *
*                    config[0:2]  -> priority setting               *
*                    config[3]    -> Interrupt Enable/Disable       *
*                    config[4:15] -> unsused                        *
*    Return Value:   None                                           *
********************************************************************/
void ConfigIntCapture2(unsigned int );

/********************************************************************
*    Function Name:  ReadCapture2                                   *
*    Description:    This routine reads all pending InputCapture    *
*                    Buffers and stores in the locations specified  *
*    Parameters:     address of locations where buffer data to be   *
*                    stored                                         *
*    Return Value:   None                                           *
********************************************************************/
void ReadCapture2(unsigned int * buffer);

#else
#warning "Does not build for _ICAP2"
#endif


#ifdef _ICAP3 //////////////////////////

/* List of SFRs for Input Capture modules */
/* This list contains the SFRs with default (POR) values to be used for configuring Input capture modules */
/* The user can modify this based on the requirement */
#define IC3CON_VALUE            0x0000
#define IC3BUF_VALUE            0x0000

/* Macros to  Enable/Disable interrupts and set Interrupt priority */
#define EnableIntIC3                    asm("BSET IEC1,#12")
#define DisableIntIC3                   asm("BCLR IEC1,#12")
#define SetPriorityIntIC3(priority)     (IPC7bits.IC3IP = priority)

/*******************************************************************************
* Function Name:  OpenCapture3                                                 *
* Description:    This routine include configuring clock ,                     *
*                 number of capture per interrupt ,capture mode                *
* Parameters:     unsigned int config                                          *
*                 bit[15:14] Unused                                            *
*                 bit[13]    ICSIDL : Input Capture x Stop in Idle Control bit *
*                 bit[12:8]  Unused                                            *
*                 bit[7]     ICTMR: Input Capture x Timer Select bit(1)        *
*                            1 = TMR2 contents are captured on capture event   *
*                            0 = TMR3 contents are captured on capture event   *
*                 bit[6:5]   ICI<1:0>: Select Number of Captures per Interrupt *
*                            11 = Interrupt on every fourth capture event      *
*                            10 = Interrupt on every third capture event       *
*                            01 = Interrupt on every second capture event      *
*                            00 = Interrupt on every capture event             *
*                 bit[4]     ICOV: Input Capture x Overflow Status Flag bit    *
*                                 (read-only)                                  *
*                            1 = Input capture overflow occurred               *
*                            0 = No input capture overflow occurred            *
*                 bit[3]     ICBNE: Input Capture x Buffer Empty Status bit    *
*                                   (read-only)                                *
*                            1 = Input capture buffer is not empty, at least   *
*                                one more capture value can be read            *
*                            0 = Input capture buffer is empty                 *
*                 bit[2:0]   ICM<2:0>: Input Capture x Mode Select bits        *
*                            111 = Input capture functions as interrupt pin    *
*                                  only when device is in Sleep or Idle mode   *
*                            110 = Unused (module disabled)                    *
*                            101 = Capture mode, every 16th rising edge        *
*                            100 = Capture mode, every 4th rising edge         *
*                            011 = Capture mode, every rising edge             *
*                            010 = Capture mode, every falling edge            *
*                            001 = Capture mode, every edge � rising and       *
*                                  falling (the ICI<1:0> bits do not control   *
*                                  interrupt generation for this mode)         *
*                            000 = Input capture module turned off             *
* Return Value:   None                                                         *
********************************************************************************/
void OpenCapture3(unsigned int  );

/********************************************************************
*    Function Name:  CloseCapture3                                  *
*    Description:    This routine disable the inputcapture and its  *
*                    interrupt bits.                                *
*    Parameters:     None                                           *
*    Return Value:   None                                           *
********************************************************************/
void CloseCapture3();

/********************************************************************
*    Function Name:  ConfigIntCapture3                              *
*    Description:    Set the Enable Interrupts and Interrupt        *
*                    Priorites  to the Interrupt Control and        *
*                    Interrupt Priority Register respectively       *
*    Parameters:     unsigned int config                            *
*                    config[0:2]  -> priority setting               *
*                    config[3]    -> Interrupt Enable/Disable       *
*                    config[4:15] -> unsused                        *
*    Return Value:   None                                           *
********************************************************************/
void ConfigIntCapture3(unsigned int );

/********************************************************************
*    Function Name:  ReadCapture3                                   *
*    Description:    This routine reads all pending InputCapture    *
*                    Buffers and stores in the locations specified  *
*    Parameters:     address of locations where buffer data to be   *
*                    stored                                         *
*    Return Value:   None                                           *
********************************************************************/
void ReadCapture3(unsigned int * buffer);

#else
#warning "Does not build for _ICAP3"
#endif


#ifdef _ICAP4 //////////////////////////

/* List of SFRs for Input Capture modules */
/* This list contains the SFRs with default (POR) values to be used for configuring Input capture modules */
/* The user can modify this based on the requirement */
#define IC4CON_VALUE            0x0000
#define IC4BUF_VALUE            0x0000

/* Macros to  Enable/Disable interrupts and set Interrupt priority */
#define EnableIntIC4                    asm("BSET IEC1,#13")
#define DisableIntIC4                   asm("BCLR IEC1,#13")
#define SetPriorityIntIC4(priority)     (IPC7bits.IC4IP = priority)

/*******************************************************************************
* Function Name:  OpenCapture4                                                 *
* Description:    This routine include configuring clock ,                     *
*                 number of capture per interrupt ,capture mode                *
* Parameters:     unsigned int config                                          *
*                 bit[15:14] Unused                                            *
*                 bit[13]    ICSIDL : Input Capture x Stop in Idle Control bit *
*                 bit[12:8]  Unused                                            *
*                 bit[7]     ICTMR: Input Capture x Timer Select bit(1)        *
*                            1 = TMR2 contents are captured on capture event   *
*                            0 = TMR3 contents are captured on capture event   *
*                 bit[6:5]   ICI<1:0>: Select Number of Captures per Interrupt *
*                            11 = Interrupt on every fourth capture event      *
*                            10 = Interrupt on every third capture event       *
*                            01 = Interrupt on every second capture event      *
*                            00 = Interrupt on every capture event             *
*                 bit[4]     ICOV: Input Capture x Overflow Status Flag bit    *
*                                 (read-only)                                  *
*                            1 = Input capture overflow occurred               *
*                            0 = No input capture overflow occurred            *
*                 bit[3]     ICBNE: Input Capture x Buffer Empty Status bit    *
*                                   (read-only)                                *
*                            1 = Input capture buffer is not empty, at least   *
*                                one more capture value can be read            *
*                            0 = Input capture buffer is empty                 *
*                 bit[2:0]   ICM<2:0>: Input Capture x Mode Select bits        *
*                            111 = Input capture functions as interrupt pin    *
*                                  only when device is in Sleep or Idle mode   *
*                            110 = Unused (module disabled)                    *
*                            101 = Capture mode, every 16th rising edge        *
*                            100 = Capture mode, every 4th rising edge         *
*                            011 = Capture mode, every rising edge             *
*                            010 = Capture mode, every falling edge            *
*                            001 = Capture mode, every edge � rising and       *
*                                  falling (the ICI<1:0> bits do not control   *
*                                  interrupt generation for this mode)         *
*                            000 = Input capture module turned off             *
* Return Value:   None                                                         *
********************************************************************************/
void OpenCapture4(unsigned int  );

/********************************************************************
*    Function Name:  CloseCapture4                                  *
*    Description:    This routine disable the inputcapture and its  *
*                    interrupt bits.                                *
*    Parameters:     None                                           *
*    Return Value:   None                                           *
********************************************************************/
void CloseCapture4();

/********************************************************************
*    Function Name:  ConfigIntCapture4                              *
*    Description:    Set the Enable Interrupts and Interrupt        *
*                    Priorites  to the Interrupt Control and        *
*                    Interrupt Priority Register respectively       *
*    Parameters:     unsigned int config                            *
*                    config[0:2]  -> priority setting               *
*                    config[3]    -> Interrupt Enable/Disable       *
*                    config[4:15] -> unsused                        *
*    Return Value:   None                                           *
********************************************************************/
void ConfigIntCapture4(unsigned int );

/********************************************************************
*    Function Name:  ReadCapture4                                   *
*    Description:    This routine reads all pending InputCapture    *
*                    Buffers and stores in the locations specified  *
*    Parameters:     address of locations where buffer data to be   *
*                    stored                                         *
*    Return Value:   None                                           *
********************************************************************/
void ReadCapture4(unsigned int * buffer);

#else
#warning "Does not build for _ICAP4"
#endif


#ifdef _ICAP5 //////////////////////////

/* List of SFRs for Input Capture modules */
/* This list contains the SFRs with default (POR) values to be used for configuring Input capture modules */
/* The user can modify this based on the requirement */
#define IC5CON_VALUE            0x0000
#define IC5BUF_VALUE            0x0000

/* Macros to  Enable/Disable interrupts and set Interrupt priority */
#define EnableIntIC5                    asm("BSET IEC1,#14")
#define DisableIntIC5                   asm("BCLR IEC1,#14")
#define SetPriorityIntIC5(priority)     (IPC7bits.IC5IP = priority)

/*******************************************************************************
* Function Name:  OpenCapture5                                                 *
* Description:    This routine include configuring clock ,                     *
*                 number of capture per interrupt ,capture mode                *
* Parameters:     unsigned int config                                          *
*                 bit[15:14] Unused                                            *
*                 bit[13]    ICSIDL : Input Capture x Stop in Idle Control bit *
*                 bit[12:8]  Unused                                            *
*                 bit[7]     ICTMR: Input Capture x Timer Select bit(1)        *
*                            1 = TMR2 contents are captured on capture event   *
*                            0 = TMR3 contents are captured on capture event   *
*                 bit[6:5]   ICI<1:0>: Select Number of Captures per Interrupt *
*                            11 = Interrupt on every fourth capture event      *
*                            10 = Interrupt on every third capture event       *
*                            01 = Interrupt on every second capture event      *
*                            00 = Interrupt on every capture event             *
*                 bit[4]     ICOV: Input Capture x Overflow Status Flag bit    *
*                                 (read-only)                                  *
*                            1 = Input capture overflow occurred               *
*                            0 = No input capture overflow occurred            *
*                 bit[3]     ICBNE: Input Capture x Buffer Empty Status bit    *
*                                   (read-only)                                *
*                            1 = Input capture buffer is not empty, at least   *
*                                one more capture value can be read            *
*                            0 = Input capture buffer is empty                 *
*                 bit[2:0]   ICM<2:0>: Input Capture x Mode Select bits        *
*                            111 = Input capture functions as interrupt pin    *
*                                  only when device is in Sleep or Idle mode   *
*                            110 = Unused (module disabled)                    *
*                            101 = Capture mode, every 16th rising edge        *
*                            100 = Capture mode, every 4th rising edge         *
*                            011 = Capture mode, every rising edge             *
*                            010 = Capture mode, every falling edge            *
*                            001 = Capture mode, every edge � rising and       *
*                                  falling (the ICI<1:0> bits do not control   *
*                                  interrupt generation for this mode)         *
*                            000 = Input capture module turned off             *
* Return Value:   None                                                         *
********************************************************************************/
void OpenCapture5(unsigned int  );

/********************************************************************
*    Function Name:  CloseCapture5                                  *
*    Description:    This routine disable the inputcapture and its  *
*                    interrupt bits.                                *
*    Parameters:     None                                           *
*    Return Value:   None                                           *
********************************************************************/
void CloseCapture5();

/********************************************************************
*    Function Name:  ConfigIntCapture5                              *
*    Description:    Set the Enable Interrupts and Interrupt        *
*                    Priorites  to the Interrupt Control and        *
*                    Interrupt Priority Register respectively       *
*    Parameters:     unsigned int config                            *
*                    config[0:2]  -> priority setting               *
*                    config[3]    -> Interrupt Enable/Disable       *
*                    config[4:15] -> unsused                        *
*    Return Value:   None                                           *
********************************************************************/
void ConfigIntCapture5(unsigned int );

/********************************************************************
*    Function Name:  ReadCapture5                                   *
*    Description:    This routine reads all pending InputCapture    *
*                    Buffers and stores in the locations specified  *
*    Parameters:     address of locations where buffer data to be   *
*                    stored                                         *
*    Return Value:   None                                           *
********************************************************************/
void ReadCapture5(unsigned int * buffer);

#else
#warning "Does not build for _ICAP5"
#endif 


#endif  /*__INCAP_H  */
