#ifndef __OUTCOMPARE_H
#define __OUTCOMPARE_H
/******************************************************************************
 *
 *                  OUTPUT COMPARE PERIPHERAL LIBRARY HEADER FILE
 *
 ******************************************************************************
 * FileName:        timer.h
 * Dependencies:    See include below
 * Processor:       PIC24
 * Compiler:        MPLAB C30
 * Company:         Microchip Technology, Inc.
 *
 * Software License Agreement
 * The software supplied herewith by Microchip Technology Incorporated
 * (the �Company�) for its PICmicro� Microcontroller is intended and
 * supplied to you, the Company�s customer, for use solely and
 * exclusively on Microchip PICmicro Microcontroller products. The
 * software is owned by the Company and/or its supplier, and is
 * protected under applicable copyright laws. All rights are reserved.
 * Any use in violation of the foregoing restrictions may subject the
 * user to criminal sanctions under applicable laws, as well as to
 * civil liability for the breach of the terms and conditions of this
 * license.
 *
 * THIS SOFTWARE IS PROVIDED IN AN �AS IS� CONDITION. NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
 * TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
 * IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
 * CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *
 *****************************************************************************/
#include "Generic.h"
#include "PIC24F_periph_features.h"

#ifdef USE_AND_OR /* Format for AND_OR based bit setting */

/* Output Compare Stop in Idle mode Bit defines */
#define OC_IDLE_STOP               0x2000 /* stop in idle mode */
#define OC_IDLE_CON                0x0000 /* continue operation in idle mode */
#define OC_IDLE_MASK               (~OC_IDLE_STOP)

/* Output Compare timer select Bit Defines */
#define OC_TIMER2_SRC               0x0000  /* Timer2 is the clock source 
                                                    for OutputCompare1 */
#define OC_TIMER3_SRC               0x0008  /* Timer3 is the clock source
                                                     for OutputCompare1 */
#define OC_TIMER_SRC_MASK           (~OC_TIMER3_SRC)

#define OC_PWM_FAULT_PIN_ENABLE     0x0007  /* PWM Mode on OCx, fault pin enabled, (TxIF bit 
                                               is set for PWM, OCxIF is set for fault)*/
#define OC_PWM_FAULT_PIN_DISABLE    0x0006  /* PWM Mode on OCx, fault pin disabled */
#define OC_CONTINUE_PULSE           0x0005  /* Generates Continuous Output pulse on OCx Pin */
#define OC_SINGLE_PULSE             0x0004  /* Generates Single Output pulse on OCx Pin */
#define OC_TOGGLE_PULSE             0x0003  /* Compare1 toggles  OCx pin*/
#define OC_HIGH_LOW                 0x0002  /* Compare1 forces   OCx pin Low*/
#define OC_LOW_HIGH                 0x0001  /* Compare1 forces  OCx pin High*/
#define OC_OFF                      0x0000  /* OutputCompare x Off*/
#define OC_PWM_MODE_MASK            (~OC_PWM_FAULT_PIN_ENABLE)

/* Interrupt bit definitions */
#define OC_INT_ON                   0x0008 /* OutputCompare Enable  */
#define OC_INT_OFF                  0x0000 /* OutputCompare Disable */

#define OC_INT_PRIOR_0              0x0000  /* OutputCompare PriorityLevel 0 */
#define OC_INT_PRIOR_1              0x0001  /* OutputCompare PriorityLevel 1 */
#define OC_INT_PRIOR_2              0x0002  /* OutputCompare PriorityLevel 2 */
#define OC_INT_PRIOR_3              0x0003  /* OutputCompare PriorityLevel 3 */
#define OC_INT_PRIOR_4              0x0004  /* OutputCompare PriorityLevel 4 */
#define OC_INT_PRIOR_5              0x0005  /* OutputCompare PriorityLevel 5 */
#define OC_INT_PRIOR_6              0x0006  /* OutputCompare PriorityLevel 6 */
#define OC_INT_PRIOR_7              0x0007  /* OutputCompare PriorityLevel 7 */

#define Start                       0x01
#define Stop                        0x00

#else /* Format for backward compatibility (AND based bit setting). */

/* Output Compare Stop in Idle mode Bit defines */
#define OC_IDLE_STOP               0xffff   /* stop in idle mode */
#define OC_IDLE_CON                0xdfff   /* continue operation in idle mode */

/* Output Compare timer select Bit Defines */
#define OC_TIMER2_SRC               0xfff7  /* Timer2 is the clock source 
                                                    for OutputCompare1 */
#define OC_TIMER3_SRC               0xffff  /* Timer3 is the clock source
                                                     for OutputCompare1 */

/* PWM Mode on OCx, fault pin enabled, (TxIF bit is set for PWM, OCxIF is set for fault)*/
#define OC_PWM_FAULT_PIN_ENABLE     0xffff

/* PWM Mode on OCx, fault pin disabled */
#define OC_PWM_FAULT_PIN_DISABLE    0xfffe
   
/* Generates Continuous Output pulse on OCx Pin */
#define OC_CONTINUE_PULSE           0xfffd
  
/* Generates Single Output pulse on OCx Pin */
#define OC_SINGLE_PULSE             0xfffc  
#define OC_TOGGLE_PULSE             0xfffb  /* Compare1 toggels  OCx pin*/
#define OC_HIGH_LOW                 0xfffa  /* Compare1 forces   OCx pin Low*/
#define OC_LOW_HIGH                 0xfff9  /* Compare1 forces  OCx pin High*/
#define OC_OFF                      0xfff8  /* OutputCompare x Off*/


/* Interrupt bit definitions */
#define OC_INT_ON                   0xffff  /* OutputCompare Enable  */
#define OC_INT_OFF                  0xfff7  /* OutputCompare Disable */
    
#define OC_INT_PRIOR_0              0xfff8  /* OutputCompare PriorityLevel 0 */
#define OC_INT_PRIOR_1              0xfff9  /* OutputCompare PriorityLevel 1 */
#define OC_INT_PRIOR_2              0xfffa  /* OutputCompare PriorityLevel 2 */
#define OC_INT_PRIOR_3              0xfffb  /* OutputCompare PriorityLevel 3 */
#define OC_INT_PRIOR_4              0xfffc  /* OutputCompare PriorityLevel 4 */
#define OC_INT_PRIOR_5              0xfffd  /* OutputCompare PriorityLevel 5 */
#define OC_INT_PRIOR_6              0xfffe  /* OutputCompare PriorityLevel 6 */
#define OC_INT_PRIOR_7              0xffff  /* OutputCompare PriorityLevel 7 */

#define Start                       0x01
#define Stop                        0x00

#endif /* USE_AND_OR */


#ifdef _OCMP1

/* This list contains the SFRs with default (POR) values to be used 
   for configuring Output compare modules 
   The user can modify this based on the requirement */
#define OC1RS_VALUE                0x0000
#define OC1R_VALUE                 0x0000
#define OC1CON_VALUE               0x0000

/* Macros to  Enable/Disable interrupts and set Interrupt priority of Output compare 1 thru 2 */
#define EnableIntOC1                    asm("BSET IEC0,#2")
#define DisableIntOC1                   asm("BCLR IEC0,#2")
#define SetPriorityIntOC1(priority)     (IPC0bits.OC1IP = priority)

/********************************************************************
* Function Name :  CloseOC1                                         *
* Description   :  This routine disables the Output Compare and its *
*                  interrupt bits.                                  *
* Parameter     :  None                                             *
* Return Value  :  None                                             *
********************************************************************/
void CloseOC1() __attribute__ ((section (".libperi")));

/************************************************************************
*    Function Name:  ConfigIntOC1                                       *
*    Description:    This Function Configures Interrupt and sets        *
*                    Interrupt Priority                                 *
*    Parameters:     unsigned int config                                *
*    Return Value:   None                                               *
************************************************************************/
void ConfigIntOC1(unsigned int config) __attribute__ ((section(".libperi")));

/********************************************************************
*    Function Name:  ReadDCOC1PWM                                   *
*    Description:    This routine reads duty cycle from Secondary   *
*                    register in PWM mode                           *
*    Parameters:     None                                           *
*    Return Value:   unsigned int:duty cycle from Secondary register*
********************************************************************/
unsigned int ReadDCOC1PWM() __attribute__ ((section (".libperi")));

/********************************************************************
*    Function Name:  ReadRegOC1                                     *
*    Description:    In Non PWM Mode, this function reads the OCRS  *
*                    reg or OCR reg based on input parameter        *
*    Parameters:     char reg                                       *
*    Return Value:   unsigned int OCRS (if reg is 0)                *
*                    or OCR (if reg is 1)                           *
********************************************************************/

unsigned int ReadRegOC1(char reg) __attribute__ ((section(".libperi")));

/*****************************************************************************
*    Function Name:  OpenOC1                                                 *
*    Description:    This routine configures output compare module and loads *
*                    the compare registers                                   *
*    Parameters  :   unsigned int config, unsigned int value1,               *
*                    unsigned int value2                                     *
*    Return Value:   None                                                    *
*    Notes           value1 is the compare value for the OCRS register       *
*                    value2 is the compare value for the OCR register        *
*****************************************************************************/
void OpenOC1(unsigned int config,unsigned int value1,
                  unsigned int value2) __attribute__ ((section(".libperi")));

/********************************************************************
*    Function Name:  SetDCOC1PWM                                    *
*    Description:    This routine writes the duty cycle OCRS reg    *
*    Parameters:     unsigned int duty cycle                        *
*    Return Value:   None                                           *
********************************************************************/
void SetDCOC1PWM(unsigned int dutycycle) __attribute__ ((section(".libperi")));

/*************************************************************************
*    Function Name:  SetPulseOC1                                         *
*    Description:    This routine writes the pulse_start to Main register*
*                    and pulse_stop to Secondary register                *
*    Parameters:     unsigned int pulse_start,unsigned int pulse_stop    *
*    Return Value:   None                                                *
*************************************************************************/
void SetPulseOC1(unsigned int pulse_start,unsigned int pulse_stop) __attribute__ 
((section (".libperi")));

#else
#warning "Does not build for _OCMP1"
#endif


#ifdef _OCMP2

/* This list contains the SFRs with default (POR) values to be used 
   for configuring Output compare modules 
   The user can modify this based on the requirement */
#define OC2RS_VALUE                0x0000
#define OC2R_VALUE                 0x0000
#define OC2CON_VALUE               0x0000

#define EnableIntOC2                    asm("BSET IEC0,#5")
#define DisableIntOC2                   asm("BCLR IEC0,#5")
#define SetPriorityIntOC2(priority)     (IPC1bits.OC2IP = priority)

/********************************************************************
* Function Name :  CloseOC2                                         *
* Description   :  This routine disables the Output Compare and its *
*                  interrupt bits.                                  *
* Parameter     :  None                                             *
* Return Value  :  None                                             *
********************************************************************/
void CloseOC2() __attribute__ ((section (".libperi")));

/************************************************************************
*    Function Name:  ConfigIntOC2                                       *
*    Description:    This Function Configures Interrupt and sets        *
*                    Interrupt Priority                                 *
*    Parameters:     unsigned int config                                *
*    Return Value:   None                                               *
************************************************************************/
void ConfigIntOC2(unsigned int config) __attribute__ ((section(".libperi")));

/********************************************************************
*    Function Name:  ReadDCOC2PWM                                   *
*    Description:    This routine reads duty cycle from Secondary   *
*                    register in PWM mode                           *
*    Parameters:     None                                           *
*    Return Value:   unsigned int:duty cycle from Secondary register*
********************************************************************/
unsigned int ReadDCOC2PWM() __attribute__ ((section (".libperi")));

/********************************************************************
*    Function Name:  ReadRegOC2                                     *
*    Description:    In Non PWM Mode, this function reads the OCRS  *
*                    reg or OCR reg based on input parameter        *
*    Parameters:     char reg                                       *
*    Return Value:   unsigned int OCRS (if reg is 0)                *
*                    or OCR (if reg is 1)                           *
********************************************************************/

unsigned int ReadRegOC2(char reg) __attribute__ ((section(".libperi")));

/*****************************************************************************
*    Function Name:  OpenOC2                                                 *
*    Description:    This routine configures output compare module and loads *
*                    the compare registers                                   *
*    Parameters  :   unsigned int config, unsigned int value1,               *
*                    unsigned int value2                                     *
*    Return Value:   None                                                    *
*    Notes           value1 is the compare value for the OCRS register       *
*                    value2 is the compare value for the OCR register        *
*****************************************************************************/
void OpenOC2(unsigned int config,unsigned int value1,
                  unsigned int value2) __attribute__ ((section(".libperi")));

/********************************************************************
*    Function Name:  SetDCOC2PWM                                    *
*    Description:    This routine writes the duty cycle OCRS reg    *
*    Parameters:     unsigned int duty cycle                        *
*    Return Value:   None                                           *
********************************************************************/
void SetDCOC2PWM(unsigned int dutycycle) __attribute__ ((section(".libperi")));

/*************************************************************************
*    Function Name:  SetPulseOC2                                         *
*    Description:    This routine writes the pulse_start to Main register*
*                    and pulse_stop to Secondary register                *
*    Parameters:     unsigned int pulse_start,unsigned int pulse_stop    *
*    Return Value:   None                                                *
*************************************************************************/
void SetPulseOC2(unsigned int pulse_start,unsigned int pulse_stop) __attribute__ 
((section (".libperi")));

#else
#warning "Does not build for _OCMP2"
#endif

#ifdef _OCMP3

/* This list contains the SFRs with default (POR) values to be used 
   for configuring Output compare modules 
   The user can modify this based on the requirement */
#define OC3RS_VALUE                0x0000
#define OC3R_VALUE                 0x0000
#define OC3CON_VALUE               0x0000

#define EnableIntOC3                    asm("BSET IEC1,#3")
#define DisableIntOC3                   asm("BCLR IEC1,#3")
#define SetPriorityIntOC3(priority)     (IPC4bits.OC3IP = priority)

/********************************************************************
* Function Name :  CloseOC3                                         *
* Description   :  This routine disables the Output Compare and its *
*                  interrupt bits.                                  *
* Parameter     :  None                                             *
* Return Value  :  None                                             *
********************************************************************/
void CloseOC3() __attribute__ ((section (".libperi")));

/************************************************************************
*    Function Name:  ConfigIntOC3                                       *
*    Description:    This Function Configures Interrupt and sets        *
*                    Interrupt Priority                                 *
*    Parameters:     unsigned int config                                *
*    Return Value:   None                                               *
************************************************************************/
void ConfigIntOC3(unsigned int config) __attribute__ ((section(".libperi")));

/********************************************************************
*    Function Name:  ReadDCOC3PWM                                   *
*    Description:    This routine reads duty cycle from Secondary   *
*                    register in PWM mode                           *
*    Parameters:     None                                           *
*    Return Value:   unsigned int:duty cycle from Secondary register*
********************************************************************/
unsigned int ReadDCOC3PWM() __attribute__ ((section (".libperi")));

/********************************************************************
*    Function Name:  ReadRegOC3                                     *
*    Description:    In Non PWM Mode, this function reads the OCRS  *
*                    reg or OCR reg based on input parameter        *
*    Parameters:     char reg                                       *
*    Return Value:   unsigned int OCRS (if reg is 0)                *
*                    or OCR (if reg is 1)                           *
********************************************************************/

unsigned int ReadRegOC3(char reg) __attribute__ ((section(".libperi")));

/*****************************************************************************
*    Function Name:  OpenOC3                                                 *
*    Description:    This routine configures output compare module and loads *
*                    the compare registers                                   *
*    Parameters  :   unsigned int config, unsigned int value1,               *
*                    unsigned int value2                                     *
*    Return Value:   None                                                    *
*    Notes           value1 is the compare value for the OCRS register       *
*                    value2 is the compare value for the OCR register        *
*****************************************************************************/
void OpenOC3(unsigned int config,unsigned int value1,
                  unsigned int value2) __attribute__ ((section(".libperi")));

/********************************************************************
*    Function Name:  SetDCOC3PWM                                    *
*    Description:    This routine writes the duty cycle OCRS reg    *
*    Parameters:     unsigned int duty cycle                        *
*    Return Value:   None                                           *
********************************************************************/
void SetDCOC3PWM(unsigned int dutycycle) __attribute__ ((section(".libperi")));

/*************************************************************************
*    Function Name:  SetPulseOC3                                         *
*    Description:    This routine writes the pulse_start to Main register*
*                    and pulse_stop to Secondary register                *
*    Parameters:     unsigned int pulse_start,unsigned int pulse_stop    *
*    Return Value:   None                                                *
*************************************************************************/
void SetPulseOC3(unsigned int pulse_start,unsigned int pulse_stop) __attribute__ 
((section (".libperi")));

#else
#warning "Does not build for _OCMP3"
#endif

#ifdef _OCMP4

/* This list contains the SFRs with default (POR) values to be used 
   for configuring Output compare modules 
   The user can modify this based on the requirement */
#define OC4RS_VALUE                0x0000
#define OC4R_VALUE                 0x0000
#define OC4CON_VALUE               0x0000

#define EnableIntOC4                    asm("BSET IEC1,#4")
#define DisableIntOC4                   asm("BCLR IEC1,#4")
#define SetPriorityIntOC4(priority)     (IPC5bits.OC4IP = priority)

/********************************************************************
* Function Name :  CloseOC4                                         *
* Description   :  This routine disables the Output Compare and its *
*                  interrupt bits.                                  *
* Parameter     :  None                                             *
* Return Value  :  None                                             *
********************************************************************/
void CloseOC4() __attribute__ ((section (".libperi")));

/************************************************************************
*    Function Name:  ConfigIntOC4                                       *
*    Description:    This Function Configures Interrupt and sets        *
*                    Interrupt Priority                                 *
*    Parameters:     unsigned int config                                *
*    Return Value:   None                                               *
************************************************************************/
void ConfigIntOC4(unsigned int config) __attribute__ ((section(".libperi")));

/********************************************************************
*    Function Name:  ReadDCOC4PWM                                   *
*    Description:    This routine reads duty cycle from Secondary   *
*                    register in PWM mode                           *
*    Parameters:     None                                           *
*    Return Value:   unsigned int:duty cycle from Secondary register*
********************************************************************/
unsigned int ReadDCOC4PWM() __attribute__ ((section (".libperi")));

/********************************************************************
*    Function Name:  ReadRegOC4                                     *
*    Description:    In Non PWM Mode, this function reads the OCRS  *
*                    reg or OCR reg based on input parameter        *
*    Parameters:     char reg                                       *
*    Return Value:   unsigned int OCRS (if reg is 0)                *
*                    or OCR (if reg is 1)                           *
********************************************************************/

unsigned int ReadRegOC4(char reg) __attribute__ ((section(".libperi")));

/*****************************************************************************
*    Function Name:  OpenOC4                                                 *
*    Description:    This routine configures output compare module and loads *
*                    the compare registers                                   *
*    Parameters  :   unsigned int config, unsigned int value1,               *
*                    unsigned int value2                                     *
*    Return Value:   None                                                    *
*    Notes           value1 is the compare value for the OCRS register       *
*                    value2 is the compare value for the OCR register        *
*****************************************************************************/
void OpenOC4(unsigned int config,unsigned int value1,
                  unsigned int value2) __attribute__ ((section(".libperi")));

/********************************************************************
*    Function Name:  SetDCOC4PWM                                    *
*    Description:    This routine writes the duty cycle OCRS reg    *
*    Parameters:     unsigned int duty cycle                        *
*    Return Value:   None                                           *
********************************************************************/
void SetDCOC4PWM(unsigned int dutycycle) __attribute__ ((section(".libperi")));

/*************************************************************************
*    Function Name:  SetPulseOC4                                         *
*    Description:    This routine writes the pulse_start to Main register*
*                    and pulse_stop to Secondary register                *
*    Parameters:     unsigned int pulse_start,unsigned int pulse_stop    *
*    Return Value:   None                                                *
*************************************************************************/
void SetPulseOC4(unsigned int pulse_start,unsigned int pulse_stop) __attribute__ 
((section (".libperi")));

#else
#warning "Does not build for _OCMP4"
#endif

#ifdef _OCMP5

/* This list contains the SFRs with default (POR) values to be used 
   for configuring Output compare modules 
   The user can modify this based on the requirement */
#define OC5RS_VALUE                0x0000
#define OC5R_VALUE                 0x0000
#define OC5CON_VALUE               0x0000

#define EnableIntOC5                    asm("BSET IEC2,#0")
#define DisableIntOC5                   asm("BCLR IEC2,#0")
#define SetPriorityIntOC5(priority)     (IPC8bits.OC5IP = priority)

/********************************************************************
* Function Name :  CloseOC5                                         *
* Description   :  This routine disables the Output Compare and its *
*                  interrupt bits.                                  *
* Parameter     :  None                                             *
* Return Value  :  None                                             *
********************************************************************/
void CloseOC5() __attribute__ ((section (".libperi")));

/************************************************************************
*    Function Name:  ConfigIntOC5                                       *
*    Description:    This Function Configures Interrupt and sets        *
*                    Interrupt Priority                                 *
*    Parameters:     unsigned int config                                *
*    Return Value:   None                                               *
************************************************************************/
void ConfigIntOC5(unsigned int config) __attribute__ ((section(".libperi")));

/********************************************************************
*    Function Name:  ReadDCOC5PWM                                   *
*    Description:    This routine reads duty cycle from Secondary   *
*                    register in PWM mode                           *
*    Parameters:     None                                           *
*    Return Value:   unsigned int:duty cycle from Secondary register*
********************************************************************/
unsigned int ReadDCOC5PWM() __attribute__ ((section (".libperi")));

/********************************************************************
*    Function Name:  ReadRegOC5                                     *
*    Description:    In Non PWM Mode, this function reads the OCRS  *
*                    reg or OCR reg based on input parameter        *
*    Parameters:     char reg                                       *
*    Return Value:   unsigned int OCRS (if reg is 0)                *
*                    or OCR (if reg is 1)                           *
********************************************************************/

unsigned int ReadRegOC5(char reg) __attribute__ ((section(".libperi")));

/*****************************************************************************
*    Function Name:  OpenOC5                                                 *
*    Description:    This routine configures output compare module and loads *
*                    the compare registers                                   *
*    Parameters  :   unsigned int config, unsigned int value1,               *
*                    unsigned int value2                                     *
*    Return Value:   None                                                    *
*    Notes           value1 is the compare value for the OCRS register       *
*                    value2 is the compare value for the OCR register        *
*****************************************************************************/
void OpenOC5(unsigned int config,unsigned int value1,
                  unsigned int value2) __attribute__ ((section(".libperi")));

/********************************************************************
*    Function Name:  SetDCOC5PWM                                    *
*    Description:    This routine writes the duty cycle OCRS reg    *
*    Parameters:     unsigned int duty cycle                        *
*    Return Value:   None                                           *
********************************************************************/
void SetDCOC5PWM(unsigned int dutycycle) __attribute__ ((section(".libperi")));

/*************************************************************************
*    Function Name:  SetPulseOC5                                         *
*    Description:    This routine writes the pulse_start to Main register*
*                    and pulse_stop to Secondary register                *
*    Parameters:     unsigned int pulse_start,unsigned int pulse_stop    *
*    Return Value:   None                                                *
*************************************************************************/
void SetPulseOC5(unsigned int pulse_start,unsigned int pulse_stop) __attribute__ 
((section (".libperi")));

#else
#warning "Does not build for _OCMP5"
#endif

#endif /* __OUTCOMPARE_H */

