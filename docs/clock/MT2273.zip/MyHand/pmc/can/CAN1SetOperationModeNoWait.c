#include<can.h>
#include<p30fxxxx.h>

#if defined(__dsPIC30F4013__) || defined(__dsPIC30F5011__) || defined(__dsPIC30F6011__)  || defined(__dsPIC30F6012__) \
    || defined(__dsPIC30F5013__) || defined(__dsPIC30F6013__) || defined(__dsPIC30F6014__) || defined(__dsPIC30F4012__) \
    || defined(__dsPIC30F4011__) || defined(__dsPIC30F6010__) || defined(__dsPIC30F5015__) || defined(__dsPIC30F6010A__) \
    || defined(__dsPIC30F6011A__) || defined(__dsPIC30F6012A__) || defined(__dsPIC30F6013A__) || defined(__dsPIC30F6014A__) \
    || defined(__dsPIC30F5016__) || defined(__dsPIC30F6015__)

/*********************************************************************************
* Function Name     : CAN1SetOperationModeNoWait
* Description       : This function sets the abort bit and configures the 
                      following bits of CxCTRL: CSIDL, REQOP<2:0> and CANCKS
* Parameters        : unsigned int config
* Return Value      : None 
**********************************************************************************/

void CAN1SetOperationModeNoWait(unsigned int config)
{
   C1CTRLbits.ABAT = 1;
   C1CTRL = config;
}

#endif
