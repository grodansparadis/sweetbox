#include<can.h>
#include<p30fxxxx.h>

#if defined(__dsPIC30F5011__) || defined(__dsPIC30F6011__) || defined(__dsPIC30F6012__) || defined(__dsPIC30F5013__) \
    || defined(__dsPIC30F6013__) || defined(__dsPIC30F6014__) || defined(__dsPIC30F6010__) || defined(__dsPIC30F6010A__) \
    || defined(__dsPIC30F6011A__) || defined(__dsPIC30F6012A__) || defined(__dsPIC30F6013A__) || defined(__dsPIC30F6014A__)

/****************************************************************************
* Function Name     : CAN2IsRXReady
* Description       : This function returns RXFUL bit status which indicates 
*                     whether the receive buffer contains any received message
* Parameters        : char: buffno
* Return Value      : char:RXFUL bit status 
*****************************************************************************/

char CAN2IsRXReady(char buffno)
{  
    switch(buffno)
    {
    case 0:
        return(C2RX0CONbits.RXFUL);
    case 1:
        return(C2RX1CONbits.RXFUL);
    }
    return 0;
}

#endif
