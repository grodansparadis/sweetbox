#include<can.h>
#include<p30fxxxx.h>

#if defined(__dsPIC30F4013__) || defined(__dsPIC30F5011__) || defined(__dsPIC30F6011__)  || defined(__dsPIC30F6012__) \
    || defined(__dsPIC30F5013__) || defined(__dsPIC30F6013__) || defined(__dsPIC30F6014__) || defined(__dsPIC30F4012__) \
    || defined(__dsPIC30F4011__) || defined(__dsPIC30F6010__) || defined(__dsPIC30F5015__) || defined(__dsPIC30F6010A__) \
    || defined(__dsPIC30F6011A__) || defined(__dsPIC30F6012A__) || defined(__dsPIC30F6013A__) || defined(__dsPIC30F6014A__) \
    || defined(__dsPIC30F5016__) || defined(__dsPIC30F6015__)

/***************************************************************************
* Function Name     : CAN1IsTXPassive
* Description       : This function returns the state of CAN tranmitter 
*                     whether it is in error passive mode.
* Parameters        : None
* Return Value      : char:TXEP bit status  
****************************************************************************/

char CAN1IsTXPassive(void)
{
    return C1INTFbits.TXEP;
}

#endif
