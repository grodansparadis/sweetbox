#include<can.h>
#include<p30fxxxx.h>

#if defined(__dsPIC30F4013__) || defined(__dsPIC30F5011__) || defined(__dsPIC30F6011__)  || defined(__dsPIC30F6012__) \
    || defined(__dsPIC30F5013__) || defined(__dsPIC30F6013__) || defined(__dsPIC30F6014__) || defined(__dsPIC30F4012__) \
    || defined(__dsPIC30F4011__) || defined(__dsPIC30F6010__) || defined(__dsPIC30F5015__) || defined(__dsPIC30F6010A__) \
    || defined(__dsPIC30F6011A__) || defined(__dsPIC30F6012A__) || defined(__dsPIC30F6013A__) || defined(__dsPIC30F6014A__) \
    || defined(__dsPIC30F5016__) || defined(__dsPIC30F6015__)

/**************************************************************************
* Function Name:     CAN1AbortAll
* Description:       This function sets the ABAT bit in C1CTRL register 
*                    thus initiating the abort of all pending transmissions
* Parameters:        None
* Return Value:      None 
***************************************************************************/

void CAN1AbortAll(void)
{
   C1CTRLbits.ABAT = 1;
}

#endif
