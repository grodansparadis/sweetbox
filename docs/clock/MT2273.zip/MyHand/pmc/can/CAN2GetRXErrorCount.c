#include<can.h>
#include<p30fxxxx.h>

#if defined(__dsPIC30F5011__) || defined(__dsPIC30F6011__) || defined(__dsPIC30F6012__) || defined(__dsPIC30F5013__) \
    || defined(__dsPIC30F6013__) || defined(__dsPIC30F6014__) || defined(__dsPIC30F6010__) || defined(__dsPIC30F6010A__) \
    || defined(__dsPIC30F6011A__) || defined(__dsPIC30F6012A__) || defined(__dsPIC30F6013A__) || defined(__dsPIC30F6014A__)

/*********************************************************************
* Function Name     : CAN2GetRXErrorCount
* Description       : This function gets the receive error count
* Parameters        : None
* Return Value      : unsigned char:  receive error count
*********************************************************************/

unsigned char CAN2GetRXErrorCount(void)
{
    return C2RERRCNT;/* returns the lower byte of C2EC */
}

#endif
