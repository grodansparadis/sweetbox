#if defined(__dsPIC33FJ64GP706__) || defined(__dsPIC33FJ64GP708__) || defined(__dsPIC33FJ64GP710__) ||\
	defined(__dsPIC33FJ128GP706__) || defined(__dsPIC33FJ128GP708__) || defined(__dsPIC33FJ128GP710__) || \
 	defined(__dsPIC33FJ256GP710__) || defined(__dsPIC33FJ64MC506__) || defined(__dsPIC33FJ64MC508__) || \
        defined(__dsPIC33FJ64MC510__) || defined(__dsPIC33FJ64MC706__) || defined(__dsPIC33FJ64MC710__) || \
        defined(__dsPIC33FJ128MC506__) || defined(__dsPIC33FJ128MC510__) ||defined(__dsPIC33FJ128MC706__) || \
        defined(__dsPIC33FJ128MC708__) || defined(__dsPIC33FJ128MC710__) ||defined(__dsPIC33FJ256MC510__) || \
        defined(__dsPIC33FJ256MC710__) 
#include <p33Fxxxx.h>
#elif defined(__PIC24HJ256GP610__)
	#include<p24Hxxxx.h>
#endif
#include <ecan.h>

/*************************************************************************
* Function Name     : CAN2SetMask
* Description       : This function sets the values for the acceptance 
*                     filter mask registers (SID and EID)
* Parameters        : char: mask_no
*                     unsigned int: sid register value  
*                     unsigned long: eid registers value
* Return Value      : None 
**************************************************************************/

void CAN2SetMask(char mask_no, unsigned int sid, unsigned long eid)
{ 
    unsigned int eidh;
    eidh = (eid & 0x30000) >> 16; 
 
    switch(mask_no)
    {
        case 0:
	      C2RXM0SID = sid & eidh;
	      C2RXM0EID = eid;         
	      break;
	case 1:
	      C2RXM1SID = sid & eidh;
	      C2RXM1EID = eid;         
	      break;
	case 2:
	      C2RXM2SID = sid & eidh;
	      C2RXM2EID = eid;         
	      break;
	    
    default:
      C2RXM0SID = sid & eidh;
      C2RXM0EID = eid;         
      break;
    }
}


