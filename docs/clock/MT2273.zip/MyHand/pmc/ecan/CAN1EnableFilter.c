#if defined(__dsPIC33FJ64GP706__) || defined(__dsPIC33FJ64GP708__) || defined(__dsPIC33FJ64GP710__) ||\
	defined(__dsPIC33FJ128GP706__) || defined(__dsPIC33FJ128GP708__) || defined(__dsPIC33FJ128GP710__) || \
 	defined(__dsPIC33FJ256GP710__) || defined(__dsPIC33FJ64MC506__) || defined(__dsPIC33FJ64MC508__) || \
        defined(__dsPIC33FJ64MC510__) || defined(__dsPIC33FJ64MC706__) || defined(__dsPIC33FJ64MC710__) || \
        defined(__dsPIC33FJ128MC506__) || defined(__dsPIC33FJ128MC510__) ||defined(__dsPIC33FJ128MC706__) || \
        defined(__dsPIC33FJ128MC708__) || defined(__dsPIC33FJ128MC710__) ||defined(__dsPIC33FJ256MC510__) || \
        defined(__dsPIC33FJ256MC710__) 
#include <p33Fxxxx.h>
#elif defined(__PIC24HJ256GP610__)
#include<p24Hxxxx.h>
#endif
#include <ecan.h>

/*********************************************************************
* Function Name     : CAN1EnableFilter
* Description       : This function enables the acceptance filter  
*                     
* Parameters        : char: filter_no
*                     
* Return Value      : None 
*********************************************************************/

void CAN1EnableFilter(char filter_no)
{  
    
    switch(filter_no)
    {
    case 0:
      C1FEN1bits.FLTEN0= 1;
      break;

    case 1:
     C1FEN1bits.FLTEN1 = 1;
      break;

    case 2:
      C1FEN1bits.FLTEN2 = 1;
      break;

    case 3:
      C1FEN1bits.FLTEN3 = 1;
      break;

    case 4:
      C1FEN1bits.FLTEN4 = 1;
      break;

    case 5:
      C1FEN1bits.FLTEN5 = 1;
      break;

    case 6:
      C1FEN1bits.FLTEN6 = 1;
      break;

    case 7:
      C1FEN1bits.FLTEN7 = 1;
      break;

    case 8:
      C1FEN1bits.FLTEN8 = 1;
      break;

    case 9:
      C1FEN1bits.FLTEN9 = 1;
      break;

    case 10:   
      C1FEN1bits.FLTEN10= 1;
      break;

    case 11:
      C1FEN1bits.FLTEN11 = 1;
      break;

    case 12:
      C1FEN1bits.FLTEN12 = 1;
      break;

    case 13:   
      C1FEN1bits.FLTEN13 = 1;
      break;

    case 14:
      C1FEN1bits.FLTEN14 = 1;
      break;

    case 15:
      C1FEN1bits.FLTEN15 = 1;
      break;

    default:   
      C1FEN1bits.FLTEN0= 1;
      break;
    }
}


