#include<ecan.h>
#if defined(__dsPIC33FJ64GP706__) || defined(__dsPIC33FJ64GP708__) || defined(__dsPIC33FJ64GP710__) ||\
	defined(__dsPIC33FJ128GP706__) || defined(__dsPIC33FJ128GP708__) || defined(__dsPIC33FJ128GP710__) || \
	defined(__dsPIC33FJ256GP506__) || defined(__dsPIC33FJ256GP510__) || defined(__dsPIC33FJ256GP710__) || \
	defined(__dsPIC33FJ64MC506__) || defined(__dsPIC33FJ64MC508__) ||defined(__dsPIC33FJ64MC510__) || \
        defined(__dsPIC33FJ64MC706__) || defined(__dsPIC33FJ64MC710__) ||defined(__dsPIC33FJ128MC506__) || \
        defined(__dsPIC33FJ128MC510__) || defined(__dsPIC33FJ128MC706__) ||defined(__dsPIC33FJ128MC708__) ||\
        defined(__dsPIC33FJ128MC710__) || defined(__dsPIC33FJ256MC510__) ||defined(__dsPIC33FJ256MC710__)

#include <p33Fxxxx.h>

#elif defined(__PIC24HJ64GP506__) || defined(__PIC24HJ64GP510__) || defined(__PIC24HJ128GP506__) ||\
	defined(__PIC24HJ128GP510__) || defined(__PIC24HJ256GP610__)

#include <p24Hxxxx.h>

#endif

/*********************************************************************
* Function Name     : CAN1GetTXErrorCount
* Description       : This function gets the transmit error count
* Parameters        : None
* Return Value      : unsigned char: transmit error count 
*********************************************************************/

unsigned char CAN1GetTXErrorCount(void)
{
    return C1EC>>8;    /* upper byte of C1EC */
}


