#if defined(__dsPIC33FJ64GP706__) || defined(__dsPIC33FJ64GP708__) || defined(__dsPIC33FJ64GP710__) ||\
	defined(__dsPIC33FJ128GP706__) || defined(__dsPIC33FJ128GP708__) || defined(__dsPIC33FJ128GP710__) || \
 	defined(__dsPIC33FJ256GP710__) || defined(__dsPIC33FJ64MC506__) || defined(__dsPIC33FJ64MC508__) || \
        defined(__dsPIC33FJ64MC510__) || defined(__dsPIC33FJ64MC706__) || defined(__dsPIC33FJ64MC710__) || \
        defined(__dsPIC33FJ128MC506__) || defined(__dsPIC33FJ128MC510__) ||defined(__dsPIC33FJ128MC706__) || \
        defined(__dsPIC33FJ128MC708__) || defined(__dsPIC33FJ128MC710__) ||defined(__dsPIC33FJ256MC510__) || \
        defined(__dsPIC33FJ256MC710__) 
#include <p33Fxxxx.h>
#elif defined(__PIC24HJ256GP610__)
	#include<p24Hxxxx.h>
#endif
#include <ecan.h>

/************************************************************************
* Function Name     : ConfigIntCAN2
* Description       : This function configures the interrupts for CAN2
*
* Parameters        : unsigned int: config1 individual interrupt enable
*                     unsigned int: config2 interrupt priority and enable/disable 
*                                   information
* Return Value      : None
*************************************************************************/

void ConfigIntCAN2(unsigned int config1, unsigned int config2)
{
    C2INTF = 0;                          /* the individual flag register cleared */

    IFS3bits.C2IF = 0;                   /* Clear combined IRQ C2IF */
    C2INTE = config1;            

    IPC14bits.C2IP = config2 & 0x07;      /* set interrupt priority */
    IEC3bits.C2IE = (config2 & 0x08) >>3;/* enable or disable interrupt*/
}


