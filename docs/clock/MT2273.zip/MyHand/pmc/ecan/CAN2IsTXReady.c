#if defined(__dsPIC33FJ64GP706__) || defined(__dsPIC33FJ64GP708__) || defined(__dsPIC33FJ64GP710__) ||\
	defined(__dsPIC33FJ128GP706__) || defined(__dsPIC33FJ128GP708__) || defined(__dsPIC33FJ128GP710__) || \
	defined(__dsPIC33FJ256GP506__) || defined(__dsPIC33FJ256GP510__) || defined(__dsPIC33FJ256GP710__) || \
    defined(__dsPIC33FJ64MC506__) || defined(__dsPIC33FJ64MC508__) || \
	defined(__dsPIC33FJ64MC510__) || defined(__dsPIC33FJ64MC706__) || defined(__dsPIC33FJ64MC710__) || \
	defined(__dsPIC33FJ128MC506__) || defined(__dsPIC33FJ128MC510__) || defined(__dsPIC33FJ128MC706__) ||\
	defined(__dsPIC33FJ128MC708__) || defined(__dsPIC33FJ128MC710__) || defined(__dsPIC33FJ256MC510__) ||\
	defined(__dsPIC33FJ256MC710__)

#include <p33Fxxxx.h>

#elif defined(__PIC24HJ64GP506__) || defined(__PIC24HJ64GP510__) || defined(__PIC24HJ128GP506__) ||\
	defined(__PIC24HJ128GP510__) || defined(__PIC24HJ256GP610__)

#include <p24Hxxxx.h>

#endif

#include<ECAN.h>


#if defined(__dsPIC33FJ64GP706__) || defined(__dsPIC33FJ64GP708__) || defined(__dsPIC33FJ64GP710__) ||\
	defined(__dsPIC33FJ128GP706__) || defined(__dsPIC33FJ128GP708__) || defined(__dsPIC33FJ128GP710__) || \
 	defined(__dsPIC33FJ256GP710__) || defined(__dsPIC33FJ64MC506__) ||defined(__dsPIC33FJ64MC508__) || \
	defined(__dsPIC33FJ64MC510__) || defined(__dsPIC33FJ64MC706__) || defined(__dsPIC33FJ64MC710__) || \
    defined(__dsPIC33FJ128MC506__) || defined(__dsPIC33FJ128MC510__) ||defined(__dsPIC33FJ128MC706__) || \
    defined(__dsPIC33FJ128MC708__) || defined(__dsPIC33FJ128MC710__) ||defined(__dsPIC33FJ256MC510__) || \
	defined(__dsPIC33FJ256MC710__) ||defined(__PIC24HJ256GP610__)

/***************************************************************************
* Function Name     : ECAN2IsTXReady
* Description       : This function returns TXREQ bit status which indicates 
*                     whether the transmitter is ready for next transmission.
* Parameters        : char: buffno
* Return Value      : char: compliment of TXREQ bit status 
****************************************************************************/

char ECAN2IsTXReady(char buffno)
{  
    switch(buffno)
    {
     case 0:
        return !(C2TR01CONbits.TXREQ0);
        break;
    case 1:
        return !(C2TR01CONbits.TXREQ1);
        break;
    case 2:
        return !(C2TR23CONbits.TXREQ2);
        break;
	case 3:
        return !(C2TR23CONbits.TXREQ3);
        break;
	case 4:
        return !(C2TR45CONbits.TXREQ4);
        break;
	case 5:
        return !(C2TR45CONbits.TXREQ5);
        break;
	case 6:
        return !(C2TR67CONbits.TXREQ6);
        break;
	case 7:
        return !(C2TR67CONbits.TXREQ7);
        break;
    }
    return 0;
}

#endif

