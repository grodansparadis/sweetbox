#include<ecan.h>
#if defined(__dsPIC33FJ64GP706__) || defined(__dsPIC33FJ64GP708__) || defined(__dsPIC33FJ64GP710__) ||\
	defined(__dsPIC33FJ128GP706__) || defined(__dsPIC33FJ128GP708__) || defined(__dsPIC33FJ128GP710__) || \
	defined(__dsPIC33FJ256GP506__) || defined(__dsPIC33FJ256GP510__) || defined(__dsPIC33FJ256GP710__) || \
        defined(__dsPIC33FJ64MC506__) || defined(__dsPIC33FJ64MC508__) || defined(__dsPIC33FJ64MC510__) || \
        defined(__dsPIC33FJ64MC706__) || defined(__dsPIC33FJ64MC710__) || defined(__dsPIC33FJ128MC506__) || \
        defined(__dsPIC33FJ128MC510__) || defined(__dsPIC33FJ128MC706__) ||defined(__dsPIC33FJ128MC708__) || \
        defined(__dsPIC33FJ128MC710__) || defined(__dsPIC33FJ256MC510__) ||defined(__dsPIC33FJ256MC710__)

#include <p33Fxxxx.h>

#elif defined(__PIC24HJ64GP506__) || defined(__PIC24HJ64GP510__) || defined(__PIC24HJ128GP506__) ||\
	defined(__PIC24HJ128GP510__) || defined(__PIC24HJ256GP610__)

#include <p24Hxxxx.h>

#endif
/******************************************************************************
* Function Name     : CAN1SendMessage
* Description       : This function writes the message identifiers (SID, EID), 
                      writes the data to be transmitted into the Transmit buffer
*                     and sets the corresponding Transmit request bit.
* Parameters        : unsigned long: id
*                     unsigned char: * data
*                     unsigned char: datalen 
*                     char: MsgFlag from 0 to 7
*                     unsigned int: *DMAptr(pointer to location in DMA)
* Return Value      : None 
*******************************************************************************/

void CAN2SendMessage (unsigned char * data, unsigned char  datalen, 
                     char MsgFlag, unsigned int *DMAptr)
{
    int i;
    
    for(i = 0;i < datalen;i++)
    {  
         *((unsigned char *)&DMAptr+i)= data[i];  
    }

    /* Msg send request */
    switch(MsgFlag)
    {
    case 0:
        C2TR01CONbits.TXREQ0 = 1;
        break;
    case 1:
        C2TR01CONbits.TXREQ1 = 1;
        break;
    case 2:
        C2TR23CONbits.TXREQ2 = 1;
        break;
    case 3:
	C2TR23CONbits.TXREQ3 = 1;
        break;
    case 4:
        C2TR45CONbits.TXREQ4 = 1;
        break;
    case 5:
        C2TR45CONbits.TXREQ5 = 1;
        break;
    case 6:
        C2TR67CONbits.TXREQ6 = 1;
        break;
    case 7:
        C2TR67CONbits.TXREQ7 = 1;
        break;
    default:
        C2TR01CONbits.TXREQ0 = 1;
        break;
    }
}


