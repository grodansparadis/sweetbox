#include<ecan.h>
#if defined(__dsPIC33FJ64GP706__) || defined(__dsPIC33FJ64GP708__) || defined(__dsPIC33FJ64GP710__) ||\
	defined(__dsPIC33FJ128GP706__) || defined(__dsPIC33FJ128GP708__) || defined(__dsPIC33FJ128GP710__) || \
	defined(__dsPIC33FJ256GP506__) || defined(__dsPIC33FJ256GP510__) || defined(__dsPIC33FJ256GP710__) || \
        defined(__dsPIC33FJ64MC506__) || defined(__dsPIC33FJ64MC508__) || defined(__dsPIC33FJ64MC510__) || \
        defined(__dsPIC33FJ64MC706__) || defined(__dsPIC33FJ64MC710__) || defined(__dsPIC33FJ128MC506__) || \
        defined(__dsPIC33FJ128MC510__) || defined(__dsPIC33FJ128MC706__) ||defined(__dsPIC33FJ128MC708__) || \
        defined(__dsPIC33FJ128MC710__) || defined(__dsPIC33FJ256MC510__) ||defined(__dsPIC33FJ256MC710__)

#include <p33Fxxxx.h>

#elif defined(__PIC24HJ64GP506__) || defined(__PIC24HJ64GP510__) || defined(__PIC24HJ128GP506__) ||\
	defined(__PIC24HJ128GP510__) || defined(__PIC24HJ256GP610__)

#include <p24Hxxxx.h>

#endif
/****************************************************************************
* Function Name     : CAN1SetTXRXMode
* Description       : This function configures the CxTRmnCON register
* Parameters        : char buffno, unsigned int config
* Return Value      : None 
*****************************************************************************/

void CAN1SetTXRXMode(char buffno, unsigned int config)
{  
    switch(buffno)
    {
    case 0:
      C1TR01CON = config;
      break;
    case 1:
	C1TR01CON = config;
      break;
    case 2:
    case 3: C1TR23CON = config;
	break;
    case 4:
    case 5: C1TR45CON = config;
	break;
    case 6:
    case 7: C1TR67CON = config;
	break; 
    }
}



