#include<ecan.h>
#if defined(__dsPIC33FJ64GP706__) || defined(__dsPIC33FJ64GP708__) || defined(__dsPIC33FJ64GP710__) ||\
	defined(__dsPIC33FJ128GP706__) || defined(__dsPIC33FJ128GP708__) || defined(__dsPIC33FJ128GP710__) || \
	defined(__dsPIC33FJ256GP506__) || defined(__dsPIC33FJ256GP510__) || defined(__dsPIC33FJ256GP710__) || \
        defined(__dsPIC33FJ64MC506__) || defined(__dsPIC33FJ64MC508__) || defined(__dsPIC33FJ64MC510__) || \
        defined(__dsPIC33FJ64MC706__) || defined(__dsPIC33FJ64MC710__) || defined(__dsPIC33FJ128MC506__) || \
        defined(__dsPIC33FJ128MC510__) || defined(__dsPIC33FJ128MC706__) ||defined(__dsPIC33FJ128MC708__) || \
        defined(__dsPIC33FJ128MC710__) || defined(__dsPIC33FJ256MC510__) ||defined(__dsPIC33FJ256MC710__)

#include <p33Fxxxx.h>

#elif defined(__PIC24HJ64GP506__) || defined(__PIC24HJ64GP510__) || defined(__PIC24HJ128GP506__) ||\
	defined(__PIC24HJ128GP510__) || defined(__PIC24HJ256GP610__)

#include <p24Hxxxx.h>

#endif
/***************************************************************************
* Function Name     : CAN1IsRXReady
* Description       : This function returns RXFUL bit status which indicates 
*                     whether the receive buffer contains any received message
* Parameters        : char buffno
* Return Value      : char: RXFUL bit status
****************************************************************************/

char CAN1IsRXReady(char buffno)
{  
    switch(buffno)
    {
    case 0:
        return C1RXFUL1bits.RXFUL0;
    case 1:
        return C1RXFUL1bits.RXFUL1;
    case 2:
        return C1RXFUL1bits.RXFUL2;
    case 3:
        return C1RXFUL1bits.RXFUL3;
    case 4:
        return C1RXFUL1bits.RXFUL4;
    case 5:
        return C1RXFUL1bits.RXFUL5;
    case 6:
        return C1RXFUL1bits.RXFUL6;
    case 7:
        return C1RXFUL1bits.RXFUL7;
    case 8:
        return C1RXFUL1bits.RXFUL8;
    case 9:
        return C1RXFUL1bits.RXFUL9;
    case 10:
        return C1RXFUL1bits.RXFUL10;
    case 11:
        return C1RXFUL1bits.RXFUL11;
    case 12:
        return C1RXFUL1bits.RXFUL12;
    case 13:
        return C1RXFUL1bits.RXFUL13;
    case 14:
        return C1RXFUL1bits.RXFUL14;
    case 15:
        return C1RXFUL1bits.RXFUL15;
    case 16:
        return C1RXFUL2bits.RXFUL16;
    case 17:
        return C1RXFUL2bits.RXFUL17;
    case 18:
        return C1RXFUL2bits.RXFUL18;
    case 19:
        return C1RXFUL2bits.RXFUL19;
    case 20:
        return C1RXFUL2bits.RXFUL20;
    case 21:
        return C1RXFUL2bits.RXFUL21;
    case 22:
        return C1RXFUL2bits.RXFUL22;
    case 23:
        return C1RXFUL2bits.RXFUL23;
    case 24:
        return C1RXFUL2bits.RXFUL24;
    case 25:
        return C1RXFUL2bits.RXFUL25;
    case 26:
        return C1RXFUL2bits.RXFUL26;
    case 27:
        return C1RXFUL2bits.RXFUL27;
    case 28:
        return C1RXFUL2bits.RXFUL28;
    case 29:
        return C1RXFUL2bits.RXFUL29;
    case 30:
        return C1RXFUL2bits.RXFUL30;
    case 31:
        return C1RXFUL2bits.RXFUL31;
 
    }
    return 0;
}


