#if defined(__dsPIC33FJ64GP706__) || defined(__dsPIC33FJ64GP708__) || defined(__dsPIC33FJ64GP710__) ||\
	defined(__dsPIC33FJ128GP706__) || defined(__dsPIC33FJ128GP708__) || defined(__dsPIC33FJ128GP710__) || \
 	defined(__dsPIC33FJ256GP710__) || defined(__dsPIC33FJ64MC506__) || defined(__dsPIC33FJ64MC508__) || \
        defined(__dsPIC33FJ64MC510__) || defined(__dsPIC33FJ64MC706__) || defined(__dsPIC33FJ64MC710__) || \
        defined(__dsPIC33FJ128MC506__) || defined(__dsPIC33FJ128MC510__) ||defined(__dsPIC33FJ128MC706__) || \
        defined(__dsPIC33FJ128MC708__) || defined(__dsPIC33FJ128MC710__) ||defined(__dsPIC33FJ256MC510__) || \
        defined(__dsPIC33FJ256MC710__) 
#include <p33Fxxxx.h>
#elif defined(__PIC24HJ256GP610__)
	#include<p24Hxxxx.h>
#endif
#include <ecan.h>
 
/*************************************************************************
* Function Name     : CAN2Initialize
* Description       : This function configures Sync jump width, Baud Rate
*                     Pre-scaler, Phase Buffer Segment 1 and 2, and 
*                     Propogation time segment.
* Parameters        : unsigned int: config1, unsigned int: config2
* Return Value      : None
**************************************************************************/

void CAN2Initialize(unsigned int config1, unsigned int config2)
{
    C2CFG1 = config1; /* configure SJWand BRP */
    C2CFG2 = config2; /* configure PHSEG2 and PHSEG1 and PROPSEG */
}


