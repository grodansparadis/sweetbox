#include<ecan.h>
#if defined(__dsPIC33FJ64GP706__) || defined(__dsPIC33FJ64GP708__) || defined(__dsPIC33FJ64GP710__) ||\
	defined(__dsPIC33FJ128GP706__) || defined(__dsPIC33FJ128GP708__) || defined(__dsPIC33FJ128GP710__) || \
	defined(__dsPIC33FJ256GP506__) || defined(__dsPIC33FJ256GP510__) || defined(__dsPIC33FJ256GP710__) || \
        defined(__dsPIC33FJ64MC506__) || defined(__dsPIC33FJ64MC508__) || defined(__dsPIC33FJ64MC510__) || \
        defined(__dsPIC33FJ64MC706__) || defined(__dsPIC33FJ64MC710__) || defined(__dsPIC33FJ128MC506__) || \
        defined(__dsPIC33FJ128MC510__) || defined(__dsPIC33FJ128MC706__) ||defined(__dsPIC33FJ128MC708__) || \
        defined(__dsPIC33FJ128MC710__) || defined(__dsPIC33FJ256MC510__) ||defined(__dsPIC33FJ256MC710__)

#include <p33Fxxxx.h>

#elif defined(__PIC24HJ64GP506__) || defined(__PIC24HJ64GP510__) || defined(__PIC24HJ128GP506__) ||\
	defined(__PIC24HJ128GP510__) || defined(__PIC24HJ256GP610__)

#include <p24Hxxxx.h>

#endif
/*********************************************************************
* Function Name     : CAN1SetFilter
* Description       : This function sets the acceptance filter values 
*                     (SID and EID) for the specified filter
* Parameters        : char: filter_no
*                     unsigned int: sid register value  
*                     unsigned long: eid registers value
* Return Value      : None 
*********************************************************************/

void CAN1SetFilter(char filter_no, unsigned int sid, unsigned long eid)
{  
    unsigned int eidh;
    eidh = (eid & 0x30000) >> 16;

    switch(filter_no)
    {
    case 0:
      C1RXF0SID = sid & eidh;
      C1RXF0EID = eid;       
      break;
    case 1:
      C1RXF1SID = sid & eidh;
      C1RXF1EID = eid;       
      break;

    case 2:
      C1RXF2SID = sid & eidh;
      C1RXF2EID = eid;       
      break;

    case 3:
      C1RXF3SID = sid & eidh;
      C1RXF3EID = eid;       
      break;

    case 4:
      C1RXF4SID = sid & eidh;
      C1RXF4EID = eid;       
      break;

    case 5:
      C1RXF5SID = sid & eidh;
      C1RXF5EID = eid;       
      break;

    case 6:
      C1RXF6SID = sid & eidh;
      C1RXF6EID = eid;       
      break;

    case 7:
      C1RXF7SID = sid & eidh;
      C1RXF7EID = eid;       
      break;

    case 8:
      C1RXF8SID = sid & eidh;
      C1RXF8EID = eid;       
      break;

    case 9:
      C1RXF9SID = sid & eidh;
      C1RXF9EID = eid;       
      break;

    case 10:
      C1RXF10SID = sid & eidh;
      C1RXF10EID = eid;       
      break;

    case 11:
      C1RXF11SID = sid & eidh;
      C1RXF11EID = eid;       
      break;

    case 12:
      C1RXF12SID = sid & eidh;
      C1RXF12EID = eid;       
      break;

    case 13:
      C1RXF13SID = sid & eidh;
      C1RXF13EID = eid;       
      break;

    case 14:
      C1RXF14SID = sid & eidh;
      C1RXF14EID = eid;       
      break;

    case 15:
      C1RXF15SID = sid & eidh;
      C1RXF15EID = eid;       
      break;

    default:
      C1RXF0SID = sid & eidh;
      C1RXF0EID = eid;        
      break;
    }
}

