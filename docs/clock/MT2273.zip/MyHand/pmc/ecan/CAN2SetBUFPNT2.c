#if defined(__dsPIC33FJ64GP706__) || defined(__dsPIC33FJ64GP708__) || defined(__dsPIC33FJ64GP710__) ||\
	defined(__dsPIC33FJ128GP706__) || defined(__dsPIC33FJ128GP708__) || defined(__dsPIC33FJ128GP710__) || \
 	defined(__dsPIC33FJ256GP710__) || defined(__dsPIC33FJ64MC506__) || defined(__dsPIC33FJ64MC508__) || \
        defined(__dsPIC33FJ64MC510__) || defined(__dsPIC33FJ64MC706__) || defined(__dsPIC33FJ64MC710__) || \
        defined(__dsPIC33FJ128MC506__) || defined(__dsPIC33FJ128MC510__) ||defined(__dsPIC33FJ128MC706__) || \
        defined(__dsPIC33FJ128MC708__) || defined(__dsPIC33FJ128MC710__) ||defined(__dsPIC33FJ256MC510__) || \
        defined(__dsPIC33FJ256MC710__) 
#include <p33Fxxxx.h>
#elif defined(__PIC24HJ256GP610__)
#include<p24Hxxxx.h>
#endif
#include <ecan.h>

/*********************************************************************
* Function Name     : CAN2SetBUFPNT2
* Description       : This function sets the ECAN filter 4-11 buffer
		      pointer register
*                     
* Parameters        : unsigned int : pointer_value
*                     
* Return Value      : None 
*********************************************************************/

void CAN2SetBUFPNT2(unsigned int pointer_value)
{  
   C2BUFPNT2 = pointer_value; 
   
}


