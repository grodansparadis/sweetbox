#if defined(__dsPIC33FJ64GP206__) || defined(__dsPIC33FJ64GP306__) || defined(__dsPIC33FJ64GP310__) || defined(__dsPIC33FJ64GP706__) || \
	defined(__dsPIC33FJ64GP708__) || defined(__dsPIC33FJ64GP710__) || defined(__dsPIC33FJ128GP206__) || defined(__dsPIC33FJ128GP306__) || \
	defined(__dsPIC33FJ128GP310__) || defined(__dsPIC33FJ128GP706__) || defined(__dsPIC33FJ128GP708__) || defined(__dsPIC33FJ128GP710__) || \
	defined(__dsPIC33FJ256GP506__) || defined(__dsPIC33FJ256GP510__) || defined(__dsPIC33FJ256GP710__) || defined(__dsPIC33FJ64MC506__) || \
	defined(__dsPIC33FJ64MC508__) || defined(__dsPIC33FJ64MC510__) || defined(__dsPIC33FJ64MC706__) || defined(__dsPIC33FJ64MC710__) || \
	defined(__dsPIC33FJ128MC506__) || defined(__dsPIC33FJ128MC510__) || defined(__dsPIC33FJ128MC706__) || defined(__dsPIC33FJ128MC708__) ||\
	defined(__dsPIC33FJ128MC710__) || defined(__dsPIC33FJ256MC510__) || defined(__dsPIC33FJ256MC710__) 

#include <p33Fxxxx.h>

#elif defined(__PIC24HJ64GP206__) || defined(__PIC24HJ64GP210__) || defined(__PIC24HJ64GP506__) || defined(__PIC24HJ64GP510__) || \
	defined(__PIC24HJ128GP206__) || defined(__PIC24HJ128GP210__) || defined(__PIC24HJ128GP506__) || defined(__PIC24HJ128GP510__) || \
	defined(__PIC24HJ128GP306__) || defined(__PIC24HJ128GP310__) || defined(__PIC24HJ256GP206__) || defined(__PIC24HJ256GP210__) || \
	defined(__PIC24HJ256GP610__)
#include <p24Hxxxx.h>

#endif

#include "dma.h"

/*********************************************************************
* Function Name     : OpenDMA4
* Description       : Configures the DMA4. This includes :
                    � Data size			 // DMA4CON<14> SIZE bit
		    . Data transfer direction       // DMA4CON<13> DIR bit
                    � Transfer complete interrupt select	//DMA4CON<12> HALF bit
                    � Null data peripheral write mode select bit  // DMA4CON<11> NULLW bit
                    � DMA4 addressing mode select bit	//DMA4CON<5:4> AMODE<1:0> bits
                    . DMA4 operating mode select bit	//DMA4CON<1:0> MODE<1:0> bits 
                    . Peripheral IRQ select			//DMA4REQ<6:0> IRQSEL<6:0> bits
		    . Force a manual transfer			//DMA4REQ<15> FORCE bit
		    . DMA4 start address for register A		//DMA4STA<7:0> STA<7:0> bits
		    . DMA4 start address for register B		//DMA4STB<7:0> STB<7:0> bits
		    . DMA4 peripheral address register		// DMA4PAD register
		    . DMA4 transfer count register		//DMA4CNT
* Parameters        : config,irq,sta_address, stb_address, pad_adress, count 
* Return Value      : None
*********************************************************************/

void OpenDMA4(unsigned int config,unsigned int irq,unsigned int sta_address,
		unsigned int stb_address,unsigned int pad_adress,unsigned int count )
{
    

    /* configures the DMA4 CONTROL register */

    DMA4CON = config;

	/* Set the peripheral IRQ number*/
	DMA4REQ = irq;

	/* set the start address for buffer A */
	DMA4STA = sta_address;

	/* set the start address for buffer B */
	DMA4STB = stb_address;

	/* set the peripheral address*/
	DMA4PAD = pad_adress;

	/* set the number of bytes/words to be tranfered*/
	DMA4CNT = count;
	
	/* enable the DMA4 */

	DMA4CONbits.CHEN = 1;

}


