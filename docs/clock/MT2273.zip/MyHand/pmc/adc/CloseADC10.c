#include<p30fxxxx.h>
#include<adc10.h>

#if defined (__dsPIC30F2010__) || defined (__dsPIC30F3010__) || defined (__dsPIC30F4012__) || defined (__dsPIC30F3011__) || \
    defined (__dsPIC30F4011__) || defined (__dsPIC30F6010__) || defined (__dsPIC30F5015__) || defined (__dsPIC30F6010A__) || \
    defined (__dsPIC30F5016__) || defined (__dsPIC30F6015__)

/*********************************************************************
* Function Name     : CloseADC10
* Description       : This function turns off the A/D converter. 
*                     Also, the Interrupt enable (ADIE) and Interrupt 
*                     flag (ADIF) bits are cleared
* Parameters        : None
* Return Value      : None
*********************************************************************/

void CloseADC10(void)
{
    /* disable ADC interrupt */
    IEC0bits.ADIE = 0;

    /* turn off ADC */
    ADCON1bits.ADON = 0;    

	/* clear ADIF bit */
    IFS0bits.ADIF = 0;
}

#endif
