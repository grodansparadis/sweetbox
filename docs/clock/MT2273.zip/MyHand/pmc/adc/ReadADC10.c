#include<p30fxxxx.h>
#include<adc10.h>

#if defined (__dsPIC30F2010__) || defined (__dsPIC30F3010__) || defined (__dsPIC30F4012__) || defined (__dsPIC30F3011__) || \
    defined (__dsPIC30F4011__) || defined (__dsPIC30F6010__) || defined (__dsPIC30F5015__) || defined (__dsPIC30F6010A__) || \
    defined (__dsPIC30F5016__) || defined (__dsPIC30F6015__)

/************************************************************************
* Function Name     : ReadADC10
* Description       : This function reads from one of the 16 ADC Buffers
                      (ADCBUF0 - ADCBUFF)
* Parameters        : unsigned char bufIndex
* Return Value      : unsigned int
*************************************************************************/

unsigned int ReadADC10(unsigned char bufIndex)
{
     return(*(&ADCBUF0+bufIndex));
}

#endif
