#include<p30fxxxx.h>
#include<adc12.h>

#if defined (__dsPIC30F2011__) || defined (__dsPIC30F3012__) || defined (__dsPIC30F2012__) || defined (__dsPIC30F3013__) \
    || defined (__dsPIC30F3014__) || defined (__dsPIC30F4013__) || defined (__dsPIC30F5011__) || defined (__dsPIC30F6011__) \
    || defined (__dsPIC30F6012__) || defined (__dsPIC30F5013__) || defined (__dsPIC30F6013__) || defined (__dsPIC30F6014__) \
    || defined (__dsPIC30F6011A__) || defined (__dsPIC30F6012A__) || defined (__dsPIC30F6013A__) || defined (__dsPIC30F6014A__)

/*********************************************************************
* Function Name     : BusyADC12
* Description       : This function returns the ADC conversion status.
* Parameters        : None
* Return Value      : DONE bit status
*********************************************************************/

char BusyADC12(void)
{
    return !(ADCON1bits.DONE); /* returns the DONE bit status */
}

#endif
