#include<p30fxxxx.h>
#include<adc12.h>

#if defined (__dsPIC30F2011__) || defined (__dsPIC30F3012__) || defined (__dsPIC30F2012__) || defined (__dsPIC30F3013__) \
    || defined (__dsPIC30F3014__) || defined (__dsPIC30F4013__) || defined (__dsPIC30F5011__) || defined (__dsPIC30F6011__) \
    || defined (__dsPIC30F6012__) || defined (__dsPIC30F5013__) || defined (__dsPIC30F6013__) || defined (__dsPIC30F6014__) \
    || defined (__dsPIC30F6011A__) || defined (__dsPIC30F6012A__) || defined (__dsPIC30F6013A__) || defined (__dsPIC30F6014A__)

/*********************************************************************
* Function Name     : SetChanADC12
* Description       : This function sets the ADCHS reg to get the +ve 
*                     and -ve of sample inputs A and B.
* Parameters        : unsigned int channel
* Return Value      : None
*********************************************************************/

void SetChanADC12(unsigned int channel)
{
    ADCHS = channel;
}

#endif
