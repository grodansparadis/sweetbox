#include<p30fxxxx.h>
#include<adc10.h>

#if defined (__dsPIC30F2010__) || defined (__dsPIC30F3010__) || defined (__dsPIC30F4012__) || defined (__dsPIC30F3011__) || \
    defined (__dsPIC30F4011__) || defined (__dsPIC30F6010__) || defined (__dsPIC30F5015__) || defined (__dsPIC30F6010A__) || \
    defined (__dsPIC30F5016__) || defined (__dsPIC30F6015__)

/*********************************************************************
* Function Name     : SetChanADC10
* Description       : This function sets the ADCHS reg to get the +ve 
*                     and -ve of sample inputs A and B.
* Parameters        : unsigned int channel
* Return Value      : None
*********************************************************************/

void SetChanADC10(unsigned int channel)
{
    ADCHS = channel;
}

#endif
