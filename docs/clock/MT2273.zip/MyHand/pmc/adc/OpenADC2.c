#if defined(__dsPIC33FJ64GP206__) || defined(__dsPIC33FJ64GP306__) || defined(__dsPIC33FJ64GP310__) || defined(__dsPIC33FJ64GP706__) || \
	defined(__dsPIC33FJ64GP708__) || defined(__dsPIC33FJ64GP710__) || defined(__dsPIC33FJ128GP206__) || defined(__dsPIC33FJ128GP306__) || \
	defined(__dsPIC33FJ128GP310__) || defined(__dsPIC33FJ128GP706__) || defined(__dsPIC33FJ128GP708__) || defined(__dsPIC33FJ128GP710__) || \
	defined(__dsPIC33FJ256GP506__) || defined(__dsPIC33FJ256GP510__) || defined(__dsPIC33FJ256GP710__) || defined(__dsPIC33FJ64MC506__) || \
	defined(__dsPIC33FJ64MC508__) || defined(__dsPIC33FJ64MC510__) || defined(__dsPIC33FJ64MC706__) || defined(__dsPIC33FJ64MC710__) || \
	defined(__dsPIC33FJ128MC506__) || defined(__dsPIC33FJ128MC510__) || defined(__dsPIC33FJ128MC706__) || defined(__dsPIC33FJ128MC708__) ||\
	defined(__dsPIC33FJ128MC710__) || defined(__dsPIC33FJ256MC510__) || defined(__dsPIC33FJ256MC710__) 

#include <p33Fxxxx.h>

#elif defined(__PIC24HJ64GP206__) || defined(__PIC24HJ64GP210__) || defined(__PIC24HJ64GP506__) || defined(__PIC24HJ64GP510__) || \
	defined(__PIC24HJ128GP206__) || defined(__PIC24HJ128GP210__) || defined(__PIC24HJ128GP506__) || defined(__PIC24HJ128GP510__) || \
	defined(__PIC24HJ128GP306__) || defined(__PIC24HJ128GP310__) || defined(__PIC24HJ256GP206__) || defined(__PIC24HJ256GP210__) || \
	defined(__PIC24HJ256GP610__)
#include <p24Hxxxx.h>

#endif

#include "adc.h"

#if defined(__dsPIC33FJ64GP706__) || defined(__dsPIC33FJ64GP708__) ||defined(__dsPIC33FJ64GP710__) ||\
defined(__dsPIC33FJ128GP706__) ||defined(__dsPIC33FJ128GP708__) ||defined(__dsPIC33FJ128GP710__) ||\
defined(__dsPIC33FJ256GP710__) ||defined(__dsPIC33FJ64MC706__) ||defined(__dsPIC33FJ64MC710__) ||\
defined(__dsPIC33FJ128MC706__) ||defined(__dsPIC33FJ128MC708__) ||defined(__dsPIC33FJ128MC710__) ||\
defined(__dsPIC33FJ256MC710__) ||defined(__PIC24HJ256GP610__)

/*********************************************************************
* Function Name     : OpenADC12
* Description       : This function configures the ADC. This includes :
                    � Operating mode         // ADCON1<15> ADON bit
                    � Data o/p format        // ADCON1<9:8> FORM bits
                    � Sample Clk Source      // ADCON1<7:5> SSRC<2:0>bits
                    � Vref source            // ADCON2<15:13> VCFG<2:0> bits
                    � No of samples/int      // ADCON2<4:2> SMPI<2:0>bits
                    � Buffer fill mode       // ADCON2<1> BUFM bit
                    � Alternate i/p sample mode // ADCON2<0> ALTS
                    � Auto sample time       //ADCON3<12:8> SAMC<4:0>bits
                    � Conv clock source      //ADCON3<6> ADRC
                    � Conv clock select bits //ADCON3<5:0> ADCS<5:0>
                    � Port config control bits.
		    . Select number of DMA buffer locations per analog input // AD1CON4
* Parameters        : config1, config2, config3, configscan,configport
* Return Value      : None
*********************************************************************/

void OpenADC2(unsigned int config1, unsigned int config2, unsigned int
               config3,unsigned int config4, unsigned int configport_l,
		 unsigned int configport_h, unsigned int configscan_h,
		unsigned int configscan_l)
{
    /* digital/analog mode selection on the port bits */
//    AD2PCFGH = configport_h;
    AD2PCFGL = configport_l;
 

    /* configures the input scan selection bits */
//    AD2CSSH = configscan_h;
    AD2CSSL = configscan_l;


    /* config AD1CON4 */
    AD2CON4 =  config4;	

    /* config AD1CON3 */
    AD2CON3 = config3;
    
    /* config AD1CON2 */
    AD2CON2 = config2;

    /* config AD1CON1 */
    AD2CON1 = config1;

    /* assign SAMP bit */
    AD2CON1bits.SAMP = config1 >> 1;
}

#endif
