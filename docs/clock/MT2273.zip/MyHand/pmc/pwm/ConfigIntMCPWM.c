#if defined(__dsPIC30F2010__) || defined(__dsPIC30F2011__) || defined(__dsPIC30F2012__) || defined(__dsPIC30F3010__) || \
    defined(__dsPIC30F3011__) || defined(__dsPIC30F3012__) || defined(__dsPIC30F3013__) || defined(__dsPIC30F3014__) || \
    defined(__dsPIC30F4011__) || defined(__dsPIC30F4012__) || defined(__dsPIC30F4013__) || defined(__dsPIC30F5011__) || \
    defined(__dsPIC30F5013__) || defined(__dsPIC30F5015__) || defined(__dsPIC30F5016__) || defined(__dsPIC30F6010__) || \
    defined(__dsPIC30F6010A__) || defined(__dsPIC30F6011__) || defined(__dsPIC30F6011A__) || defined(__dsPIC30F6012__) || \
    defined(__dsPIC30F6012A__) || defined(__dsPIC30F6013__) || defined(__dsPIC30F6013A__) || defined(__dsPIC30F6014__) || \
    defined(__dsPIC30F6014A__) || defined(__dsPIC30F6015__)
 
#include <p30fxxxx.h>

#elif defined(__dsPIC33FJ64GP206__) || defined(__dsPIC33FJ64GP306__) || defined(__dsPIC33FJ64GP310__) || defined(__dsPIC33FJ64GP706__) || \
	defined(__dsPIC33FJ64GP708__) || defined(__dsPIC33FJ64GP710__) || defined(__dsPIC33FJ128GP206__) || defined(__dsPIC33FJ128GP306__) || \
	defined(__dsPIC33FJ128GP310__) || defined(__dsPIC33FJ128GP706__) || defined(__dsPIC33FJ128GP708__) || defined(__dsPIC33FJ128GP710__) || \
	defined(__dsPIC33FJ256GP506__) || defined(__dsPIC33FJ256GP510__) || defined(__dsPIC33FJ256GP710__) || defined(__dsPIC33FJ64MC506__) || \
	defined(__dsPIC33FJ64MC508__) || defined(__dsPIC33FJ64MC510__) || defined(__dsPIC33FJ64MC706__) || defined(__dsPIC33FJ64MC710__) || \
	defined(__dsPIC33FJ128MC506__) || defined(__dsPIC33FJ128MC510__) || defined(__dsPIC33FJ128MC706__) || defined(__dsPIC33FJ128MC708__) ||\
	defined(__dsPIC33FJ128MC710__) || defined(__dsPIC33FJ256MC510__) || defined(__dsPIC33FJ256MC710__)

#include <p33Fxxxx.h>

#elif defined(__PIC24HJ64GP206__) || defined(__PIC24HJ64GP210__) || defined(__PIC24HJ64GP506__) || defined(__PIC24HJ64GP510__) || \
	defined(__PIC24HJ128GP206__) || defined(__PIC24HJ128GP210__) || defined(__PIC24HJ128GP506__) || defined(__PIC24HJ128GP510__) || \
	defined(__PIC24HJ128GP306__) || defined(__PIC24HJ128GP310__) || defined(__PIC24HJ256GP206__) || defined(__PIC24HJ256GP210__) || \
	defined(__PIC24HJ256GP610__)

#include <p24Hxxxx.h>

#endif
#include <pwm.h>


/* PWM1-3 are defined in following devices */
/* PWM1-4 are defined in 33F MC family devices. */
#if defined(__dsPIC30F2010__) || defined(__dsPIC30F3010__) || defined(__dsPIC30F4012__) || \
    defined(__dsPIC30F3011__) || defined(__dsPIC30F4011__) || defined(__dsPIC30F6010__) || \
    defined(__dsPIC30F5015__) || defined(__dsPIC30F6010A__) || \
    defined(__dsPIC30F5016__) || defined(__dsPIC30F6015__) || \
	defined(__dsPIC33FJ64MC506__) || defined(__dsPIC33FJ64MC508__) || defined(__dsPIC33FJ64MC510__) || \
    defined(__dsPIC33FJ64MC706__) || defined(__dsPIC33FJ64MC710__) || defined(__dsPIC33FJ128MC506__) || \
    defined(__dsPIC33FJ128MC510__) || defined(__dsPIC33FJ128MC706__) || defined(__dsPIC33FJ128MC708__) || \
    defined(__dsPIC33FJ128MC710__) || defined(__dsPIC33FJ256MC510__) || defined(__dsPIC33FJ256MC710__) 

/**********************************************************************
* Function Name     :ConfigIntMCPWM
* Description       :This function Enable/Disable interrupts and 
*                    sets Interrupt priority for period match, 
*                    FaultA and FaultB.  
* Parameters        :unsigned int Config
* Return Value      :None 
**********************************************************************/

void ConfigIntMCPWM(unsigned int config)
{


#if defined(__dsPIC33FJ64MC506__) || defined(__dsPIC33FJ64MC508__) || defined(__dsPIC33FJ64MC510__) || \
    defined(__dsPIC33FJ64MC706__) || defined(__dsPIC33FJ64MC710__) || defined(__dsPIC33FJ128MC506__) || \
    defined(__dsPIC33FJ128MC510__) || defined(__dsPIC33FJ128MC706__) || defined(__dsPIC33FJ128MC708__) || \
    defined(__dsPIC33FJ128MC710__) || defined(__dsPIC33FJ256MC510__) || defined(__dsPIC33FJ256MC710__)

    /* clear the Interrupt flags */
    IFS3bits.PWMIF = 0;	
    IFS3bits.FLTAIF = 0;	

    /* Set priority for the period match */
    IPC14bits.PWMIP      = (0x0007 & config);

    /* Set priority for the Fault A */
    IPC15bits.FLTAIP    = (0x0070 & config)>> 4;

    /* enable /disable of interrupt Period match */
    IEC3bits.PWMIE      = (0x0008 & config) >> 3;

    /* enable /disable of interrupt Fault A.*/
    IEC3bits.FLTAIE     = (0x0080 & config) >> 7;

#else

	/* clear the Interrupt flags */
    IFS2bits.PWMIF = 0;	
    IFS2bits.FLTAIF = 0;	

    /* Set priority for the period match */
    IPC9bits.PWMIP      = (0x0007 & config);

    /* Set priority for the Fault A */
    IPC10bits.FLTAIP    = (0x0070 & config)>> 4;

    /* enable /disable of interrupt Period match */
    IEC2bits.PWMIE      = (0x0008 & config) >> 3;

    /* enable /disable of interrupt Fault A.*/
    IEC2bits.FLTAIE     = (0x0080 & config) >> 7;

#endif

#if defined(__dsPIC33FJ64MC506__) || defined(__dsPIC33FJ64MC508__) || defined(__dsPIC33FJ64MC510__) || \
    defined(__dsPIC33FJ64MC706__) || defined(__dsPIC33FJ64MC710__) || defined(__dsPIC33FJ128MC506__) || \
    defined(__dsPIC33FJ128MC510__) || defined(__dsPIC33FJ128MC706__) || defined(__dsPIC33FJ128MC708__) || \
    defined(__dsPIC33FJ128MC710__) || defined(__dsPIC33FJ256MC510__) || defined(__dsPIC33FJ256MC710__)

 /* clear the Interrupt flags */
    IFS4bits.FLTBIF = 0;	

    /* Set priority for the Fault B */
    IPC16bits.FLTBIP    = (0x0700 & config)>>8;

    /* enable /disable of interrupt Fault B.*/
    IEC4bits.FLTBIE     = (0x0800 & config) >> 11;

#elif defined(__dsPIC30F6010__) || defined(__dsPIC30F5015__) || defined(__dsPIC30F6010A__) || \
    defined (__dsPIC30F5016__) || defined (__dsPIC30F6015__) 
    /* clear the Interrupt flags */
    IFS2bits.FLTBIF = 0;	

    /* Set priority for the Fault B */
    IPC11bits.FLTBIP    = (0x0700 & config)>>8;

    /* enable /disable of interrupt Fault B.*/
    IEC2bits.FLTBIE     = (0x0800 & config) >> 11;

#endif

}

#endif
