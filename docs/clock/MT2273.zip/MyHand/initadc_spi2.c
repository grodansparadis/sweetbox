/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Author            Date      Comments on this revision
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Nghia Tran        09/19/07    Original Release
* Vincent Dinh      09/19/07    Original Release
* Tu Anh            09/19/07    Original Release
* Hoa Phan          09/19/07    Original Release
***********************************************************************/

#if defined(__dsPIC33F__)
#include "p33fxxxx.h"
#elif defined(__PIC24H__)
#include "p24hxxxx.h"
#endif

#include "h\initadc_spi2.h"
#include "h\adcDrv1.h"
#include "spi2.h"
#include "outcompare.h"
#include "timer.h"
//#include 


#define TRUE	1
#define FALSE	0

#define Fcy					16000000
//#define PRESCALER			0x11		//11 is for 1:256
//#define PRESCALER			0x10		//10 is for 1:64
//#define PRESCALER			0x01		//01 is for 1:8
#define PRESCALER			0x00		//00 is for 1:1

#define OC1					799
#define OC2					636
#define OC3					477
#define OC4					318
#define OC5					159					

void InitPorts(void);
void FingerMotorOn(void);
void OnTimer2(void);

void InitADC1andSPI2(void)
{

// Peripheral Initialisation used timer #3 for ADC
   	initAdc1();             	// Initialize ADC
	//initTmr3();				    // Initialise TIMER 3

//Timer 0
	
	

// SPI init with No DMA
    SPI2Init();
	InitPorts();


	//OnTimer3();

	//Init timer 2
//	T2CON = 0x0000;
//	T2CONbits.TCKPS = PRESCALER;
	//PR2 = OC1;
	//FingerMotorOn();
	OpenTimer2(0x8010,99);

	//Configure OC1, OC2..OC5 default values
	OpenOC1(0x0006,0,0);
	OpenOC2(0x0006,0,0);
	OpenOC3(0x0006,0,0);
	OpenOC4(0x0006,0,0);
	//OpenOC5(0x0006,0,0);
//	SetDCOC1PWM(90);
//	SetDCOC2PWM(85);
//	SetDCOC3PWM(85);
//	SetDCOC4PWM(98);
	//SetDCOC5PWM(600);
	//SetPulseOC1(100, 300);

	
}

/*=============================================================================  
Timer 2 is setup to time-out every 50 microseconds (20Khz Rate). As a result, the module
will turn specific motors on every Timer2 time-out, i.e., Ts=50us.
Each motor will be on for Ts/5 = 50us /5 = 10us
=============================================================================*/
void initTimer2() 
{
        TMR2 = 0x0000;
        PR2 = 799;
        IFS0bits.T2IF = 0;
        IEC0bits.T2IE = 0;
		//OpenTimer2(0x8010,39999);
}

void OnTimer2()
{
        initTimer2();
		//Start Timer 2		
        T2CONbits.TON = 1;
}

void OffTimer2() 
{
		initTimer2();
        //Start Timer 2
        T2CONbits.TON = 0;
}

void LoadOC1(unsigned int value_R, unsigned int value_RS)
{
	    OC1CONbits.OCM = 0;		/* turn off OC before switching to new mode */
    	OC1RS = value_RS;   	/* assign value1 to OCxRS Secondary Register */
    	OC1R = value_R;			/* assign value2 to OCxR Main Register*/
		OC1CONbits.OCM = 1;		/* turn on OC */
}

void LoadOC2(unsigned int value_R, unsigned int value_RS)
{
	    OC2CONbits.OCM = 0; /* turn off OC before switching to new mode */
    	OC2RS = value_RS;     /* assign value1 to OCxRS Secondary Register */
    	OC2R = value_R;      /* assign value2 to OCxR Main Register*/
		OC2CONbits.OCM = 1;		/* turn on OC */	
}
void LoadOC3(unsigned int value_R, unsigned int value_RS)
{
	    OC3CONbits.OCM = 0; /* turn off OC before switching to new mode */
    	OC3RS = value_RS;     /* assign value1 to OCxRS Secondary Register */
    	OC3R = value_R;      /* assign value2 to OCxR Main Register*/
		OC3CONbits.OCM = 1;		/* turn on OC */	
}
void LoadOC4(unsigned int value_R, unsigned int value_RS)
{
	    OC4CONbits.OCM = 0; /* turn off OC before switching to new mode */
    	OC4RS = value_RS;     /* assign value1 to OCxRS Secondary Register */
    	OC4R = value_R;      /* assign value2 to OCxR Main Register*/	
		OC4CONbits.OCM = 1;		/* turn on OC */
}
void LoadOC5(unsigned int value_R, unsigned int value_RS)
{
	    OC5CONbits.OCM = 0; /* turn off OC before switching to new mode */
    	OC5RS = value_RS;     /* assign value1 to OCxRS Secondary Register */
    	OC5R = value_R;      /* assign value2 to OCxR Main Register*/	
		OC5CONbits.OCM = 1;		/* turn on OC */
}

void FingerMotorOn(void)
{
	OC1CONbits.OCM = 1; /* turn on OC before switching to new mode */
	OC2CONbits.OCM = 1; /* turn on OC before switching to new mode */
	OC3CONbits.OCM = 1; /* turn on OC before switching to new mode */
	OC4CONbits.OCM = 1; /* turn on OC before switching to new mode */
	OC5CONbits.OCM = 1; /* turn on OC before switching to new mode */
}

void InitPorts()
{
	
	//TRISG = 0x0080; // RG9 as CS for EEPROM
	
	//TRISD = 0x0000;	//
	TRISAbits.TRISA1 = 0;
	TRISGbits.TRISG9 = 0;
}
