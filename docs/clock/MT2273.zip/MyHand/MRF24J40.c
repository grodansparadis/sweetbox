#include "MRF24J40.h"
#include "generic.h"
#include "Console.h"
#include "Compiler.h"
#include "spi.h"
//#include "stdio.h"

BYTE update_data_buffer[2] ;
int bVibrate;
int bTap;

void MRF24J40Init(void)
{
	//BYTE ii;
	unsigned int jj;
	int RESETn;

	/* place the device in hardware reset */
	RESETn = 0;
	for(jj  = 0; jj < (WORD)300; jj++){}

	/* remove the device from hardware reset */
	RESETn = 1;
	for(jj  = 0; jj < (WORD)300; jj++){}

	/* reset the RF module */
	SetShortRAMAddr(RFCTL, 0x04);
	/* remove the RF module reom reset */
	SetShortRAMAddr(RFCTL,0x00);

	/* flush the RX fifo */
	SetShortRAMAddr(RXFLUSH, 0x01); 

	/* Program the short MAC Address, 0xffff */
	SetShortRAMAddr(SADRL,0xFF);
	SetShortRAMAddr(SADRH,0xFF);
	SetShortRAMAddr(PANIDL,0xFF);
	SetShortRAMAddr(PANIDH,0xFF);

	/* Program Long MAC Address, 0xFFFFFFFFFFFFFFFF*/
    SetShortRAMAddr(EADR0, MAC_LONG_ADDR_BYTE0);
    SetShortRAMAddr(EADR1, MAC_LONG_ADDR_BYTE1);
    SetShortRAMAddr(EADR2, MAC_LONG_ADDR_BYTE2);
    SetShortRAMAddr(EADR3, MAC_LONG_ADDR_BYTE3);
    SetShortRAMAddr(EADR4, MAC_LONG_ADDR_BYTE4);
    SetShortRAMAddr(EADR5, MAC_LONG_ADDR_BYTE5);
    SetShortRAMAddr(EADR6, MAC_LONG_ADDR_BYTE6);
    SetShortRAMAddr(EADR7, MAC_LONG_ADDR_BYTE7);

	/* enable the RF-PLL */
	SetLongRAMAddr(RFCTRL2,0x80);

	/* set TX for max output power */
	SetLongRAMAddr(RFCTRL3,0x00);     // 0dB

	/* enable TX filter control */
	SetLongRAMAddr(RFCTRL6, 0x80);

	SetLongRAMAddr(RFCTRL8, 0b00010000);  //bit 4:Enhanced VCO(recommended) and bit 0:stabilize CLKOUT after a wake from sleep

	/* Program CCa mode using RSSI*/
	SetShortRAMAddr(BBREG2,0x78);  //CCA Mode 1, carrier sense only
	/* Enable the packet RSSI */
	SetShortRAMAddr(BBREG6,0x40);	//Cal RSSI for rx packet

	/* Program CCA, RSSI threshold values*/
	SetShortRAMAddr(RSSITHCCA,0x00);

	SetLongRAMAddr(RFCTRL0, 0x00); //channel 11
	
	//ta new add
	/* Receive filters  */
	SetShortRAMAddr(RXMCR,0x04);	// Set as coordinator 

	SetShortRAMAddr(RFCTL, 0x040); // reset the RF modle with new settings
	SetShortRAMAddr(RFCTL, 0x00); 
	
}

void SetLongRAMAddr(WORD address, BYTE value)
{
   	PHY_CS = 0;
  	SPIPut((((BYTE)(address>>3))&0b01111111)|0x80);
   	 SPIPut((((BYTE)(address<<5))&0b11100000)|0x10);
    	SPIPut(value);
    	PHY_CS = 1;			//PORTGbits.RG3 = 1;
}

void SetShortRAMAddr(BYTE address, BYTE value)
{
  	PHY_CS = 0;
  	SPIPut(((address<<1)&0b01111111)|0x01);
    	SPIPut(value);
    	PHY_CS = 1;
}

BYTE GetShortRAMAddr(BYTE address)
{
	BYTE toReturn;
	
   	PHY_CS = 0;
  	SPIPut((address<<1)&0b01111110);
    	toReturn = SPIGet();
    	PHY_CS = 1;
    
    return toReturn;
}

BYTE GetLongRAMAddr(WORD address)
{	
    	BYTE toReturn;

	PHY_CS = 0;//PORTGbits.RG3 = 0;//PHY_CS = 0;		
	SPIPut(((address>>3)&0b01111111)|0x80);		
	SPIPut(((address<<5)&0b11100000));
	toReturn = SPIGet();
	PHY_CS = 1;   
	
    	return toReturn;
}

void SetUpACKpackage(BYTE sequenceNumber)  // send ACK back to other side if this device is the vibrate one 
{
	SetLongRAMAddr ((WORD)NORMAL_TX_FIFO, 0x00);//header length 
	SetLongRAMAddr ((WORD)(NORMAL_TX_FIFO+1), 0x06);//packet length (2 bytes of frame control,
												  // 1 byte of sequence number, 1 bytes for ACK and
												  // 2 bytes of FCS
	SetLongRAMAddr ((WORD)(NORMAL_TX_FIFO+2), FRAME_ACK_MSB); //frame control MSB - user define this packet as a data packet
	SetLongRAMAddr ((WORD)(NORMAL_TX_FIFO+3), FRAME_ACK_LSB); //frame control LSB 
	SetLongRAMAddr ((WORD)(NORMAL_TX_FIFO+4), sequenceNumber); //sequence number 
	// data
	SetLongRAMAddr ((WORD)(NORMAL_TX_FIFO+5), ACK); // first byte of data
}	

void SetUpDataPackage(BYTE data1, BYTE data2)
{
	BYTE buffer[60];
	static BYTE sequenceNumber;
	sequenceNumber++;
	
	if(sequenceNumber > 254) 
		sequenceNumber = 0;
		
	 sprintf( (char *)buffer, (ROM char *) "THIS PACKET'S SEQUENCE NUMBER is %02x \r\n\0",sequenceNumber );
		ConsolePutString( buffer );	
		
	SetLongRAMAddr ((WORD)NORMAL_TX_FIFO, 0x00);//header length 
	SetLongRAMAddr ((WORD)(NORMAL_TX_FIFO+1), 0x07);//packet length (2 bytes of frame control,
												  // 1 byte of sequence number, 2 bytes of data and
												  // 2 bytes of FCS
	SetLongRAMAddr ((WORD)(NORMAL_TX_FIFO+2), FRAME_DATA_MSB);//frame control MSB - user define this packet as a data packet
	SetLongRAMAddr ((WORD)(NORMAL_TX_FIFO+3), FRAME_DATA_LSB);//frame control LSB 
	SetLongRAMAddr ((WORD)(NORMAL_TX_FIFO+4), sequenceNumber);//sequence number 
	// data
	SetLongRAMAddr ((WORD)(NORMAL_TX_FIFO+5),data1); // first byte of data
	SetLongRAMAddr ((WORD)(NORMAL_TX_FIFO+6), data2); // second byte of data
}

void SendPackage(void)
{
	SetShortRAMAddr (TXNMTRIG,0x01);	// transmit trigger 
}

void ReceivedPackage(void)
{
	int ii;
	BYTE local_data[10];
	WORD beginPackage;
	int seqNo;
	
	beginPackage = 0x300;
	
	// check if there is data to receive
	if( GetLongRAMAddr ((WORD)(0x300 + ii)) != 0)  // have data
	{
		// get/read packet
		for(ii = 0;ii <8; ii++)
		{
			local_data[beginPackage+ii] = GetLongRAMAddr(beginPackage+ii);
		}
		// decode packet here
		if( (local_data[300] == 0x06)  && ( local_data[302] ==  FRAME_ACK_LSB ) )   // if ACK package length is 6 and frame ack controll 
		{
			// this is ACK packet
			ConsolePutROMString( (ROM char *)"Received ACK packet\r\n\r\n" );
		}
		if( (local_data[300] == 0x07)  && ( local_data[302] ==  FRAME_DATA_LSB  ) ) 
		{
			 update_data_buffer[0] = local_data[304]; 	
			 update_data_buffer[1] = local_data[305];
			 bVibrate = 1;  
			 bTap = 0;
			 seqNo = local_data[303];
			 SetUpACKpackage(seqNo);
			 SendPackage();
		}
	}else{
			ConsolePutROMString( (ROM char *)"No Data to receive\r\n\r\n" );
	}
}

 