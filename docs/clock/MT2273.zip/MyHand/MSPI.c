/*********************************************************************
 *
 *                  Master SPI routintes
 *
 *********************************************************************
 * FileName:        MSPI.c
 * Dependencies:
 * Processor:       PIC18 / PIC24 / dsPIC33
 * Complier:        MCC18 v1.00.50 or higher
 *                  MCC30 v2.05 or higher
 * Company:         Microchip Technology, Inc.
 *
 * Software License Agreement
 *
 * The software supplied herewith by Microchip Technology Incorporated
 * (the �Company�) for its PICmicro� Microcontroller is intended and
 * supplied to you, the Company�s customer, for use solely and
 * exclusively on Microchip PICmicro Microcontroller products. The
 * software is owned by the Company and/or its supplier, and is
 * protected under applicable copyright laws. All rights are reserved.
 * Any use in violation of the foregoing restrictions may subject the
 * user to criminal sanctions under applicable laws, as well as to
 * civil liability for the breach of the terms and conditions of this
 * license.
 *
 * THIS SOFTWARE IS PROVIDED IN AN �AS IS� CONDITION. NO WARRANTIES,
 * WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT NOT LIMITED
 * TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. THE COMPANY SHALL NOT,
 * IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL OR
 * CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
 *
 *
 * Author               Date    Comment
 *~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * Nilesh Rajbharti     7/12/04 Original
 * Nilesh Rajbharti     11/1/04 Pre-release version
 * DF/KO                04/29/05 Microchip ZigBee Stack v1.0-2.0
 * DF/KO                07/18/05 Microchip ZigBee Stack v1.0-3.0
 * DF/KO                07/27/05 Microchip ZigBee Stack v1.0-3.1
 * DF/KO                01/09/06 Microchip ZigBee Stack v1.0-3.5
 * DF/KO                08/31/06 Microchip ZigBee Stack v1.0-3.6
 * DF/KO/YY             11/27/06 Microchip ZigBee Stack v1.0-3.7
 * DF/KO/YY				01/12/07 Microchip ZigBee Stack v1.0-3.8
 * DF/KO/YY             02/26/07 Microchip ZigBee Stack v1.0-3.8.1
 ********************************************************************/
#include "MSPI.h"
#include "Zigbee.def"
#include "Compiler.h"

#if defined(__dsPIC33F__) || defined(__PIC24F__) || defined(__PIC24H__)

//ta
void InitSPI(void)
{
	/* Following code snippet shows SPI register configuration for MASTER mode */

	IFS0bits.SPI1IF = 0; //Clear the Interrupt Flag
	IEC0bits.SPI1IE = 0; //disable the Interrupt
		                // SPI1CON1 Register Settings
	SPI1CON1bits.DISSCK = 0; //Internal Serial Clock is Enabled.
	SPI1CON1bits.DISSDO = 0; //SDOx pin is controlled by the module.
	SPI1CON1bits.MODE16 = 1; //Communication is word-wide (16 bits).
	SPI1CON1bits.SMP = 0; //Input Data is sampled at the middle of data output time.
	SPI1CON1bits.CKE = 0; //Serial output data changes on transition from
	//Idle clock state to active clock state
	SPI1CON1bits.CKP = 0; //Idle state for clock is a low level;
	//active state is a high level
	SPI1CON1bits.MSTEN = 1; //Master Mode Enabled  - 0 for SPI configuration as  slave mode
	SPI1STATbits.SPIEN = 1; //Enable SPI Module
	SPI1BUF = 0x0000; //Write data to be transmitted
	//Interrupt Controller Settings
	IFS0bits.SPI1IF = 0; //Clear the Interrupt Flag
	IEC0bits.SPI1IE = 1; //Enable the Interrupt

	//SPI1CON1 = 0b0000000100111110;
    SPI1STAT = 0x8000;

}

/*****************************************************************************
*     Function Name :  putsSPI1                                              *
*     Description   :  This function writes the specified length of data     *
*                      word/byte to be transmitted into the transmit buffer  *
*     Parameters    :  unsigned int: length of bytes/words to be written     *
*                      unsigned int*:  Address ofthe location where the data *
*                      to be transmitted is stored                           *
*     Return Value  :  None                                                  *                                                                
*****************************************************************************/
void putsSPI1(unsigned int length, unsigned int *wrptr)
{  
    char *temp_ptr = (char *) wrptr;
    while (length)                   /* write byte/word until length is 0 */
    {            
        if(SPI1CON1bits.MODE16)
            SPI1BUF = *wrptr++;      /* initiate SPI bus cycle by word write */ 
        else
            SPI1BUF = *temp_ptr++;   /* initiate SPI bus cycle by byte write */ 
        while(SPI1STATbits.SPITBF);  /* wait until 'SPITBF' bit is cleared */
        length--;                    /* decrement length */
    }
}



/****************************************************************************
*     Function Name :  getsSPI1                                             *
*     Description   :  This routine reads a string from the SPI             *
*                      receive buffer.The number of byte/word to be read    *
*                      is determined by parameter 'length'                  *
*     Parameters    :  unsigned int length: The length of data expected     *
*                      unsigned int *rdptr   the received data to be        *
*                      recorded to this array                               *  
*                      unsigned int uart_data_wait timeout value            *
*     Return Value  :  unsigned int number of data bytes yet to be received *                     
****************************************************************************/

unsigned int getsSPI1(unsigned int length, unsigned int *rdptr, unsigned int spi_data_wait)
{
    int wait = 0;
    char *temp_ptr = (char *)rdptr;
    while (length)                     /* stay in loop until length = 0  */
    {
        while(!SPI1STATbits.SPIRBF) // DataRdySPI1() ->return SPI1STATbits.SPIRBF
        {

           if(wait < spi_data_wait)
               wait++ ;                /* wait for time out operation */
           else
               return(length);         /*Time out, return number of byte/word to be read */
        }
        wait = 0;
        
        if(SPI1CON1bits.MODE16)
            *rdptr++ = getcSPI1();     /* read a single word */
        else
            *temp_ptr++ = getcSPI1();  /* read a single byte */
        length--;                      /* reduce string length count by 1*/
    }
    return (length);                   /* return number of byte/word to be read i.e, 0 */
}

void SPIPut(BYTE v)	//void RF_SPIPut(BYTE v)	//void write_SPI(short command)
{	
	short temp;	

	PORTGbits.RG3 = 0;		// lower the slave select line
	temp = SPI1BUF;			// dummy read of the SPI1BUF register to clear the SPIRBF flag
	SPI1BUF = v;		// write the data out to the SPI peripheral
    while (!SPI1STATbits.SPIRBF)	// wait for the data to be sent out
		;
	PORTGbits.RG3 = 1;		// raise the slave select line
	
}


/******************************************************************************
*     Function Name :   ReadSPI1                                              *
*     Description   :   This function will read single byte/ word  from SPI   *
*                       bus. If SPI is configured for byte  communication     *
*                       then upper byte of SPIBUF is masked.                  *         
*     Parameters    :   None                                                  *
*     Return Value  :   contents of SPIBUF register                           *
******************************************************************************/

BYTE SPIGet(void) //    ReadSPI1T
{
	 /* Check for Receive buffer full status bit of status register*/
    if (SPI1STATbits.SPIRBF)
    { 
        SPI1STATbits.SPIROV = 0;
                
        if (SPI1CON1bits.MODE16)
            return (SPI1BUF);           /* return word read */
        else
            return (SPI1BUF & 0xff);    /* return byte read */
    }
    return -1;                  		/* RBF bit is not set return error*/
}

/*
	void RF_SPIPut(BYTE v)
	{
    	BYTE dummy;
    
	    RF_SSPIF_BIT = 0;
    	dummy = SPI1BUF;
	    RF_SSPBUF_REG = v;
        while(RF_SSPIF_BIT == 0) {}
	}

	BYTE RF_SPIGet(void)
	{
    	RF_SPIPut(0x00);
	    return RF_SSPBUF_REG; 
	}

	void EE_SPIPut(BYTE v)
	{
		BYTE dummy;

		EE_SSPIF_BIT = 0;
		dummy = EE_SSPBUF_REG; 
		EE_SSPBUF_REG = v;
		while(EE_SSPIF_BIT == 0 );
	}

	BYTE EE_SPIGet(void)
	{
		EE_SPIPut(0x00);
		return EE_SSPBUF_REG; 
	}

#elif defined(__18CXX)


	#if defined(USE_EXTERNAL_NVM) && !defined(EE_AND_RF_SHARE_SPI)

    	void RF_SPIPut(BYTE v)
	    {
    	    RF_SSPIF_BIT = 0;

        	do
        	{
            	RF_WCOL_BIT = 0;
	            RF_SSPBUF_REG = v;
    	    }
        	while (RF_WCOL_BIT);
	        while(RF_SSPIF_BIT == 0){}
    	}

	    BYTE RF_SPIGet(void)
    	{
        	RF_SPIPut(0x00);
	        return RF_SSPBUF_REG;
    	}


	    void EE_SPIPut(BYTE v)
    	{
        	EE_SSPIF_BIT = 0;

	        do
    	    {
        	    EE_WCOL_BIT = 0;
            	EE_SSPBUF_REG = v;
	        }
    	    while (EE_WCOL_BIT);
        	while(EE_SSPIF_BIT == 0){}
	    }

    	BYTE EE_SPIGet(void)
	    {
    	    EE_SPIPut(0x00);
        	return EE_SSPBUF_REG;
	    }

	#else


        void SPIPut(BYTE v)
        {
            SSPIF_BIT = 0;
    
            do
            {
                WCOL_BIT = 0;
                SSPBUF_REG = v;
            }
            while (WCOL_BIT);
            while(SSPIF_BIT == 0){}
        }
    
        BYTE SPIGet(void)
        {
            SPIPut(0x00);
            return SSPBUF_REG;
        }

		// The ZMD44101 requires SS to be driven high between reading bytes,
		// so these functions are not used and should not be compiled.
		#if !defined(USE_ZMD44101)
			void SPIGetArray(BYTE *buffer, BYTE len)
			{
			    while( len-- )
        			*buffer++ = SPIGet();
			}

			void SPIPutArray(BYTE *buffer, BYTE len)
			{
		    	while( len-- )
        			SPIPut(*buffer++);
			}
		#endif
	#endif

#else
    #error Unknown processor.  See Compiler.h


*/

#endif


