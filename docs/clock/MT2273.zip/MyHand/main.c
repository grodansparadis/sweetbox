/*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Author            Date      Comments on this revision
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Nghia Tran        09/19/07    Original Release
* Vincent Dinh      09/19/07    Original Release
* Tu Anh            09/19/07    Original Release
* Hoa Phan          09/19/07    Original Release
***********************************************************************/

#include "p33FJ256MC510.h"

//******************************************************************************
// Header Files
//******************************************************************************

// If you are going to send data to a terminal, include this file.
#include "console.h"

#include "h\adcDrv1.h"
#include "MSPI.h"
#include "h\motor_control.h"

#include "h\spi2.h"
#include "h\initadc_spi2.h"


//******************************************************************************
// Configuration Bits
//******************************************************************************
	_FOSCSEL(FNOSC_PRIPLL)				// primary osc PLL
	_FOSC(OSCIOFNC_OFF & POSCMD_XT)	// XT Osc
	_FWDT(FWDTEN_OFF)				// Disable Watchdog timer

//******************************************************************************
// Compilation Configuration
//******************************************************************************

//#define USE_BINDINGS
//#define I_AM_LIGHT
//#define I_AM_SWITCH

//******************************************************************************
// Constants
//******************************************************************************

#define SWITCH_PRESSED      0

#define LIGHT_SWITCH				PORTDbits.RD6
#define BIND_SWITCH					PORTDbits.RD7
#define BIND_INDICATION				LATAbits.LATA6
#define MESSAGE_INDICATION			LATAbits.LATA7

#define BIND_STATE_BOUND            0
#define BIND_STATE_TOGGLE           1
#define BIND_STATE_UNBOUND          1
#define BIND_WAIT_DURATION          (5*ONE_SECOND)

#define LIGHT_OFF                   0x00
#define LIGHT_ON                    0xFF
#define LIGHT_TOGGLE                0xF0

//define Modes
#define TYPE		1
#define REPLAY		2
#define REMOTE		3
#define EEPROM		4


//******************************************************************************
// Function Prototypes
//******************************************************************************

void HardwareInit( void );

//******************************************************************************
// Application Variables
//******************************************************************************


// All inits are here (e.g. hardwareInit, SPIInit, zPHYInit, zMACInit

int main()
{
	//unsigned int i;
	BYTE KeyCommand = 0;
	
	CLRWDT();
    ENABLE_WDT();

	// Configure Oscillator to operate the device at 16Mhz
	// Fosc= Fin*M/(N1*N2), Fcy=Fosc/2
	// Fosc= 8 MHz * (16 / (2 * 2)) = 32 Mhz

	PLLFBD = 14;            	// Set M=16
	CLKDIVbits.PLLPOST = 0;  	// Set N1=2
	CLKDIVbits.PLLPRE = 0;    	// Set N2=2

/*
	// Disable Watch Dog Timer
	RCONbits.SWDTEN=0;

	// Clock switch to incorporate PLL
	__builtin_write_OSCCONH(0x01);		// Initiate Clock Switch to
													// FRC with PLL (NOSC=0b001)
	__builtin_write_OSCCONL(0x01);		// Start clock switching
	while (OSCCONbits.COSC != 0b001);	// Wait for Clock switch to occur	


	// Wait for PLL to lock
	while(OSCCONbits.LOCK!=1) {};
*/
	// Disable Watch Dog Timer
	RCONbits.SWDTEN=0;
	
    //currentPrimitive = NO_PRIMITIVE;

    // If you are going to send data to a terminal, initialize the UART.
    ConsoleInit();
	//ConsolePut('x');

	//ConsolePutROMString( (ROM char *)"\r\n\r\n\r\n*************************************\r\n" );
    //ConsolePutROMString( (ROM char *)"Microchip ZigBee(TM) Stack - v1.0-3.8.1\r\n\r\n" );
    //ConsolePutROMString( (ROM char *)"ZigBee Coordinator\r\n\r\n" );
    //ConsolePutROMString( (ROM char *)"Transceiver-MRF24J40\r\n\r\n" );


	 // Initialize the hardware - must be done before initializing ZigBee.
    //HardwareInit();

    // Initialize the ZigBee Stack.
    //ZigBeeInit();

	InitADC1andSPI2();
	//ConsoleInit();
	testADC();

//Feature Modes	
	while (1) {
		
		//KeyCommand = GetKeyCommand();
		switch (KeyCommand) {
			case TYPE:
				TypeMode();
				break;
			case REPLAY:
				ReplayMode();
				break;
			case REMOTE:
				RemoteMode();
				break;
			case EEPROM:
				EEPROM_Mode();
				break;
			default:
				break;
		}
	}

	while (1);
	
}


/*******************************************************************************
HardwareInit

All port directioning and SPI must be initialized before calling ZigBeeInit().

For demonstration purposes, required signals are configured individually.
*******************************************************************************/
void HardwareInit(void)
{
    InitSPI();
    
    PHY_RESETn = 0;
    PHY_RESETn_TRIS = 0;
    PHY_CS = 1;
    PHY_CS_TRIS = 0;
    
    TRISAbits.TRISA6 = 0;
    TRISAbits.TRISA7 = 0;
    
    RFIF = 0;
    RFIE = 1;
    
    if(RF_INT_PIN == 0)
    {
        RFIF = 1;
    }
    
    TRISDbits.TRISD6 = 1;
    TRISDbits.TRISD7 = 1;
  
    CNEN1bits.CN15IE = 1;
    CNEN2bits.CN16IE = 1;
    CNPU1bits.CN15PUE = 1;
    CNPU2bits.CN16PUE = 1;
    
    IFS1bits.CNIF = 0;
    IEC1bits.CNIE = 1;


    	   
}

/*******************************************************************************
User Interrupt Handler

The stack uses some interrupts for its internal processing.  Once it is done
checking for its interrupts, the stack calls this function to allow for any
additional interrupt processing.
*******************************************************************************/

void UserInterruptHandler(void)
{
}


