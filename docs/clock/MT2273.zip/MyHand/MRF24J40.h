#include "generic.h"
#include "Console.h"
#include "Compiler.h"


#define PHY_CS LATGbits.LATG3   
#define NORMAL_TX_FIFO  (0x000)	

// define frame control
#define FRAME_DATA_MSB          0b00000000  
#define FRAME_DATA_LSB          0b00000001 
#define FRAME_ACK_MSB           0b00000000 
#define FRAME_ACK_LSB           0b00000010

#define ACK 0x0a



// PIC Information

#define CLOCK_FREQ 16000000
#define BAUD_RATE 19200
#define HEAP_LOCATION 0x0100
#define MAX_HEAP_SIZE 2048

//MRF24J40 short address registers
#define RXMCR (0x00)
#define PANIDL (0x01)
#define PANIDH (0x02)
#define SADRL (0x03)
#define SADRH (0x04)
#define EADR0 (0x05)
#define EADR1 (0x06)
#define EADR2 (0x07)
#define EADR3 (0x08)
#define EADR4 (0x09)
#define EADR5 (0x0a)
#define EADR6 (0x0b)
#define EADR7 (0x0c)
#define RXFLUSH (0x0d)
#define TXNMTRIG (0x1b)
#define TXSR (0x24)
#define RXSR (0x30)//
#define ISRSTS (0x31)
#define INTMSK (0x32)
#define GPIO (0x33)
#define GPIODIR (0x34)
#define RFCTL (0x36)
#define BBREG2 (0x3a)
#define BBREG6 (0x3e)
#define RSSITHCCA (0x3f)

//MRF24J40 long address registers
#define RFCTRL0 (0x200)
#define RFCTRL2 (0x202)
#define RFCTRL3 (0x203)
#define RFCTRL6 (0x206)
#define RFCTRL7 (0x207)
#define RFCTRL8 (0x208)
#define CLKINTCR (0x211)
#define SRCADRMODE (0x212)//
#define CLKCTRL (0x220)


#define WRITE_RXFLUSH (0x0E)

// Device MAC Address

#define MAC_LONG_ADDR_BYTE7 0x00
#define MAC_LONG_ADDR_BYTE6 0x04
#define MAC_LONG_ADDR_BYTE5 0xA3
#define MAC_LONG_ADDR_BYTE4 0x00
#define MAC_LONG_ADDR_BYTE3 0x00
#define MAC_LONG_ADDR_BYTE2 0x00
#define MAC_LONG_ADDR_BYTE1 0x00
#define MAC_LONG_ADDR_BYTE0 0x65

BYTE GetLongRAMAddr(WORD address);
BYTE GetShortRAMAddr(BYTE address);
void SetShortRAMAddr(BYTE address, BYTE value);
void SetLongRAMAddr(WORD address, BYTE value);

void MRF24J40Init();
void SetUpDataPackage(BYTE data1, BYTE data2);
void SendPackage(void);  // Trigger
void SetUpACKpackage(BYTE sequenceNumber);
void ReceivedPackage(void);

extern BYTE update_data_buffer[2] ;
extern int bVibrate;
extern int bTap;




