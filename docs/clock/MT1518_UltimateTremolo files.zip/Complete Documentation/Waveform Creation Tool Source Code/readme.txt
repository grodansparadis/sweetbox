Contest Entrant MT1518 (UltimateTremolo Guitar Effect Processor)
Source code for PC (Waveform Creation software)

Application compiled with Microsoft's Visual Basic .NET (Visual Studio 2005 version)
All files listed below must be in the same directory to build application

To run the application, mcHID.dll must be in either the WINDOWS\SYSTEM32 directory or
in the same directory as the UltimateTremelo.EXE file.

The latest version of the Microsoft .NET Framework also needs to be installed on the
PC running the application if Visual Studio isn't installed on the system.

VB source files had to be renamed with the extension .vb_ from the original .vb extension.
This had to be done to or my e-mail account wouldn't send the files (it considers VB files
executable files, which it won't send)

File					Description
------------------------------------------------------------------------------------------------------------
UltimateTremelo.suo			Visual Studio Solution User Options file
UltimateTremelo.vbproj.user		Visual Studio Project User Options file
UltimateTremelo - Guitar Verison.vbproj	Visual Basic Project file
UltimateTremelo.sln			Microsoft Visual Studio Solution file
UltimateTremelo.exe			Waveform Creation Tool application
AssemblyInfo.vb				Visual Basic Source file
Beautification.vb			"
constants.vb				"
eepromEdit.vb				"
Form1.vb				"
mcHIDInterface.vb			"
MonoWaveEditor.vb			"
OpenPatchFromPedal.vb			"
PedalComm.vb				"
SavePatchToPedal.vb			"
setPhaseShift.vb			"
usbTools.vb				"
waveFileInfo.vb				"
waveformProperties.vb			"
mcHID.dll				Contains USB functions
eepromEdit.resx				.NET Managed Resources file
Form1.resx				"
MonoWaveEditor.resx			"	
OpenPatchFromPedal.resx			"
PedalComm.resx				"
SavePatchToPedal.resx			"
setPhaseShift.resx			"
waveformProperties.resx			"
