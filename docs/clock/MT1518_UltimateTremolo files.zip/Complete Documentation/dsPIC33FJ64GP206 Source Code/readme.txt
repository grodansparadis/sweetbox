Contest Entrant MT1518 (UltimateTremolo Guitar Effect Processor)
Source code for dsPIC33FJ64GP206

Firmware compiled with Microchip's C30 compiler via Microchip's MPLAB development software.
All files listed below must be in the same directory to build firmware.

Building the firmware also requires that the header file "p33FJ64GP206.h" be located in its default
location within the C30 compiler's installation location.

File			Description
------------------------------------------------------------------------------------------------------------
TREMELO.C		Main source file - DSP functions and 18F4455 communications
I2C_FUNC.C		Code for interfacing with I2C EEPROM (copied from Microchip Application Note AN1079)
INIT.C			Chip configuration and initialization code
DSTREMELO.H		Header file
I2C.H			"
INIT.H			"
TREMELO2.MCP		MPLAB project file
DS33TREMELO.MCW		MPLAB workspace file