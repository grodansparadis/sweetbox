/********************************************************************
* File name: init.c		Contest Entrant: MT1518						*
* 																	*
* This file sets up the dsPIC33FJ64GP206 pin I/O and peripherals.   *
********************************************************************/


#include "p33FJ64GP206.h"
#include "dsTremelo.h"

/* Setup I/O pins and initialize peripherals */
void setup (void)
{
	// calibrate PLL settings
	// Fosc = Fin*(M / (N1*N2) ) ==> 8 Mhz * (40 / (2*2)) = 80 Mhz
	// Fcy = Fosc/2 = 40 MHz ==> 40 MIPS
	OSCTUNbits.TUN = 22;		// set FRC oscillator to 8 MHz
	CLKDIVbits.PLLPRE = 0;		// N1 factor = 2
	PLLFBDbits.PLLDIV = 40;		// M factor = 40 for 40 MIPS, or 20 for 20 MIPS
	CLKDIVbits.PLLPOST = 0;		// N2 factor = 2

	// configure the chip's DSP module
	CORCONbits.US = 1;			// set for unsigned DSP multiplications
	CORCONbits.ACCSAT = 1;		// enable super saturation mode for accumulators A and B
	CORCONbits.SATA = 1;
	CORCONbits.SATB = 1;
	CORCONbits.IF = 1;			// set DSP multiplication to integer mode

	AD1PCFGH = 0xFFFF;			// make all analog inputs digital I/O
	AD1PCFGL = 0xFFFF;

	IEC0bits.U1RXIE = 1;	// enable the UART Receive Interrupt
	U1MODE = 0x8000;		// setup UART (8N1 format)
	U1STA = 0x04C0;			// more UART setup
	
	// U1BRG = Fcy / (16*Baud Rate) - 1
	// 40 MIPS => 40000000 / (16*9600) - 1 = 259
	U1BRG = 259;
	
	IC1CON = 0;			// diable input capture 1 module
	IC2CON = 0;			// diable input capture 2 module
	OC1CON = 0;			// disable output compare modules
	OC2CON = 0;
	OC3CON = 0;
	OC4CON = 0;
	SPI1STAT = 0;		// disable SPI module

	T1CON = 0;			// disable timer1
	T2CON = 0;			// disable timer2
	T3CON = 0;			// disable timer3

	CNEN1 = 0;
	CNEN2 = 0;
	
	TRISB = 0;

	TRISFbits.TRISF3 = 1;				// UART1 TX pin
	TRISFbits.TRISF2 = 1;				// UART1 RX pin
	
	TRISCbits.TRISC15 = 0;				// UART receive enabled/disabled output to 18F4455
	uartRxDisabled = 0;					// UART1 is ready to receive data

	TRISGbits.TRISG3 = 1;				// I2C data pin
	TRISGbits.TRISG2 = 1;				// I2C clock pin
}

/**************************************************************
* Initialize the DCI module									  *
* This code was copied from example program "CE016" included  *
* with Microchip's C30 compiler.  Slight modifications were   *
* made to the module's configuration to suit my application.  *
**************************************************************/
void initDCI (void)
{
	DCICON1bits.CSCKD = 1;	/*Serial Bit Clock (CSCK pin) is input	*/
	DCICON1bits.CSCKE = 1;	/*Data changes on falling edge		*/
				/*& sampled on rising edge of CSCK	*/
	DCICON1bits.COFSD = 1;	/*Frame Sync Signal is input		*/
	DCICON1bits.UNFM = 1;	/*If Tx Buffers are not reloaded after	*/
				/*transmission is complete, then 0's are*/
				/*transmitted				*/
	DCICON1bits.CSDOM = 0;	/*CSDO pin is held low during inactive 	*/
				/*time-slots				*/
	DCICON1bits.DJST = 0;	/*Data is transmitted one bit clock	*/
				/*after Frame Sync pulse		*/
	DCICON1bits.COFSM = 1;	/*Frame Sync Signal set up for I2S mode */

/*
DCI Control Register DCICON2 Initialization
*/
/* 
In this section we will set up the frame length for
the operation shown in Figure 1.
*/

	DCICON2bits.BLEN = 3;	// set up to receive 4 words between interrupts
	DCICON2bits.COFSG = 1;	// set up Frame Sync Generator for 1	words per frame
	DCICON2bits.WS = 15;	// set up Word Size to 16 bits

/*
DCI Control Register DCICON3 Initialization
*/
	//DCICON3 = FCY / (2*FCSCK - 1);	/*Set up CSCK Bit Clock Frequency*/

/*
Transmit Slot Control Register Initialization
*/
	TSCONbits.TSE0 = 1;	/*Transmit on Time Slot 0		*/
	TSCONbits.TSE1 = 1;	/*Transmit on Time Slot 1		*/
				/*2 timeslots are enabled to send 32-   */
				/*bit data per channel (left or right)  */

/*
Receiver Slot Control Register Initialization
*/
	RSCONbits.RSE0 = 1;	/*Receive on Time Slot 0		*/
	RSCONbits.RSE1 = 1;	/*Receive on Time Slot 1		*/
				/*2 timeslots are enabled to send 32-   */
				/*bit data per channel (left or right)  */


	_DCIIE = 1;		/*Clear the DCI Interrupt Flag          */
	_DCIIF = 0;		/*Enable DCI ISR processing             */
	DCICON1bits.DCIEN = 1;  /*Enable the DCI module         */
}
