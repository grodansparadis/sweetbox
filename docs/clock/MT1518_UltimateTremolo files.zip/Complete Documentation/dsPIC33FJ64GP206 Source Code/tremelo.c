/********************************************************************
* File name: tremelo.c		Contest Entrant: MT1518					*
* 																	*
* This is the main file for the dsPIC33FJ64GP206 firmware.			*
* Constants and global variables are defined here.  The program     *
* then loops indefinitely with all data processing being triggered  *
* by interrupts from either the DCI module (DSP processing) or the  *
* UART (communications with PIC18F4455).							*
********************************************************************/

#include <p33FJ64GP206.h>
#include "dsTremelo.h"
#include "i2c.h"
#include "init.h"

// constants
#define MIPS 40							// number of MIPS the processor is running at
#define	FSAMPLE 96000					// audio sampling frequency
#define AMPFRACTIONS 800				// number of amplitude fractions available
#define MIN_PERIOD 20					// minimum period length (in milliseconds)
#define TRUE 1							// true and false booleans
#define FALSE 0
#define EEPROM_CONTROL_BYTE 0xA0		// control byte for EEPROM
#define EEPROM_READ_LENGTH 1			// # of bytes to read from EEPROM

// command codes - used to communicate with 18F4455 MCU
#define CHANGE_PATCH 0					// change patch
#define CHANGE_RATE 1					// change modulation rate (period)
#define CHANGE_DEPTH 2					// change modulation depth
#define REVERT_PATCH 3					// revert current patch to original settings
#define SAVE_PATCH_CHANGES 4			// save changes to patch made by the depth and rate knobs
#define SET_DIGITAL_BYPASS_MODE 5		// enable/disable digital bypass mode

// set chip configuration bits
_FGS(GSS_OFF & GWRP_OFF);
_FOSCSEL(FNOSC_FRCPLL & IESO_OFF);
_FOSC(FCKSM_CSDCMD & OSCIOFNC_ON & POSCMD_NONE);
_FWDT(FWDTEN_OFF);



// global variables
unsigned char globalMinAmp;					// minimum amplitude level
unsigned char globalMaxAmp;					// maximum amplitude level
unsigned int globalPeriod;					// waveform period length in milliseconds
unsigned char globalCurrentPatch;			// number of the currently loaded patch (0-24)
unsigned int globalAmpFractions[800];		// holds the 800 16-bit amplitude fractions
unsigned int globalOriginalAmpFractions[800];	// holds the 800 16-bit amplitude fractions - these are referred to when the Depth Knob is changed
unsigned long globalNumAmpFractionUses;		// number of times to use an individual amplitude fraction
unsigned int globalAmpFracCounter;			// keeps track of how many times we've used the current amp fraction
unsigned int globalCurrentAmpFraction;		// index of 'globalAmpFractions' that is currently being used
unsigned char globalIsDigitalBypassModeActive;	// true if incoming signal isn't being processed, false if we're processing the signal

unsigned char globalHasDepthChanged;		// boolean that indicates if the patch's original depth has changed
unsigned char globalHasRateChanged;			// boolean that indicates if the patch's original rate has changed

unsigned char globalIsDepthChanging;		// boolean that indicates if the patch is in the process of changing its depth
unsigned int globalNumAmpFracsChanged;		// when patch depth is being changed, this variable keeps track of how many ampFracs have been changed
unsigned char globalDepthADValue;			// A/D value from the Depth Knob - used in adjusting depth of waveform

unsigned long globalNewPeriod;				// patch period if a change has been made to the Rate knob

/************************************************************************
* main() initializes UART, I2C, and DCI peripherals as well as pin I/O  *
* The function then loops indefinitely, waiting for interrupts from     *
* DCI and UART modules.													*
************************************************************************/
int main (void)
{
	unsigned int i, j;		// used in creating a delay before main program begins

	setup();				// setup I/O pin directions
	initI2C();				// initialize I2C module
	initDCI();				// initialize DCI module


	// initialize counter that keep track of how many times the current ampFrac has been used
	globalAmpFracCounter = 0;

	// initialize index pointer for globalAmpFractions[] array
	globalCurrentAmpFraction = 0;

	// this delay is needed so that false signals aren't read from the USB PIC on start up.
	for(i=0;i<60000;i++){
		for(j=0;j<40;j++){}}

	// loop forever
	while (1){}
}


/********************************************************************
* This interrupt is called when the 18F4455 has a command byte to   *
* send.  The command byte is read and the appropriate function is   *
* called.														 	*
/*******************************************************************/
void __attribute__((__interrupt__)) _U1RXInterrupt(void)
{
	unsigned char command;		// command byte from 18F4455 - tells what action to take
	unsigned char dump;			// used to read unused bytes sent from 18F4455
	unsigned char dataByte;

	IFS0bits.U1RXIF = 0;		// reset UART receive flag
	uartRxDisabled = 1;			// tell 18F4455 to wait to send any other data
	_DCIIE = 0;					// disable DCI interrupt	

	command = U1RXREG;			// get command byte from 18F4455
	switch(command)
	{
		case CHANGE_PATCH:						// load a patch from EEPROM into RAM
			globalCurrentPatch = U1RXREG;		// read which patch to load from UART1 RX register
			loadPatch(globalCurrentPatch);		// load the patch from EEPROM
			dump = U1RXREG;						// read excess bytes from UART receive register
			dump = U1RXREG;
			break;
		case CHANGE_RATE:
			changeRate(U1RXREG);				// change the modulation rate according to A/D value sent from USB PIC
			dump = U1RXREG;						// read excess bytes from UART receive register
			dump = U1RXREG;
			break;
		case CHANGE_DEPTH:
			changeDepth(U1RXREG);				// change the modulation depth according to A/D value sent from USB PIC
			dump = U1RXREG;						// read excess bytes from UART receive register
			dump = U1RXREG;
			break;
		case REVERT_PATCH:
			revertPatch();						// revert current patch to its original settings
			dump = U1RXREG;						// read excess bytes from UART receive register
			dump = U1RXREG;
			dump = U1RXREG;
			break;
		case SAVE_PATCH_CHANGES:
			savePatchChanges();					// save changes to patch made by rate and depth knobs
			dump = U1RXREG;						// read excess bytes from UART receive register
			dump = U1RXREG;
			dump = U1RXREG;
			break;
		case SET_DIGITAL_BYPASS_MODE:
			dataByte = U1RXREG;
			dump = U1RXREG;						// read excess bytes from UART receive register
			dump = U1RXREG;
			if(dataByte==0)
				globalIsDigitalBypassModeActive = FALSE;
			else
				globalIsDigitalBypassModeActive = TRUE;
			break;
	}

	uartRxDisabled = 0;			// tell 18F4455 it can start sending data again
	_DCIIE = 1;					// re-enable DCI interrupt
}

/********************************************************************
* The DCI interrupt is triggered when the PCM3060 audio codec has   *
* sent data to be processed.  The digitized audio sample is read,   *
* processed, and sent back to the DAC of the PCM3060				*
********************************************************************/
void __attribute__((__interrupt__)) _DCIInterrupt(void)
{
	unsigned long newFraction;		// used to calculate new ampFrac values when the user changes the depth of the modulation amplitude
	int adc0;						// holds the 16 MSBs of the 24-bit audio sample
	int adc1;						// holds the 8 LSBs of the 8-bit audio sample
	unsigned int tempBits;
	unsigned char isNegative;		// flag used to remember if the audio sample is negative

	_DCIIF = 0;				// clear DCI ISR flag

	adc0 = RXBUF0;			// read 16 MSBs from DCI register
	adc1 = RXBUF1;			// read 8 LSBs from DCI register

	// check if we're in digital bypass mode
	if(globalIsDigitalBypassModeActive==TRUE)
	{
		TXBUF0 = adc0;
		TXBUF1 = adc1;
		return;
	}

	isNegative = FALSE;		// initialze negative flag

	asm("MOV %0, W5" : :"g"(adc0));			// put 16 MSBs of ADC value into W5
	asm("MOV %0, W6" : :"g"(adc1));			// put 8 LSBs of ADC value into W6
	asm("MOV %0, W4" : :"g"(globalAmpFractions[globalCurrentAmpFraction]));		// put amplitude fraction in W4	

	if(adc0<0)					// check if ADC result is negative
	{
		isNegative = TRUE;		// set negative flag
		asm("CLR A");			// clear ACCA
		asm("ADD W6, A");		// put 8 LSBs in ACCA.H
		asm("SFTAC A, #16");	// move 8 LSBs to ACCA.L
		asm("ADD W5, A");		// put 16 MSBs in ACCA.H
		asm("SFTAC A, #8");		// move ADC result to lower 24 bits of ACCA
		asm("NEG A");			// get 2's complement of ADC result
		asm("SFTAC A, #-8");	// move 16 MSBs to ACCA.H
		asm("SAC A, W5");		// store 16 MSBs in W5
		asm("SFTAC A, #-16");	// move 8 LSBs into high byte of ACCA.H
		asm("SAC A, W6");		// store 8 LSBs in high byte of W6
	}


	asm("MPY W5*W4, A");		// multiply ADC's 16 MSBs by amplitude fraction - store in ACCA
	asm("SFTAC A, #-8");		// shift ACCA left 8 bits since we treated a 24-bit value as a 16-bit value
	asm("LSR W6, #8, W6");		// move ADC's 8 LSBs to lower byte of W6
	asm("MPY W6*W4, B");		// multiply ampFraction by audio 8 LSBs - store in ACCB
	asm("ADD A");				// add accumulators - store result in ACCA

	if(isNegative==TRUE)		// negate ACCA if the ADC sample was negative
		asm("NEG A");

	asm("SFTAC A, #8");			// move 16 MSBs of result to ACCA.H
	asm("SAC A, W5");			// store 16 MSBs in W5
	asm("SFTAC A, #-16");		// move 8 LSBs of result to high byte of ACCA.H
	asm("SAC A, W6");			// store 8 LSBs of result in high byte of W6

	asm("MOV W5, %0" : "=g"(TXBUF0));		// send 16 MSBs to DAC
	asm("MOV W6, %0" : "=g"(TXBUF1));		// send 8 LSBs to DAC

	globalAmpFracCounter++;					// increment # of times this amplitude fraction has been used


	// check if it's time to switch to the next ampFrac
	if(globalAmpFracCounter==globalNumAmpFractionUses)
	{
		globalAmpFracCounter = 0;			// reset counter
		globalCurrentAmpFraction++;			// increment ampFraction array index

		if(globalCurrentAmpFraction==AMPFRACTIONS)		// check if we're at the end of the array
			globalCurrentAmpFraction = 0;

	if(globalIsDepthChanging==TRUE)		// check if depth is changing
		{
			// adjust ampFrac based on the Depth knob's A/D value sent from the 18F4455
			newFraction = 65535 - ( (globalDepthADValue * (65535 - globalOriginalAmpFractions[globalCurrentAmpFraction]) ) >> 8);

			// this prevents any rounding errors from causing the ampFraction to overflow			
			 if(newFraction>65535)
				newFraction = 65535;

			// replace original ampFrac with the new one
			globalAmpFractions[globalCurrentAmpFraction] = (unsigned int)newFraction;

			globalNumAmpFracsChanged++;					// increment the number of amplitude fractions that have been adjusted
			if(globalNumAmpFracsChanged==AMPFRACTIONS)	// check if depth is done changing
				globalIsDepthChanging = FALSE;
		}
	}
}



/********************************************************************
* Reverts the current patch to its original settings if any changes *
* have been made on the pedal's Depth and/or Rate knobs.		    *
********************************************************************/
void revertPatch (void)
{
	unsigned int i;

	// reset amplitude fractions if they've changed
	if(globalHasDepthChanged==TRUE)
		for(i=0; i<AMPFRACTIONS; i++)
			globalAmpFractions[i] = globalOriginalAmpFractions[i];


	// reset period if it's changed
	if(globalHasRateChanged==TRUE)
	{
		// calculate number of times use each amplitude fraction
		globalNumAmpFractionUses = 12 * globalPeriod / 100;
		globalAmpFracCounter = 0;
	}

	// reset change flagsb
	globalHasDepthChanged = FALSE;
	globalHasRateChanged = FALSE;
	globalIsDepthChanging = FALSE;
}



/********************************************************************************
* Change the depth of modulation due to a change on the Depth Knob. 		    *
* 'depthADValue' is the 8-bit A/D result from the Depth Knob					*
*   - center value (ie. 127 of 255) is a depth (maxAmplitude-minAmplitude) / 2	*
*   - max value (255) is a depth of maxAmplitude								*
*   - min value (0) is a depth of minAmplitude									*
********************************************************************************/
void changeDepth (unsigned char depthADValue)
{
	unsigned long newFraction;
	unsigned long tempLong;

	globalDepthADValue = depthADValue;	// remember value for on-the-fly depth changing
	globalIsDepthChanging = TRUE;		// depth is now changing
	globalHasDepthChanged = TRUE;		// set change flag

	// adjust ampFracs with full range
	if(globalMaxAmp==100 && globalMinAmp==0)
	{
		// adjust ampFrac based on the Depth knob's A/D value sent from the 18F4455
		newFraction = 65535 - ( (globalDepthADValue * (65535 - globalOriginalAmpFractions[globalCurrentAmpFraction]) ) >> 8);
		if(newFraction>65535)				// this prevents any rounding errors from causing the ampFraction to overflow
			newFraction = 65535;
	}
	// adjust ampFracs with range other than 100%-0%
	// substitute (maxAmp/100*65536) for the '65536' value used in the equation for full amplitude range above
	else
	{
		tempLong = globalMaxAmp;
		tempLong <<= 16;
		tempLong /= 100;
		newFraction = tempLong - ( (globalDepthADValue * (tempLong - globalOriginalAmpFractions[globalCurrentAmpFraction]) ) >> 8);
	}


	// put new ampFrac value in the ampFrac array
	globalAmpFractions[globalCurrentAmpFraction] = newFraction;
	globalNumAmpFracsChanged = 1;		// remember how many ampFracs have been adjusted
}



/****************************************************************************************
* Change the rate of modulation due to a change on the Rate Knob						*
* 'rateADValue' is the 8-bit A/D result from the Rate Knob								*
* The period range is from .25*period to 2*period										*
* If .25*period < MIN_PERIOD, MIN_PERIOD becomes the floor period						*
****************************************************************************************/
void changeRate (unsigned char rateADValue)
{
	unsigned int lowPeriod;

	// check if MIN_PERIOD is less than 1/4 of the original period
	if((globalPeriod >> 2) < MIN_PERIOD)
		lowPeriod = MIN_PERIOD;
	else
		lowPeriod = globalPeriod >> 2;

	//globalNewPeriod = ((((globalPeriod << 1) - lowPeriod) * rateADValue) >> 8) + lowPeriod;
	globalNewPeriod = globalPeriod << 1;
 	globalNewPeriod -= lowPeriod;
	globalNewPeriod *= rateADValue;
	globalNewPeriod >>= 8;
	globalNewPeriod += lowPeriod;


	// calculate number of times use each amplitude fraction
	globalNumAmpFractionUses = 12 * globalNewPeriod / 100;
	globalAmpFracCounter = 0;

	globalHasRateChanged = TRUE;		// set change flag
}

/****************************************************
* Load the patch 'patchNum' from EEPROM into RAM	*
****************************************************/
void loadPatch (unsigned char patchNum)
{
	unsigned int baseAddress;			// address of the beginning of the patch to be loaded
	unsigned char highByte, lowByte;	// used to get the 16-bit values from the patch
	unsigned int tempFrac;
	unsigned long tempLong1, tempLong2;
	unsigned int i;

	// reset change flags
	globalHasDepthChanged = FALSE;
	globalHasRateChanged = FALSE;
	globalIsDepthChanging = FALSE;

	// address of the first byte of the patch to load
	baseAddress = PATCH_LENGTH * patchNum;

	// load patch minimum amplitude
	globalMinAmp = readByteFromEEPROM(baseAddress + MIN_AMP_OFFSET);

	// load patch maximum amplitude
	globalMaxAmp = readByteFromEEPROM(baseAddress + MAX_AMP_OFFSET);

	// load 16-bit patch period
	highByte = readByteFromEEPROM(baseAddress + PERIOD_OFFSET);
	lowByte = readByteFromEEPROM(baseAddress + PERIOD_OFFSET + 1);
	globalPeriod = (highByte << 8) + lowByte;

	// load the 800 16-bit patch amplitude fractions
	baseAddress = PATCH_LENGTH * patchNum + AMP_FRACTION_OFFSET;	// calculate address where ampFracs are stored within the patch
	for(i=0; i<1600; i+=2)
	{
		highByte = readByteFromEEPROM(baseAddress + i);						// read MSByte of ampFrac from EEPROM
		lowByte = readByteFromEEPROM(baseAddress + i + 1);					// read LSByte of ampFrac from EEPROM
		globalAmpFractions[i>>1] = (highByte << 8) + lowByte;				// store ampFrac in array
		globalOriginalAmpFractions[i>>1] = globalAmpFractions[i>>1];		// store original ampFracs in case Depth Knob is changed
	}

	// calculate number of times use each amplitude fraction
	globalNumAmpFractionUses = 12 * globalPeriod / 100;
}


/****************************************************************
* Save changes to the current patch made by the rate and depth 	*
* knobs.														*
*****************************************************************/
void savePatchChanges (void)
{
	unsigned int baseAddress;			// address where the patch to update begins
	unsigned int address;
	unsigned char highByte;
	unsigned char lowByte;
	unsigned int data;
	unsigned int i, j;
	unsigned char patch[2560];			// holds the patch to write to EEPROM
	unsigned int patchIndex;			// index in the patch array
	unsigned char patchPage[128];		// array that holds the page to be written to EEPROM

	// beginning address of patch in EEPROM
	baseAddress = PATCH_LENGTH * globalCurrentPatch;

	// check if rate has changed and depth hasn't
	// if only the rate has changed, we just write the 16-bit period value to EEPROM
	if(globalHasRateChanged==TRUE && globalHasDepthChanged==FALSE)
	{
		// convert 16-bit period to 2 8-byte values
		highByte = globalNewPeriod >> 8;
		lowByte = globalNewPeriod - (highByte << 8);

		// write new period to EEPROM	
		writeByteToEEPROM(baseAddress + PERIOD_OFFSET, highByte);
		writeByteToEEPROM(baseAddress + PERIOD_OFFSET + 1, lowByte);

		globalPeriod = globalNewPeriod;			// update globalPeriod with its new value
		globalHasRateChanged = FALSE;			// reset change flag
	}

	// if the depth has changed, we store the entire patch in RAM, then write it to EEPROM
	// patch is stored into RAM so we can write 128-byte pages to EEPROM instead of individual bytes
	if(globalHasDepthChanged==TRUE)
	{
		// put amplitude ranges in patch array
		patch[MIN_AMP_OFFSET] = globalMinAmp;
		patch[MAX_AMP_OFFSET] = globalMaxAmp;
		
		// put 0's in the 2 MSBytes of the 4-byte period
		patch[PERIOD_OFFSET-2] = 0;
		patch[PERIOD_OFFSET-1] = 0;

		// check if period has changed
		if(globalHasRateChanged==TRUE)
		{
			// convert 16-bit period to 2 8-byte values
			highByte = globalNewPeriod >> 8;
			lowByte = globalNewPeriod - (highByte << 8);
		}
		else
		{
			// convert 16-bit period to 2 8-byte values
			highByte = globalPeriod >> 8;
			lowByte = globalPeriod - (highByte << 8);
		}
		
		// put period values in patch array
		patch[PERIOD_OFFSET] = highByte;
		patch[PERIOD_OFFSET + 1] = lowByte;

		// put ampFracs in patch array
		patchIndex = AMP_FRACTION_OFFSET;
		for(i=0; i<AMPFRACTIONS; i++)
		{
			// convert 16-bit ampFracs to 2 8-bit values
			highByte = globalAmpFractions[i] >> 8;
			lowByte = globalAmpFractions[i] - (highByte << 8);

			// put period bytes into patch array
			patch[patchIndex] = highByte;
			patchIndex++;
			patch[patchIndex] = lowByte;
			patchIndex++;

			// put altered ampFracs into main ampFrac array
			globalOriginalAmpFractions[i] = globalAmpFractions[i];
		}

		// put graphPoints in patch array
		address = baseAddress + GRAPH_POINT_OFFSET;
		patchIndex = GRAPH_POINT_OFFSET;
		for(i=address; i<(address+AMPFRACTIONS); i++)
		{
			data = readByteFromEEPROM(i);				// read graphPoint from EEPROM
			data = (data * globalDepthADValue) >> 8;	// adjust graphPoint based on Depth knob value
			patch[patchIndex] = data;					// put adjusted byte into patch array
			patchIndex++;
		}

		// put patch description in patch array
		address = baseAddress + PATCH_DESCRIPTION_OFFSET;
		patchIndex = PATCH_DESCRIPTION_OFFSET;
		for(i=patchIndex; i<PATCH_LENGTH; i++)
		{
			data = readByteFromEEPROM(i);		// read graphPoint from EEPROM
			patch[i] = data;					// put adjusted byte into patch array
		}

		// write patch array to EEPROM in 128-byte pages
		patchIndex = 0;
		address = baseAddress;
		for(i=0; i<(PATCH_LENGTH>>7); i++)
		{
			for(j=0; j<PAGE_SIZE; j++)					// put next page of data into page array
			{
				patchPage[j] = patch[patchIndex];
				patchIndex++;
			}
		
			// convert 16-bit address to 2 8-byte addresses for EEPROM
			highByte = address >> 8;
			lowByte = address - (highByte << 8);

			// write page to EEPROM
			HDPageWriteI2C(EEPROM_CONTROL_BYTE, highByte, lowByte, patchPage);

			// pause to wait for byte to be written to EEPROM
			pause(5);
		
			// move address to beginning of next page
			address += PAGE_SIZE;
		}
		globalHasDepthChanged = FALSE;					// reset change flag
	}
}

/****************************************************************
* Reads a byte from EEPROM 								    	*
* 'address' is the 16-bit EEPROM address to read from			*
*****************************************************************/
unsigned char readByteFromEEPROM (unsigned int address)
{
	unsigned char highAdd;			// high Address byte
	unsigned char lowAdd;			// low Address byte
	unsigned char data;				// data byte
	unsigned char pageString[64];	// array to hold page data to/from EEPROM

	//unsigned char controlByte;	// control byte
	//unsigned char length;			// length of Bytes to Read
	//controlByte = 0xA0;
	//length = 1;

	// calculate byte-sized EEPROM address variables from word-sized 'address'
	highAdd = address >> 8;
	lowAdd = address - (highAdd << 8);

	// read byte from EEPROM - result is stored in 'data' variable
	HDByteReadI2C(EEPROM_CONTROL_BYTE, highAdd, lowAdd, &data, EEPROM_READ_LENGTH);
	
	return data;
}


/****************************************************************
* Writes a byte to EEPROM 								    	*
* 'address' is the 16-bit EEPROM address to write to			*
*****************************************************************/
void writeByteToEEPROM (unsigned int address, unsigned char data)
{
	unsigned char highAdd;			// high Address byte
	unsigned char lowAdd;			// low Address byte

	// calculate byte-sized EEPROM address variables from word-sized 'address'
	highAdd = address >> 8;
	lowAdd = address - (highAdd << 8);

	// write byte to EEPROM
	HDByteWriteI2C(EEPROM_CONTROL_BYTE, highAdd, lowAdd, data);

	// pause to wait for byte to be written to EEPROM
	pause(5);
}

/****************************************************************
* Pauses the program for a specified number of milliseconds    	*
* 'milliseconds' is the number of milliseconds to pause for		*
*****************************************************************/
void pause (unsigned char milliseconds)
{
	unsigned char j;
		
	// to adjust for different MIPS processors, the value to count to with variable 'j' = MIPS * 1000
	for(j=0; j<milliseconds; j++)
		__delay32(40000);
}
