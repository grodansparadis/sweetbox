void setup (void);					// setup I/O pins and initialize peripherals
void initDCI (void);				// setup DCI module
