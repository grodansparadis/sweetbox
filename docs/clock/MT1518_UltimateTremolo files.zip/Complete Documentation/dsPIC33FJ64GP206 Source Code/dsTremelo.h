#define uartRxDisabled _RC15		// high if UART is ready to receive data from 18F4455

#define PATCH_LENGTH 2560			// length of a patch stored on EEPROM
#define PAGE_SIZE 128				// EEPROM page size
#define MIN_AMP_OFFSET 0			// offset to add to beginning of patch to get minimum amplitude
#define MAX_AMP_OFFSET 1			// offset to add to beginning of patch to get maximum amplitude
#define PERIOD_OFFSET 4				// offset to add to beginning of patch to get period
#define AMP_FRACTION_OFFSET 6		// offset to add to beginning of patch to get amplitude fractions
#define GRAPH_POINT_OFFSET 1606		// offset to add to beginning of patch to get graph point values
#define PATCH_DESCRIPTION_OFFSET 2406	// offset to add to beginning of patch to get patch description


void loadPatch(unsigned char);		// loads a patch into RAM from EEPROM
void changeRate (unsigned char);	// changes the period based on a change from the Rate Knob
void changeDepth (unsigned char);	// changes the modulation depth based on a change from the Depth Knob
void revertPatch (void);			// revert current patch to its original settings
void savePatchChanges (void);		// save changes to patch made by rate and depth knobs
unsigned char readByteFromEEPROM (unsigned int);			// reads a byte from EEPROM
void writeByteToEEPROM (unsigned int, unsigned char);		// writes a byte to EEPROM
void pause (unsigned char);			// pauses the program for a specified number of milliseconds

void __attribute__((__interrupt__)) _U1RXInterrupt(void);		// UART1 Receive ISR
void __attribute__((__interrupt__)) _DCIInterrupt(void);		// DCI module ISR
