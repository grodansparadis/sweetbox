Contest Entrant MT1518  (UltimateTremolo Guitar Effect Processor)
Source code for PIC18F4455

Firmware compiled with the microEngineering Labs PicBasic Pro compiler (version 2.47).
All files listed below must be in the same directory to build firmware.

To compile, type "pbpw -ampasmwin -p18f4455 usb"
Microchip's Assembler, MPASMWIN, needs to be in the same directory as the PicBasic Pro files

File			Description
----------------------------------------------------
PBPW.EXE		PicBasic Pro compiler executable (not included with my files)
MPASMWIN.EXE		Microchip assembler used by PicBasic Pro (not included with my files)

USB.BAS			Main firmware source file
INPUT.BAS		Handles user input from knobs and switches
USBPCCOM.BAS		Handles communications between the PC and pedal

DESCUSB.ASM		Used by PBP for USB functionality
USB.ASM			"
USBDESC.ASM		"
18F4455.INC		Used by PBP compiler
18F4455.BAS		"
P18F4455.INC		Used by Microchip assembler
README.TXT		This file