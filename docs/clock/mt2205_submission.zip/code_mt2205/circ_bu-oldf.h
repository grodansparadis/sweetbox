/** Misc Setup */
typedef unsigned char byte;
typedef unsigned short word;

/** Data structs for acquisition */
#define ACQUIRE_BUFFER_SIZE 25
#define OUTPUT_BUFFER_SIZE 25

/**
 * CircularBuffer - a circular buffer implementation
 */
// lets us use a quicker wrapping algorithm by setting the mask
#define numToByteMask(x) (x-1)
enum bufSize {_1 = numToByteMask(1), _2 = numToByteMask(2), _4 = numToByteMask(4), _8 = numToByteMask(8), \
				_16 = numToByteMask(16), _32 = numToByteMask(32), _64 = numToByteMask(64), _128 = numToByteMask(128), \
				_256 = numToByteMask(256)};

typedef struct _CircularBuffer {
	unsigned short *data; // data pointer
	byte maxLen; // max length of data (used to wrap)
	byte wrapMask; // mask used to wrap indicies quicker
	byte readIndex; // the next short we will read
	byte writeIndex; // the next short we will write
} CircularBuffer;
void CircularBufferConstructor(CircularBuffer *buf, unsigned short *data, byte maxLen, byte wrapMask);
short hasData(CircularBuffer *buf);
unsigned short wrapIndex(CircularBuffer *buf, short index);
void incrementRead(CircularBuffer *buf);
unsigned short readInPlace(CircularBuffer *buf);
unsigned short readCircBuf(CircularBuffer *buf);
unsigned short readAtIndex(CircularBuffer *buf, short index);
void incrementWrite(CircularBuffer *buf);
void writeInPlace(CircularBuffer *buf, unsigned short value);
void writeCircBuf(CircularBuffer *buf, unsigned short value);
#define loopCircularBuffer(buf, statements) {byte i = buf->readIndex; \
						while(i != buf->writeIndex) { \
							{##statements} \
							i = (++i)&(buf->wrapMask); \
						} \
					}
/**
 * AcquireBuffer - holds the input and output buffers on which we will be working
 */
typedef struct {
	CircularBuffer X; // input (from ADC) 
	CircularBuffer Y; // output (to DAC)
} AcquireBuffer;


void SetupAcqBuffer(AcquireBuffer *buf, unsigned short xLen, unsigned short *xData, byte xWrapMask, \
										unsigned short yLen, unsigned short *yData, byte yWrapMask);


unsigned short testCircBuf();
