%t = linspace(0.1,4*pi, 1000000);
t = 0:0.001:2*pi;
%x = sin(t)./(pi.*t);
x= sinc(t);

figure(1)
subplot(2,1,1)
plot(t,abs(x))

subplot(2,1,2)
plot(t,(angle(x)))

figure(2)
subplot(2,1,1)
%plot(t./pi,abs(fft(x)))
semilogx(t./pi,abs(fft(x)))

subplot(2,1,2)
plot(t./pi,(angle(fft(x))))
semilogx(t./pi,(angle(fft(x))))