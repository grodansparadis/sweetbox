/**
 * Main file for the speaker project. Contains basic setup code as well as the main loop.
 *
 * Overview: 
 * 	- Interrupt: - reads in data from the ADCs (as many as there are channels we are handling)
 *				 - writes out data to the DACs per channel
 * 	- Main Loop: - Does PID processing, consuming ADC data from the buffer and writing out DAC data to it
 * 				 - Runs autotune code on data as well
 *
 * Design Guides:
 *				- Inline all functions
 * 				- minimize number of arguments passed
 *				- for now, dont do null checks, debugger will catch them for us
*/


#include "p30F2010.h"
/*
void testFloatMath(void) {
	int i = 0;
	for(i=0; i<100; ++i) {
		int k = 0;
		float accum = 1.0f;
		TMR1 = 0;
		for(k=0; k<100; ++k) {
			accum += accum*accum;
		}
		short time = TMR1;
		time = time;
	    LATE ^= 0xF;			//Toggle LED's
	}
}
*/
/** Misc Setup */
typedef unsigned char byte;

/** Data structs for acquisition */
#define ACQUIRE_BUFFER_SIZE 25
#define OUTPUT_BUFFER_SIZE 25

/**
 * CircularBuffer - a circular buffer implementation
 */
// lets us use a quicker wrapping algorithm by setting the mask
#define numToByteMask(x) (x-1)
enum bufSize {_1 = numToByteMask(1), _2 = numToByteMask(2), _4 = numToByteMask(4), _8 = numToByteMask(8), \
				_16 = numToByteMask(16), _32 = numToByteMask(32), _64 = numToByteMask(64), _128 = numToByteMask(128), \
				_256 = numToByteMask(256)};

typedef struct _CircularBuffer {
	unsigned short *data; // data pointer
	byte maxLen; // max length of data (used to wrap)
	byte wrapMask; // mask used to wrap indicies quicker
	byte readIndex; // the next short we will read
	byte writeIndex; // the next short we will write
} CircularBuffer;
void CircularBufferConstructor(CircularBuffer *buf, unsigned short *data, byte maxLen, byte wrapMask){ 
	buf->data = data; 
	buf->maxLen = maxLen;
	buf->wrapMask = wrapMask;
	buf->readIndex = buf->writeIndex = 0;
}
inline short hasData(CircularBuffer *buf) { 
	if(buf->readIndex <= buf->writeIndex) {
		return buf->writeIndex - buf->readIndex;
	} else {
		return ((buf->maxLen - buf->readIndex) + (buf->writeIndex + 1));
	}
}
inline void incrementRead(CircularBuffer *buf) { buf->readIndex = (++buf->readIndex) & (buf->wrapMask); }
inline unsigned short readInPlace(CircularBuffer *buf) {
	return (buf->data)[buf->readIndex];
}
inline unsigned short readCircBuf(CircularBuffer *buf) {
	unsigned short retVal = readInPlace(buf);
	if(buf->readIndex + 1 <= buf->writeIndex)
		incrementRead(buf);
	return retVal;
}
inline void incrementWrite(CircularBuffer *buf) { buf->writeIndex = (++buf->writeIndex) & (buf->wrapMask); }
inline void writeInPlace(CircularBuffer *buf, unsigned short value) {
	(buf->data)[buf->readIndex] = value;
}
inline void writeCircBuf(CircularBuffer *buf, unsigned short value) {
	writeInPlace(buf, value);
	incrementWrite(buf);
	if(buf->writeIndex == buf->readIndex) 
		incrementRead(buf);
}
#define loopCircularBuffer(buf, statements) {byte i = buf->readIndex; \
						while(i != buf->writeIndex) { \
							(##statements) \
							i = (++i)&(buf->wrapIndex); \
						} \
					}
/**
 * AcquireBuffer - holds the input and output buffers on which we will be working
 */
typedef struct {
	CircularBuffer X; // input (from ADC) 
	CircularBuffer Y; // output (to DAC)
} AcquireBuffer;

/** Data Acquisition Code */
#define SAMPCOUNT 16
#define NUMCHANNELS 2
inline short readShortAddr(short *port){return *port;}
inline void writeShortAddr(short *port, short value){*port = value;}
inline byte readByteAddr(byte *port){return *port;}
inline void writeByteAddr(byte *port, byte value){*port = value;}
inline void acquire(CircularBuffer *dest, short *ADC){writeCircBuf(dest, readShortAddr(ADC));}

	/** ADC setup */
inline void setup10BitADC() {
	ADCON1bits.ADON = 0; 		// Must be off to change settings
	ADCON1bits.FORM = 0x0; 		// unsigned int
	ADCON1bits.SSRC = 0x7; 		// free-running (back-to-back conversions)
	ADCON1bits.ASAM = 0x1; 		// back-to-back samples

	//timer setup
	TMR3 = 0x0000;			// reset timer
	PR3 = SAMPCOUNT;		// set compare value?
	IFS0bits.T3IF = 0; 		// clear interrupt acknowledge
	IEC0bits.T3IE = 0;		// clear interrupt enable

	ADCON2bits.SMPI = 15; // interrupt every sample/convert sequence NOTE: May want to sample faster then average, if so this needs to be changed.

	ADCON3bits.ADCS = 63;

	ADCHSbits.CH123NA = 0x0; 		// ch1,2,3 -ve is Vref- for MUXA
	ADCHSbits.CH123SA = 0x1; 		// ch1=AN3, ch2=AN4, ch3=AN5 for MUXA
	ADCHSbits.CH0NA = 0x0; 			//ch0 -ve is Vref- for MUXA
	ADCHSbits.CH0SA = 0x5; 			//ch0=AN2 for MUXA

	ADCSSL = 0;
	ADCSSLbits.CSSL4 = 1;
	ADCSSLbits.CSSL5 = 1;

	ADPCFG = 0xffff; 		// set all pins to digital
	ADPCFGbits.PCFG4 = 0;	// set pin 4 to analog
	ADPCFGbits.PCFG5 = 0;	// set pin 5 to analog
}

inline void startSampling() {
	IFS0bits.ADIF = 0; // clear interrupt flag;
	IEC0bits.ADIE = 0x1; // enable the ADC interrupt
	ADCON1bits.ADON = 0x1;

	//Start Timer 3
	T3CONbits.TON = 1;
}

inline void readADC() {
	unsigned short tmp = 0;
	short i = 0;
	for(i = 0; i<NUMCHANNELS; ++i) {
		tmp = *(&ADCBUF0 + i);
	}
}

/** Processing Function */
int main(void)
{

	setup10BitADC();
	startSampling();
	while(1) {
		LATE ^= 0x1;
	}

/*
	ADPCFG = 0xFF;			//Make analog pins digital 
	while(1) {
		int boo = PORTDbits.RD1;
	}
*/
	LATE = 0x0;
	TRISE = 0x0;			//Configure LED pins as output

	TMR1 = 0;				// clear timer 1
	PR1 = 0x7270;			// interrupt every 250ms
	IFS0bits.T1IF = 0;		// clr interrupt flag
	IEC0bits.T1IE = 1;		// set interrupt enable bit
	T1CON = 0x8030;			// Fosc/4, 1:256 prescale, start TMR1

	while(1) { // loop on there being data waiting to be processed	
	// process data on each channel (3 function calls)
	// auto-tune algorithm
	}		
return 0;
}


void __attribute__((interrupt, no_auto_psv)) _T1Interrupt(void)
{
	IFS0bits.T1IF = 0;		// clear interrupt flag
	
	LATE ^= 0x1;			//Toggle LED's
}
void __attribute__((interrupt, no_auto_psv)) _ADCInterrupt(void)
{
	IFS0bits.T3IF = 0;
	IFS0bits.ADIF = 0; // clear interrupt flag;
	LATE ^= 0x2;			//Toggle LED's
	readADC();
	// acquire data on each channel (3 function calls)
	// write out data that's ready to be written (3 function calls)
}
