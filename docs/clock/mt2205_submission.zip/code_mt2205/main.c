#include "p30fxxxx.h"
#include "p30f2010.h"
#include "math.h"
#include "tuner.h"
#include "filt.h"
void ADC_Init(void)
{
	/*	
	ADCON1bits.FORM
	0 -- integer
	1 -- signed integer
	3 -- signed fractional	
	*/
        ADCON1bits.FORM = 0;
	/*	
	ADCON1bits.SSRC -- conversion trigger source select
	7 -- Internal counter ends sampling and starts conversion (auto-convert)
	3 -- Motor control PWM
	2 -- GP timer3
	1 -- Active transition on INTO pin
	0 -- Clearing SAMP bit	
	*/
		ADCON1bits.SSRC = 2;
		T3CONbits.TSIDL = 0; // continue in idle mode
		T3CONbits.TGATE = 0; // gated time accum disabled
		T3CONbits.TCKPS = 0x0; // 1:1 prescale
		T3CONbits.TCS = 0; // use internal clock, Fosc/4
		PR3 = 6000; // set period (to trigger interrupt), 5khz
		TMR3 = 0; // set timer to 0
		IPC1bits.T3IP = 0; // set interrupt priority
		IEC0bits.T3IE = 0; // enable interrupt on the timer
	/*	
	ADCON1bits.ASAM
	1 -- Sampling begins immediately after last conversion completes.  SAMP bit automatically set
	0 -- Sampling begins when SAMP bit is set	
	*/
	ADCON1bits.ASAM = 1;
	/*	
	ADCON1bits.SIMSAM -- simultaneous sampling
	1 -- sample multiple channels simultaneously
	0 -- sample multiple channels in sequence
	Channels used must be set up with ADCON2:CHPS	
	*/
        ADCON1bits.SIMSAM = 0;
	/*	
	ADCON2bits.SMPI
	0 -- interrupt follows each conversion
	1 -- interrupt follows every second conversion
	...and so on to 15	
	*/
        ADCON2bits.SMPI = 0;
	/*	
	ADCON2bits.CHPS
	2 -- convert all four channels
	1 -- convert only Ch0 and Ch1
	0 -- convert Ch0 only	
	*/
	ADCON2bits.CHPS = 0;
	/*	
	ADCON3 Register
        At 29.4 MIPS, Tcy = 33.9 ns = Instruction Cycle Time
        The A/D converter will take 12*Tad periods to convert each sample
        So for ~1 MSPS we need to have Tad close to 83.3ns
        Using equaion in the Family Reference Manual we have
        ADCS = 2*Tad/Tcy - 1
	*/
	/*	
	ADCON3bits.SAMC -- sample and hold time
	31 -- 31 Tad
	0 -- 30 Tad
	...and so on down to 0 Tad.  If you use 0 though, there better be something else that makes a non-zero sampling time	
	*/
	ADCON3bits.SAMC = 10;
	/*	
	ADCON3bits.ADCS -- conversion clock divider (makes Tad from the instruction clock Tcy)
	For ADCS = 4 and 30 MIPS, Tad ~ 83 ns -- the minimum	
	*/
	ADCON3bits.ADCS = 4;
    /*	
	ADCHS Register
	Upper 8 bits are for MUX B, lower 8 for MUX A
	The pot on the eval board is connected to AN5 -- so connect the positive input of Ch0 to this and the negative input to Vref- with 0x0005
	*/
	ADCHS = 0x0005;
        /*	
	ADCSSL Register
        Channel Scanning is disabled. All bits left to their default state	
	*/
	ADCSSL = 0x0000;
	/*	
	ADPCFG Register -- A/D pin configuration register
	Setting all bits high makes all input digital
	Setting a bit to 0 puts that pin to analog mode
	Pot is on channel AN5 -- ADPCFGbits.PCFG5 makes in an analog input	
	*/
	ADPCFG = 0xFFFF;
	ADPCFGbits.PCFG5 = 0;
	/*	Clear the A/D interrupt flag bit	*/
	IFS0bits.ADIF = 0;
	/*	Set the A/D interrupt enable bit	*/
	IEC0bits.ADIE = 1;
	IPC2bits.ADIP = 0x7; // set interrupt priority
	/*	
	Turn on the A/D converter
        This is typically done after configuring other registers	
	*/
	ADCON1bits.ADON = 1;
}


void PWM_Init(void)
{
	PWMCON1bits.PEN1H = 1; // high & low pin made to pwm outputs, not GPIO
	PWMCON1bits.PEN1L = 1;
	PWMCON1bits.PMOD1 = 1; // set to indep mode on hi/low switches (0 for complementary)
	OVDCONbits.POVD1L = 1; // overrides not possible (error conds), PWMH controlled by pwm
	OVDCONbits.POVD1H = 1;
	PWMCON2bits.SEVOPS = 0; // trigger every time it hits trigger
	SEVTCMPbits.SEVTCMP = 0; // compare value on counter (causes trigger).
	//SEVTCMPbits.SEVTDIR = 0x0; // trigger on count up
	IFS2bits.FLTBIF = 0; // clear interrupt FAULT B status bit
	IFS2bits.FLTAIF = 0; // clear interrupt FAULT B status bit
	IFS2bits.PWMIF = 0; // PWM interrupt;
	FLTACON = 0; // FAULT A, B control regs
	//FLTBCON = 0; // NOTE: Commented out because not in package
	//PWMCON2bits.IUE = 1; // force immediate updates on pwm output
	PWMCON2bits.IUE = 0; // do not force immediate updates on pwm output

	PTPER = 0x03ff; // 2^10, setup period (samples)

	PTCONbits.PTEN = 1; // enable PWM timebase
	PTCONbits.PTOPS = 0; // 1:1 to sys clock
	PTCONbits.PTCKPS = 0; // prescale 1:1
	PTCONbits.PTMOD = 0; // free running mode
}
inline void setPWM1DutyCycle(short duty) {
	//NOTE: pwm somehow gives us 1 more bit to fiddle with, hence shift by 1023
	unsigned short realDuty = duty + 1023; // shift up from signed
	PDC1 = (realDuty >= 4096)?(4095):(realDuty);
}
/*	
Macros for Configuration Fuse Registers:
Invoke macros to set up device configuration fuse registers.
The fuses will select the oscillator source, power-up timers, watch-dog
timers, BOR characteristics etc. The macros are defined within the device
header files. The configuration fuse registers reside in Flash memory.

Oscillator setup:
Run this project using an external crystal routed via the PLL in 16x multiplier mode.  For the 7.3728 MHz crystal we will derive a throughput of 7.3728e+6*16/4 = 29.4 MIPS(Fcy) -- ~33.9 nanoseconds instruction cycle time(Tcy).
*/
_FOSC(CSW_FSCM_OFF & XT_PLL16);

/*
Watch-dog timer setup:
Turn off watch-dog timer
*/
_FWDT(WDT_OFF);                 //Turn off the Watch-Dog Timer.

/*
Brown-out and power-on reset settings
Enable MCLR reset pin and turn off the power-up timers.
*/
_FBORPOR(MCLR_EN & PWRT_OFF & PWMxH_ACT_HI & PWMxL_ACT_HI);

/*
Code protection settings
Disable code protection
*/
_FGS(CODE_PROT_OFF);

// variables brought in from the tuner section
extern unsigned short inTuner;
extern unsigned char zeroCal;
extern unsigned short zeroLevel;
extern unsigned short zeroCrossCount;
int main (void)
{
	ADC_Init();             //Initialize the A/D converter
	PWM_Init();
	T3CONbits.TON = 1;	// turn on timer3, causes sampling to begin

	// tune
	setupTuner(0.01*TUNER_TICKS_PER_SECOND, 0xffff);
	startTuner();
	while(inTuner);

	while (1);              //Loop Endlessly - Execution is interrupt driven
                                //from this point on.
	return 0;
}

void __attribute__((__interrupt__)) _ADCInterrupt(void)
{
	/*	
	Clear the A/D Interrupt flag bit or else the CPU will
        keep vectoring back to the ISR	
	*/
	IFS0bits.ADIF = 0;
	PORTEbits.RE2 = 0; // ISR handle start
	unsigned short ADResult1 = ((unsigned short)ADCBUF0); // grab sample from ADC buffer

	if(inTuner) {
		if(zeroCal) {
			// zero cal ISR code
			// NOTE: match this up with the zeroCal count in runZeroCal()
			zeroLevel  += ADResult1>>3; // add to average, /8 because we take that many readings
			--zeroCal; // decrement the count, will cause zeroCal to end in the tuner code
		} else {
			// Tuner ISR Code
			volatile static short x1, x2 = 0;
			unsigned short time = TMR2; // NOTE: This should be moved to the beginning of the ISR body for better precision
			volatile short new = ADResult1 - zeroLevel; // 
			if(zeroCross(x2, new)) zeroCrossNotify(time); // count a zero
			else if(minMax(x1, x2, new)) minMaxNotify(time); // count a min/max
			x1 = x2;  // shuffle things along
			x2 = new;
		}
	} else {
		// Normal ISR Code
		// IIR Filter calls	
		short Y = filter((float)ADResult1);
		// write out to PWM
		setPWM1DutyCycle(Y);
	}
	// debug code used to test firing rate and ISR time
	// Ensure LED's are setup as GPIO and stuff
	PWMCON1bits.PEN2H = 0;
	PWMCON1bits.PEN2L = 0;
	TRISEbits.TRISE2 = 0;
	TRISEbits.TRISE3 = 0;
	PORTEbits.RE2 = 1; // ISR handle end
	LATEbits.LATE3 = 1;
}
