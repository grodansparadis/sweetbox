#include <stdlib.h> 
#include <string.h>
#include <math.h>

#include "p30f2010.h"
#include "tuner.h"
#include "filt.h"

// credit to dan for this
#define ARRAY_LEN(a)   (sizeof(a)/sizeof(a[0]))

extern void setPWM1DutyCycle(short duty);

const COEF_T pi = 3.1415926535897932384626433832795; // pi value used in maths
const short pulseMag = 209; // magnitude of pulse

unsigned short pulseWidth = 0; // width of pulse to knock system with
unsigned short period = 0; // period between the start of successive pulses

unsigned char dummy = 0; // needed this to allow linking, reuse if possible
unsigned char inPulse = 1; // denotes whether we're in the pulse or not
unsigned char inTuner = 0; // !=0 when in tuner, 0 otherwise
unsigned char zeroCal = 0; // !=0 when trying to acquire the 0 level
unsigned short zeroLevel = 0; // level at which 0 is coming in from the ADC (unsigned)

unsigned short zeroCrossCount = 0; // number of zero crossings seen
unsigned short zeroTimes[] = {0,0,0,0}; // times of zero crossings
unsigned short minMaxTimes[] = {0,0,0,0}; // times of min/max
const unsigned char zLen = ARRAY_LEN(zeroTimes); // length of zeroTimes
const unsigned char minMaxLen = ARRAY_LEN(minMaxTimes); // length of minMaxTimes

// functions prototypes
inline void setupTimer2(); // setup the timer, run once
inline void setupTimer2Period(unsigned short period); // set the period for the interrupt
inline void stopInt(); // stop the interrupt from timer2 (bound to the tuner code)
inline void startInt(); //start interrupt for timer2


// Zero Cross & Min/Max Functions
// checks if x1, x2 lie on different sides of 0
inline unsigned char zeroCross(short x1, short x2) {
	return (x1 >= 0)?((x2 < 0)?(1):(0)):((x2 >= 0)?(1):(0));
}
// checks if we hit a min or max
inline unsigned char minMax(short x1, short x2, short x3) {
	return zeroCross(x2-x1,x3-x2); // ie, check if the sign of the gradient changed
}
inline void clearZeroCrossTimes() {
	unsigned char i = 0;
	for(i=0; i<zLen; ++i) zeroTimes[i] = 0;
}
inline void clearMinMaxTimes() {
	unsigned char i = 0;
	for(i=0; i<minMaxLen; ++i) minMaxTimes[i] = 0;
}
/**
 * zeroCrossNotify - record a zero-crossing time
 * time: time, in timer 2 ticks, when zero-level was crossed
 */
inline void zeroCrossNotify(unsigned short time) {
	unsigned char i = 0;
	// write value into first non-zero slot, times will never be 0
	for(i=0; i<zLen; ++i) if(zeroTimes[i] == 0) { zeroTimes[i] = time; break; }
	if(i==(zLen-1)) stopTuner(); // end tuning once we have enough data
}
/**
 * minMaxNotify - record a local minimum/maximum
 * time: time, in timer 2 ticks, when minimum/maximum was hit
 */
inline void minMaxNotify(unsigned short time) {
	unsigned char i = 0;
	// write value into first non-zero slot, times will never be 0
	for(i=0; i<minMaxLen; ++i) if(minMaxTimes[i] == 0) { minMaxTimes[i] = time; break; }
	if(i==(minMaxLen-1)) stopTuner(); // end tuning once we have enough data
}

// TIMER 2 Functions
inline void setupTimer2Period(unsigned short period) {
	PR2 = period;
}
inline void setupTimer2() {
	T2CONbits.TSIDL = 0; // continue in idle mode
	T2CONbits.TGATE = 0; // gated time accumulation disabled ?
	T2CONbits.TCKPS = 0x3; // 1:256 prescaler
	T2CONbits.T32 = 0; // use in 16-bit mode
	T2CONbits.TCS = 0; // internal clock, Fosc/4

	T2CONbits.TON = 1; // turn on timer
}

// Tuner Functions
/**
 * setupTuner - configure the tuner
 * _pulseWidth: width of pulse, in timer2 ticks
 * _period: period of pulse train, in timer2 ticks
 */
inline void setupTuner(unsigned short _pulseWidth, unsigned short _period) {
	period = _period;
	pulseWidth = _pulseWidth;
	setupTimer2();
}

inline void runZeroCal() {
	zeroLevel = 0;
	zeroCal = 7; // NOTE: match this up with the divisor in the ISR, gets counted down to 0
	while(zeroCal); // wait until we have all the values we need
}

inline void startTuner() {
	inTuner = 1; // in tuner
	clearZeroCrossTimes();
	clearMinMaxTimes();
	runZeroCal(); // calibrate 0 level
	zeroCrossCount = 0; // reset 0 crossing count
	inPulse = 0; // force next interrupt on T2 to trigger the pulse
	setupTimer2Period(period); // setup the period so we hit the pulse in 1 period
	TMR2 = 0; // zero the timer
	startInt(); // start pulse train
}
inline void stopTuner() {
	stopInt();
	inTuner = 0;
}

inline void calcCoeffs() {
	// get the average time between peaks
	// NOTE: TODO: find a better way to do this, to ensure we dont have overflows
	unsigned long avg = 0;
	unsigned char len = 0;
	while(len < minMaxLen) {
		avg += minMaxTimes[len];
		++len;
	}
	avg /= minMaxLen;
	avg = avg<<1; // multiply by 2 since we count mins and maxes

	// figure out coefficients
	// NOTE: TODO: Optimize.
	COEF_T alpha, beta, gamma;
	COEF_T omegaHi = 2.0*pi/avg; // corner on the lowpass part of the filter
	COEF_T omegaLo1 = 10.0 * omegaHi; // first corner of hipass 
	COEF_T omegaLo2 = 100.0 * omegaHi; // second corner of hipass
	const COEF_T Td = 0.0002; // sample time, constant for our system, 1/5kHz
	COEF_T B[] = { 0,0,0 }; // temp coeffs for input
	COEF_T A[] = { 0,0 }; // temp coeffs for output
	
	// magic maths
	alpha = exp(-omegaHi*Td);
	beta = exp(-omegaLo1*Td);
	gamma = exp(-omegaLo2*Td);
	B[0] = (1-beta-gamma+beta*gamma)/(alpha*alpha - 2*alpha + 1);// B[0] is Kz
	B[1] = -2*alpha*B[0];
	B[2] = B[0]*alpha*alpha;

	A[0] = beta + gamma;
	A[1] = -beta * gamma;
	// set the coefficients
	setCoeffs(A, B, (unsigned char)ARRAY_LEN(B), (unsigned char) ARRAY_LEN(B));
}

// Interrupt Functions
inline void stopInt() {
	IEC0bits.T2IE = 0; // disable interrupt
}
inline void startInt() {
	IEC0bits.T2IE = 1; // enable interrupt
}
void __attribute__((__interrupt__)) _T2Interrupt(void) {
	IFS0bits.T2IF = 0; // ackknowledge interupt
	//NOTE: When this interrupt goes off, we're ending the time section denoted by inPulse
	if(inPulse) {
		inPulse = 0;
		setPWM1DutyCycle(0); // set value on PWM
		// set time until level switch
		// 	- if upDown == 1 then switch at pulse width
		// 	- if upDown == 0 then switch at period (corrected for time spent in pulse itself)
		setupTimer2Period(period - pulseWidth);
	} else {
		inPulse = 1;
		setPWM1DutyCycle(pulseMag); // set value on PWM
		// set time until level switch
		// 	- if upDown == 1 then switch at pulse width
		// 	- if upDown == 0 then switch at period (corrected for time spent in pulse itself)
		setupTimer2Period(pulseWidth);
		// NOTE: TODO: make sure this can run fast enough, clear* functions may be too slow!
		clearZeroCrossTimes(); // clear out zero cross and min/max times before pulse is over
		clearMinMaxTimes();
	}
}
