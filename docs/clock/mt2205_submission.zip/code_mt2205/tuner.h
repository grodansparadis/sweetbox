/*************
 * Pulse Tuner - does sys ID assuming 2nd order model through zero counting
 * pulse response
 * 
*/
// NOTE: period & pulsewidth based on Fosc/256 timer
// sets up the tuner, run once
inline void setupTuner(unsigned short _pulseWidth, unsigned short _period);
// enter tuning mode, will disable control/filter code & turn on timer2 int
inline void startTuner();
// exit tuner mode, turns off interrupt
inline void stopTuner();

// called to add a zero cross
inline void zeroCrossNotify(unsigned short time);
// called to add a min/max
inline void minMaxNotify(unsigned short time);
// checks if we crossed 0
inline unsigned char zeroCross(short x1, short x2);
// checks if we hit a min or max
inline unsigned char minMax(short x1, short x2, short x3);

// number of Timer2 ticks in a second, setup with a 1:256 prescaler
#define TUNER_TICKS_PER_SECOND 30000000/256
