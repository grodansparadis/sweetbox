// JUNK, DO NOT USE

/*
inline unsigned short IIR_hardcode_test(AcquireBuffer *acq) {
		// - sum up the input coeffs
		// - sum up the output coeffs
		// - scale
		// - insert & return new output
		//typedef unsigned short elemType;
		typedef float elemType;
		#define FILTER_COEFF_SUM 1.0f
		//const static float K = 1.0f;
		//static float A[3] = { 1.0f/FILTER_COEFF_SUM, -1.915f/FILTER_COEFF_SUM, 0.916f/FILTER_COEFF_SUM}; // coeffs for input
		//static float B[2] = { 1.29f/FILTER_COEFF_SUM, -0.42f/FILTER_COEFF_SUM }; // coeffs for output
		// lowpass 10Hz/
		//const static float K = 1.0f;
		//static float A[3] = { 0.003132f, 0.003132f, 0.0f}; // coeffs for input
		//static float B[2] = { 0.9397f,  0.0f }; // coeffs for output
		// lowpass 10Hz/4.9kHz
		//const static float K = 1.0f;
		//static float A[3] = { 0.06017f, 0.06017f, 0.0f}; // coeffs for input
		//static float B[2] = { 0.8797f,  0.0f }; // coeffs for output
		// lowpass book, 300Hz/14200Hz
		//const static float K = 1.0f;
		//static float A[3] = { 0.1243f/FILTER_COEFF_SUM, 0.0f/FILTER_COEFF_SUM, 0.0f/FILTER_COEFF_SUM}; // coeffs for input
		//static float B[2] = { -0.8757f/FILTER_COEFF_SUM,  0.0f/FILTER_COEFF_SUM }; // coeffs for output
		// passthrough
		const static float K = 1.0f;
		static float A[3] = { 1.0f/FILTER_COEFF_SUM, 0.0f/FILTER_COEFF_SUM, 0.0f/FILTER_COEFF_SUM}; // coeffs for input
		static float B[2] = { 0.0f/FILTER_COEFF_SUM,  0.0f/FILTER_COEFF_SUM }; // coeffs for output
		// bandpass
		//const static float K = 1.0f;
		//static float A[3] = { 1.0f, 0.0f, -1.0f}; // coeffs for input
		//static float B[2] = { -1.9452195167541504f, 0.9567030668258667f }; // coeffs for output
		// bugger all pass
		//const static elemType K = 1;
		//static elemType A[3] = { 1,0,0}; // coeffs for input
		//static elemType B[2] = { 0,0 }; // coeffs for output
		elemType accum = 0; // accumulator for output
		int i = 0;
		for(i = 0; i<3; ++i) accum += A[i]*readAtIndex(&(acq->X), -i); // input sum
		for(i = 0; i<2; ++i) accum += B[i]*readAtIndex(&(acq->Y), -i); // output sum
		writeCircBuf(&(acq->Y), (unsigned short)(K*accum));
		return readCircBuf(&(acq->Y));
}
*/