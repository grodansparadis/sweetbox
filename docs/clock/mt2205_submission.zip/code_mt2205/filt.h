#include <stdio.h>
#include <stdlib.h>

typedef float SAMPLE_T; // type for filter samples (type passed in/out)
typedef float COEF_T; // type for filter coefficients
SAMPLE_T filter(SAMPLE_T newX);

void setCoeffs(COEF_T newA[], COEF_T newB[], unsigned char ALen, unsigned char BLen);
