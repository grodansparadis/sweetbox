//////////////////////////////////////////////////////////////////////////
// Filename: filt.c
// Author:   Daniel Kurtz
// Date:     Oct 07, 2007
// Rev:      1.0
// Description:
//   Test program for IIR filter computation.
//
#include "filt.h"
#include <string.h>

#define ARRAY_LEN(a)   (sizeof(a)/sizeof(a[0]))

// Define filter coefficients (B = Numerator; A = Denominator)
COEF_T B[] = { 10.26, -18.097, 7.98 }; // coeffs for input
COEF_T A[] = { 0.2846, 0 }; // coeffs for output


#define A_LENGTH ARRAY_LEN(A)
#define B_LENGTH ARRAY_LEN(B)

///////////////////////////////////////////////////////////////////////////
// Function:  dotShiftInput
// Inputs:
//   [IN]    SAMPLE_T x0   new input
//   [INOUT] SAMPLE_T X[]  input sample vector
//   [IN]    SAMPLE_T B[]  coefficient vector
//   [IN]    unsigned len  length of 'X & 'B
// Returns:
//   Inner product 'X * 'B
// Description:
//   Compute inner (dot) product 'X * 'B & shift 'x0 into 'X.
//       accum = sum(X(0:len-1) .* B(0:len-1));
//       X(1:len-1) = [x0 , X(1:len-2)];
// Assumptions:
//   'B & 'X are contain at least 'len SAMPLE_T.
////////////////////////////////////////////////////////////////////////////
SAMPLE_T dotShiftInput(SAMPLE_T x0, SAMPLE_T X[], COEF_T const B[], unsigned len)
{
  SAMPLE_T accum = 0; 

  // Compute Inner Product and shift each input sample to the right
  while (len--)
  {
    SAMPLE_T swap = x0;    // Swap Variable

    accum += swap * *B++;  // Multiply & Accumulate next sample and coefficient
    
    // Shift input...
    x0   = *X;             // Save next sample
    *X++ = swap;           // Replace it with current sample
  }

  return accum;
} 

///////////////////////////////////////////////////////////////////////////
// Function:  dotShiftOutput
// Inputs:
//   [IN]    SAMPLE_T accum  current accumulator value (from dotShiftInput)
//   [INOUT] SAMPLE_T Y[]    output vector
//   [IN]    SAMPLE_T A[]    coefficient vector
//   [IN]    unsigned len    length of 'Y & 'A
// Returns:
//   'accum - inner product 'Y * 'A
// Description:
//   Compute inner (dot) product 'Y * 'A, and shift result into 'Y.
//       accum -= sum(Y(0:len-1) .* A(0:len-1));
//       Y(1:len-1) = [accum , Y(1:len-2)];
// Assumptions:
//   'A & 'Y are contain at least 'len SAMPLE_T.
////////////////////////////////////////////////////////////////////////////
SAMPLE_T dotShiftOutput(SAMPLE_T accum, SAMPLE_T Y[], COEF_T const A[], unsigned len)
{
  // Start at END of 'A & 'Y:
  A += len-1;
  Y += len-1;

  while (--len)
  {
    *Y     = *--Y;        // Shift output to the right
	//rbejjani - JP says add, dont subtract
    accum += *Y * *A--;   // Multiply & Accumulate this output & coefficient
  }

  //rbejjani - JP says no scaling
  //accum /= *A;          // A[0] is scale factor
  *Y = accum;           // Store final output

  return accum;
}

// gives average of samples to date, with a len sized window
// TODO: Actually implement the window averager
///////////////////////////////////////////////////////////////////////////
// Function:  doAverage
// NOTE: currently hacked to return half ADC scale FIXME
// Inputs:
//   [IN]   SAMPLE_T X[]        input vector, before shifting on newSample
//   [IN]   unsigned len        length of 'X
//   [IN]   SAMPLE_T newSample  sample to be added to average
// Returns:
//   'avg - running average
// Description:
//   calculate the average of values being pushed onto vector X
// Assumptions:
//   newSample hasn't been shifted onto X and that X has not been 
//   changed since last call to this function
////////////////////////////////////////////////////////////////////////////
SAMPLE_T doAverage(SAMPLE_T X[], const unsigned int len, SAMPLE_T newSample) {
	static SAMPLE_T sum = 0; // running sum of values
	sum -= X[len-1]; // remove oldest value
	sum += newSample; // add in new value
	SAMPLE_T avg = sum*(float)(1.0f/B_LENGTH);
	//return avg;
	return (511);
}


///////////////////////////////////////////////////////////////////////////
// Function:  filter
// Inputs:
//   [IN]    SAMPLE_T newX   new input sample
// Returns:
//   next filter output
// Description:
//   Compute next filter output given new input sample.
//   This function maintains its own static input & output buffers.
//   Equivalent to MATLAB command:  filter(B,A,X)
//     y = (1/A[0]) * sum(B * X) - sum(A(1:len-1) .* Y(1:len-1))
// Assumptions:
////////////////////////////////////////////////////////////////////////////
SAMPLE_T filter(SAMPLE_T newX)
{
  static SAMPLE_T X[B_LENGTH] = { 0 };  // Input Vector
  static SAMPLE_T Y[A_LENGTH] = { 0 };  // Output Vector
  SAMPLE_T accum;                       // Accumulator

  // Do DC Nulling
  newX -= doAverage(X, B_LENGTH, newX);
  // First compute inner product of numerator (A) and Input (X), and shift in new input
  accum = dotShiftInput(newX, X, B, B_LENGTH);
  // then, inner product of denominator (B) and Output (Y), and shift in new output
  return dotShiftOutput(accum, Y, A, A_LENGTH);
}


// Tuner related Functions
///////////////////////////////////////////////////////////////////////////
// Function:  setCoeffs
// Inputs:
//   [IN]    COEF_T newA[]        new A array (output coefficients)
//   [IN]    COEF_T newB[]        new B array (input coefficients)
//   [IN]    unsigned char ALen   lenth of newA
//   [IN]    unsigned char BLen   lenth of newB
// Returns:
//   void
// Description:
//   Set the filter coefficients to the new values, if there are enough.
// Assumptions:
///////////////////////////////////////////////////////////////////////////
void setCoeffs(COEF_T newA[], COEF_T newB[], unsigned char ALen, unsigned char BLen) {
	if(ALen != A_LENGTH || BLen != B_LENGTH)  return; // fail if we dont have the right number of coeffs
	memcpy(A, newA, A_LENGTH*sizeof(COEF_T));
	memcpy(B, newB, B_LENGTH*sizeof(COEF_T));
}

// Test code
/*
int main(int argc, void *argv)
{
  SAMPLE_T XX[] = {  0.466, 0.419, 0.846, 0.525, 0.203, 0.111, 0.814, 14.13, -13.2 };
  unsigned XX_len = ARRAY_LEN(XX);
  unsigned cnt;

  printf("Input\t\tOutput\n");

  for (cnt = 0; cnt < XX_len; cnt++)
  {
    SAMPLE_T output;
    output = filter(XX[cnt]);
    printf("%f\t%f\n", XX[cnt], output);
  }
}
*/
