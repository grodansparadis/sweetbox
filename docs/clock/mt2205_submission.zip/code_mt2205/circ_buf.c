#include "circ_buf.h"
/**
 * CircularBuffer - a circular buffer implementation
 */
// lets us use a quicker wrapping algorithm by setting the mask
inline void CircularBufferConstructor(CircularBuffer *buf, unsigned short *data, byte maxLen, byte wrapMask){ 
	buf->data = data; 
	buf->maxLen = maxLen;
	buf->wrapMask = wrapMask;
	buf->index = 0;
	int i = 0;
	for(i=0; i<maxLen; ++i) buf->data[i] = 0;
}
inline unsigned short wrapIndex(CircularBuffer *buf, short index) {
	while(index<0) index = buf->maxLen + index;
	return (buf->index + index)&buf->wrapMask;
}
inline unsigned short readCircBuf(CircularBuffer *buf) {
	return (buf->data)[buf->index];
}
inline unsigned short readAtIndex(CircularBuffer *buf, short index) {
	short realIndex = wrapIndex(buf, index);
	return (buf->data)[realIndex];
}
inline void incrementIndex(CircularBuffer *buf) { buf->index = (++buf->index) & (buf->wrapMask); }
inline void writeCircBuf(CircularBuffer *buf, unsigned short value) {
	incrementIndex(buf);
	(buf->data)[buf->index] = value;
}

/**
 * AcquireBuffer - holds the input and output buffers on which we will be working
 */
inline void SetupAcqBuffer(AcquireBuffer *buf, unsigned short xLen, unsigned short *xData, byte xWrapMask, \
										unsigned short yLen, unsigned short *yData, byte yWrapMask) {
	CircularBufferConstructor(&(buf->X), xData, xLen, xWrapMask);
	CircularBufferConstructor(&(buf->Y), yData, yLen, yWrapMask);
}


inline unsigned short testCircBuf() {
	// - setup test array
	//	- make sure its bigger than the buffer
	// - insert into buffer
	// - read it out & verify

	static unsigned short BAD = 0;
	static short testSRC[8] = {8,7,6,5,4,3,2,1};
	static short testDST[8] = {0,0,0,0,0,0,0,0};
	CircularBuffer buf;

	CircularBufferConstructor(&buf, testDST, 4, _4);
	unsigned short i = 0, j=0;
	// test as you go along
	for(i=0; i<8; ++i) {
		writeCircBuf(&buf, testSRC[i]);
		if(testSRC[i] != readCircBuf(&buf)) ++BAD;
	}
	//test writes then reads
	for(i=0; i<8; ++i) 
		writeCircBuf(&buf, testSRC[i]);
	for(i=4; i<8; ++i) 
		if(testSRC[i] != readCircBuf(&buf)) 
			++BAD;

	//test *AtIndex ops
	for(i=0; i<8; ++i) 
		writeCircBuf(&buf, testSRC[i]);
	for(i=7; i>=4; --i) 
		if(testSRC[i] != readAtIndex(&buf,i-8)) 
			++BAD;
	//test *AtIndex ops
	for(i=0; i<4; ++i) 
		writeCircBuf(&buf, testSRC[i]);
	for(i=7,j=3; i>=4; --i,--j) 
		if(testSRC[j] != readAtIndex(&buf,i-8)) 
			++BAD;
		writeCircBuf(&buf, testSRC[i]);
		if(testSRC[j] != readAtIndex(&buf,i-8)) 
			++BAD;
	return BAD;
}
