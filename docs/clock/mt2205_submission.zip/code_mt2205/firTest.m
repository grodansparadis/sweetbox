clear all;
frqResp = [];
M = 128;
for k=0:4*M
      %frqResp = [frqResp, (k<M) + 1*i];
       frqResp = [frqResp,  0.5*k^2 + (1+mod(k,2))*i];
end
frqResp;
impulse = abs(ifft(frqResp));
impulse = circshift(impulse',M/2)';
response = fft(impulse);
kernel = impulse(1:M).*hamming(M)';
raw_response = fft([kernel, zeros(1,1024*M-length(kernel))]);

figure(1)
subplot(3,1,1)
semilogx(frqResp)
subplot(3,1,2)
plot(impulse)
subplot(3,1,3)
plot(angle(ifft(frqResp)));

figure(2)
subplot(2,1,1)
semilogx(abs(raw_response));
subplot(2,1,2)
semilogx(angle(raw_response));