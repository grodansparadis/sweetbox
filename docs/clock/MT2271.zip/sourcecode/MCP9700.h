#ifndef MCP9700_H
#define MCP9700_H


#ifdef MCP9700_C
#define EXTERN
#else
#define EXTERN extern
#endif

EXTERN unsigned char MCP9700_get_temp(void);

#endif
