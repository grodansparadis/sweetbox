#define INTERRUPT_C
#include <p30f2012.h>
#include "FIR_Filter.h"
#include "firLPF200.h"
#include "firLPF1500.h"
#include "firLPF3000.h"
#include "firBPF.h"
#include "interrupt.h"
#include "switch_drv.h"
#include "display_drv.h"
#include "mode.h"

#define NUM_SAMPLES 16

unsigned char adintcnt;
unsigned char sampling_tmrcnt;
unsigned int ADCvalue;
unsigned int Filtered_Data[16];
unsigned int Filtered_Data1[16];
unsigned char current_filter;
unsigned int gen_tmrcnt;
static unsigned hb_flag;


void interrupt_init(void)
{
  //Interrupt config
   _NSTDIS = 1;
   _T3IF = 0;	
   _T3IE = 1;
   _ADIF = 0;
   _ADIE  =1;
   _SPI1IF = 0;
   _SPI1IE = 1;
  SPI_tx_complete = 0; 
  adintcnt = 0;
  sampling_tmrcnt = 0;
  gen_tmrcnt = 0;
  hb_flag = 0;
  current_filter = 0;
}

void wait(unsigned int tm)
{
  gen_tmrcnt = tm;
  while (gen_tmrcnt); // wait till it becomes zero
}


void set_filter(unsigned char f)
{
  current_filter = f; 
}

unsigned int get_ADC_value(void)
{
   return (ADCvalue);
}

void __attribute__((__interrupt__)) _T3Interrupt(void)
{
  static unsigned int tmc;
  static unsigned char hb; 
  static unsigned int tmp;
  _T3IF = 0;
  gen_tmrcnt--;
  
  if (system_mode !=THERM) // Don't play anything while measuring body temp
  {  
     /*Hear beat rate processing*/ 
     if (hb_flag ==0)
     {
       hb_flag = 1;
       tmc = 0;
       hb=0;
     }
     else
     {
        tmc++;
     }
     if (tmc >= 40000)
     {
        hb_flag = 0;
        hb *= 12;
        if (system_mode == VOL)
          disp_no(hb);
      }
  
  
      if (sampling_tmrcnt >15)
        sampling_tmrcnt = 0;
      sampling_tmrcnt ++;
      Filtered_Data1[sampling_tmrcnt-1] /= 	8;
      Filtered_Data[sampling_tmrcnt-1] /= 12;
      if (Filtered_Data1[sampling_tmrcnt-1]>400)
        hb++;
   
      /*Signal clipping*/
      if (Filtered_Data[sampling_tmrcnt-1]>500)
        Filtered_Data[sampling_tmrcnt-1] = 500; //upper clip
      else if (Filtered_Data[sampling_tmrcnt-1]<10) 
        Filtered_Data[sampling_tmrcnt-1] = 10;//lower clip
     
      if (current_filter == 1)
       OC1RS =Filtered_Data1[sampling_tmrcnt-1];  //Modulate PWM  
      else
       OC1RS =Filtered_Data[sampling_tmrcnt-1];  //Modulate PWM  
   }

   /*Display flashing - alternates mode and value*/
   tmp++;
  
   if (tmp > 24000)
     tmp = 0; 
   if (tmp<12000)
   {
      disp_ch(); //show mode in alphabets
   } 
   else 
   {
      disp_show(); //show the computed value
   }
   
   switch_read(); //Process switch debouncing
}

void __attribute__((__interrupt__)) _ADCInterrupt(void)
{
 unsigned int * buf_ptr; 
  unsigned char cnt;
 _ADIF = 0;
 buf_ptr = (unsigned int*)0x0280; //ADCBUF0 address
 
 
  if (system_mode == THERM)
  {
    for(cnt=0;cnt<16;cnt++)
     ADCvalue = *(buf_ptr+cnt);
    ADCvalue /= 16; //simple average filter for temp sensor
  }
  
    
   // Call BlockFIRFilter for each block of input samples
   // This routine would normally be called inside a FOR or a DO-WHILE loop
   // Only one instance has been shown
  if (system_mode != THERM)
  { 
     switch (current_filter)
     {
       case 1:
       
       break;
       case 2:
        BlockFIRFilter( &firLPF1500Filter, buf_ptr, Filtered_Data, NUM_SAMPLES );
       break;
       case 3:
        BlockFIRFilter( &firLPF3000Filter, buf_ptr, Filtered_Data, NUM_SAMPLES );
       break;
       case 4:
        BlockFIRFilter( &firBPFFilter, buf_ptr, Filtered_Data, NUM_SAMPLES );
       break;
     }
  } 
  
  BlockFIRFilter( &firLPF200Filter, buf_ptr, Filtered_Data1, NUM_SAMPLES );
  
}

void __attribute__((__interrupt__)) _SPI1Interrupt(void)
{
  _SPI1IF = 0;
  SPI_tx_complete = SPI1BUF; //Dummy read to clear RxBuf full flag
  SPI_tx_complete = 1;
}
