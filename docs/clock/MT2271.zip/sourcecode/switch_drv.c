#define SWITCH_DRV_C
#include <p30f2012.h>
#include "switch_drv.h"

#define SWITCH_DEFAULT 0
#define DEBOUNCE_TIME 50
//#define DBG 1 //Disable this fir release version

static unsigned char current_switch_state;
static unsigned char prev_switch_state;
static unsigned char debounce_ctr;
static unsigned char switch_val;

void switch_init(void)
{
  prev_switch_state = 3; //Both switches are released
  current_switch_state = prev_switch_state;
  debounce_ctr = DEBOUNCE_TIME;
  switch_val = SWITCH_DEFAULT;
}

void switch_read(void)
{
  
  if (_RF2) // Read port for SW1
   current_switch_state |= 0x01;
  else
   current_switch_state &= ~0x01;

#ifndef DBG
  if (_RC13) // Read port for SW2
   current_switch_state |= 0x02;
  else
   current_switch_state &= ~0x02; 
#endif
  
    
  if (current_switch_state != prev_switch_state)//keys have been pressed/released
  {
    debounce_ctr = 0;
    prev_switch_state = current_switch_state;
  
  }
  else if (debounce_ctr!= DEBOUNCE_TIME)
  {
     debounce_ctr++;
     if (debounce_ctr == DEBOUNCE_TIME)
     {
        if(current_switch_state&0x01) //debouced value 
        {
          switch_val |= SW1_RELEASED;
          switch_val &= ~SW1_PRESSED;
        }
        else
        {
          switch_val |= SW1_PRESSED;
          switch_val &= ~SW1_RELEASED;
        }
        
        if(current_switch_state&0x02) //debouced value 
        {
          switch_val |= SW2_RELEASED;
          switch_val &= ~SW2_PRESSED; 
        }
        else
        {
          switch_val |= SW2_PRESSED;
          switch_val &= ~SW2_RELEASED;
        }
        
      }
     
  }
  else {}
  
  
}

unsigned char switch_value(void)
{
  unsigned char temp;
  temp = switch_val;   
  if (switch_val&SW1_RELEASED)
   switch_val &= ~SW1_RELEASED;
  if (switch_val&SW2_RELEASED)
    switch_val &= ~SW2_RELEASED;
  return (temp);
}
