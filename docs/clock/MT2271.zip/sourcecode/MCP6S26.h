#ifndef MCP6S26_H
#define MCP6S26_H

#ifdef MCP6S26_C
#define EXTERN
#else
#define EXTERN extern
#endif

EXTERN void MCP6S26_init(void);
EXTERN void MCP6S26_select_channel(unsigned char);
EXTERN void MCP6S26_set_gain(unsigned char);
EXTERN unsigned char MCP6S26_get_gain(void);
#endif
