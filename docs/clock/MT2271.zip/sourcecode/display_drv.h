#ifndef DISPLAY_DRV_H
#define DISPLAY_DRV_H


#ifdef DISPLAY_DRV_C
#define EXTERN
#else
#define EXTERN extern
#endif

EXTERN void disp_show(void);
EXTERN void disp_init(void);
EXTERN void disp_no(unsigned char);
EXTERN void disp_ch(void);



#endif
