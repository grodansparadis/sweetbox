#define DISPLAY_DRV_C
#include <p30f2012.h>
#include "display_drv.h"
#include "mode.h"

/*Map 7 segments in a byte*/
/*b7 b6 b5 b4 b3 b2 b1 b0*/
/*0  G  F  E  D  C  B  A*/ 
#define SEGA 0x01
#define SEGB 0X02
#define SEGC 0X04
#define SEGD 0X08
#define SEGE 0X10
#define SEGF 0x20
#define SEGG 0X40
#define BLANK 10;
static unsigned char mux_cnt; //Multiplex count
static unsigned char no;
/*Segment map for numbers*/
const unsigned char segments[] =
{
  (SEGA|SEGB|SEGC|SEGD|SEGE|SEGF),
  (SEGB|SEGC),
  (SEGA|SEGB|SEGG|SEGE|SEGD),
  (SEGA|SEGB|SEGC|SEGD|SEGG),
  (SEGF|SEGG|SEGB|SEGC),
  (SEGA|SEGF|SEGG|SEGC|SEGD),
  (SEGA|SEGF|SEGG|SEGC|SEGD|SEGE),
  (SEGA|SEGB|SEGC),
  (SEGA|SEGB|SEGC|SEGD|SEGE|SEGF|SEGG),
  (SEGA|SEGB|SEGC|SEGD|SEGF|SEGG),
  0x00
};

/*Segment map for characters*/
const unsigned char ch_seg[] =
{
  /*HEA*/
  (SEGF|SEGE|SEGB|SEGC|SEGG),
  (SEGA|SEGF|SEGE|SEGD|SEGG),
  (SEGE|SEGF|SEGA|SEGB|SEGC|SEGG),
  /*FIL*/
  (SEGA|SEGF|SEGE|SEGG),
  (SEGF|SEGE),
  (SEGF|SEGE|SEGD),
  /*GAI*/
  (SEGA|SEGF|SEGE|SEGD|SEGC),
  (SEGE|SEGF|SEGA|SEGB|SEGC|SEGG),
  (SEGF|SEGE),
  /*tHE*/
  (SEGF|SEGE|SEGD|SEGG),
  (SEGF|SEGE|SEGB|SEGC|SEGG),
  (SEGA|SEGF|SEGE|SEGD|SEGG)
};

void disp_init(void)
{
  mux_cnt = 0;    
  no = 0;
  _LATB3 = 0;
  _LATB2 = 0;
  _LATB1 = 0; 
}

void disp_no(unsigned char n)
{
  no = n;
}

void disp_ch(void)
{
   unsigned tmp;
   
   if (mux_cnt > 2)
     mux_cnt = 0;
   tmp = system_mode*3;
   tmp = ch_seg[tmp+mux_cnt];
   _LATB4 = ((tmp >> 0)&0x01); //SegA
  _LATB5 = ((tmp >> 1)&0x01); //SegB
  _LATF5 = ((tmp >> 2)&0x01); //SegC
  _LATF4 = ((tmp >> 3)&0x01); //SegD
  _LATB9 = ((tmp >> 4)&0x01); //SegE
  _LATB7 = ((tmp >> 5)&0x01); //SegF
  _LATB6 = ((tmp >> 6)&0x01); //SegG

  
  switch (mux_cnt)
  {
    case 2:
     _LATB3 = 1;
     _LATB2 = 0;
     _LATB1 = 0; 
    break;
    case 1:
     _LATB3 = 0;
     _LATB2 = 1;
     _LATB1 = 0; 
    break;
    case 0:
     _LATB3 = 0;
     _LATB2 = 0;
     _LATB1 = 1; 
    break;
    default: break;
  }  

  mux_cnt++; 
   
}

void disp_show(void)
{
  unsigned char temp;
  
  if (mux_cnt > 2)
   mux_cnt = 0;
  
  switch (mux_cnt)
  {
    case 0:
     temp = no%10;
    break;
    case 1:
     temp = no/10;
     temp = temp%10;
    break;
    case 2:
     temp = no/100;
     temp = temp%10;
     if (temp== 0)
       temp = BLANK;
    break;
    default: break;
  }
  
  temp = segments[temp];
  
  _LATB4 = ((temp >> 0)&0x01); //SegA
  _LATB5 = ((temp >> 1)&0x01); //SegB
  _LATF5 = ((temp >> 2)&0x01); //SegC
  _LATF4 = ((temp >> 3)&0x01); //SegD
  _LATB9 = ((temp >> 4)&0x01); //SegE
  _LATB7 = ((temp >> 5)&0x01); //SegF
  _LATB6 = ((temp >> 6)&0x01); //SegG

  
  switch (mux_cnt)
  {
    case 0:
     _LATB3 = 1;
     _LATB2 = 0;
     _LATB1 = 0; 
    break;
    case 1:
     _LATB3 = 0;
     _LATB2 = 1;
     _LATB1 = 0; 
    break;
    case 2:
     _LATB3 = 0;
     _LATB2 = 0;
     _LATB1 = 1; 
    break;
    default: break;
  }  

  mux_cnt++;
}

