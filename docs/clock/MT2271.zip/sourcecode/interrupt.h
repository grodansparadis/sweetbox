#ifndef INTERRUPT_H
#define INTERRUPT_H

#ifdef INTERRUPT_C
#define EXTERN
#else
#define EXTERN extern
#endif

EXTERN void interrupt_init(void);
EXTERN unsigned char SPI_tx_complete;
EXTERN void wait(unsigned int);
EXTERN void set_filter(unsigned char);
EXTERN unsigned int get_ADC_value(void);

#endif
