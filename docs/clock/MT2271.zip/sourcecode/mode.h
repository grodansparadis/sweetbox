#ifndef MODE_H
#define MODE_H

#ifdef MODE_C
#define EXTERN
#else
#define EXTERN extern
#endif

#define VOL    0
#define FILTER 1
#define GAIN   2
#define THERM  3

EXTERN void mode_init(void);
EXTERN void mode_process(void);

EXTERN unsigned char system_mode;

#endif
