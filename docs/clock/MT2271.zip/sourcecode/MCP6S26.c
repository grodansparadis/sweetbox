#define MCP6S26_C
#include <p30f2012.h>
#include "MCP6S26.h"
#include "interrupt.h"

/*PGA commands*/
#define SET_GAIN 0x4000
#define SELECT_CHANNEL 0x4100
#define CHAN0 0x00
#define CHAN1 0x01
 
static unsigned char gain;

void MCP6S26_init(void)
{
  
  MCP6S26_select_channel(CHAN0);
  MCP6S26_set_gain(0); //Sets gain to 1
  gain = 0;   
}

unsigned char MCP6S26_get_gain(void)
{
  return (gain);
}

void MCP6S26_set_gain(unsigned char g)
{
   gain = g;
   _LATD9 = 0; //ensure chip select
   SPI1BUF = (SET_GAIN|g);
   while (SPI1STATbits.SPITBF); //wait till tx is complete;
   while (!SPI_tx_complete);
   SPI_tx_complete = 0;
   wait(50);
   _LATD9 = 1;
}

void MCP6S26_select_channel(unsigned char c)
{
  
   _LATD9 = 0; //ensure chip select
   SPI1BUF = (SELECT_CHANNEL|c);
   while (SPI1STATbits.SPITBF); //wait till tx is complete;
   while (!SPI_tx_complete);
   SPI_tx_complete = 0;
   wait(50);
  _LATD9 = 1;
}
