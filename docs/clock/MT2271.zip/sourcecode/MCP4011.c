#define MCP4011_C
#include <p30f2012.h>
#include "MCP4011.h"
#include "interrupt.h"

static unsigned char vol;

void MCP4011_init(void)
{
  MCP4011_decrement(64);
  vol = 0;
}

unsigned char MCP4011_get(void)
{
  return (vol);
}

void MCP4011_increment(unsigned char inc)
{
  
  vol = inc;
  inc *= 7;
    
  _LATD8 = 1;//UD
  wait(1);
  _LATD9 = 0;//CS
  wait(1);
  for (;inc>0;inc--) //increment
  {
    _LATD8 =0;
    wait(1);
    _LATD8 =1;
    wait(1);
  }  

  _LATD9 = 1;//CS
  wait(1);
  _LATD8 = 1; //UD
}

void MCP4011_decrement(unsigned char dec)
{
  _LATD8 = 0; //UD
  wait(1);
  _LATD9 = 0; //CS
  wait(1);
  for (;dec>0;dec--) //Decrement 
  {
    _LATD8 =1;
    wait(1);
    _LATD8 =0;
    wait(1);
  }  

  _LATD9 = 1; //CS
   wait(1);
  _LATD8=1; //UD
}
