#ifndef SWITCH_DRV_H
#define SWITCH_DRV_H

#ifdef SWITCH_DRV_C
#define EXTERN
#else
#define EXTERN extern
#endif

#define SW1_RELEASED 1 
#define SW2_RELEASED 2
#define SW1_PRESSED  4
#define SW2_PRESSED  8

EXTERN void switch_init(void);
EXTERN void switch_read(void);
EXTERN unsigned char switch_value(void);


#endif
