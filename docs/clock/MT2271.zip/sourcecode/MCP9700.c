#define MCP9700_C
#include <p30f2012.h>
#include "MCP9700.h"
#include "MCP6S26.h"
#include "interrupt.h"


unsigned char MCP9700_get_temp(void)
{
   unsigned int sens_volt;

   MCP6S26_select_channel(1); //Select temperature sensor input in the PGA mux
   sens_volt = get_ADC_value();
   sens_volt *= 1.22; //convert ADC count to millivolts
   
    //This expression calculates temp in DegC
   sens_volt -= 500; //V at 0 Deg  
   sens_volt = (sens_volt/10);
   
   //convert to Deg F
   sens_volt *= 1.8;
   sens_volt += 32;
   return (sens_volt);
   
}
