#ifndef MCP4011_H
#define MCP4011_H

#ifdef MCP4011_C
#define EXTERN
#else
#define EXTERN extern
#endif

EXTERN void MCP4011_init(void);

EXTERN void MCP4011_increment(unsigned char);

EXTERN void MCP4011_decrement(unsigned char);

EXTERN unsigned char MCP4011_get(void);

#endif
