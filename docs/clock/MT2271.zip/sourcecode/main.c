#include <p30f2012.h>
#include "interrupt.h"
#include "display_drv.h"
#include "FIR_Filter.h"
#include "firLPF200.h"
#include "firLPF1500.h"
#include "firLPF3000.h"
#include "firBPf.h"
#include "MCP6S26.h"
#include "MCP4011.h"
#include "switch_drv.h"
#include "mode.h"

/*Prototypes*/
void Reg_Init(void);



void Reg_Init(void)
{
  
   // Call the FIRFilterInit routine to zero out the delay line
   FIRFilterInit( &firLPF200Filter );
   FIRFilterInit( &firLPF1500Filter );
   FIRFilterInit( &firLPF3000Filter );
   FIRFilterInit( &firBPFFilter );
   
   
   //Peripheral disable to reduce power consumption
   _I2CMD = 1;
   _T1MD = 1;
   _OC2MD = 1;
   _IC1MD = 1;
   _IC2MD = 1;
   
   	
   
   //Ports initialization
   LATB = 0;
   TRISB = 0;
   _TRISB0 = 1; //Set as input for AN0
   
   LATF = 1;
   TRISF = 0;
   _TRISF2 = 1; //use SDI pin for switch scan
   
      
   //Port D used for CS signals
   LATD = 1;
   TRISD = 0;
   
   //Port C for switch
   _TRISC13 = 1;
   
  //Seven segment display driver init
   disp_init();
   
   //SPI init
   SPI1STATbits.SPIEN = 0;
   SPI1STATbits.SPISIDL = 1;
   SPI1CONbits.SSEN = 0;
   SPI1CONbits.FRMEN = 0;
   SPI1CONbits.SPIFSD = 0;
   SPI1CONbits.DISSDO = 0;
   SPI1CONbits.MODE16 = 1;
   SPI1CONbits.CKP = 1;
   SPI1CONbits.CKE = 0;
   SPI1CONbits.MSTEN = 1; 
   SPI1CONbits.PPRE = 0;
   SPI1CONbits.SPRE = 0;
   SPI1STATbits.SPIEN = 1; //Enable SPI module
   
     
   //ADC initialization
   ADPCFG = 0xFFFE;//AN0 is for analog.
   ADCON1 = 0;
   _FORM = 0;
   _SSRC = 2; //Trigger from timer 3
   _ADSIDL = 1;
   _ASAM = 1;
   ADCHS = 0x00; // connect AN0 to Ch0
   ADCSSL = 0;
   ADCON3 = 0;
   _ADCS = 0x3F;
   ADCON2 = 0;
   _SMPI = 0x0F; // interrupt every 16 bytes
   _ADON = 1;
  

   //Timer initialization
   T3CONbits.TON = 0;
   T3CONbits.TCS = 0;
   T3CONbits.TGATE = 0;
   T3CONbits.TSIDL = 1;
   T3CONbits.TCKPS = 2; //Set 64 prescaler
   TMR3 = 0; //Clear timer
   PR3 = 31;//8Khz
   //Timer 2 for PWM carrier generation
   T2CONbits.TON = 0;
   T2CONbits.TCS = 0;
   T2CONbits.TGATE = 0;
   T2CONbits.TSIDL = 1;
   T2CONbits.TCKPS = 0; //Set 1 prescaler
   T2CONbits.T32 = 0;
   TMR2 = 0; //Clear timer
   PR2 = 512; // 30 Khzs rate	 
   OC1RS = 256;
   OC1R = 0;
   

   //Output compare for PWM
   OC1CONbits.OCSIDL = 1;
   OC1CONbits.OCTSEL = 0;
   OC1CONbits.OCM = 0x06;
   
   interrupt_init(); //config interrupt
   
   mode_init(); 
   switch_init();  
   T3CONbits.TON = 1;
   T2CONbits.TON = 1;
 
   MCP6S26_init();
   MCP4011_init();
   MCP6S26_set_gain(1); //set mic gain to 1 
   MCP4011_increment(1); //set low volume
   

}

int main(void)
{
  unsigned char a;
  unsigned char incr;
  a = 0;
  incr=0;
  
  
  while(!_LOCK); // wait till pll is locked
  Reg_Init();
  
  while (1)
  {
     mode_process();
  }
}


