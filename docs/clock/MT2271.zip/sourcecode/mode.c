#define MODE_C
#include <p30f2012.h>
#include "mode.h"
#include "switch_drv.h"
#include "MCP4011.h"
#include "display_drv.h"
#include "interrupt.h"
#include "MCP6S26.h"
#include "MCP9700.h"


static unsigned char counter;
void mode_init(void)
{
  system_mode = VOL;
  counter = 0;
}

void mode_process(void)
{
  unsigned char switch_v; 
  
  switch_v = switch_value();
  
  if (system_mode == VOL)
  {
    counter = MCP4011_get();
    if (switch_v & SW1_RELEASED)
    {
     
      if (counter <10)
        counter++;
      MCP4011_increment(counter*7);
      
    }
    else  if (switch_v & SW2_RELEASED)
    {
       if (switch_v & SW1_PRESSED)
       {
        system_mode = FILTER;
        counter = 0;
       }
       else if (counter > 0)
       {
          counter--;
          MCP4011_decrement(counter*7);
      
       }
    }
               
  }
  else if (system_mode == FILTER)
  {
     if (switch_v & SW2_RELEASED) 
     {
        if (counter <4)
         counter++;
        else
         counter = 1;
        set_filter(counter);
        disp_no(counter);
        if (switch_v & SW1_PRESSED)
        {
          system_mode = GAIN;
          counter = 0;
        }
      }
   }
   else if (system_mode == GAIN)
   {
      counter = MCP6S26_get_gain();
      if (switch_v & SW1_RELEASED)
      {
        if (counter <7)
           counter++;  
        MCP6S26_set_gain(counter);
        disp_no(counter);
          
      }
    else  if (switch_v & SW2_RELEASED)
    {
       if (switch_v & SW1_PRESSED)
       {
        system_mode = THERM;
        counter = 0;
       }
       else if (counter > 0)
       {   
          counter--;
          MCP6S26_set_gain(counter);
          disp_no(counter);
      
       }
    }
      
   }
   else if (system_mode == THERM) 
   {
      if (switch_v & SW2_RELEASED)
      {
         if (switch_v & SW1_PRESSED)
         {
           system_mode = VOL;
           counter = 0;
         }
      }
      disp_no(MCP9700_get_temp());
   }
}
