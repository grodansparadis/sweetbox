/**********************************************************************
*Program to Test LCM Display
**********************************************************************/
#define __dsp33FJ256GP710__
#include "p33fxxxx.h"
#include <libpic30.h>
#include<spi.h>
#include <xlcd.h>
#include <stdio.h>
#include "Graph_head.h"
#include <dsp.h>

_FGS(GSS_OFF & GWRP_OFF);			//Set up for using FRC + PLL	
_FOSCSEL(FNOSC_FRCPLL & IESO_OFF);
_FOSC(FCKSM_CSECME & OSCIOFNC_ON & POSCMD_NONE);
_FWDT(FWDTEN_OFF);

unsigned int Command_6655;			//AD6655 Communication Variables
unsigned char Data_6655; 
unsigned char DAC0=0x7A,DAC1=0x5A;	//DAC0=RF Gain, DAC1=IF Gain
unsigned char size[4] = {1,2,4,8};	//For checkerboard test program
static unsigned char x=4;
char Line1[16] = "SYSTEM READY! \0";//Line 1 and 2 of LCD Display
char Line2[16], a = '\0';			//a is termination character
int Plot_Data[256];					//Data scaled to LCM Display
int	peakFrequencyBin = 0;			//Used by VectorMax 
int Keyin_Value;					//Holds last number keyed in 

extern fractcomplex sigCmpx[FFT_BLOCK_LENGTH] 	//Used CE018_FFT to set up Data & Twiddle Factor framework	
__attribute__ ((section (".ydata, data, ymemory"), 	
aligned (FFT_BLOCK_LENGTH * 2 *2)));      			

extern const fractcomplex twiddleFactors[FFT_BLOCK_LENGTH/2]	// Twiddle Factor array in Program memory 
__attribute__ ((space(auto_psv), aligned (FFT_BLOCK_LENGTH*2)));

int main(void)
{
PLLFBD = 65;					//Stuff to setup Up PLL to get Fcy=40Mhz
CLKDIVbits.PLLPOST = 0;			//M=65,N1(PRE)=3,N2(POST)=2(fcyc=Fint*M/N1N2)
CLKDIVbits.PLLPRE = 1;			//Fosc=2*Fcyc  approx 80MHz
OSCTUN = 0;
RCONbits.SWDTEN = 0;			//I probably don't need this again
while(OSCCONbits.LOCK!=1){};	//Wait for PLL to lock

Init_IO();
Init_3550();		//Setup AD3550 tuning registers
Init_LCD();			//Sets LCD up for Four Bit Mode and two lines
Init_Display();		//Set up LCM Graphics Display
DAC_Set(DAC0,DAC1);	//Set initial RF and IF gains voltages from DACS
Init_6655();		//Set up ADC registers for channel B conversion

int j = 15;			//Checkerboard the LCM Display-startup Fluff
while(j)
	{
	Write_Checkerboard(size[x]);
	__delay32(10000000);
	x++;
	j--;
	if(x>3)
	x=0;
	}

sprintf(Line2,"INPUT CTR FREQ %c",a);		//Input Center Frequency of 5MHZ BW to analyze
Update_LCD(Line1,Line2);				//Send Current Line1/2 to LCD
Keyin_Value= Get_Key();					//Input Center Freq from keypad (12 band choices for now)
PLL_3550(Keyin_Value);					//Center 3550 on center frequency of interest

while(1)				//Main ADC, FIFO fill, transfer to uP, FFT, Bit reverse,SquareMag,Display Loop
						//For now, need to reset uP to change center frequency
{
Fill_FIFO();			//Enable ADC and Fill FIFO with 65k ADC samples

fractional *p_real = &sigCmpx[0].real ; 	//Set up pointers for data array
fractcomplex *p_cmpx = &sigCmpx[0] ;

RCLK=0;	NOE=0;	NREN=0;				//Transfer data from FIFO to uP
int i;
for(i=0;i<FFT_BLOCK_LENGTH;i++)
	{
	RCLK=0; Nop();RCLK=1;
	Nop();
	*p_real =(Inport & 0x3FFF)<<2;	//Put FIFO data into upper 14 bits of data array
	*p_real = *p_real >>1;			//Keep data to <+-.5 for DSP routines (sign extends)
	*p_real++;		
	}
RCLK=0;	NREN=1;	NOE=1;				//Disable FIFO Output
	
p_real = &sigCmpx[(FFT_BLOCK_LENGTH/2)-1].real ;	// Set up pointers to convert real array to complex array
p_cmpx = &sigCmpx[FFT_BLOCK_LENGTH-2] ; 
					
for ( i = FFT_BLOCK_LENGTH; i > 0; i-- )			/* Convert the Real input sample array */
	{										   		/* to a Complex input sample array  */
	(*p_cmpx).real = (*p_real--);					/* By zeroing out the imaginary  */
	(*p_cmpx--).imag = 0x0000;						/* part of each data sample */
	}		
		
FFTComplexIP (LOG2_BLOCK_LENGTH, &sigCmpx[0], (fractcomplex *) __builtin_psvoffset(&twiddleFactors[0]), (int) __builtin_psvpage(&twiddleFactors[0]));
BitReverseComplex (LOG2_BLOCK_LENGTH, &sigCmpx[0]);
SquareMagnitudeCplx(FFT_BLOCK_LENGTH, &sigCmpx[0], &Plot_Data[0]);

int  Max_Value;
Max_Value=(int) VectorMax(FFT_BLOCK_LENGTH/2, &Plot_Data[0], &peakFrequencyBin);	//Find largest array element

unsigned long  int Scaler;			//Draw plot on LCM Display scaled to 64 levels
for(j=0;j<128;j++)		
	{
	Scaler= (unsigned long int) Plot_Data[j]*63/Max_Value;
	Plot_Data[j]=(int) Scaler;
	}

Display_Clear();
Display_Data(Plot_Data);
}
return 0;
}

