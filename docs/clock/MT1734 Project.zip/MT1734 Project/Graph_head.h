
/*******************XLCD DEFINES********************/
#define CLEAR_XLCD		0x01			/* Clears the LCD		*/
#define RETURN_CURSOR_HOME	0x02		/* Returns the cursor to the HOME position	*/

#define SD3550		LATGbits.LATG8	//DATA PIN TO MAX3550
#define CLK3550		LATGbits.LATG6	//CLOCK PIN TO MAX3550
#define CS3550		LATDbits.LATD8	//CHIP SELECT MAX3550
#define CS6655		LATAbits.LATA4	//CHIP SELECT AD6655
#define OE6655		LATGbits.LATG15	//OUTPUT ENABLE AD6655
#define SYNC		LATGbits.LATG2	//SYNC CONTROL FOR AD6655
/********DEFINES FOR SN74V293 FIFO**************/
#define NSEN  LATCbits.LATC1		//Serial enable (not used)
#define NWEN  LATCbits.LATC2		//Write enable
#define WCLK  LATCbits.LATC3		//Write clock
#define NPRS  LATCbits.LATC4		//Soft reset
#define NMRS  LATGbits.LATG7		//Master reset
#define NLD   LATAbits.LATA14		//Serial load (not used)
#define FWFT  LATCbits.LATC15		//Operating mode (plan on std mode)
#define NFF   PORTCbits.RC12		//FIFO full
#define NBE   LATFbits.LATF7		//Big endian (not used in word mode)
#define NEF   PORTGbits.RG9			//FIFO empty
#define RM    LATAbits.LATA0		//Retransmit latency (Pnot used)
#define RCLK  LATAbits.LATA12		//Read clock
#define NREN  LATAbits.LATA13		//Read enable
#define NRT   LATAbits.LATA9		//Retransmit (not used)
#define NOE   LATAbits.LATA10		//Output enable
#define Inport  PORTB				//14bit FIFO output into RB0-RB13

#define NUMBER_OF_COLUMNS 128		//LCM STUFF
#define NUMBER_OF_ROWS 64
#define NUMBER_OF_PAGES 8
#define FIRST_PAGE 0
#define FIRST_COLUMN 0
#define LAST_PAGE 7
#define LAST_COLUMN 127
#define CMD 0x01					//FLAG TO SIGNAL COMMND/DATA
#define DATA 0xFF
#define DISPLAY_ON 0xAF				//LCM COMMANDS
#define DISPLAY_OFF 0xAE
#define START_LINE_SET 0x40
#define PAGE_ADDRESS_SET 0xB0
#define COLUMN_ADDRESS_HIGH 0x10
#define COLUMN_ADDRESS_LOW 0x00
#define ADC_SELECT_NORMAL 0xA0
#define ADC_SELECT_REVERSE 0xA1
#define DISPLAY_NORMAL 0xA6
#define DISPLAY_REVERSE 0xA7
#define ALL_POINTS_ON 0xA5
#define LCD_BIAS_1_9 0xA2
#define LCD_BIAS_1_7 0xA3
#define READ_MODIFY_WRITE 0xE0
#define END 0xEE
#define RESET_DISPLAY 0xE2
#define COMMON_OUTPUT_NORMAL 0xC0
#define COMMON_OUTPUT_REVERSE 0xC8
#define POWER_CONTROL_SET 0x28
#define BOOSTER_CIRCUIT 0x04
#define VOLTAGE_REGULATOR 0x02
#define VOLTAGE_FOLLOWER 0x01
#define V5_RESISTOR_RATIO 0x26
#define ELECTRONIC_VOLUME_SET 0x81
#define ELECTRONIC_VOLUME_INIT 0x1A
#define NCS1_LCM   LATDbits.LATD13		//LCM CONTROL PINS
#define A0_LCM     LATDbits.LATD11
#define NWR_LCM    LATDbits.LATD10
#define NRD_LCM    LATDbits.LATD9
#define NRES_LCM   LATDbits.LATD12

#define No_Key     0xEE				//Keypad return if no key pressed
#define Key_Error  0xFF				//Keypad return if multi key pressed
#define All_Rows_On  0xF0			//LAT byte to drive keypad all keypad rows high

#define FFT_BLOCK_LENGTH	256   	//FFT Defines  
#define LOG2_BLOCK_LENGTH 	8
#define SAMPLING_RATE		10000	
#define FFTTWIDCOEFFS_IN_PROGMEM 

void Init_IO(void);						//Function Prototypes
void AD6655(unsigned int,unsigned char);
void DAC_Set(unsigned char,unsigned char);
void Init_3550(void);
void MAX3550(unsigned int, unsigned int);
void Init_LCD(void);
void Fill_FIFO(void);
void Update_LCD(char *Line1, char *Line2);
unsigned char Get_Key();
void Init_Display(void);
void Write_Display(unsigned char command, unsigned char data);
void Write_Checkerboard(unsigned char width);
unsigned char Read_Display(unsigned char command);
void PutsXLCD(char *) __attribute__ ((section (".libperi"))); //Lowercase puts in XLCD.h
void Display_Clear(void);
void Display_Data(int *Plot_Data);
void Init_6655(void);
void PLL_3550(int Keyin_Value);

/******************************************************
*The following comes from a special i2c.h file I found 
*at Microchip's site.  Could have used std i2c, but already
*had this working
*******************************************************/
#define PAGESIZE	32

//Low Level Functions
unsigned int IdleI2C(void);
unsigned int StartI2C(void);
unsigned int WriteI2C(unsigned char);
unsigned int StopI2C(void);
unsigned int RestartI2C(void);
unsigned int getsI2C(unsigned char*, unsigned char);
unsigned int NotAckI2C(void);
unsigned int InitI2C(void);
unsigned int ACKStatus(void);
unsigned int getI2C(void);
unsigned int AckI2C(void);
unsigned int EEAckPolling(unsigned char);
unsigned int putstringI2C(unsigned char*);

//High Level Functions for Low Density Devices
unsigned int LDByteReadI2C(unsigned char, unsigned char, unsigned char*, unsigned char);
unsigned int LDByteWriteI2C(unsigned char, unsigned char, unsigned char);
unsigned int LDPageWriteI2C(unsigned char, unsigned char, unsigned char*);
unsigned int LDSequentialReadI2C(unsigned char, unsigned char, unsigned char*, unsigned char);

//High Level Functions for High Density Devices
unsigned int HDByteReadI2C(unsigned char, unsigned char, unsigned char, unsigned char*, unsigned char);
unsigned int HDByteWriteI2C(unsigned char, unsigned char, unsigned char, unsigned char);
unsigned int HDPageWriteI2C(unsigned char, unsigned char, unsigned char, unsigned char*);
unsigned int HDSequentialReadI2C(unsigned char, unsigned char, unsigned char, unsigned char*, unsigned char);

