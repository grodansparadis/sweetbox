#include "p33fxxxx.h"
#include "Graph_head.h"
#include <libpic30.h>
#include<spi.h>
#include <xlcd.h>
#include <stdio.h>

/******************************************
*Initilizes IO PortsDirections and starting values
*Input-None, Outputs-None
******************************************/
void Init_IO(void)
{
	TRISGbits.TRISG8 = 0;		//3550 data
	TRISGbits.TRISG6 = 0;		//3550 clock
	TRISDbits.TRISD8 = 0;		//3550 CS
	TRISAbits.TRISA1 = 0;		//test pin
	TRISAbits.TRISA2 = 1;		//DAC I2C Clock
	TRISAbits.TRISA3 = 1;		//DAC I2C Data
	TRISAbits.TRISA4 = 0;		//6655 CS
	TRISFbits.TRISF6 = 0;		//6655 clock
	TRISFbits.TRISF8 = 0;		//6655 data
	TRISGbits.TRISG15 = 0;		//OE 6655
	TRISGbits.TRISG2 = 0;		//AD6655 SYNC

	TRISCbits.TRISC1 = 0;		//SN74V293 Control pins
	TRISCbits.TRISC2 = 0;
	TRISCbits.TRISC3 = 0;		//****Output for now
	TRISCbits.TRISC4 = 0;
	TRISGbits.TRISG7 = 0;
	TRISAbits.TRISA14 = 0;
	TRISCbits.TRISC15 = 0;
	TRISCbits.TRISC12 = 1;
	TRISFbits.TRISF7 = 0;
	TRISGbits.TRISG9 = 1;
	TRISAbits.TRISA0 = 0;
	TRISAbits.TRISA12 = 0;
	TRISAbits.TRISA13 = 0;
	TRISAbits.TRISA9 = 0;
	TRISAbits.TRISA10 = 0;
	TRISB = 0xFFFF;				//PORTB is input port

	TRISDbits.TRISD13 = 0;		//LCM CONTROL PINS
	TRISDbits.TRISD11 = 0;
	TRISDbits.TRISD10 = 0;
	TRISDbits.TRISD9  = 0;
	TRISDbits.TRISD12 = 0;

	CS3550 = 1;				//MAX3550 CS disable
	CLK3550 = 0;			//MAX3550 Clocks init
	CS6655 = 1;				//AD6655 CS init 
	OE6655 = 1;				//AD6655 Output Disable
	SYNC = 0;				//AD6655 SYNC Control

	AD1PCFGL = 0xFFFF;		//PORTB IS DIGITAL
	AD2PCFGL = 0xFFFF;
	AD1PCFGH = 0xFFFF;

/****INITIALIZE THE CONTROL PINS TO SN74V293****/
	NMRS = 1; NPRS = 1; NSEN = 1; NWEN = 1; WCLK = 0; NLD = 1;	
	FWFT = 0; NBE = 1; RM = 0; RCLK = 0; NREN = 1; NOE = 1; NRT = 1;
	WCLK = 0;

	NCS1_LCM = 1; A0_LCM = 1; NWR_LCM = 1; NRD_LCM = 1; NRES_LCM= 1;	//LCM CONTROL ALL HIGH
}

/**********************************
*Set DAC Outputs 
*Inputs-DAC0=RFGain,DAC1=IFGain
*Outputs-None
**********************************/
void DAC_Set(unsigned char DAC0,unsigned char DAC1)
{
	unsigned char ControlByte,LowByte,HighByte;	//DAC Variables
	InitI2C();			//Initialise the I2C(1) Peripheral
	HighByte=DAC0>>4;	//xxxxDAC0upper:DAC0lowerxxxx
	LowByte=DAC0<<4;			
	ControlByte = 0x18; 	//Talks to A0=0 DAC (RF Gain)
	LDByteWriteI2C(ControlByte, HighByte,  LowByte);
	__delay32(4000);		//About 100usec
	HighByte=DAC1>>4;
	LowByte=DAC1<<4;
	ControlByte = 0x1A;		//Talks to A0=1 DAC (IF Gain)
	LDByteWriteI2C(ControlByte, HighByte, LowByte);	
	Nop();
	__delay32(4000);
}

/**********************************************
*WRITING COMMANDS OR DATA TO LCM DISPLAY
*INPUTS=CMD FOR COMMAND AND DATA FOR DATA
*OUTPUTS=NONE
**********************************************/
void Write_Display(unsigned char command, unsigned char data)
{
	TRISD=TRISD & 0XFF00; 		//LOWER 8 BITS OF PORTD ARE OUTPUTS
	if(command==CMD)
		A0_LCM=0;
	else
		A0_LCM=1;
	NCS1_LCM=0;
	NWR_LCM=0;
	LATD=(LATD & 0xFF00) | data;
	__delay32(11);
	NWR_LCM=1;
	NCS1_LCM=1;
	TRISD=TRISD | 0X00FF; 		//LOWER 8 BITS OF PORTD ARE INPUTS
}
/**********************************************
*WRITING COMMANDS OR DATA TO LCM DISPLAY
*INPUTS=CMD FOR COMMAND AND DATA FOR DATA
*OUTPUTS=NONE
**********************************************/
unsigned char Read_Display(unsigned char command)
{
	unsigned char return_byte;
	TRISD=TRISD | 0X00FF; 		//LOWER 8 BITS OF PORTD ARE inputs
	Nop();
	if(command==CMD)
		A0_LCM=0;
	else
		A0_LCM=1;
	Nop();
	NCS1_LCM=0;
	NRD_LCM=0;
	__delay32(11);
	NRD_LCM=1;
	return_byte = PORTD & 0x00FF;
	Nop();
	NCS1_LCM=1;
	Nop();
	TRISD=TRISD & 0XFF00; 		//LOWER 8 BITS OF PORTD ARE OUTPUTS
	Nop();
	return(return_byte);

}
/******************************************************************************
This performs all of the necessary initialization of the SED-1565 controller
inside the Optrex display.
******************************************************************************/
void Init_Display(void)
{
NRES_LCM=0; /* Hold the display in reset. */
__delay32(80000);
NRES_LCM=1; /* Release the display in reset. */
__delay32(9000);
Write_Display(CMD,LCD_BIAS_1_9);
Write_Display(CMD,ADC_SELECT_REVERSE);
Write_Display(CMD,COMMON_OUTPUT_NORMAL);
Write_Display(CMD,V5_RESISTOR_RATIO);
Write_Display(CMD,ELECTRONIC_VOLUME_SET);
Write_Display(CMD,ELECTRONIC_VOLUME_INIT);
Write_Display(CMD,(POWER_CONTROL_SET | VOLTAGE_REGULATOR |
VOLTAGE_FOLLOWER | BOOSTER_CIRCUIT));
Write_Display(CMD,DISPLAY_ON);
};
/******************************************************************************
** Write_Checkerboard **************************************** MKO 14JUN01 ****
*******************************************************************************
This generates a checkerboard test pattern across the entire display. The size
of the square is passed to the routine. The routine requires that the checker
size be an integer multiple of a single page (i.e. 1, 2, 4, or 8 pixels)
Usage Examples:
Write_Checkerboard(4);
******************************************************************************/
void Write_Checkerboard(unsigned char width)
{
unsigned char i,j,page,pattern;
/* Determine the pattern for the appropriately sized checkerboard. If the
desired width is not a legitimate value of 1, 2, 4, or 8, it will be sized
to 8 by default. */
switch(width)
{
case 1:
pattern = 0x55;
break;
case 2:
pattern = 0x33;
break;
case 4:
pattern = 0x0F;
break;
default:
width = 8;
pattern = 0x00;
};
/* Initialize the column address to zero and allow the auto increment to
move the column address after each write. */

for(page=0;page<NUMBER_OF_PAGES;page++)
{
Write_Display(CMD,START_LINE_SET);
Write_Display(CMD,PAGE_ADDRESS_SET + page);
Write_Display(CMD,COLUMN_ADDRESS_HIGH);
Write_Display(CMD,COLUMN_ADDRESS_LOW);
/* If the width is eight, then complement the pattern every other
page. This is a special case since the pattern for a single square
occupies the entire page. */
if(width == 8)
pattern = ~pattern;
for(i=0;i<NUMBER_OF_COLUMNS/width;i++)
{
for(j=0;j<width;j++)
Write_Display(DATA,pattern);
pattern = ~pattern;
};
Nop();
};
Nop();
/* Turn on the display to see the new checkerboard. */
Write_Display(CMD,DISPLAY_ON);
Nop();
};

/******************************************
*Routine to clear LCM Display
*******************************************/
void Display_Clear(void)
{
unsigned char i,page,pattern;
pattern=0x00;
for(page=0;page<NUMBER_OF_PAGES;page++)
	{
	Write_Display(CMD,START_LINE_SET);
	Write_Display(CMD,PAGE_ADDRESS_SET + page);
	Write_Display(CMD,COLUMN_ADDRESS_HIGH);
	Write_Display(CMD,COLUMN_ADDRESS_LOW);
	for(i=0;i<NUMBER_OF_COLUMNS;i++)
		Write_Display(DATA,pattern);	
	}
};

/*******************************************
*Routine to Plot data to LCM
*ptr points to array to plot
*The 128 values in array have magnitudes 0 to 63
*******************************************/
void Display_Data(int *ptr)
{
int temp,*ptrr;
unsigned char i,j,page,pattern;
ptrr=ptr;						//save pointer to start of array
for(j=NUMBER_OF_PAGES;j>0;j--)
	{
	ptrr=ptr;						//reset pointer to start of plot data array
	Write_Display(CMD,START_LINE_SET);			//Set starting line to top left
	Write_Display(CMD,COLUMN_ADDRESS_HIGH);		//Set starting column to 0=far left
	Write_Display(CMD,COLUMN_ADDRESS_LOW);
	page=PAGE_ADDRESS_SET + j - 1;				//Concatenates instruction + page number
	Write_Display(CMD,page);					//Tell Display what page
	for(i=0;i<NUMBER_OF_COLUMNS;i++)
		{
		temp = 8-*ptrr/NUMBER_OF_PAGES;
		if(j> temp)
		 pattern=0xFF;	//turn on display bits below data point
		if(j< temp)
		 pattern=0x00;	//Turn off bits above data point
		if(j == temp)
			{
			temp= *ptrr % NUMBER_OF_PAGES;					//Remainder tells what how high up page to turn on 
			switch (temp)								//to get to data point				
			{
			case 0:pattern=0x80;break;
			case 1:pattern=0xC0;break; 
			case 2:pattern=0xE0;break; 
			case 3:pattern=0xF0;break;
			case 4:pattern=0xF8;break; 
			case 5:pattern=0xFC;break; 
			case 6:pattern=0xFE;break; 
			case 7:pattern=0xFF;break;
			default:pattern=0xAA;
			};
			}
		Write_Display(DATA,pattern);			//Write 8 bit vertical patern in col x/page y
		ptrr++;
		}
}
}


/******************************************
*Sends 16bit command and 8 bit data to 6655
*Inputs-Command_6655,Data_6655
*Outputs-None
******************************************/
void AD6655(unsigned int Command_6655,unsigned char Data_6655)
{
	unsigned int config1,config2,config3;	//Used to config SPI
	CS6655 = 1;					//Disable 6655
	CloseSPI1();				//Turn off SP1
    config1 = ENABLE_SDO_PIN &	//Configuration of SP1 to send 16bits
	SPI_MODE16_ON &				
	SPI_SMP_OFF &
	SPI_CKE_ON &
	SLAVE_ENABLE_OFF &
	CLK_POL_ACTIVE_HIGH &
	MASTER_ENABLE_ON &
	SEC_PRESCAL_7_1 &
	PRI_PRESCAL_64_1;

	config2 = FRAME_ENABLE_OFF&
	FRAME_SYNC_OUTPUT & 
	FRAME_POL_ACTIVE_HIGH &
	FRAME_SYNC_EDGE_COINCIDE;

	config3 = SPI_ENABLE &
	SPI_IDLE_CON &
	SPI_RX_OVFLOW_CLR;

	OpenSPI1(config1, config2, config3);	//Send to SP1 module

	CS6655 = 0;					//Enable 6655
    WriteSPI1(Command_6655);	//Send AD6655 16bit command
	__delay32(8000);			//About 200usec for 16bits
	CloseSPI1();

    config1 = ENABLE_SDO_PIN &	//Configure SP1 to send 8 bits
	SPI_MODE16_OFF &			
	SPI_SMP_OFF &
	SPI_CKE_ON &
	SLAVE_ENABLE_OFF &
	CLK_POL_ACTIVE_HIGH &
	MASTER_ENABLE_ON &
	SEC_PRESCAL_7_1 &
	PRI_PRESCAL_64_1;

	OpenSPI1(config1, config2, config3);

	WriteSPI1(Data_6655);		//Send Data to 6655
	__delay32(4000);
	CS6655 = 1;					//Deselect the 6655
	__delay32(40000);
	CloseSPI1();	
}


/************************************
*Initialize various MAX3550 registers
*Input=None,outputs=None
************************************/
void Init_3550()
{
unsigned int Value[9],i;	//MAX3550 setup variables
/*flo1=flo2+45MHz+freq of interest*/
	Value[0] = 0x04;		/*VC1N=1240MHz fcomp=1Mhz*/
	Value[1] = 0xD8;
	Value[2] = 4;			/*VC1R*/
	Value[3] = 0x1B;		/*VC2N=7082=1180.33Mhz fcomp=166.333kHz*/
	Value[4] = 0xAA;
	Value[5] = 24;			/*VC2R*/
	Value[6] = 0x05;		/*Set*/
	Value[7] = 0x00;		/*Test*/
	Value[8] = 0x15;		/*HiIF*/

for(i=0; i<9; i++)
	{
	MAX3550(i,Value[i]);	//Send 12bits to MAX3550
	}
}
/***********************************
*Concatenates address:data into 12 bitword
*Inputs-Address, Data
*Output-None
***********************************/
void MAX3550(unsigned int ADD_3550,unsigned int DATA_3550)
{
	unsigned int j,OUT12BIT;		// Out12BIT is MAX3550 12bit address+data
	OUT12BIT=((ADD_3550<<8) & 0x0FFF) | DATA_3550;	//Forms 12bit ADD:Value
	__delay32(100);
	CS3550=0;
	__delay32(100);
	j=0;
	while(j<12)
	{
		if(OUT12BIT & 0x0800)	/*Look at next bit to transfer to 3550*/
			SD3550=1;
		else
			SD3550=0;
		CLK3550=1;				/*Send next bit to 3550*/
		__delay32(100);		
		CLK3550=0;
		__delay32(100);
		OUT12BIT=OUT12BIT<<1;	/*Move next bit to send into position for testing*/
		j=j+1;
	}
	CS3550=1;					/*Latch into 3550*/	
}
/**************************************************
*Routine to send current two lines to LCD Display
*Inputs=pointers to start of 16 element line arrays
****************************************************/
void Update_LCD(char *Line1, char *Line2)
{
	WriteCmdXLCD(CLEAR_XLCD);
	__delay32(1000000);
	WriteCmdXLCD(RETURN_CURSOR_HOME);
	__delay32(1000000);
    PutsXLCD(Line1);		//Sends Line1 to LCD
    while(BusyXLCD()); 
    SetDDRamAddr(0x40);		//Sets DDram to start of second line
    while(BusyXLCD()); 
    PutsXLCD(Line2);		//Sends Line2 to LCD
    while(BusyXLCD());
	WriteCmdXLCD(RETURN_CURSOR_HOME);
	while(BusyXLCD());
}

/***************************************
*Routine to fill FIFO with AD6655 output samples
*Inputs-None
*Outputs-None
***************************************/
void Fill_FIFO(void)
{
	NMRS=1;NMRS=0;NMRS=1;	//MASTER RESET
	while(NEF);				//WAIT FOR FIFI EMPTY SIGNAL
	OE6655=0;				//ENABLE AD6655 OUTPUT
	__delay32(10000);			//Let AD6655 output stabilize
	NWEN=0;					//WRITE ENABLE THE FIFO
	while(NFF);				//WAIT FOR FIFO FULL SIGNAL
	NWEN=1;					//WRITE DISABLE FIFO
	OE6655=1;				//DISABLE AD6655 OUTPUT
}
/**************************************
*Sets LCD display up for four bit mode and 2 line
*Inputs-None
*Outputs-None
**************************************/
void Init_LCD(void)
{
    OpenXLCD(FOUR_BIT & TWO_LINE & SEG1_50_SEG51_100 & COM1_COM16);
    while(BusyXLCD());
	__delay32(1000000);
    WriteCmdXLCD(DON & CURSOR_OFF & BLINK_OFF);
	__delay32(1000000);
	WriteCmdXLCD(CLEAR_XLCD);
	__delay32(1000000);
	WriteCmdXLCD(RETURN_CURSOR_HOME);
	__delay32(1000000);
}
/***********************************
*Routine to find out which key is pressed
*Inputs-None
*Output=Key value 0,1,..9,10=*,11=#
*      =EE if no key pressed
*	   =FF if multi keys pressed
************************************/
unsigned char Get_Key(void)
{
unsigned char Row,Col,Row_Mask,Col_Mask;	//Keypad polling variables
TRISE = 0x0F;		//Upper nibble drive rows, lower nibble read columns
LATE = All_Rows_On;	//Drive rows high

__delay32(100);
if((PORTE & 0x0E)==0)	//If button pushed one of the 3 col will be high
	return(0xEE);
else
	__delay32(800000); //debounce for 20msec
Col=Row=1;			//key search cycles through 1 row and 1 column at a time
Row_Mask=0x80;
for(Row=1;Row<5;Row++)
	{
	Col_Mask=0x08;
	for(Col=1;Col<4;Col++)
		{
		LATE=Row_Mask;  //Drive next row high
		__delay32(100);
		if((PORTE & Col_Mask)==Col_Mask)  //Is this column being driven high?
			goto Key_Calc;				 //Yes so go calculate key key value
		else
		Col_Mask=Col_Mask>>1;		//Move mask bit to drive next column
		}
	Row_Mask=Row_Mask>>1;			//Move mask bit to drive next row
	}
Key_Calc:
while(PORTE & 0x0E);				//Wait for key release
__delay32(800000);					//Debounce
switch((Row<<4) | Col)				//Concatenate Row:Col
{
case 0x11:return(1); case 0x12:return(2); case 0x13:return(3);
case 0x21:return(4); case 0x22:return(5); case 0x23:return(6);
case 0x31:return(7); case 0x32:return(8); case 0x33:return(9);
case 0x41:return(10); case 0x42:return(0); case 0x43:return(11);
default : return(0xFF); break;
}
}

/*********************************************************************
* Function:        InitI2C()
*
* Input:		None.
*
* Output:		None.
*
* Overview:		Initialises the I2C(1) peripheral
*
* Note:			Sets up Master mode, No slew rate control, 100Khz
********************************************************************/
unsigned int InitI2C(void)
{	
	//This function will initialize the I2C(1) peripheral.
	//First set the I2C(1) BRG Baud Rate.

	//Consult the dSPIC Data Sheet for information on how to calculate the
	//Baud Rate.

	I2C2BRG = 272; 

	//Now we will initialise the I2C peripheral for Master Mode, No Slew Rate
	//Control, and leave the peripheral switched off.
	
	I2C2CON = 0x1200;
	
	I2C2RCV = 0x0000;
	I2C2TRN = 0x0000;
	//Now we can enable the peripheral
	
	I2C2CON = 0x9200;
	return 0;
}


/*********************************************************************
* Function:        StartI2C()
*
* Input:		None.
*
* Output:		None.
*
* Overview:		Generates an I2C Start Condition
*
* Note:			None
********************************************************************/
unsigned int StartI2C(void)
{
	//This function generates an I2C start condition and returns status 
	//of the Start.

	I2C2CONbits.SEN = 1;		//Generate Start COndition
	while (I2C2CONbits.SEN);	//Wait for Start COndition
	//return(I2C2STATbits.S);	//Optionally return status
	return 0;
}


/*********************************************************************
* Function:        RestartI2C()
*
* Input:		None.
*
* Output:		None.
*
* Overview:		Generates a restart condition and optionally returns status
*
* Note:			None
********************************************************************/
unsigned int RestartI2C(void)
{
	//This function generates an I2C Restart condition and returns status 
	//of the Restart.

	I2C2CONbits.RSEN = 1;		//Generate Restart		
	while (I2C2CONbits.RSEN);	//Wait for restart	
	//return(I2C2STATbits.S);	//Optional - return status
	return 0;
}


/*********************************************************************
* Function:        StopI2C()
*
* Input:		None.
*
* Output:		None.
*
* Overview:		Generates a bus stop condition
*
* Note:			None
********************************************************************/
unsigned int StopI2C(void)
{
	//This function generates an I2C stop condition and returns status 
	//of the Stop.

	I2C2CONbits.PEN = 1;		//Generate Stop Condition
	while (I2C2CONbits.PEN);	//Wait for Stop
	//return(I2C2STATbits.P);	//Optional - return status
	return 0;
}


/*********************************************************************
* Function:        WriteI2C()
*
* Input:		Byte to write.
*
* Output:		None.
*
* Overview:		Writes a byte out to the bus
*
* Note:			None
********************************************************************/
unsigned int WriteI2C(unsigned char byte)
{
	//This function transmits the byte passed to the function
	//while (I2C2STATbits.TRSTAT);	//Wait for bus to be idle
	I2C2TRN = byte;					//Load byte to I2C2 Transmit buffer
	while (I2C2STATbits.TBF);		//wait for data transmission
	return 0;

}


/*********************************************************************
* Function:        IdleI2C()
*
* Input:		None.
*
* Output:		None.
*
* Overview:		Waits for bus to become Idle
*
* Note:			None
********************************************************************/
unsigned int IdleI2C(void)
{
	while (I2C2STATbits.TRSTAT);		//Wait for bus Idle
	return 0;
}


/*********************************************************************
* Function:        LDByteWriteI2C()
*
* Input:		Control Byte, 8 - bit address, data.
*
* Output:		None.
*
* Overview:		Write a byte to low density device at address LowAdd
*
* Note:			None
********************************************************************/
unsigned int LDByteWriteI2C(unsigned char ControlByte, unsigned char LowAdd, unsigned char data)
{
	unsigned int ErrorCode;

	IdleI2C();						//Ensure Module is Idle
	StartI2C();						//Generate Start COndition
	WriteI2C(ControlByte);			//Write Control byte
	IdleI2C();

	ErrorCode = ACKStatus();		//Return ACK Status
	
	WriteI2C(LowAdd);				//Write Low Address
	IdleI2C();

	ErrorCode = ACKStatus();		//Return ACK Status

	WriteI2C(data);					//Write Data
	IdleI2C();
	StopI2C();						//Initiate Stop Condition
/*	EEAckPolling(ControlByte);		//Perform ACK polling*/
	return(ErrorCode);
}


/*********************************************************************
* Function:        LDByteReadI2C()
*
* Input:		Control Byte, Address, *Data, Length.
*
* Output:		None.
*
* Overview:		Performs a low density read of Length bytes and stores in *Data array
*				starting at Address.
*
* Note:			None
********************************************************************/
unsigned int LDByteReadI2C(unsigned char ControlByte, unsigned char Address, unsigned char *Data, unsigned char Length)
{
	IdleI2C();					//wait for bus Idle
	StartI2C();					//Generate Start Condition
	WriteI2C(ControlByte);		//Write Control Byte
	IdleI2C();					//wait for bus Idle
	WriteI2C(Address);			//Write start address
	IdleI2C();					//wait for bus Idle

	RestartI2C();				//Generate restart condition
	WriteI2C(ControlByte | 0x01);	//Write control byte for read
	IdleI2C();					//wait for bus Idle

	getsI2C(Data, Length);		//read Length number of bytes
	NotAckI2C();				//Send Not Ack
	StopI2C();					//Generate Stop
	return 0;
}


/*********************************************************************
* Function:        HDByteWriteI2C()
*
* Input:		ControlByte, HighAddr, LowAddr, Data.
*
* Output:		None.
*
* Overview:		perform a high density byte write of data byte, Data.
*				starting at the address formed from HighAdd and LowAdd
*
* Note:			None
********************************************************************/
unsigned int HDByteWriteI2C(unsigned char ControlByte, unsigned char HighAdd, unsigned char LowAdd, unsigned char data)
{
	unsigned int ErrorCode;

	IdleI2C();						//Ensure Module is Idle
	StartI2C();						//Generate Start COndition
	WriteI2C(ControlByte);			//Write Control byte
	IdleI2C();

	ErrorCode = ACKStatus();		//Return ACK Status
	
	WriteI2C(HighAdd);
	IdleI2C();						//Write High Address
	WriteI2C(LowAdd);				//Write Low Address
	IdleI2C();

	ErrorCode = ACKStatus();		//Return ACK Status

	WriteI2C(data);					//Write Data
	IdleI2C();
	StopI2C();						//Initiate Stop Condition
	EEAckPolling(ControlByte);		//perform Ack Polling
	return(ErrorCode);
}


/*********************************************************************
* Function:        HDByteReadI2C()
*
* Input:		Control Byte, HighAdd, LowAdd, *Data, Length.
*
* Output:		None.
*
* Overview:		Performs a low density read of Length bytes and stores in *Data array
*				starting at Address formed from HighAdd and LowAdd.
*
* Note:			None
********************************************************************/
unsigned int HDByteReadI2C(unsigned char ControlByte, unsigned char HighAdd, unsigned char LowAdd, unsigned char *Data, unsigned char Length)
{
	IdleI2C();						//Wait for bus Idle
	StartI2C();						//Generate Start condition
	WriteI2C(ControlByte);			//send control byte for write
	IdleI2C();						//Wait for bus Idle

	WriteI2C(HighAdd);				//Send High Address
	IdleI2C();						//Wait for bus Idle
	WriteI2C(LowAdd);				//Send Low Address
	IdleI2C();						//Wait for bus Idle

	RestartI2C();					//Generate Restart
	WriteI2C(ControlByte | 0x01);	//send control byte for Read
	IdleI2C();						//Wait for bus Idle

	getsI2C(Data, Length);			//Read Length number of bytes to Data
	NotAckI2C();					//send Not Ack
	StopI2C();						//Send Stop Condition
	return(0);
}


/*********************************************************************
* Function:        LDPageWriteI2C()
*
* Input:		ControlByte, LowAdd, *wrptr.
*
* Output:		None.
*
* Overview:		Write a page of data from array pointed to be wrptr
*				starting at LowAdd
*
* Note:			LowAdd must start on a page boundary
********************************************************************/
unsigned int LDPageWriteI2C(unsigned char ControlByte, unsigned char LowAdd, unsigned char *wrptr)
{
	IdleI2C();					//wait for bus Idle
	StartI2C();					//Generate Start condition
	WriteI2C(ControlByte);		//send controlbyte for a write
	IdleI2C();					//wait for bus Idle
	WriteI2C(LowAdd);			//send low address
	IdleI2C();					//wait for bus Idle
	putstringI2C(wrptr);		//send data
	IdleI2C();					//wait for bus Idle
	StopI2C();					//Generate Stop
	return(0);
}


/*********************************************************************
* Function:        HDPageWriteI2C()
*
* Input:		ControlByte, HighAdd, LowAdd, *wrptr.
*
* Output:		None.
*
* Overview:		Write a page of data from array pointed to be wrptr
*				starting at address from HighAdd and LowAdd
*
* Note:			Address must start on a page boundary
********************************************************************/
unsigned int HDPageWriteI2C(unsigned char ControlByte, unsigned char HighAdd, unsigned char LowAdd, unsigned char *wrptr)
{
	IdleI2C();				//wait for bus Idle
	StartI2C();				//Generate Start condition
	WriteI2C(ControlByte);	//send controlbyte for a write
	IdleI2C();				//wait for bus Idle
	WriteI2C(HighAdd);		//send High Address
	IdleI2C();				//wait for bus Idle
	WriteI2C(LowAdd);		//send Low Address
	IdleI2C();				//wait for bus Idle
	putstringI2C(wrptr);	//Send data
	IdleI2C();				//wait for bus Idle
	StopI2C();				//Generate a stop
	return(0);
}


/*********************************************************************
* Function:        LDSequentialReadI2C()
*
* Input:		ControlByte, address, *rdptr, length.
*
* Output:		None.
*
* Overview:		Performs a sequential read of length bytes starting at address
*				and places data in array pointed to by *rdptr
*
* Note:			None
********************************************************************/
unsigned int LDSequentialReadI2C(unsigned char ControlByte, unsigned char address, unsigned char *rdptr, unsigned char length)
{
	IdleI2C();						//Ensure Module is Idle
	StartI2C();						//Initiate start condition
	WriteI2C(ControlByte);			//write 1 byte
	IdleI2C();						//Ensure module is Idle
	WriteI2C(address);				//Write word address
	IdleI2C();						//Ensure module is idle
	RestartI2C();					//Generate I2C Restart Condition
	WriteI2C(ControlByte | 0x01);	//Write 1 byte - R/W bit should be 1 for read
	IdleI2C();						//Ensure bus is idle
	getsI2C(rdptr, length);			//Read in multiple bytes
	NotAckI2C();					//Send Not Ack
	StopI2C();						//Send stop condition
	return(0);
}


/*********************************************************************
* Function:        HDSequentialReadI2C()
*
* Input:		ControlByte, HighAdd, LowAdd, *rdptr, length.
*
* Output:		None.
*
* Overview:		Performs a sequential read of length bytes starting at address
*				and places data in array pointed to by *rdptr
*
* Note:			None
********************************************************************/
unsigned int HDSequentialReadI2C(unsigned char ControlByte, unsigned char HighAdd, unsigned char LowAdd, unsigned char *rdptr, unsigned char length)
{
	IdleI2C();						//Ensure Module is Idle
	StartI2C();						//Initiate start condition
	WriteI2C(ControlByte);			//write 1 byte
	IdleI2C();						//Ensure module is Idle
	WriteI2C(HighAdd);				//Write High word address
	IdleI2C();						//Ensure module is idle
	WriteI2C(LowAdd);				//Write Low word address
	IdleI2C();						//Ensure module is idle
	RestartI2C();					//Generate I2C Restart Condition
	WriteI2C(ControlByte | 0x01);	//Write 1 byte - R/W bit should be 1 for read
	IdleI2C();						//Ensure bus is idle
	getsI2C(rdptr, length);			//Read in multiple bytes
	NotAckI2C();					//Send Not Ack
	StopI2C();						//Send stop condition
	return(0);
}


/*********************************************************************
* Function:        ACKStatus()
*
* Input:		None.
*
* Output:		Acknowledge Status.
*
* Overview:		Return the Acknowledge status on the bus
*
* Note:			None
********************************************************************/
unsigned int ACKStatus(void)
{
	return (!I2C2STATbits.ACKSTAT);		//Return Ack Status
}


/*********************************************************************
* Function:        NotAckI2C()
*
* Input:		None.
*
* Output:		None.
*
* Overview:		Generates a NO Acknowledge on the Bus
*
* Note:			None
********************************************************************/
unsigned int NotAckI2C(void)
{
	I2C2CONbits.ACKDT = 1;			//Set for NotACk
	I2C2CONbits.ACKEN = 1;
	while(I2C2CONbits.ACKEN);		//wait for ACK to complete
	I2C2CONbits.ACKDT = 0;			//Set for NotACk
	return 0;
}


/*********************************************************************
* Function:        AckI2C()
*
* Input:		None.
*
* Output:		None.
*
* Overview:		Generates an Acknowledge.
*
* Note:			None
********************************************************************/
unsigned int AckI2C(void)
{
	I2C2CONbits.ACKDT = 0;			//Set for ACk
	I2C2CONbits.ACKEN = 1;
	while(I2C2CONbits.ACKEN);		//wait for ACK to complete
	return 0;
}


/*********************************************************************
* Function:       getsI2C()
*
* Input:		array pointer, Length.
*
* Output:		None.
*
* Overview:		read Length number of Bytes into array
*
* Note:			None
********************************************************************/
unsigned int getsI2C(unsigned char *rdptr, unsigned char Length)
{
	while (Length --)
	{
		*rdptr++ = getI2C();		//get a single byte
		
		if(I2C2STATbits.BCL)		//Test for Bus collision
		{
			return(-1);
		}

		if(Length)
		{
			AckI2C();				//Acknowledge until all read
		}
	}
	return(0);
}


/*********************************************************************
* Function:        getI2C()
*
* Input:		None.
*
* Output:		contents of I2C2 receive buffer.
*
* Overview:		Read a single byte from Bus
*
* Note:			None
********************************************************************/
unsigned int getI2C(void)
{
	I2C2CONbits.RCEN = 1;			//Enable Master receive
	Nop();
	while(!I2C2STATbits.RBF);		//Wait for receive bufer to be full
	return(I2C2RCV);				//Return data in buffer
}


/*********************************************************************
* Function:        EEAckPolling()
*
* Input:		Control byte.
*
* Output:		error state.
*
* Overview:		polls the bus for an Acknowledge from device
*
* Note:			None
********************************************************************/
unsigned int EEAckPolling(unsigned char control)
{
	IdleI2C();				//wait for bus Idle
	StartI2C();				//Generate Start condition
	
	if(I2C2STATbits.BCL)
	{
		return(-1);			//Bus collision, return
	}

	else
	{
		if(WriteI2C(control))
		{
			return(-3);		//error return
		}

		IdleI2C();			//wait for bus idle
		if(I2C2STATbits.BCL)
		{
			return(-1);		//error return
		}

		while(ACKStatus())
		{
			RestartI2C();	//generate restart
			if(I2C2STATbits.BCL)
			{
				return(-1);	//error return
			}

			if(WriteI2C(control))
			{
				return(-3);
			}

			IdleI2C();
		}
	}
	StopI2C();				//send stop condition
	if(I2C2STATbits.BCL)
	{
		return(-1);
	}
	return(0);
}


/*********************************************************************
* Function:        putstringI2C()
*
* Input:		pointer to array.
*
* Output:		None.
*
* Overview:		writes a string of data upto PAGESIZE from array
*
* Note:			None
********************************************************************/
unsigned int putstringI2C(unsigned char *wrptr)
{
	unsigned char x;

	for(x = 0; x < PAGESIZE; x++)		//Transmit Data Until Pagesize
	{	
		if(WriteI2C(*wrptr))			//Write 1 byte
		{
			return(-3);				//Return with Write Collision
		}
		IdleI2C();					//Wait for Idle bus
		if(I2C2STATbits.ACKSTAT)
		{
			return(-2);				//Bus responded with Not ACK
		}
		wrptr++;
	}
	return(0);
}
/***********************************************
*Routine to init the 6655 registers
************************************************/
void Init_6655(void)
{
Nop();
	AD6655(0x0000,0x18);	//Sets up MSB first Communication
	AD6655(0x0005,0x01);	//Shutdown ADC channel A
	AD6655(0x0008,0x01);	//Full power down ADC A
	AD6655(0x00FF,0x01);	//Latch from master to slave

	AD6655(0x0005,0x02);	//Channel B
	AD6655(0x000B,0x01);	//Clock Divide
	AD6655(0x0008,0x03);	//Normal Power modes
	AD6655(0x000D,0x00);	//Test modes Off
	AD6655(0x0016,0x80);	//Invert DCO Clock
	AD6655(0x0015,0x0C);	//Output Drive strength
	AD6655(0x0103,0x07);	//Turn on LPF Mode
	AD6655(0x0102,0x07);	//FIR enable,Fs/8 on,Gain=2
	AD6655(0x0014,0x01);	//Two's compliment output;enable output
	AD6655(0x011E,0xC7);	//NCO frequency shift of 6.5mHx
	AD6655(0x011F,0x92);
	AD6655(0x0120,0x5F);
	AD6655(0x0121,0xAC);
	AD6655(0x011D,0x07);	//Enable NCO w/ phase & Ampl dither
	AD6655(0x00FF,0x01);	//Latch from master to slave
	__delay32(10000000);
	OE6655=1;				//Disable output
}

/***********************************************
*Routine to tune 3550 to center frequency of interest
***********************************************/
void PLL_3550(int Keyin_Value)
{
/*For now I am just manually changing the Band that the
*MAX3550 looks at in the Init_3550 routine
**********************************/
Nop();
};



