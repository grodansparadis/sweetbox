/*
 * File: SRPM_Core.c
 *
 * Real-Time Workshop code generated for Simulink model SRPM_Core.
 *
 * Model version                        : 1.0
 * Real-Time Workshop file version      : 6.1  (R14SP1)  05-Sep-2004
 * Real-Time Workshop file generated on : Mon Oct 15 23:08:01 2007
 * TLC version                          : 6.1 (Aug 24 2004)
 * C source code generated on           : Mon Oct 15 23:08:02 2007
 *
 * You can customize this banner by specifying a different template.
 */

#include "SRPM_Core.h"
#include "SRPM_Core_private.h"

/* Block signals (auto storage) */
BlockIO_SRPM_Core SRPM_Core_B;

/* Block states (auto storage) */
D_Work_SRPM_Core SRPM_Core_DWork;

/* External inputs (root inport signals with auto storage) */
ExternalInputs_SRPM_Core SRPM_Core_U;

/* External output (root outports fed by signals with auto storage) */
ExternalOutputs_SRPM_Core SRPM_Core_Y;

/* Real-time model */
RT_MODEL_SRPM_Core SRPM_Core_M_;
RT_MODEL_SRPM_Core *SRPM_Core_M = &SRPM_Core_M_;

/* Functions for block: <Root>/SRPM_Core */

#define SRPM_Core_IN_NO_ACTIVE_CHILD    (0L)
#define SRPM_Core_IN_ON                 (1L)
#define SRPM_Core_IN_Off                (2L)
#define SRPM_Core_IN_ZtS_Base           (1L)
#define SRPM_Core_IN_count_base         (1L)
#define SRPM_Core_IN_ZtS_wait           (2L)
#define SRPM_Core_IN_ZtS_active         (2L)
#define SRPM_Core_IN_ZtS_not_ready      (1L)
#define SRPM_Core_IN_ZtS_ready          (2L)
#define SRPM_Core_IN_ZtS_hold           (2L)
#define SRPM_Core_IN_MPG_base           (2L)
#define SRPM_Core_IN_MPG_active         (1L)
#define SRPM_Core_IN_Calc_MPG           (1L)
#define SRPM_Core_IN_MPG_Update         (2L)
#define SRPM_Core_IN_inc_count          (2L)
#define SRPM_Core_IN_ZtS_go             (1L)
#define SRPM_Core_IN_ZtS_counting       (1L)
#define SRPM_Core_IN_Ensure_odo_ready   (1L)
#define SRPM_Core_IN_Q_or_E_Mile_Active (2L)
#define SRPM_Core_IN_QE_Ready           (1L)
#define SRPM_Core_IN_QE_moving          (2L)
#define SRPM_Core_IN_QE_count           (1L)
#define SRPM_Core_IN_dist_reached       (2L)
#define SRPM_Core_IN_Boost_base         (1L)
#define SRPM_Core_IN_Do_nothing         (2L)
#define SRPM_Core_MODE_ZtS              (0)
#define SRPM_Core_MODE_MPG              (1)
#define SRPM_Core_MODE_QM_Time          (2)
#define SRPM_Core_MODE_EM_Time          (3)
#define SRPM_Core_MODE_boost            (4.0)

/* Model step function */
void SRPM_Core_step(void)
{

  /* Stateflow: '<Root>/SRPM_Core' incorporates:
   *   Inport: '<Root>/MODE_API'
   *   Inport: '<Root>/veh_speed_API'
   *   Inport: '<Root>/clock_timer_API'
   *   Inport: '<Root>/MAF_API'
   *   Inport: '<Root>/ODO_API'
   *   Inport: '<Root>/EEPROM_ZtS_best_API'
   *   Inport: '<Root>/EEPROM_QM_best_time_API'
   *   Inport: '<Root>/EEPROM_QM_best_speed_API'
   *   Inport: '<Root>/EEPROM_EM_best_time_API'
   *   Inport: '<Root>/EEPROM_EM_best_speed_API'
   */

  if(SRPM_Core_DWork.SRPM_Core.is_active_c1_SRPM_Core == 0) {
    SRPM_Core_DWork.SRPM_Core.is_active_c1_SRPM_Core = 1;
    SRPM_Core_DWork.SRPM_Core.is_c1_SRPM_Core = (uint8_T)SRPM_Core_IN_Off;
  } else {
    switch(SRPM_Core_DWork.SRPM_Core.is_c1_SRPM_Core) {
     case SRPM_Core_IN_ON:
      switch(SRPM_Core_DWork.SRPM_Core.is_Zero_to_Sixty) {
       case SRPM_Core_IN_ZtS_Base:
        if((SRPM_Core_U.MODE_API == (uint16_T)SRPM_Core_MODE_ZtS) &&
         (SRPM_Core_U.veh_speed_API == 0U)) {
          SRPM_Core_DWork.SRPM_Core.is_Zero_to_Sixty =
            (uint8_T)SRPM_Core_IN_ZtS_active;
          SRPM_Core_DWork.SRPM_Core.is_ZtS_active =
            (uint8_T)SRPM_Core_IN_ZtS_wait;
          SRPM_Core_DWork.SRPM_Core.is_ZtS_wait =
            (uint8_T)SRPM_Core_IN_ZtS_not_ready;
        }
        break;
       case SRPM_Core_IN_ZtS_active:
        if(SRPM_Core_U.MODE_API != (uint16_T)SRPM_Core_MODE_ZtS) {
          SRPM_Core_DWork.SRPM_Core.is_ZtS_counting =
            (uint8_T)SRPM_Core_IN_NO_ACTIVE_CHILD;
          SRPM_Core_DWork.SRPM_Core.is_ZtS_go =
            (uint8_T)SRPM_Core_IN_NO_ACTIVE_CHILD;
          SRPM_Core_DWork.SRPM_Core.is_ZtS_wait =
            (uint8_T)SRPM_Core_IN_NO_ACTIVE_CHILD;
          SRPM_Core_DWork.SRPM_Core.is_ZtS_active =
            (uint8_T)SRPM_Core_IN_NO_ACTIVE_CHILD;
          SRPM_Core_B.ZtS_time = 0U;
          SRPM_Core_B.ZtS_ready = 0;
          SRPM_Core_DWork.SRPM_Core.is_Zero_to_Sixty =
            (uint8_T)SRPM_Core_IN_ZtS_Base;
        } else {
          switch(SRPM_Core_DWork.SRPM_Core.is_ZtS_active) {
           case SRPM_Core_IN_ZtS_go:
            switch(SRPM_Core_DWork.SRPM_Core.is_ZtS_go) {
             case SRPM_Core_IN_ZtS_counting:
              if(SRPM_Core_U.veh_speed_API == 0U) {
                SRPM_Core_DWork.SRPM_Core.is_ZtS_counting =
                  (uint8_T)SRPM_Core_IN_NO_ACTIVE_CHILD;
                SRPM_Core_DWork.SRPM_Core.is_ZtS_go =
                  (uint8_T)SRPM_Core_IN_NO_ACTIVE_CHILD;
                SRPM_Core_B.ZtS_time = 0U;
                SRPM_Core_DWork.SRPM_Core.is_ZtS_active =
                  (uint8_T)SRPM_Core_IN_ZtS_wait;
                SRPM_Core_DWork.SRPM_Core.is_ZtS_wait =
                  (uint8_T)SRPM_Core_IN_ZtS_not_ready;
              } else if(SRPM_Core_U.veh_speed_API > 96U) {
                SRPM_Core_DWork.SRPM_Core.is_ZtS_counting =
                  (uint8_T)SRPM_Core_IN_NO_ACTIVE_CHILD;
                SRPM_Core_DWork.SRPM_Core.is_ZtS_go =
                  (uint8_T)SRPM_Core_IN_NO_ACTIVE_CHILD;
                if((!((SRPM_Core_B.ZtS_time >= SRPM_Core_B.ZtS_best) &&
                   (SRPM_Core_B.ZtS_best != 0U))) && ((SRPM_Core_B.ZtS_time <
                   SRPM_Core_B.ZtS_best) || (SRPM_Core_B.ZtS_best == 0U))) {
                  SRPM_Core_B.ZtS_best = SRPM_Core_B.ZtS_time;
                }
                SRPM_Core_DWork.SRPM_Core.is_ZtS_go =
                  (uint8_T)SRPM_Core_IN_ZtS_hold;
              } else {
                switch(SRPM_Core_DWork.SRPM_Core.is_ZtS_counting) {
                 case SRPM_Core_IN_count_base:
                  if(SRPM_Core_U.clock_timer_API >
                   SRPM_Core_DWork.SRPM_Core.ZtS_base_time) {
                    SRPM_Core_DWork.SRPM_Core.is_ZtS_counting =
                      (uint8_T)SRPM_Core_IN_inc_count;
                  }
                  break;
                 case SRPM_Core_IN_inc_count:
                  SRPM_Core_B.ZtS_time = (uint16_T)(SRPM_Core_U.clock_timer_API
                    - SRPM_Core_DWork.SRPM_Core.ZtS_base_time);
                  SRPM_Core_DWork.SRPM_Core.is_ZtS_counting =
                    (uint8_T)SRPM_Core_IN_count_base;
                  break;
                }
              }
              break;
             case SRPM_Core_IN_ZtS_hold:
              if(SRPM_Core_U.veh_speed_API == 0U) {
                SRPM_Core_DWork.SRPM_Core.is_ZtS_counting =
                  (uint8_T)SRPM_Core_IN_NO_ACTIVE_CHILD;
                SRPM_Core_DWork.SRPM_Core.is_ZtS_go =
                  (uint8_T)SRPM_Core_IN_NO_ACTIVE_CHILD;
                SRPM_Core_DWork.SRPM_Core.is_ZtS_active =
                  (uint8_T)SRPM_Core_IN_ZtS_wait;
                SRPM_Core_DWork.SRPM_Core.is_ZtS_wait =
                  (uint8_T)SRPM_Core_IN_ZtS_not_ready;
              }
              break;
            }
            break;
           case SRPM_Core_IN_ZtS_wait:
            if((SRPM_Core_U.veh_speed_API > 0U) && (SRPM_Core_B.ZtS_ready == 1))
            {
              SRPM_Core_DWork.SRPM_Core.is_ZtS_wait =
                (uint8_T)SRPM_Core_IN_NO_ACTIVE_CHILD;
              SRPM_Core_DWork.SRPM_Core.ZtS_base_time =
                SRPM_Core_U.clock_timer_API;
              SRPM_Core_B.ZtS_time = 0U;
              SRPM_Core_B.ZtS_ready = 0;
              SRPM_Core_DWork.SRPM_Core.is_ZtS_active =
                (uint8_T)SRPM_Core_IN_ZtS_go;
              SRPM_Core_DWork.SRPM_Core.is_ZtS_go =
                (uint8_T)SRPM_Core_IN_ZtS_counting;
              SRPM_Core_DWork.SRPM_Core.is_ZtS_counting =
                (uint8_T)SRPM_Core_IN_count_base;
            } else {
              switch(SRPM_Core_DWork.SRPM_Core.is_ZtS_wait) {
               case SRPM_Core_IN_ZtS_not_ready:
                if(SRPM_Core_U.veh_speed_API == 0U) {
                  SRPM_Core_B.ZtS_ready = 1;
                  SRPM_Core_DWork.SRPM_Core.is_ZtS_wait =
                    (uint8_T)SRPM_Core_IN_ZtS_ready;
                }
                break;
              }
            }
            break;
          }
        }
        break;
      }
      switch(SRPM_Core_DWork.SRPM_Core.is_RT_MPG) {
       case SRPM_Core_IN_MPG_active:
        if(SRPM_Core_U.MODE_API != (uint16_T)SRPM_Core_MODE_MPG) {
          SRPM_Core_DWork.SRPM_Core.is_MPG_active =
            (uint8_T)SRPM_Core_IN_NO_ACTIVE_CHILD;
          SRPM_Core_B.MPG = 0U;
          SRPM_Core_DWork.SRPM_Core.is_RT_MPG = (uint8_T)SRPM_Core_IN_MPG_base;
        } else {
          switch(SRPM_Core_DWork.SRPM_Core.is_MPG_active) {
           case SRPM_Core_IN_Calc_MPG:
            if(SRPM_Core_DWork.SRPM_Core.MPG_base_time !=
             SRPM_Core_U.clock_timer_API) {
              SRPM_Core_DWork.SRPM_Core.MPG_base_time =
                SRPM_Core_U.clock_timer_API;
              SRPM_Core_DWork.SRPM_Core.is_MPG_active =
                (uint8_T)SRPM_Core_IN_MPG_Update;
            }
            break;
           case SRPM_Core_IN_MPG_Update:
            if(SRPM_Core_U.MAF_API == 0U) {
              SRPM_Core_DWork.SRPM_Core.is_MPG_active =
                (uint8_T)SRPM_Core_IN_Calc_MPG;
            } else if(SRPM_Core_U.MAF_API != 0U) {
              SRPM_Core_B.MPG = 7107U * SRPM_Core_U.veh_speed_API /
                SRPM_Core_U.MAF_API;
              SRPM_Core_DWork.SRPM_Core.is_MPG_active =
                (uint8_T)SRPM_Core_IN_Calc_MPG;
            }
            break;
          }
        }
        break;
       case SRPM_Core_IN_MPG_base:
        if(SRPM_Core_U.MODE_API == (uint16_T)SRPM_Core_MODE_MPG) {
          SRPM_Core_DWork.SRPM_Core.MPG_base_time = 0UL;
          SRPM_Core_DWork.SRPM_Core.is_RT_MPG = (uint8_T)SRPM_Core_IN_MPG_active;
          SRPM_Core_DWork.SRPM_Core.is_MPG_active =
            (uint8_T)SRPM_Core_IN_Calc_MPG;
        }
        break;
      }
      switch(SRPM_Core_DWork.SRPM_Core.is_Quarter_or_Eighth_Mile) {
       case SRPM_Core_IN_Ensure_odo_ready:
        if(((SRPM_Core_U.MODE_API == (uint16_T)SRPM_Core_MODE_QM_Time) ||
          (SRPM_Core_U.MODE_API == (uint16_T)SRPM_Core_MODE_EM_Time)) &&
         (SRPM_Core_U.veh_speed_API == 0U)) {
          SRPM_Core_DWork.SRPM_Core.is_Quarter_or_Eighth_Mile =
            (uint8_T)SRPM_Core_IN_Q_or_E_Mile_Active;
          SRPM_Core_DWork.SRPM_Core.is_Q_or_E_Mile_Active =
            (uint8_T)SRPM_Core_IN_QE_Ready;
          SRPM_Core_B.QE_ready = 1;
        }
        break;
       case SRPM_Core_IN_Q_or_E_Mile_Active:
        if((SRPM_Core_U.MODE_API != (uint16_T)SRPM_Core_MODE_QM_Time) &&
         (SRPM_Core_U.MODE_API != (uint16_T)SRPM_Core_MODE_EM_Time)) {
          switch(SRPM_Core_DWork.SRPM_Core.is_Q_or_E_Mile_Active) {
           case SRPM_Core_IN_QE_Ready:
            SRPM_Core_B.QE_ready = 0;
            SRPM_Core_DWork.SRPM_Core.is_Q_or_E_Mile_Active =
              (uint8_T)SRPM_Core_IN_NO_ACTIVE_CHILD;
            break;
           case SRPM_Core_IN_QE_moving:
            SRPM_Core_DWork.SRPM_Core.is_QE_moving =
              (uint8_T)SRPM_Core_IN_NO_ACTIVE_CHILD;
            SRPM_Core_DWork.SRPM_Core.is_Q_or_E_Mile_Active =
              (uint8_T)SRPM_Core_IN_NO_ACTIVE_CHILD;
            break;
          }
          SRPM_Core_DWork.SRPM_Core.is_Quarter_or_Eighth_Mile =
            (uint8_T)SRPM_Core_IN_Ensure_odo_ready;
        } else {
          switch(SRPM_Core_DWork.SRPM_Core.is_Q_or_E_Mile_Active) {
           case SRPM_Core_IN_QE_Ready:
            if(SRPM_Core_U.veh_speed_API > 0U) {
              SRPM_Core_B.QE_ready = 0;
              SRPM_Core_DWork.SRPM_Core.is_Q_or_E_Mile_Active =
                (uint8_T)SRPM_Core_IN_NO_ACTIVE_CHILD;
              SRPM_Core_DWork.SRPM_Core.QE_base_time =
                SRPM_Core_U.clock_timer_API;
              SRPM_Core_B.QE_time = 0UL;
              if(SRPM_Core_U.MODE_API == (uint16_T)SRPM_Core_MODE_EM_Time) {
                SRPM_Core_DWork.SRPM_Core.target_dist = 20.0 +
                  SRPM_Core_U.ODO_API;
              } else if(SRPM_Core_U.MODE_API ==
               (uint16_T)SRPM_Core_MODE_QM_Time) {
                SRPM_Core_DWork.SRPM_Core.target_dist = 40.0 +
                  SRPM_Core_U.ODO_API;
              }
              SRPM_Core_DWork.SRPM_Core.is_Q_or_E_Mile_Active =
                (uint8_T)SRPM_Core_IN_QE_moving;
              SRPM_Core_DWork.SRPM_Core.is_QE_moving =
                (uint8_T)SRPM_Core_IN_QE_count;
            }
            break;
           case SRPM_Core_IN_QE_moving:
            if(SRPM_Core_U.veh_speed_API == 0U) {
              SRPM_Core_DWork.SRPM_Core.is_QE_moving =
                (uint8_T)SRPM_Core_IN_NO_ACTIVE_CHILD;
              SRPM_Core_DWork.SRPM_Core.is_Q_or_E_Mile_Active =
                (uint8_T)SRPM_Core_IN_QE_Ready;
              SRPM_Core_B.QE_ready = 1;
            } else {
              switch(SRPM_Core_DWork.SRPM_Core.is_QE_moving) {
               case SRPM_Core_IN_QE_count:
                if((SRPM_Core_U.clock_timer_API !=
                  SRPM_Core_DWork.SRPM_Core.QE_base_time) &&
                 (SRPM_Core_U.ODO_API < SRPM_Core_DWork.SRPM_Core.target_dist)) {
                  SRPM_Core_B.QE_time += SRPM_Core_U.clock_timer_API -
                    SRPM_Core_DWork.SRPM_Core.QE_base_time;
                  SRPM_Core_B.QE_speed = SRPM_Core_U.veh_speed_API;
                  SRPM_Core_DWork.SRPM_Core.QE_base_time =
                    SRPM_Core_U.clock_timer_API;
                  SRPM_Core_DWork.SRPM_Core.is_QE_moving =
                    (uint8_T)SRPM_Core_IN_QE_count;
                } else if(SRPM_Core_U.ODO_API >=
                 SRPM_Core_DWork.SRPM_Core.target_dist) {
                  SRPM_Core_DWork.SRPM_Core.is_QE_moving =
                    (uint8_T)SRPM_Core_IN_NO_ACTIVE_CHILD;
                  SRPM_Core_B.QE_time = SRPM_Core_U.clock_timer_API -
                    SRPM_Core_DWork.SRPM_Core.QE_base_time;
                  SRPM_Core_B.QE_speed = SRPM_Core_U.veh_speed_API;
                  if(SRPM_Core_U.MODE_API == (uint16_T)SRPM_Core_MODE_EM_Time) {
                    if((SRPM_Core_B.EM_best_time < SRPM_Core_B.QE_time) ||
                     (SRPM_Core_B.EM_best_time == 0UL)) {
                      SRPM_Core_B.EM_best_time = SRPM_Core_B.QE_time;
                      goto sf_label_0_0_1;
                    } else if((SRPM_Core_B.EM_best_time >= SRPM_Core_B.QE_time)
                     && (SRPM_Core_B.EM_best_time != 0UL)) {
                      goto sf_label_0_0_1;
                    }
                  }
                  if(SRPM_Core_U.MODE_API == (uint16_T)SRPM_Core_MODE_QM_Time) {
                    if((SRPM_Core_B.QM_best_time >= SRPM_Core_B.QE_time) &&
                     (SRPM_Core_B.QM_best_time != 0UL)) {
                    } else if((SRPM_Core_B.QM_best_time < SRPM_Core_B.QE_time)
                     || (SRPM_Core_B.QM_best_time == 0UL)) {
                      SRPM_Core_B.QM_best_time = SRPM_Core_B.QE_time;
                    } else {
                      goto sf_label_0_0_2;
                    }
                  } else {
                    goto sf_label_0_0_2;
                  }
                  SRPM_Core_B.QM_best_speed = SRPM_Core_B.QE_speed;
                  goto sf_label_0_0_2;
                  sf_label_0_0_1:;
                  SRPM_Core_B.EM_best_speed = SRPM_Core_B.QE_speed;
                  sf_label_0_0_2:;
                  SRPM_Core_DWork.SRPM_Core.is_QE_moving =
                    (uint8_T)SRPM_Core_IN_dist_reached;
                }
                break;
              }
            }
            break;
          }
        }
        break;
      }
      switch(SRPM_Core_DWork.SRPM_Core.is_Boost) {
       case SRPM_Core_IN_Boost_base:
        if((real_T)SRPM_Core_U.MODE_API == SRPM_Core_MODE_boost) {
          SRPM_Core_DWork.SRPM_Core.is_Boost = (uint8_T)SRPM_Core_IN_Do_nothing;
        }
        break;
       case SRPM_Core_IN_Do_nothing:
        if((real_T)SRPM_Core_U.MODE_API != SRPM_Core_MODE_boost) {
          SRPM_Core_DWork.SRPM_Core.is_Boost = (uint8_T)SRPM_Core_IN_Boost_base;
        }
        break;
      }
      break;
     case SRPM_Core_IN_Off:
      SRPM_Core_B.ZtS_best = SRPM_Core_U.EEPROM_ZtS_best_API;
      SRPM_Core_B.QM_best_time = (uint32_T)SRPM_Core_U.EEPROM_QM_best_time_API;
      SRPM_Core_B.QM_best_speed = SRPM_Core_U.EEPROM_QM_best_speed_API;
      SRPM_Core_B.EM_best_time = (uint32_T)SRPM_Core_U.EEPROM_EM_best_time_API;
      SRPM_Core_B.EM_best_speed = SRPM_Core_U.EEPROM_EM_best_speed_API;
      SRPM_Core_DWork.SRPM_Core.is_c1_SRPM_Core = (uint8_T)SRPM_Core_IN_ON;
      SRPM_Core_DWork.SRPM_Core.ZtS_base_time = 0UL;
      SRPM_Core_DWork.SRPM_Core.is_active_Zero_to_Sixty = 1;
      SRPM_Core_B.ZtS_time = 0U;
      SRPM_Core_B.ZtS_ready = 0;
      SRPM_Core_DWork.SRPM_Core.is_Zero_to_Sixty =
        (uint8_T)SRPM_Core_IN_ZtS_Base;
      SRPM_Core_DWork.SRPM_Core.MPG_base_time = 0UL;
      SRPM_Core_DWork.SRPM_Core.is_active_RT_MPG = 1;
      SRPM_Core_B.MPG = 0U;
      SRPM_Core_DWork.SRPM_Core.is_RT_MPG = (uint8_T)SRPM_Core_IN_MPG_base;
      SRPM_Core_DWork.SRPM_Core.QE_base_time = 0UL;
      SRPM_Core_DWork.SRPM_Core.target_dist = 0.0;
      SRPM_Core_DWork.SRPM_Core.is_active_Quarter_or_Eighth_Mile = 1;
      SRPM_Core_B.QE_time = 0UL;
      SRPM_Core_DWork.SRPM_Core.is_Quarter_or_Eighth_Mile =
        (uint8_T)SRPM_Core_IN_Ensure_odo_ready;
      SRPM_Core_DWork.SRPM_Core.is_active_Boost = 1;
      SRPM_Core_DWork.SRPM_Core.is_Boost = (uint8_T)SRPM_Core_IN_Boost_base;
      break;
    }
  }

  /* Outport: '<Root>/ZtS_time' */
  SRPM_Core_Y.ZtS_time = SRPM_Core_B.ZtS_time;

  /* Outport: '<Root>/ZtS_ready' */
  SRPM_Core_Y.ZtS_ready = SRPM_Core_B.ZtS_ready;

  /* Outport: '<Root>/ZtS_best' */
  SRPM_Core_Y.ZtS_best = SRPM_Core_B.ZtS_best;

  /* Outport: '<Root>/MPG' */
  SRPM_Core_Y.MPG = SRPM_Core_B.MPG;

  /* Outport: '<Root>/QE_time' */
  SRPM_Core_Y.QE_time = SRPM_Core_B.QE_time;

  /* Outport: '<Root>/QE_speed' */
  SRPM_Core_Y.QE_speed = SRPM_Core_B.QE_speed;

  /* Outport: '<Root>/QM_best_time' */
  SRPM_Core_Y.QM_best_time = SRPM_Core_B.QM_best_time;

  /* Outport: '<Root>/QM_best_speed' */
  SRPM_Core_Y.QM_best_speed = SRPM_Core_B.QM_best_speed;

  /* Outport: '<Root>/EM_best_time' */
  SRPM_Core_Y.EM_best_time = SRPM_Core_B.EM_best_time;

  /* Outport: '<Root>/EM_best_speed' */
  SRPM_Core_Y.EM_best_speed = SRPM_Core_B.EM_best_speed;

  /* Outport: '<Root>/QE_ready' */
  SRPM_Core_Y.QE_ready = SRPM_Core_B.QE_ready;

  /* (no update code required) */
}

/* Model initialize function */
void SRPM_Core_initialize(boolean_T firstTime)
{

  if (firstTime) {
    /* registration code */

    /* initialize error status */
    rtmSetErrorStatus(SRPM_Core_M, (const char_T *)0);

    {
      /* block I/O */
      void *b = (void *) &SRPM_Core_B;

      (void)memset(b, 0, sizeof(BlockIO_SRPM_Core));
    }

    /* data type work */
    (void)memset((char_T *) &SRPM_Core_DWork, 0, sizeof(D_Work_SRPM_Core));

    /* external inputs */
    SRPM_Core_U.MODE_API = 0;
    SRPM_Core_U.veh_speed_API = 0;
    SRPM_Core_U.clock_timer_API = 0;
    SRPM_Core_U.MAF_API = 0;
    SRPM_Core_U.ODO_API = 0.0;
    SRPM_Core_U.EEPROM_ZtS_best_API = 0;
    SRPM_Core_U.EEPROM_QM_best_time_API = 0;
    SRPM_Core_U.EEPROM_EM_best_time_API = 0;
    SRPM_Core_U.EEPROM_QM_best_speed_API = 0;
    SRPM_Core_U.EEPROM_EM_best_speed_API = 0;

    /* external outputs */
    SRPM_Core_Y.ZtS_time = 0;
    SRPM_Core_Y.ZtS_ready = 0;
    SRPM_Core_Y.ZtS_best = 0;
    SRPM_Core_Y.MPG = 0;
    SRPM_Core_Y.QE_time = 0;
    SRPM_Core_Y.QE_speed = 0;
    SRPM_Core_Y.QM_best_time = 0;
    SRPM_Core_Y.QM_best_speed = 0;
    SRPM_Core_Y.EM_best_time = 0;
    SRPM_Core_Y.EM_best_speed = 0;
    SRPM_Core_Y.QE_ready = 0;
  }

  /* Initialize code for chart: <Root>/SRPM_Core */
  SRPM_Core_DWork.SRPM_Core.is_active_Boost = 0;
  SRPM_Core_DWork.SRPM_Core.is_Boost = 0;
  SRPM_Core_DWork.SRPM_Core.is_active_Quarter_or_Eighth_Mile = 0;
  SRPM_Core_DWork.SRPM_Core.is_Quarter_or_Eighth_Mile = 0;
  SRPM_Core_DWork.SRPM_Core.is_Q_or_E_Mile_Active = 0;
  SRPM_Core_DWork.SRPM_Core.is_QE_moving = 0;
  SRPM_Core_DWork.SRPM_Core.is_active_RT_MPG = 0;
  SRPM_Core_DWork.SRPM_Core.is_RT_MPG = 0;
  SRPM_Core_DWork.SRPM_Core.is_MPG_active = 0;
  SRPM_Core_DWork.SRPM_Core.is_active_Zero_to_Sixty = 0;
  SRPM_Core_DWork.SRPM_Core.is_Zero_to_Sixty = 0;
  SRPM_Core_DWork.SRPM_Core.is_ZtS_active = 0;
  SRPM_Core_DWork.SRPM_Core.is_ZtS_go = 0;
  SRPM_Core_DWork.SRPM_Core.is_ZtS_counting = 0;
  SRPM_Core_DWork.SRPM_Core.is_ZtS_wait = 0;
  SRPM_Core_DWork.SRPM_Core.is_active_c1_SRPM_Core = 0;
  SRPM_Core_DWork.SRPM_Core.is_c1_SRPM_Core = 0;
  SRPM_Core_DWork.SRPM_Core.ZtS_base_time = 0UL;
  SRPM_Core_DWork.SRPM_Core.MPG_base_time = 0UL;
  SRPM_Core_DWork.SRPM_Core.QE_base_time = 0UL;
  SRPM_Core_DWork.SRPM_Core.target_dist = 0.0;
  SRPM_Core_B.ZtS_time = 0U;
  SRPM_Core_B.ZtS_ready = 0;
  SRPM_Core_B.ZtS_best = 0U;
  SRPM_Core_B.MPG = 0U;
  SRPM_Core_B.QE_time = 0UL;
  SRPM_Core_B.QE_speed = 0U;
  SRPM_Core_B.QM_best_time = 0UL;
  SRPM_Core_B.QM_best_speed = 0U;
  SRPM_Core_B.EM_best_time = 0UL;
  SRPM_Core_B.EM_best_speed = 0U;
  SRPM_Core_B.QE_ready = 0;
}

/* Model terminate function */
void SRPM_Core_terminate(void)
{
  /* (no terminate code required) */
}

/* File trailer for Real-Time Workshop generated code.
 *
 * You can customize this file trailer by specifying a different template.
 *
 * [EOF]
 */
