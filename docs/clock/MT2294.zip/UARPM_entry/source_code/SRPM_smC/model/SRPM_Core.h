/*
 * File: SRPM_Core.h
 *
 * Real-Time Workshop code generated for Simulink model SRPM_Core.
 *
 * Model version                        : 1.0
 * Real-Time Workshop file version      : 6.1  (R14SP1)  05-Sep-2004
 * Real-Time Workshop file generated on : Mon Oct 15 23:08:01 2007
 * TLC version                          : 6.1 (Aug 24 2004)
 * C source code generated on           : Mon Oct 15 23:08:02 2007
 *
 * You can customize this banner by specifying a different template.
 */

#ifndef _RTW_HEADER_SRPM_Core_h_
#define _RTW_HEADER_SRPM_Core_h_

#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <string.h>
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "rtlibsrc.h"

#include "SRPM_Core_types.h"

/* Macros for accessing real-time model data structure  */

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm) ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val) ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm) ()
#endif

/* Block signals (auto storage) */
typedef struct _BlockIO_SRPM_Core {
  uint32_T QE_time;                     /* 'synthesized block' */
  uint32_T QM_best_time;                /* 'synthesized block' */
  uint32_T EM_best_time;                /* 'synthesized block' */
  uint16_T ZtS_time;                    /* 'synthesized block' */
  uint16_T ZtS_best;                    /* 'synthesized block' */
  uint16_T MPG;                         /* 'synthesized block' */
  uint16_T QE_speed;                    /* 'synthesized block' */
  uint16_T QM_best_speed;               /* 'synthesized block' */
  uint16_T EM_best_speed;               /* 'synthesized block' */
  uint8_T ZtS_ready;                    /* 'synthesized block' */
  uint8_T QE_ready;                     /* 'synthesized block' */
} BlockIO_SRPM_Core;

/* Block states (auto storage) for system: '<Root>' */
typedef struct D_Work_SRPM_Core_tag {
  CSc1_SRPM_Core_ChartStruct SRPM_Core; /* 'synthesized block' */
} D_Work_SRPM_Core;

/* External inputs (root inport signals with auto storage) */
typedef struct _ExternalInputs_SRPM_Core_tag {
  uint16_T MODE_API;                    /* '<Root>/MODE_API' */
  uint16_T veh_speed_API;               /* '<Root>/veh_speed_API' */
  uint32_T clock_timer_API;             /* '<Root>/clock_timer_API' */
  uint16_T MAF_API;                     /* '<Root>/MAF_API' */
  real_T ODO_API;                       /* '<Root>/ODO_API' */
  uint16_T EEPROM_ZtS_best_API;         /* '<Root>/EEPROM_ZtS_best_API' */
  uint16_T EEPROM_QM_best_time_API;     /* '<Root>/EEPROM_QM_best_time_API' */
  uint16_T EEPROM_EM_best_time_API;     /* '<Root>/EEPROM_EM_best_time_API' */
  uint16_T EEPROM_QM_best_speed_API;    /* '<Root>/EEPROM_QM_best_speed_API' */
  uint16_T EEPROM_EM_best_speed_API;    /* '<Root>/EEPROM_EM_best_speed_API' */
} ExternalInputs_SRPM_Core;

/* External outputs (root outports fed by signals with auto storage) */
typedef struct _ExternalOutputs_SRPM_Core_tag {
  uint16_T ZtS_time;                    /* '<Root>/ZtS_time' */
  uint8_T ZtS_ready;                    /* '<Root>/ZtS_ready' */
  uint16_T ZtS_best;                    /* '<Root>/ZtS_best' */
  uint16_T MPG;                         /* '<Root>/MPG' */
  uint32_T QE_time;                     /* '<Root>/QE_time' */
  uint16_T QE_speed;                    /* '<Root>/QE_speed' */
  uint32_T QM_best_time;                /* '<Root>/QM_best_time' */
  uint16_T QM_best_speed;               /* '<Root>/QM_best_speed' */
  uint32_T EM_best_time;                /* '<Root>/EM_best_time' */
  uint16_T EM_best_speed;               /* '<Root>/EM_best_speed' */
  uint8_T QE_ready;                     /* '<Root>/QE_ready' */
} ExternalOutputs_SRPM_Core;

/* Real-time Model Data Structure */
struct _RT_MODEL_SRPM_Core_Tag {
  const char *errorStatus;
};

/* Block signals (auto storage) */
extern BlockIO_SRPM_Core SRPM_Core_B;

/* Block states (auto storage) */
extern D_Work_SRPM_Core SRPM_Core_DWork;

/* External inputs (root inport signals with auto storage) */
extern ExternalInputs_SRPM_Core SRPM_Core_U;

/* External outputs (root outports fed by signals with auto storage) */
extern ExternalOutputs_SRPM_Core SRPM_Core_Y;

/* Model entry point functions */

extern void SRPM_Core_initialize(boolean_T firstTime);
extern void SRPM_Core_step(void);
extern void SRPM_Core_terminate(void);

/* Real-time Model object */
extern RT_MODEL_SRPM_Core *SRPM_Core_M;

/* 
 * The generated code includes comments that allow you to trace directly 
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : SRPM_Core
 * '<S1>'   : SRPM_Core/SRPM_Core
 * '<S2>'   : SRPM_Core/xx_LockDownSignalSpec_1
 * '<S3>'   : SRPM_Core/xx_LockDownSignalSpec_10
 * '<S4>'   : SRPM_Core/xx_LockDownSignalSpec_11
 * '<S5>'   : SRPM_Core/xx_LockDownSignalSpec_12
 * '<S6>'   : SRPM_Core/xx_LockDownSignalSpec_13
 * '<S7>'   : SRPM_Core/xx_LockDownSignalSpec_14
 * '<S8>'   : SRPM_Core/xx_LockDownSignalSpec_15
 * '<S9>'   : SRPM_Core/xx_LockDownSignalSpec_16
 * '<S10>'  : SRPM_Core/xx_LockDownSignalSpec_17
 * '<S11>'  : SRPM_Core/xx_LockDownSignalSpec_18
 * '<S12>'  : SRPM_Core/xx_LockDownSignalSpec_19
 * '<S13>'  : SRPM_Core/xx_LockDownSignalSpec_2
 * '<S14>'  : SRPM_Core/xx_LockDownSignalSpec_20
 * '<S15>'  : SRPM_Core/xx_LockDownSignalSpec_21
 * '<S16>'  : SRPM_Core/xx_LockDownSignalSpec_3
 * '<S17>'  : SRPM_Core/xx_LockDownSignalSpec_4
 * '<S18>'  : SRPM_Core/xx_LockDownSignalSpec_5
 * '<S19>'  : SRPM_Core/xx_LockDownSignalSpec_6
 * '<S20>'  : SRPM_Core/xx_LockDownSignalSpec_7
 * '<S21>'  : SRPM_Core/xx_LockDownSignalSpec_8
 * '<S22>'  : SRPM_Core/xx_LockDownSignalSpec_9
 */

#endif                                  /* _RTW_HEADER_SRPM_Core_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * You can customize this file trailer by specifying a different template.
 *
 * [EOF]
 */
