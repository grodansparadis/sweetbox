/*
 * File: SRPM_Core_types.h
 *
 * Real-Time Workshop code generated for Simulink model SRPM_Core.
 *
 * Model version                        : 1.0
 * Real-Time Workshop file version      : 6.1  (R14SP1)  05-Sep-2004
 * Real-Time Workshop file generated on : Mon Oct 15 23:08:01 2007
 * TLC version                          : 6.1 (Aug 24 2004)
 * C source code generated on           : Mon Oct 15 23:08:02 2007
 *
 * You can customize this banner by specifying a different template.
 */

#ifndef _RTW_HEADER_SRPM_Core_types_h_
#define _RTW_HEADER_SRPM_Core_types_h_

#ifndef _CSC1_SRPM_CORE_CHARTSTRUCT_
#define _CSC1_SRPM_CORE_CHARTSTRUCT_

typedef struct {
  real_T target_dist;
  uint32_T MPG_base_time;
  uint32_T QE_base_time;
  uint32_T ZtS_base_time;
  uint8_T is_Boost;
  uint8_T is_MPG_active;
  uint8_T is_QE_moving;
  uint8_T is_Q_or_E_Mile_Active;
  uint8_T is_Quarter_or_Eighth_Mile;
  uint8_T is_RT_MPG;
  uint8_T is_Zero_to_Sixty;
  uint8_T is_ZtS_active;
  uint8_T is_ZtS_counting;
  uint8_T is_ZtS_go;
  uint8_T is_ZtS_wait;
  uint8_T is_active_Boost;
  uint8_T is_active_Quarter_or_Eighth_Mile;
  uint8_T is_active_RT_MPG;
  uint8_T is_active_Zero_to_Sixty;
  uint8_T is_active_c1_SRPM_Core;
  uint8_T is_c1_SRPM_Core;
} CSc1_SRPM_Core_ChartStruct;

#endif                                  /* _CSC1_SRPM_CORE_CHARTSTRUCT_ */

/* Forward declaration for rtModel */
typedef struct _RT_MODEL_SRPM_Core_Tag RT_MODEL_SRPM_Core;

#endif                                  /* _RTW_HEADER_SRPM_Core_types_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * You can customize this file trailer by specifying a different template.
 *
 * [EOF]
 */
