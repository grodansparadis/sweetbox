/*
 * File: SRPM_Core_private.h
 *
 * Real-Time Workshop code generated for Simulink model SRPM_Core.
 *
 * Model version                        : 1.0
 * Real-Time Workshop file version      : 6.1  (R14SP1)  05-Sep-2004
 * Real-Time Workshop file generated on : Mon Oct 15 23:08:01 2007
 * TLC version                          : 6.1 (Aug 24 2004)
 * C source code generated on           : Mon Oct 15 23:08:02 2007
 *
 * You can customize this banner by specifying a different template.
 */

#ifndef _RTW_HEADER_SRPM_Core_private_h_
#define _RTW_HEADER_SRPM_Core_private_h_

#include "rtwtypes.h"

#ifndef min
# ifndef rt_MIN
# include "rtlibsrc.h"
# endif
# define min rt_MIN
#endif
#ifndef max
# define max rt_MAX
#endif
#define CALL_EVENT                      (MAX_uint8_T)
/* Private macros used by the generated code to access rtModel */

#ifndef __RTWTYPES_H__
#error This file requires rtwtypes.h to be included
#else
#ifdef TMWTYPES_PREVIOUSLY_INCLUDED
#error This file requires rtwtypes.h to be included before tmwtypes.h
#else
/* Check for inclusion of an incorrect version of rtwtypes.h */
#ifndef RTWTYPES_ID_C08S08I16L32N16F1
#error This code was generated with a different "rtwtypes.h" than the file included
#endif                                  /* RTWTYPES_ID_C08S08I16L32N16F1 */
#endif                                  /* TMWTYPES_PREVIOUSLY_INCLUDED */
#endif                                  /* __RTWTYPES_H__ */

#endif                                  /* _RTW_HEADER_SRPM_Core_private_h_ */

/* File trailer for Real-Time Workshop generated code.
 *
 * You can customize this file trailer by specifying a different template.
 *
 * [EOF]
 */
