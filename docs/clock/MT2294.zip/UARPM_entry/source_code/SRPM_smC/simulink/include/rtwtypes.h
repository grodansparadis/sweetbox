/* Copyright 2003 The MathWorks, Inc. */

/* Static rtwtypes.h to support non RTW based cases. */
#ifndef __RTWTYPES_H__  
  #define __RTWTYPES_H__  
  #include "simstruc_types.h"  
#endif  
