//UART config

unsigned int baudrate_9600=32;
unsigned int baudrate_38400=0;

#define FCY 20000000

#define BAUD_RATE_GENERATOR_9600 (((FCY/4) / (16 * 9600)) - 1)
#define BAUD_RATE_GENERATOR_38400 (((FCY/4) / (16 * 38400)) - 1)


inline void  UART_config1(){
	    U1MODEbits.STSEL=0;
        U1MODEbits.PDSEL=0;
        U1MODEbits.ABAUD=0;
        U1MODEbits.LPBACK=0;
        U1MODEbits.WAKE=0;
        U1MODEbits.ALTIO=1;
        U1MODEbits.USIDL=0;
        U1MODEbits.UARTEN=1;
        
        U1STAbits.URXDA=0;
        U1STAbits.OERR=0;
        U1STAbits.FERR=0;
        U1STAbits.PERR=0;
        U1STAbits.RIDLE=0;
        U1STAbits.ADDEN=0;
        U1STAbits.URXISEL=0;
        U1STAbits.TRMT=0;
        U1STAbits.UTXBF=0;
        U1STAbits.UTXEN=1;
        U1STAbits.UTXBRK=0;
        U1STAbits.UTXISEL=0;  
        
        //IFS0bits.U1TXIF = 0;	// Clear the Transmit Interrupt Flag
		//IEC0bits.U1TXIE = 1;	// Enable Transmit Interrupts
		IFS0bits.U1RXIF = 0;	// Clear the Recieve Interrupt Flag
		IEC0bits.U1RXIE = 1;	// Enable Recieve Interrupts
	
	
        //U1BRG=BAUD_RATE_GENERATOR_9600;
        U1BRG=baudrate_9600;
        
}

inline void UART_config2(){
	    U2MODEbits.STSEL=0;
        U2MODEbits.PDSEL=0;
        U2MODEbits.ABAUD=0;
        U2MODEbits.LPBACK=0;
        U2MODEbits.WAKE=0;
        U2MODEbits.ALTIO=0;
        U2MODEbits.USIDL=0;
        U2MODEbits.UARTEN=1;
        
        U2STAbits.URXDA=0;
        U2STAbits.OERR=0;
        U2STAbits.FERR=0;
        U2STAbits.PERR=0;
        U2STAbits.RIDLE=0;
        U2STAbits.ADDEN=0;
        U2STAbits.URXISEL=0;
        U2STAbits.TRMT=0;
        U2STAbits.UTXBF=0;
        U2STAbits.UTXEN=1;
        U2STAbits.UTXBRK=0;
        U2STAbits.UTXISEL=0;  
        
        //IFS1bits.U2TXIF = 0;	// Clear the Transmit Interrupt Flag
		//IEC1bits.U2TXIE = 1;	// Enable Transmit Interrupts
		IFS1bits.U2RXIF = 0;	// Clear the Recieve Interrupt Flag
		IEC1bits.U2RXIE = 1;	// Enable Recieve Interrupts
		
        U2BRG=BAUD_RATE_GENERATOR_38400;
        
}

inline void UARTsetBaud_38400(int uart){
	switch(uart){
		case 1:		IFS0bits.U1RXIF = 0;	// Clear the Recieve Interrupt Flag
					IEC0bits.U1RXIE = 0;	// Enable Recieve Interrupts
					U1BRG=BAUD_RATE_GENERATOR_38400;
					IFS0bits.U1RXIF = 0;	// Clear the Recieve Interrupt Flag
					IEC0bits.U1RXIE = 1;	// Enable Recieve Interrupts
					break;
		case 2:		break;//dont change baud rate for elm327
		default:	break;
	}

}













