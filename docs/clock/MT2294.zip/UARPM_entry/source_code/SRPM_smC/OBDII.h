#define MPH60	96
#define MPH25	40

#define BUSY 5
#define READY 6


unsigned int carriage_return = 0xD;
//unsigned int newline = 0xA;

unsigned int lrequest = 5;

char mcoolant_temp[] = "01 05";
unsigned int lrcoolant_temp = 1;

char mveh_speed[] = "01 0D";
unsigned int lrveh_speed = 1;

char mMAF[] = "01 10";
unsigned int lMAF = 2;

char mBoost[] = "01 0B";
unsigned int lBoost=1;

unsigned int getASCIInum(unsigned char MSC, unsigned char LSC);

unsigned int getMAF(unsigned char MSCA, unsigned char LSCA, unsigned char MSCB, unsigned char LSCB);








