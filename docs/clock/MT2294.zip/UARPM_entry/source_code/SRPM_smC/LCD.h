

char DEF_header[]=   "Unknown Mode    ";
char ZtS_header[]=   "Zero to Sixty   ";
char MPG_header[]=   "Miles Per Gallon";
char QM_header[]=	 "1/4 Mile Time   ";
char EM_header[]=	 "1/8 Mile Time   ";
char Bst_header[]=	 "Boost           ";


//char VBATT_header[]= "Battery Voltage ";
//char D_header[]=     "Diagnostic      ";

int LCDsetBaud(int baud);

int writeln(char *msg, int length, int row);

void dispTime(char *msg,unsigned long clock_timer);
void dispMPG(char *msg, unsigned int MPG);
void diagDump(char *msg, char *diag);
void displayZtS(char *msg, unsigned long time, unsigned int ready);
void dispMile(char *msg, unsigned long time, unsigned int speed);
void displayZtSBest(char *msg, unsigned long time);
void dispBoost(char *msg, unsigned int boost);




