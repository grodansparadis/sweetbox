#include <p30f3013.h>
#include <string.h>
#include <stdio.h>


void write(char *msg, int length){
	int i=0;
	for (i=0; (i<length); i++){
		while(U1STAbits.UTXBF==1){}
		U1TXREG=msg[i];
	}
}


int LCDsetBaud(int baud){
	switch(baud){
		case 9600:	U1TXREG=124;
					write("<control>m", 10);
					break;
		case 38400:	U1TXREG=124;
					write("<control>p", 10);
					break;
		default:	break;
	}

	return 0;
}
					
int writeln(char *msg, int length, int row){
	int i=0;

	//if(length>16){
		//return -1;
	//}
	while(U1STAbits.UTXBF==1){}
	U1TXREG=254;

	if(row==1){
		while(U1STAbits.UTXBF==1){}
		U1TXREG=128;
	}
	else{
		while(U1STAbits.UTXBF==1){}
		U1TXREG=192;
	}


	for (i=0; i<length; i++){
		while(U1STAbits.UTXBF==1){}
		U1TXREG=msg[i];
	}

	return 0;
		
}

char Max_ZtS[]="            99.9";

void dispTime(char *msg, unsigned long time){
	char newStr[4];
	int i; 
	
	for(i=0; i<16;i++){
		msg[i]=' ';	
	}
	if (time>999){
		memcpy(msg, Max_ZtS, 16);
	}
	else if(time>99){	
		sprintf(newStr,"%d",(int)time);
		msg[12]=newStr[0];
		msg[13]=newStr[1];
		msg[14]='.';
		msg[15]=newStr[2];
	}
	else if(time>9){	
		sprintf(newStr,"%d",(int)time);
		msg[12]=' ';
		msg[13]=newStr[0];
		msg[14]='.';
		msg[15]=newStr[1];
	}
	else{	
		sprintf(newStr,"%d",(int)time);
		msg[12]=' ';
		msg[13]='0';
		msg[14]='.';
		msg[15]=newStr[0];
	}
}
/*void dispMPG(char *msg, unsigned long clock_timer){


}
void diagDump(char *msg, char *diag){
	int i;
	for (i=0;i<16;i++){
		msg[i]=diag[i];
	}
}*/
void displayZtS(char *msg, unsigned long time, unsigned int ready){
	dispTime(msg, time);
	if(ready==1){
		msg[0]='R';
		msg[1]='e';
		msg[2]='a';
		msg[3]='d';
		msg[4]='y';
		msg[5]=':';
	}
}
void displayZtSBest(char *msg, unsigned long time){
	dispTime(msg, time);
		msg[0]='B';
		msg[1]='e';
		msg[2]='s';
		msg[3]='t';
		msg[4]=':';

}

char Max_M_time[]="99.9sec  99.9mph";
void dispMile(char *msg, unsigned long time, unsigned int speed){
	char newStr[4];
	unsigned int speed_mph;

	speed_mph=(int)(speed*31/5);

	if (time>999){
		memcpy(msg, Max_M_time, 16);
	}
	else if(time>99){	
		sprintf(newStr,"%d",(int)time);
		msg[0]=newStr[0];
		msg[1]=newStr[1];
		msg[2]='.';
		msg[3]=newStr[2];
	}
	else if(time>9){	
		sprintf(newStr,"%d",(int)time);
		msg[0]=' ';
		msg[1]=newStr[0];
		msg[2]='.';
		msg[3]=newStr[1];
	}
	else{	
		sprintf(newStr,"%d",(int)time);
		msg[0]=' ';
		msg[1]='0';
		msg[2]='.';
		msg[3]=newStr[0];
	}

	msg[4]='s';
	msg[5]='e';
	msg[6]='c';
	msg[7]=' ';
	msg[8]=' ';
	memset(newStr,0,4);
	if (speed_mph>999){
		msg[9]='9';
		msg[10]='9';
		msg[11]='.';
		msg[12]='9';
	}
	else if(speed>99){	
		sprintf(newStr,"%d",(int)speed_mph);
		msg[8]=newStr[0];
		msg[9]=newStr[1];
		msg[10]=newStr[2];
		msg[11]='.';
		msg[12]='0';
	}
	else if(speed>9){	
		sprintf(newStr,"%d",(int)speed_mph);
		msg[9]=newStr[0];
		msg[10]=newStr[1];
		msg[11]='.';
		msg[12]='0';
	}
	else{	
		sprintf(newStr,"%d",(int)speed_mph);
		msg[9]=' ';
		msg[10]=newStr[0];
		msg[11]='.';
		msg[12]='0';
	}
	msg[13]='m';
	msg[14]='p';
	msg[15]='h';

}

char Max_M_boost[]="        99.9 PSI";

void dispBoost(char *msg, unsigned int boost){
	unsigned int PSI_boost;
	char newStr[4];
	int i;

	PSI_boost=(unsigned int)(boost*10*.14503773773020923);
	for (i=0;i<16;i++){
		msg[i]=' ';
	}
	if (PSI_boost>999){
		memcpy(msg, Max_M_boost, 16);
		return;
	}
	else if(PSI_boost>99){	
		sprintf(newStr,"%d",(int)PSI_boost);
		msg[8]=newStr[0];
		msg[9]=newStr[1];
		msg[10]='.';
		msg[11]=newStr[2];
	}
	else if(PSI_boost>9){	
		sprintf(newStr,"%d",(int)PSI_boost);
		msg[8]=' ';
		msg[9]=newStr[0];
		msg[10]='.';
		msg[11]=newStr[1];
	}
	else{	
		sprintf(newStr,"%d",(int)PSI_boost);
		msg[8]=' ';
		msg[9]='0';
		msg[10]='.';
		msg[11]=newStr[0];
	}
	msg[13]='P';
	msg[14]='S';
	msg[15]='I';


}


