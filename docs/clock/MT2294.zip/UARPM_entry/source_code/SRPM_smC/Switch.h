#define CLOSED 0
#define OPEN   1



void initSwitches();


int debounceSW(unsigned int Switch, unsigned int index);

