#include <p30f3013.h>
#include <string.h>
#include "UART_config.h"
#include "TIMER_config.h"
#include "OBDII.h"
#include "LCD.h"
#include "model.h"
#include "Switch.h"
#include "drivers/DataEEPROM.h"

#define OFF 0
#define ON  1

#define MODE_ZtS	0
#define MODE_MPG	1
#define MODE_QM		2
#define MODE_EM		3
#define MODE_Boost	4


void init_RAM();

//UART recieve
char newData1, newData2;

//timers
unsigned int timer20ms_A;
unsigned int timer20ms_B;
unsigned int timer20ms_C;
unsigned int timer20ms_D;
unsigned long timer20ms_ODO;
unsigned long timer100ms;
unsigned long timer20ms_saved;

//OBD-II bus managemant
unsigned int next_send;
unsigned short int clr_to_snd;
unsigned int ODBII_timeout;
//unsigned int num_recs;

//OBD-II bus receive buffer
#define REC_BUFF_SIZE	96
char rec_buff[REC_BUFF_SIZE];
unsigned int rec_buff_index;

//data management
unsigned short int show_best;
unsigned int veh_speed;
unsigned int MODE;
unsigned int old_MODE;
unsigned int MAF;
unsigned int boost;
#define KMp100msec	0.0000278
#define KMp20msec	0.00000556
#define hunderedKMp20msec	000.000556
double ODO;

/********** UART RECEIVE INTERUPTS **********/
//UART1=LCD
void __attribute__ ((interrupt)) _U1RXInterrupt(void){
	newData1=U1RXREG;
	IFS0bits.U1RXIF = 0;
}
//UART2=ELM327
void __attribute__ ((interrupt)) _U2RXInterrupt(void){
	int n=0;
	int exit=0;
	
	newData2=U2RXREG;
	
	if ('>'==newData2){
		//case response to request
		while(exit==0){
			if( (rec_buff[n]=='4')&&(rec_buff[n+1]=='1') ){
				exit=1;
			}
			else if (n>(rec_buff_index-2)){
				exit=1;
			}
			else{
				n++;
			}
		}
		if(n<(REC_BUFF_SIZE+3)){	
			//case veh_speed
			if ((rec_buff[n+3]=='0')&&(rec_buff[n+4]=='D')){
				veh_speed=getASCIInum(rec_buff[n+6], rec_buff[n+7]);
				if (timer20ms_saved>timer20ms_ODO){
					timer20ms_saved=1;
				}
				if (timer20ms_saved!=0){
					ODO=ODO+(veh_speed*hunderedKMp20msec*(timer20ms_ODO-timer20ms_saved));
				}
				timer20ms_saved=timer20ms_ODO;
				//num_recs++;
			}
			//case MAF
			else if ((rec_buff[n+3]=='1')&&(rec_buff[n+4]=='0')){
				MAF=getMAF(rec_buff[n+6], rec_buff[n+7], rec_buff[n+9], rec_buff[n+10]);
				//num_recs++;
			}
			//case boost
			else if ((rec_buff[n+3]=='0')&&(rec_buff[n+4]=='B')){
				boost=getASCIInum(rec_buff[n+6], rec_buff[n+7]);
				//num_recs++;
			}
		}
		//set up for next
		memset(rec_buff,0,REC_BUFF_SIZE);
		clr_to_snd=READY;
		rec_buff_index=0;
	}
	//insert new character int receive buffer
	else if ((REC_BUFF_SIZE>rec_buff_index)&&(clr_to_snd==BUSY)) {
		rec_buff[rec_buff_index]=newData2;
		rec_buff_index++;
	}
	//shouldn't get to here, not expecting to overflow receive buffer
	if(rec_buff_index>REC_BUFF_SIZE){
		memset(rec_buff,0,REC_BUFF_SIZE);
		rec_buff_index=0;
	}
	ODBII_timeout=0;
	IFS1bits.U2RXIF = 0;
}
/********** ******************** **********/

/********** TIMER INTERUPTS **********/
//T1 = OBDII - 50 msec
void __attribute__ ((interrupt)) _T1Interrupt(void){
	int i;
	//send next OBD-II request
	if ((clr_to_snd==READY)||(ODBII_timeout>10)){
		clr_to_snd=READY;
		switch (next_send){
			case 0:		for(i=0; i<lrequest; i++){
							while(U2STAbits.UTXBF==1){}
							U2TXREG=mveh_speed[i];
						}
						break;
			case 1:		for(i=0; i<lrequest; i++){
							while(U2STAbits.UTXBF==1){}
							U2TXREG=mMAF[i];
						}
						break;
			case 2:  	for(i=0; i<lrequest; i++){
							while(U2STAbits.UTXBF==1){}
							U2TXREG=mBoost[i];
						}
						break;
		}
		while(U2STAbits.UTXBF==1){}
		U2TXREG=carriage_return;
		clr_to_snd=BUSY;
		//decide what message to request next
		switch (MODE){
			case MODE_ZtS:		next_send=0;
								break;
			case MODE_MPG:		next_send++;
								if(next_send>1){next_send=0;}
								break;
			case MODE_QM:		
			case MODE_EM:		next_send=0;
								break;
			case MODE_Boost:    next_send=2;
								break;
			default:			next_send=0;
		}
		ODBII_timeout=0;
	}

	
	IFS0bits.T1IF = 0;		// clear interrupt flag
}
//T2 = clock - 20 msec
void __attribute__ ((interrupt)) _T2Interrupt(void){
	//update timers
	timer20ms_A++;
	timer20ms_B++;
	timer20ms_C++;
	timer20ms_D++;
	timer20ms_ODO++;
	if (timer20ms_A>=5){
		timer100ms++;
		ODBII_timeout++;
		timer20ms_A=0;
	}
	
	IFS0bits.T2IF = 0;		// clear interrupt flag
}
/********** ******************** **********/

int _EEDATA(32) DataEE[] = {0,1,2,3,4,5,6,7,8,9,0xA,0xB,0xC,0xD,0xE,0xF};
int InRAM[] = {0xAAAA, 0xBBBB, 0xCCCC, 0xDDDD, 0xEEEE, 0xFFFF, 0xABCD, 0xBCDE,
                       0xCDEF, 0xDEFA, 0x0000, 0x1111, 0x2222, 0x3333, 0x4444, 0x5555};
//main-loop
//simply updates inputs, calls model, dispalys model's outputs
int main(){
	char msg[16];
	//int first_run=0;
	init_RAM();
	UART_config1();
	UART_config2();
	TIMER_config1();
	TIMER_config2();
	initSwitches();

	ADPCFG = 0xFFFF;			//Make analog pins digital 
	//TRISB = 0x0000; 			//All of port B is output
	TRISB = 0x0003; 			//0 and 1 are inputs
	LATBbits.LATB6=OFF;
	  
	//delay to allow LCD to boot up
	timer20ms_C=0;                                  
	while(timer20ms_C<15){}//wait 3 seconds for LCD to boot up
	timer20ms_C=0;

	SRPM_Core_initialize(1);

	//EraseEE(0, 0, 16);
	//memset(_EEDATA,0,32*sizeof(int));
	//ReadEE(0x7F, 0xFC00, &_EEDATA[0], 16);

	writeln("ZERO TO SIXTY                0.0", 32, 1);

//while 1
	while(1){
		
		if (timer20ms_B>=2){//40ms
			debounceSW((unsigned int) PORTBbits.RB0, 0);
			debounceSW((unsigned int) PORTBbits.RB1, 1);
			timer20ms_B=0;
		}

		//update inputs
		MODE_API=MODE;
		veh_speed_API=veh_speed;
		clock_timer_API=timer100ms;
		MAF_API = MAF;
		ODO_API=ODO;
		//eeprom inputs
		EEPROM_ZtS_best_API=0;//_EEDATA[0];
		EEPROM_QM_best_time_API=0;//_EEDATA[1];
		EEPROM_QM_best_speed_API=0;//_EEDATA[2];
		EEPROM_EM_best_time_API=0;//_EEDATA[3];
		EEPROM_EM_best_speed_API=0;//_EEDATA[4];
	
		//run model
		rt_OneStep();

		//handle outputs
		if (timer20ms_C>=5){//refresh LCD every 100 ms
			if((old_MODE!=MODE)||(timer20ms_D>125)){
				switch(MODE){
					case MODE_ZtS:		writeln(ZtS_header, 16, 1);
										break;
					case MODE_MPG:		writeln(MPG_header, 16, 1);
										break;
					case MODE_QM:		writeln(QM_header, 16, 1);
										break;
					case MODE_EM:		writeln(EM_header, 16, 1);
										break;
					case MODE_Boost:	writeln(Bst_header, 16, 1);
										break;
					default:			writeln(DEF_header, 16, 1);

				}
				timer20ms_D=0;
				old_MODE=MODE;
			}
			switch(MODE){
				case MODE_ZtS:		if(show_best==0){
										displayZtS(msg, ZtS_time_API,ZtS_ready_API);
										//displayZtS(msg, 149,ZtS_ready_API);
									}else{
										displayZtSBest(msg, ZtS_best_API);
										//displayZtSBest(msg, 123);
									}
									break;
				case MODE_MPG:		dispTime(msg, MPG_API);
									break;
				case MODE_QM:		if(show_best==0){
										dispMile(msg, QE_time_API, QE_speed_API);
									}else{
										
										dispMile(msg, QM_best_time_API, QM_best_speed_API);
									}
									break;
				case MODE_EM:		if(show_best==0){
										dispMile(msg, QE_time_API, QE_speed_API);
									}else{
										
										dispMile(msg, EM_best_time_API, EM_best_speed_API);
									}
									break;
				case MODE_Boost:	dispBoost(msg, boost);
									//dispBoost(msg, 40);
									break;
			}
			writeln(msg, 16, 2);
			timer20ms_C=0;

			//write to eeprom?
			//if( (ZtS_best_API!=_EEDATA[0])||(QM_best_time_API!=_EEDATA[1])||(QM_best_speed_API!=_EEDATA[2])||
				//(EM_best_time_API!=_EEDATA[3])||(EM_best_speed_API!=_EEDATA[4]) ){
				//_EEDATA[0]=1;//ZtS_best_API;
				//_EEDATA[1]=1;//QM_best_time_API;
				//_EEDATA[2]=1;//QM_best_speed_API;
				//_EEDATA[3]=1;//EM_best_time_API;
				//_EEDATA[4]=1;//EM_best_speed_API;
				//WriteEE(&_EEDATA[0], 0x7F, 0xFC00, 16);
				//EraseEE(__builtin_tblpage(&DataEE[0]), __builtin_tbloffset(&DataEE[0]), ROW);
				//WriteEE(&InRAM[0],__builtin_tblpage(&DataEE[0]),__builtin_tbloffset(&DataEE[0]), ROW);			
			//}

		}
	}
//end while 1

	SRPM_Core_terminate();
	return 0;
}

//initializes RAM variables to 0, only do once upon bootup
void init_RAM(){
	//num_recs=0;
	next_send=0;
	clr_to_snd=BUSY;

	memset(rec_buff,0,REC_BUFF_SIZE);
	rec_buff_index=0;
	ODBII_timeout=0;
	MODE=MODE_ZtS;
	old_MODE=99;
	veh_speed=0;
	MAF=0;
	ODO=0;
	show_best=0;
	boost=0;

	timer20ms_A=0;
	timer20ms_B=0;
	timer20ms_C=0;
	timer20ms_D=0;
	timer20ms_ODO=0;
	timer100ms=0;
	timer20ms_saved=0;


}
