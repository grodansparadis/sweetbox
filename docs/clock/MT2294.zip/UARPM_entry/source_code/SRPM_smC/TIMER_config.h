

inline void TIMER_config1(){
	TMR1 = 0;				// clear timer 1

	PR1=0x0F42;			//every 50 ms
	//PR1=0x1E85;				//interupt every 100 msec

	IFS0bits.T1IF = 0;		// clr interrupt flag
	IEC0bits.T1IE = 1;		// set interrupt enable bit

	T1CON=0xA020;			// 20Mhz/4, 1:64 prescale: 78125 counts/sec
}

inline void TIMER_config2(){
	TMR2 = 0;				// clear timer 2

	//PR2=0x030D			//every 10 ms
	PR2=0x61A;				//every 20 ms
	//PR2=0x0F42			//every 50 ms
	//PR2=0x1E85;				//interupt every 100 ms

	IFS0bits.T2IF = 0;		// clr interrupt flag
	IEC0bits.T2IE = 1;		// set interrupt enable bit

	T2CON=0xA020;			// 20Mhz/4, 1:64 prescale: 78125 counts/sec
}

inline void TIMER_config3(){
	TMR3 = 0;
}


