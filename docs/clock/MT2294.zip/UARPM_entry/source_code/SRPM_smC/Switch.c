
#include <p30f3013.h>
#include "Switch.h"
//#include "OBDII.h"


unsigned short int ok_to_toggle[2];
unsigned short int SW[2];
unsigned short int old_SW[2];
extern unsigned int MODE;
extern unsigned short int show_best;



void initSwitches(){
	ok_to_toggle[0]=0;
	ok_to_toggle[1]=0;
	SW[0]=OPEN;
	SW[1]=OPEN;
	old_SW[0]=OPEN;
	old_SW[1]=OPEN;
}


int debounceSW(unsigned int Switch, unsigned int index){
	//int i=0;
	if(Switch==OPEN){
		SW[index]=OPEN;//normally = 1
		if(SW[index]==old_SW[index]){
			ok_to_toggle[index]=1;
			if(index==0){
			}
			else{
				show_best=0;
			}
		}
	}
	else{
		SW[index]=CLOSED;
		if((SW[index]==old_SW[index])&&(ok_to_toggle[index]==1)){
			if(index==0){
				MODE++;
				if (MODE>4){
					MODE=0;
				}
			}
			else if (index==1){
				show_best=1;
			}
			ok_to_toggle[index]=0;
		}
	}
	old_SW[index]=SW[index];
	return 0;
}

