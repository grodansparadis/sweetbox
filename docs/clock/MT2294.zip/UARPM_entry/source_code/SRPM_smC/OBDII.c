//#include <p30f3013.h>
//#include "OBDII.h"


unsigned int getASCIInum(unsigned char MSC, unsigned char LSC){
	unsigned int retval=0;

	if ((MSC>=48)&&(MSC<=57)) {
		retval=retval+((MSC-48)*16);
	}
	else if ((MSC>=65)&&(MSC<=70)) {
		retval=retval+((MSC-55)*16);
	}
	else{
		return 0;
	}

	if ((LSC>=48)&&(LSC<=57)) {
		retval=retval+((LSC-48)*1);
	}
	else if ((LSC>=65)&&(LSC<=70)) {
		retval=retval+((LSC-55)*1);
	}
	else{
		return 0;
	}

	return retval;

}

unsigned int getMAF(unsigned char MSCA, unsigned char LSCA, unsigned char MSCB, unsigned char LSCB){
	unsigned int A,B;
	A=getASCIInum(MSCA, LSCA);
	B=getASCIInum(MSCB, LSCB);

	return ((256*A)+B)/100;


}
