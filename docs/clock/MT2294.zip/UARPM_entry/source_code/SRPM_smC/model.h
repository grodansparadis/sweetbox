#include "model\SRPM_Core.h"                  /* Model's header file */
#include "model\rtwtypes.h"                   /* MathWorks types */

static boolean_T OverrunFlag = 0;
//inputs
#define MODE_API		SRPM_Core_U.MODE_API
#define veh_speed_API	SRPM_Core_U.veh_speed_API
#define clock_timer_API	SRPM_Core_U.clock_timer_API
#define MAF_API			SRPM_Core_U.MAF_API	
#define ODO_API			SRPM_Core_U.ODO_API

#define EEPROM_ZtS_best_API			SRPM_Core_U.EEPROM_ZtS_best_API
#define EEPROM_QM_best_time_API		SRPM_Core_U.EEPROM_QM_best_time_API
#define EEPROM_QM_best_speed_API	SRPM_Core_U.EEPROM_QM_best_speed_API
#define EEPROM_EM_best_time_API		SRPM_Core_U.EEPROM_EM_best_time_API
#define EEPROM_EM_best_speed_API	SRPM_Core_U.EEPROM_EM_best_speed_API
		
//outputs
#define ZtS_time_API	SRPM_Core_Y.ZtS_time
#define ZtS_ready_API	SRPM_Core_Y.ZtS_ready
#define ZtS_best_API	SRPM_Core_Y.ZtS_best
#define MPG_API			SRPM_Core_Y.MPG
#define QE_time_API		SRPM_Core_Y.QE_time
#define QE_speed_API	SRPM_Core_Y.QE_speed
#define QM_best_time_API	SRPM_Core_Y.QM_best_time
#define QM_best_speed_API	SRPM_Core_Y.QM_best_speed
#define EM_best_time_API	SRPM_Core_Y.EM_best_time
#define EM_best_speed_API	SRPM_Core_Y.EM_best_speed
#define QE_ready_API	SRPM_Core_Y.QE_ready


void rt_OneStep(void)
{
  /* Disable interrupts here */

  /* Check for overun */
  if (OverrunFlag++) {
    rtmSetErrorStatus(SRPM_Core_M, "Overrun");
    return;
  }

  /* Save FPU context here (if necessary) */
  /* Re-enable timer or interrupt here */
  /* Set model inputs here */

  SRPM_Core_step();

  /* Get model outputs here */

  OverrunFlag--;

  /* Disable interrupts here */
  /* Restore FPU context here (if necessary) */
  /* Enable interrupts here */
}




