dsNavCon project Registration Number MT2155

In this folder there are:

MT2155_dsNavCon_Full_Doc.doc
  A complete description of the project
Full_Doc_Pictures
  A folder with a high resolution copy of the pictures embedded in the document