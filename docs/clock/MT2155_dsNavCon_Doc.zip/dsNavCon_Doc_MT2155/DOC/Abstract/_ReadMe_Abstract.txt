dsNavCon project Registration Number MT2155

In this folder there are:

MT2155_dsNavCon_Abstract.doc
  A brief description of the project
MT2155_dsNavCon_Code_Sample.doc
  The main loop and the Interrupt Service Routines as a sample of the code
dsNavCon_Schematic.gif
  Schematic diagram of the dsNavCon board
dsNavCon_Block_diagram.jpg
  Block diagram with interconnections between board and other devices involved 
dsNavCon_Pict.jpg
  A photo of the dsNavcon board installed on the robot and connected to motors and sensors