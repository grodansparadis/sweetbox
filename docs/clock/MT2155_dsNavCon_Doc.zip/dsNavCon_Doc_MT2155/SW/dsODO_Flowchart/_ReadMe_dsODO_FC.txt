dsNavCon project Registration Number MT2155

Flow chart of the Supervisor portion of the code.
It is described in:
dsODO_FC_Main			Main loop
dsODO_FC_ISR			Interrupt Service Routines
dsODO_FC_Functions		Standard routines

The program is full interrupt driven.
After initialization it enters in a very simple Main loop, acting as a state machine.
Here it checks some flags enabled by external events and enters in the relative state. 
Since it's a some kind of a very simple cooperative "Real Time Operative System", every routine has to be executed in the shortest possible time, freeing the system to serve the very frequent interrupts.

Detailed descriptions are on file "descrEng.txt" in the code folder.
Numbers between brackets, eg.: [1] , are the references to the specific decription into that file.
