dsNavCon project Registration Number MT2155

Flow chart of the Motor Controllers portion of the code.
It is described in:
dsPID_FC_Main			Main loop
dsPID_FC_ISR			Interrupt Service Routines
dsPID_FC_Functions		Standard routines

The same program is loaded in both motor controllers dsPIC30F4012, the supervisor assigns them a different id after initialization.
The program is full interrupt driven.
After the supervisor enabling, initialization starts and it enters in a very simple Main loop, acting as a state machine.
Here it checks some flags enabled by external events and enters in the relative state. 
Since it's a some kind of a very simple cooperative "Real Time Operative System", every routine has to be executed in the shortest possible time, freeing the system to serve the very frequent interrupts.

Detailed descriptions are on file "descrEng.txt" in the code folder.
Numbers between brackets, eg.: [1] , are the references to the specific decription into that file.
