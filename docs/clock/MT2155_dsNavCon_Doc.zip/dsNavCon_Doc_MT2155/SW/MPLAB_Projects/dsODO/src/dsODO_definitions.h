/* ////////////////////////////////////////////////////////////////////////////
** Included in "dsODO.c", it contains definitions and variables initialization
/////////////////////////////////////////////////////////////////////////////*/

/*---------------------------------------------------------------------------*/
/* standard	includes													     */
/*---------------------------------------------------------------------------*/
#include "dsODO_common.h"

/*---------------------------------------------------------------------------*/
/* Status bits			    											     */
/*---------------------------------------------------------------------------*/
/* Run this project using an external crystal routed via the PLL in 
16x multiplier mode 
For the 7.3728 MHz crystal we will derive a throughput of 
7.3728e+6*16/4 = 29.5s MIPS(Fcy) ~33.9 nanoseconds instruction 
cycle time(Tcy).*/
_FOSC(CSW_FSCM_OFF & XT_PLL16);

#ifdef debug_SA	// [15c]
	//Turn off the Watch-Dog Timer.	 [1]		
	_FWDT(WDT_OFF);	
#else
	// WDT Period = 2 ms � Prescale A � Prescale B	-> 2 x 8 x 5 = 80ms
	_FWDT(WDT_ON & WDTPSA_8 & WDTPSB_5);
#endif

//Enable MCLR reset pin and turn on the power-up timers with 64ms delay.
_FBORPOR(MCLR_EN & PWRT_64);				
//Disable Code Protection											
_FGS(CODE_PROT_OFF);            			 

/*---------------------------------------------------------------------------*/
/* include       														     */
/*---------------------------------------------------------------------------*/
#include "dsODO_prototypes.h"


/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/* Definizioni globali                                                       */
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

struct Bits{
	unsigned bit0:1;
	unsigned bit1:1;
	unsigned bit2:1;
	unsigned bit3:1;
	unsigned bit4:1;
	unsigned bit5:1;
	unsigned bit6:1;
	unsigned bit7:1;
};

struct Bits VARbits1;
struct Bits VARbits2;

//----- Flags

#define HRT_BT _LATB5
#define LED1 _LATB6
#define LED2 _LATB9
#define CS1	_LATB1		// Generic chip select 1
#define TX_EN1	_LATB2	// TX enable 1
#define CS2	_LATB3		// Generic chip select 2
#define TX_EN2	_LATB4	// TX enable 2
#define MAX_TX_BUFF 32
#define MAX_RX_BUFF 32
#define DISABLE_TX U1STAbits.UTXEN = 0
#define ENABLE_TX U1STAbits.UTXEN = 1
#define DISABLE_TX2 U2STAbits.UTXEN = 0
#define ENABLE_TX2 U2STAbits.UTXEN = 1

const long Tcy = 1000000/(float)(FCY)* 100000000;

//----- Variabili
int i = 0; // generic index
int j = 0; // generic index
long Blink = 0; // heartbeat blink index

// UART1
unsigned char IdRx;					// Motor Controller Id [14]
unsigned char IdTx;
#define ID_R 1						// right motor Id
#define ID_L 2						// left motor Id
#define ID_I 9						// start-up Id
#define ID_A 0						// Id all (broadcast)
#define R 0							// right index
#define L 1							// right index

unsigned char UartRxBuff[MAX_RX_BUFF];	// serial communication buffer
unsigned char UartTxBuff[MAX_TX_BUFF];
unsigned char UartTmpBuff[MAX_TX_BUFF-4];// temp buffer to compose TX buffer
#define TX_FLAG VARbits1.bit0			// transmission status
#define	TX_BUFF_FULL VARbits1.bit1		// TX bufer status		
int UartRxCntr=0;						// buffer index
unsigned int UartTxCntr=0;
unsigned int UartRxBuffSize=0;			// buffer size
unsigned int UartTxBuffSize=0;
#define UART_RX_TIME_OUT 5				// RX timeout timer in ms
int UartRxTmr = UART_RX_TIME_OUT;
int UartRxStatus =0;					// index for command decoding status
#define RX_FLAG VARbits1.bit2			// new character coming flag
#define OVERRUN_ERROR U1STAbits.OERR	// RX overrun error flag
#define TX_REG_EMPTY  U1STAbits.TRMT	// TX shift register empty
#define FRAME_ERROR U1STAbits.FERR		// RX frame error flag
#define HEADER '@'						// command string header
#define UART_RX_CMD UartRxBuff[2]		// command code
#define UART_RX_CMD_LEN UartRxBuff[3]	// command length
#define RX_ID_FLAG VARbits1.bit3		// command decode flag
#define RX_HEADER_LEN 3					// command string header length (byte) 

// UART2
unsigned char IdRx2;
unsigned char UartRx2Buff[MAX_RX_BUFF];	// serial communication buffer
unsigned char UartTx2Buff[MAX_TX_BUFF];
unsigned char UartTmp2Buff[MAX_TX_BUFF-4];// temp buffer to compose TX buffer 
#define TX2_FLAG VARbits1.bit4			// transmission status
#define	TX2_BUFF_FULL VARbits1.bit5		// TX bufer status		
int UartRx2Cntr=0;						// buffer index
unsigned int UartTx2Cntr=0;
unsigned int UartRx2BuffSize=0;			// buffer size
unsigned int UartTx2BuffSize=0;
#define UART_RX2_TIME_OUT 5				// RX timeout timer in ms
int UartRx2Tmr = UART_RX2_TIME_OUT;
int UartRx2Status =0;					// index for command decoding status
#define RX2_FLAG VARbits1.bit6			// new character coming flag
#define OVERRUN_ERROR2 U2STAbits.OERR	// RX overrun error flag
#define TX2_REG_EMPTY  U2STAbits.TRMT	// TX shift register empty
#define FRAME_ERROR2 U2STAbits.FERR		// RX frame error flag
#define UART_RX2_CMD UartRx2Buff[2]		// command code
#define UART_RX2_CMD_LEN UartRx2Buff[3]	// command length
#define RX2_HEADER_LEN 3				// command string header length (byte) 

int Kpid[3][2] = {{600,600},{200,200},{20,20}};// parametri PID * 1000

/*
->  [19] and also dsPID:descr.txt [4] [7]
Encoder = 300 cpr 
Gear reduction ratio = 30:1
Wheel speed = 200 rpm
Encoder pulses for each wheel turn = 9.000
Wheel diameter = 58mm -> circumference = 182,2123739mm
Space for each encoder pulse 1x mode Delta S = 0,020245819mm
Space for each encoder pulse 2x mode Delta S = 0,01012291mm
Space for each encoder pulse 4x mode Delta S = 0,005061455mm
Speed calculation K in micron/second = 298536736 -> [19]
*/
#define CPR 300
#define GEAR_RATIO 30
#define CPR_WHEEL CPR*GEAR_RATIO				// 9000
#define DIAMETER  0.058
#define CIRC  DIAMETER*PI						// 0,182212374
#define SPACE_ENC_1X (CIRC / (CPR_WHEEL))
#define SPACE_ENC_2X (CIRC / (CPR_WHEEL * 2))	// 1,012291E-05
#define SPACE_ENC_4X (CIRC / (CPR_WHEEL * 4))
#define K_VEL ((SPACE_ENC_2X) / (TCY))			// TCY = 3,390842E-08
// Speed calculation K in m/s
long Kvel[2] = {9782453,9782453}; // K_VEL << 15
int VelDes[2] = {0,0};							// desired speed mm/s
int VelMes[2] = {0,0};							// measured speed mm/s	

// costants for traveled distance calculation: SPACE_ENC_4X in mm
float Ksp[2] = {0.00506145483078356,0.00506145483078356};
float Axle = 185.2222;// base width, distance between center of the wheels
float SemiAxle = 92.6111; // Axle / 2
int SpTick[2] = {0,0};	// distance traveled by a wheel as encoder pulses
float Spmm[2] = {0,0};	// distance traveled by a wheel as mm(SpTick[x]*Ksp[x])
float Space = 0;		// total distance traveled by the robot
#define SPMIN 0.003		// TO CHECK. Minimum value to perform odometry
float CosPrev =	1;		// previous value for Cos(Theta)
float SinPrev =	0;		// previous value for Sin(Theta)
float PosX = 0;			// X position coordinate
float PosY = 0;			// X position coordinate
float Theta = 0;		// Current orientation angle
#define PI 	  3.1415926536
#define TWOPI 6.2831853072

	
// parameters request to Motor Controllers [20]
unsigned char AskParam;
unsigned char AskParamStatus;
#define ASK_PARAM_FLAG VARbits1.bit7
unsigned char AskParamTimer1;	// timer for parameters request
unsigned char AskParamTimer2;	// timer for ALL parameters request
#define	ASK_PARAM_TMO 10		// asks parameters every Xms	
#define	ASK_PARAM_ALL_TMO 5		// asks all parameters every N x Xms	

int Curr[2] = {0,0};			// motor current

typedef struct 
{
	unsigned char Low:4;
	unsigned char High:4;
}_Coordinate;

 _Coordinate MapXY [25][50];	// to store field mapping [21]
 unsigned char XnormPrev;		// previous X index in 0-49 range
 unsigned char YindxPrev;		// previous Y index in 0-49 range
#define SPACE_FLAG VARbits2.bit0
#define ODO_FLAG VARbits2.bit1
#define CELL_SIZE 10			// Dimension of grid cell side in cm


/* Definitions end ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
