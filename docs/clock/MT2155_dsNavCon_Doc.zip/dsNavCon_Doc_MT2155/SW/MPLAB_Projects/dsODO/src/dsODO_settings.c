/* ////////////////////////////////////////////////////////////////////////////
** It contains dsPIC settings and initializations
**
** Detailed description are on file "descrEng.txt" 
** numbers between brackets, eg.: [1] , are the references to the specific 
** decription into the file
**
** I commenti dettagliati sono sul file "descrIta.txt" 
** il numero fra parentesi quadre, es.: [1] , e' il riferimento al relativo 
** commento nel documento di descrizione        
/////////////////////////////////////////////////////////////////////////////*/


// standard includes
#include "dsODO_common.h"

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/* ports and peripherals registers setting an initialization                 */
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
void Settings(void)
{
/*---------------------------------------------------------------------------*/
/* Port	B   			    											     */
/*---------------------------------------------------------------------------*/

// all pins are digital OUT
TRISB  = 0b0000000000000000;
ADPCFG = 0b0000000000000000;

/*---------------------------------------------------------------------------*/
/* USART1	[6]     			    									     */
/*---------------------------------------------------------------------------*/
long BaudRate;
//Baud Rate=Fcy/(16*(UxBRG+1)) MAX for dsPIC to dsPIC is 921.600 or 1.843.200
BaudRate = 921600; // baud rate desired 

#define BRG (FCY/(16*((long)BaudRate)))-1//value to place in the U1BRG register

// Holds the value of uart config reg
unsigned int U1MODEvalue;
// Holds the information regarding uart TX & RX interrupt modes
unsigned int U1STAvalue;

// Configure UART1 module to transmit 8 bit data with one stopbit.
U1MODEvalue= UART_EN & UART_IDLE_STOP & UART_DIS_WAKE & UART_ALTRX_ALTTX & 
			UART_DIS_ABAUD & UART_NO_PAR_8BIT & UART_2STOPBITS & 
			UART_DIS_LOOPBACK;
U1STAvalue= UART_INT_TX & UART_TX_PIN_NORMAL & UART_TX_ENABLE &
			UART_INT_RX_CHAR & UART_ADR_DETECT_DIS & UART_RX_OVERRUN_CLEAR;
OpenUART1(U1MODEvalue, U1STAvalue, BRG);
/*.....................................................................USART1*/

/*---------------------------------------------------------------------------*/
/* USART2	[6d]     			    									     */
/*---------------------------------------------------------------------------*/
long BaudRate2;
// Baud Rate = Fcy / ( 16 * (UxBRG + 1) )
BaudRate = 115200; // baud rate desired 

//value to place in the U2BRG register
#define BRG2 (FCY/(16*((long)BaudRate2)))-1

// Holds the value of uart config reg
unsigned int U2MODEvalue;
// Holds the information regarding uart TX & RX interrupt modes
unsigned int U2STAvalue;

// Configure UART2 module to transmit 8 bit data with one stopbit.
U2MODEvalue= UART_EN & UART_IDLE_STOP & UART_DIS_WAKE & 
			UART_DIS_ABAUD & UART_NO_PAR_8BIT & UART_1STOPBIT & 
			UART_DIS_LOOPBACK;
U2STAvalue= UART_INT_TX & UART_TX_PIN_NORMAL & UART_TX_ENABLE &
			UART_INT_RX_CHAR & UART_ADR_DETECT_DIS & UART_RX_OVERRUN_CLEAR;
OpenUART2(U2MODEvalue, U2STAvalue, BRG2);
/*.....................................................................USART2*/

/*---------------------------------------------------------------------------*/
/* Timer 1	1ms [13]    			    									 */
/*---------------------------------------------------------------------------*/
OpenTimer1(	T1_ON & 
		T1_GATE_OFF & 
		T1_PS_1_1 & 
		T1_SYNC_EXT_OFF &
		T1_SOURCE_INT, 
		TMR1_VALUE);
/*................................................................ ..Timer 1 */

/*---------------------------------------------------------------------------*/
/* Timer 2	[12]    			    									     */
/*---------------------------------------------------------------------------*/
#define TMR2_VALUE 3
OpenTimer2(	T2_ON & 
			T2_GATE_OFF & 
			T2_PS_1_1 &
			T1_SYNC_EXT_OFF &
			T2_SOURCE_INT, 
			TMR2_VALUE);
/*...................................................................Timer 2 */

/*---------------------------------------------------------------------------*/
/* PWM [5]    		             	    									 */
/*---------------------------------------------------------------------------*/
OpenOC1(OC_IDLE_STOP & OC_TIMER2_SRC & OC_PWM_FAULT_PIN_DISABLE, 2, 2);

/*.......................................................................PWM */
}


/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/* Interrupts setting                                                        */
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
void ISR_Settings(void)
{
//-------USART1	[6]
ConfigIntUART1(UART_RX_INT_EN & UART_RX_INT_PR4 & UART_TX_INT_EN & 
				UART_TX_INT_PR4);
				
//-------USART2	[6d]
ConfigIntUART2(UART_RX_INT_EN & UART_RX_INT_PR4 & UART_TX_INT_EN & 
				UART_TX_INT_PR4);
}

