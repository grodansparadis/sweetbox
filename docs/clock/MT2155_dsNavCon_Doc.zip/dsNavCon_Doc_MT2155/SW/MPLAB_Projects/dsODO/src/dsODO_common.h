/* //////////////////////////////////////////////////////////////////////////*/
/*Commons includes and definitions                                           */
/* //////////////////////////////////////////////////////////////////////////*/

// include standard
#include <p30f3013.h>
#include <uart.h>
#include <ports.h>
#include <timer.h>
#include <outcompare.h>
#include <math.h>
#include <stdlib.h> /* for div, div_t */
/*
#include <dsp.h>
*/

#define CLOCK_FREQ 7372800 					//7.3728 MHz
#define PLL 16 		 						//x16 mode
#define FCY (CLOCK_FREQ*PLL)/4				//29,4912 MHz period = 33,90842ns
#define TCY 1/((float)(CLOCK_FREQ*PLL/4))

#define _ISR_PSV __attribute__((interrupt, auto_psv))

#define debug_SA	// [15]

#define TMR1_VALUE 29491	// it means a 1ms period on TMR1
