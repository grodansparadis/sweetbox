/* ////////////////////////////////////////////////////////////////////////////
** File:      dsODO.c
*/                                  
#define  Ver "dsODO ver 0.1\n\r 07-2007"
/*
** Description:navigation control through odometry with dsPIC30F3013   
** Descrizione:controllo movimento tramite odometria con dsPIC30F3013   
**
** Detailed descriptions are on file "descrEng.txt" 
** numbers between brackets, eg.: [1] , are the references to the specific 
** decription into the file
**
** I commenti dettagliati sono sul file "descr.txt" 
** il numero fra parentesi quadre, es.: [1] , e' il riferimento al relativo 
** commento nel documento di descrizione        
/////////////////////////////////////////////////////////////////////////////*/

#include "dsODO_definitions.h"


int main (void)
{
Settings();

LED1 = 1;			// [1]
LED2 = 0;
RX_FLAG = 0;
RX2_FLAG = 0;
TX_FLAG = 0;
TX_BUFF_FULL=0;		
TX2_FLAG = 0;
TX2_BUFF_FULL=0;		
UartRxStatus = 0;
UartRx2Status = 0;
ASK_PARAM_FLAG = 0;	// [20]
SPACE_FLAG=0;		// [21c]
ODO_FLAG=0;
AskParam = 0;
AskParamTimer1 = 0;
AskParamTimer2 = 0;
		
ISR_Settings();	// Configures and enables ISRs

MC_Setting();	// Configures both motor controllers [16a]

//------- Enables Timer 1 interrupt	[13]
// Starts timing for Supervisor and Motor Controllers
ConfigIntTimer1(T1_INT_PRIOR_4 & T1_INT_ON);
PR1 = TMR1_VALUE;

/*===========================================================================*/
/* Main loop                                                                 */
/*===========================================================================*/
while (1)
{	
/* ----------------------------------------- one character coming from UART1 */	
if (RX_FLAG) UartRx();	

/* ----------------------------------------- one character coming from UART2 */	
if (RX2_FLAG) UartRx2();	

/* ------------ a command coming from serial interface 1 (Motor Controllers) */	 
if (UartRxStatus == 99) Parser();

/* --------------------- a command coming from serial interface 2 (telemetry)*/	 
if (UartRx2Status == 99) Parser2();

/* ---------------- a string has to be sent on serial interface 2 towards MCs*/	 
if (TX_FLAG)	UartTx();

/* --------- a string has to be sent on serial interface 2 towards Main board*/	 
if (TX2_FLAG) UartTx2();

/* ------------------ it's time to ask parameters to Motor Controllers [20a] */	 
if (ASK_PARAM_FLAG)	AskParamCall();

/* ----------------------------------------- DeadReckonig field mapping [21] */	 
if (ODO_FLAG) DeadReckoning();

	if (Blink == 200)	// [1a]
	{
		LED1 = 0;
		Blink ++;
	}
	if (Blink == 1001)
	{
		LED1 = 1;
		Blink = 0;
	}
}/*....Main loop*/

}/*.....................................................................Main */


/*===========================================================================*/
/* Functions                                                                 */
/*===========================================================================*/
void DeadReckoning(void) // [21]
{
	float CosNow;		// current value for Cos
	float SinNow;		// current value for Sin
	float DSpace;		// delta traveled distance by the robot
	float DTheta;		// delta rotation angle
	float DPosX;		// delta space on X axis
	float DPosY;		// delta space on Y axis
	float SrMinusSl;
	float SrPlusSl;
	float Radius;
	
	unsigned char Xnorm;	// X index in 0-49 range
 	unsigned char Xindx;	// X index in 0-24 range
 	unsigned char Yindx;	// Y index in 0-49 range
 	div_t z;				// for div function
 			
	SPACE_FLAG=0;	// [21c]
	ODO_FLAG=0;
	
	Spmm[R]=SpTick[R]*Ksp[R];	// distance of right wheel in mm
	Spmm[L]=SpTick[L]*Ksp[L];	// distance of left wheel in mm
	SrMinusSl=Spmm[R]-Spmm[L];
	SrPlusSl=Spmm[R]+Spmm[L];
	if (fabs(SrMinusSl) <= SPMIN)
	{// traveling in a nearly straight line [21a]
		DSpace=Spmm[R];
		DPosX=DSpace*CosPrev;
		DPosY=DSpace*SinPrev;
	}
	else if (fabs(SrPlusSl) <= SPMIN)
	{// pivoting around vertical axis without translation [21a]
		DTheta=SrMinusSl/Axle;
		Theta = fmodf((Theta+DTheta),TWOPI);// current orientation in 2PI range
		CosPrev=cosf(Theta);	// for the next cycle
		SinPrev=sinf(Theta);
		DPosX=0;
		DPosY=0;
		DSpace=0;
	}
	else
	{// rounding a curve	
		DTheta=SrMinusSl/Axle;
		Theta = fmodf((Theta+DTheta),TWOPI);// current orientation in 2PI range
		CosNow=cosf(Theta);
		SinNow=sinf(Theta);
		DSpace=SrPlusSl/2;
		Radius=SemiAxle*(SrPlusSl/SrMinusSl);
		DPosX=Radius*(SinNow-SinPrev);
		DPosY=Radius*(CosPrev-CosNow);
		CosPrev=CosNow;		// to avoid re-calculation on the next cycle
		SinPrev=SinNow;
	}

	Space += DSpace;	// total traveled distance
	PosX += DPosX;		// current position
	PosY += DPosY;
	
	// field mapping [21b]
	Xnorm=(__builtin_modsd((PosX+5000),5000))/100;	// index in the range 0-49
	Yindx=(__builtin_modsd((PosY+5000),5000))/100;
	z=div(Xnorm,2);		// index in the range 0-24 and remainder 0-1
	Xindx=z.quot;
	if ((Xnorm != XnormPrev) || (Yindx != YindxPrev)) //only when cell changes
	{
		if (z.rem)
		{// increment cell value only if < 10
			if (MapXY[Xindx][Yindx].High < 10) MapXY[Xindx][Yindx].High ++;
		}
		else
		{
			if (MapXY[Xindx][Yindx].Low < 10) MapXY[Xindx][Yindx].Low ++;		
		}
		XnormPrev=Xnorm;
		YindxPrev=Yindx;		
	}
}

void AskParamCall(void)
{
	if (AskParamStatus == 1) // [20]
	{
		IdTx = ID_R;
		TX_EN2 = 0;
		Nop();
		TX_EN1 = 1;
	}
	if (AskParamStatus == 2)
	{
		IdTx = ID_L;
		TX_EN1 = 0;
		Nop();	
		TX_EN2 = 1;
	}
	switch (AskParam)
	{
		case 1:
			TxParameters(IdTx,'P',0);  // position value request [16]		
		break;
		
		case 4:
			TxParameters(IdTx,'A',0);  // all parameters request [16]		
		break;

		case 2:
			TxParameters(IdTx,'V',0);  // speed parameter request [16]		
		break;

		case 3:
			TxParameters(IdTx,'C',0);  // motor current request [16]		
		break;
	}	
	ASK_PARAM_FLAG = 0; // [20b]
}
void TxParameters(char Id,char TxCmd,int TxCmdLen)	// [18]
{
	int TxCount;
	
	UartTxBuff[0] = '@';		// Header
	UartTxBuff[1] = Id;			// Id
	UartTxBuff[2] = TxCmd;		// Cmd
	UartTxBuff[3] = TxCmdLen +1;	// CmdLen
	if (TxCmdLen)	// at least one parameter to send
	{
		for (TxCount = 0; TxCount < TxCmdLen; TxCount ++)
		{
			UartTxBuff[TxCount + 4] = UartTmpBuff[TxCount];
		}
	}
	UartTxBuff[TxCount + 4] = UartChkSum(UartTxBuff,TxCount + 4);
	UartTxBuffSize = TxCount + 5;
	TX_FLAG =1;	// invia il buffer
}

void Tx2Parameters(char TxCmd,int TxCmdLen)	// [18a]
{
	int TxCount;
	
	UartTx2Buff[0] = '@';			// Header
	UartTx2Buff[1] = ID_A;			// Id broadcast
	UartTx2Buff[2] = TxCmd;			// Cmd
	UartTx2Buff[3] = TxCmdLen +1;	// CmdLen
	if (TxCmdLen)	// at least one parameter to send
	{
		for (TxCount = 0; TxCount < TxCmdLen; TxCount ++)
		{
			UartTx2Buff[TxCount + 4] = UartTmp2Buff[TxCount];
		}
	}
	UartTx2Buff[TxCount + 4] = UartChkSum(UartTx2Buff,TxCount + 4);
	UartTx2BuffSize = TxCount + 5;
	TX2_FLAG =1;	// sends buffer
}

void UartTx(void)	// [6a]
{
UartTxCntr = 1;	// initializes array to send
TX_FLAG = 0;
TX_BUFF_FULL = 1;
// first INT occurs and everything is managed by ISR
WriteUART1(UartTxBuff[UartTxCntr-1]); // sends first character
}

void UartTx2(void)	// [6d]
{
UartTx2Cntr = 1;	// initializes array to send
TX2_FLAG = 0;
TX2_BUFF_FULL = 1;
// first INT happens and everything is managed by ISR
WriteUART2(UartTx2Buff[UartTx2Cntr-1]); // sends first character
}

void UartRx(void)	// [6b]
{	
	if (UartRxStatus < 0)	// if error, RX is terminated
	{
		UartRxError(UartRxStatus);		   	
	}
	else					// 	otherwise it analyzes status 
	{					
		switch (UartRxStatus)
		{     
   			case 0:	// idle
   	    		if (UartRxBuff[UartRxCntr] == HEADER)
   	    		{
	   	    		UartRxStatus = 1;	// next status
	   	    	}
	   	    	else					// out of command sequence -> error
	   	    	{
					UartRxError(-5);		   	
				}
			break;
		
			case 1:	// header received
   	    		IdRx = (UartRxBuff[UartRxCntr]) - 1; // Id motore da 0 a 1
   	     	 	UartRxStatus = 2;		// next status
			break;
		
			case 2:	// command received
   	     	 	UartRxStatus = 3;		// next status
			break;
		
			case 3:	// command length received
				// length of whole command string
				UartRxBuffSize = UART_RX_CMD_LEN + RX_HEADER_LEN; 
   	     	 	UartRxStatus = 4;		// next status
			break;
			
			case 4:	// waiting for command end
   	      		if (UartRxCntr >= UartRxBuffSize)
   	      		{	
	   	      		if ((UartChkSum(UartRxBuff,UartRxBuffSize)==
	   	      			UartRxBuff[UartRxCntr]) && ((IdRx + 1)  == IdTx))
	   	      		// checksum and Id OK ? (in 1 to 2 mode)		   	    
	   	      		{
	   	      			UartRxStatus=99;// enables command parser  
		   	      	}
		   	      	else
		   	      	{
			   	    	UartRxError(-1); // checksum error	
			   	    }
			   		UartRxCntr=-1;	// next increase will reset index to 0	
   	      		}
			break;
		
			default:// error: not a known status
				UartRxError(-6);				   	
			break;
		} // switch end
	}	// if end
		
	RX_FLAG=0;			// comes back in a new character waiting
	UartRxCntr++;
}

void UartRx2(void)	// [6d]
{	
	if (UartRx2Status < 0)	// if error, RX is terminated
	{
		UartRx2Error(UartRx2Status);		   	
	}
	else					// 	otherwise it analyzes status 
	{					
		switch (UartRx2Status)
		{     
   			case 0:	// idle
   	    		if (UartRx2Buff[UartRx2Cntr] == HEADER)
   	    		{
	   	    		UartRx2Status = 1;	// next status
	   	    	}
	   	    	else					// out of sequence command -> error
	   	    	{
					UartRx2Error(-5);		   	
				}
			break;
		
			case 1:	// header received
   	    		IdRx2 = (UartRx2Buff[UartRx2Cntr]) - 1;// Indirizzo MC da 0 a 1
   	     	 	UartRx2Status = 2;		// next status
			break;
		
			case 2:	// command received
   	     	 	UartRx2Status = 3;		// next status
			break;
		
			case 3:	// command length received
				// length of whole command string
				UartRx2BuffSize = UART_RX2_CMD_LEN + RX2_HEADER_LEN; 
   	     	 	UartRx2Status = 4;		// next status
			break;
			
			case 4:	// waiting for command end
   	      		if (UartRx2Cntr >= UartRx2BuffSize)
   	      		{	
	   	      		if (UartChkSum(UartRx2Buff,UartRx2BuffSize)==
	   	      			UartRx2Buff[UartRx2Cntr])// checksum OK?		   	    
	   	      		{
	   	      		UartRx2Status=99;// enables command parser
		   	      	}
		   	      	else
		   	      	{
			   	    	UartRx2Error(-1); // checksum error	
			   	    }
			   		UartRx2Cntr=-1;	// next increase will reset index to 0	
   	      		}
			break;
		
			default:// error: not a known status
				UartRx2Error(-6);				   	
			break;
		} // fine switch
	}	// fine if
		
	RX2_FLAG=0;			// comes back in a new character waiting
	UartRx2Cntr++;
}

unsigned char UartChkSum (unsigned char *Buff,unsigned int BuffSize)	// [17]
{
	unsigned char ChkSum=0;	// checksum
	int ChkIndx;
	for (ChkIndx = 0; ChkIndx < BuffSize; ChkIndx ++)
	{
		ChkSum = ChkSum + Buff[ChkIndx];
	}
			
/*	#ifdef debug_SA	// [15f]
		return '@';
	#else
		return (ChkSum);
	#endif */	   	

	return (ChkSum);      	
}	
	   	      	
void UartRxError(int Err)	// RX error occured
{
	LED2=1;				// turns on error LED
	UartRxCntr=0;
	UartRxStatus=0; 
}

void UartRx2Error(int Err)	// RX error occured
{
	LED2=1;				// turns on error LED
	UartRx2Cntr=0;
	UartRx2Status=0; 
}

void CmdHalt(void)	// [16]
{// immediate Halt without decelerating ramp for both motors
	TxParameters(0,'H',0);  		
}

void CmdWriteVel(char Id,int Vel)	// [16]
{// setting reference speed as mm/s (-999 +999)
	UartTmpBuff[0]=Vel>>8; 
	UartTmpBuff[1]=Vel;
	TxParameters(Id,'W',2);  		
}

void CmdWriteId(char Id, char Id1)	// [16a]
{// Id designation
	UartTmpBuff[0]=Id1; 
	TxParameters(Id,'I',1);  		
}

void CmdWritePar(char Id)			// [16]
{// setting of Kp, Ki, Kd e Kvel coefficients
	unsigned char IdIndx;
	IdIndx = Id - 1;
	UartTmpBuff[0]=Kpid[0][IdIndx]>>8; 
	UartTmpBuff[1]=Kpid[0][IdIndx];
	UartTmpBuff[2]=Kpid[1][IdIndx]>>8; 
	UartTmpBuff[3]=Kpid[1][IdIndx];
	UartTmpBuff[4]=Kpid[2][IdIndx]>>8; 
	UartTmpBuff[5]=Kpid[2][IdIndx];
	UartTmpBuff[6]=Kvel[IdIndx]>>24; 
	UartTmpBuff[7]=Kvel[IdIndx]>>16;
	UartTmpBuff[8]=Kvel[IdIndx]>>8; 
	UartTmpBuff[9]=Kvel[IdIndx];
	TxParameters(Id,'K',10);		
}
void Parser (void)	// [16]
{
	char ParserFlag=0;
	switch (UART_RX_CMD)
	{
		case 'P':		// traveled distance = int -> 2byte
			 	SpTick[IdRx]=(UartRxBuff[RX_HEADER_LEN + 1] << 8) + 
					   	  (UartRxBuff[RX_HEADER_LEN + 2]);
				SPACE_FLAG=1;	// [21c]
		break;
		
		case 'A':		// all parameters
				// measured speed value = Int -> 2 byte
				VelMes[IdRx]=(UartRxBuff[RX_HEADER_LEN + 1] << 8) + 
					   		 (UartRxBuff[RX_HEADER_LEN + 2]);
				// motor current = int -> 2byte
			 	Curr[IdRx]=(UartRxBuff[RX_HEADER_LEN + 3] << 8) + 
					   	  (UartRxBuff[RX_HEADER_LEN + 4]);
				// traveled distance = int -> 2byte
			 	SpTick[IdRx]=(UartRxBuff[RX_HEADER_LEN + 5] << 8) + 
					   	  (UartRxBuff[RX_HEADER_LEN + 6]);		
		break;
		
		case 'V':		// measured speed value = Int -> 2 byte
				VelMes[IdRx]=(UartRxBuff[RX_HEADER_LEN + 1] << 8) + 
					   		 (UartRxBuff[RX_HEADER_LEN + 2]);
		break;
		
		case 'C':		// motor current = int -> 2byte
			 	Curr[IdRx]=(UartRxBuff[RX_HEADER_LEN + 1] << 8) + 
					   	  (UartRxBuff[RX_HEADER_LEN + 2]);
		break;
		
				
		default:
			UartRxError(-7); // error: not a known command
			ParserFlag=1;
		break;
	}
	
	if (!ParserFlag)		  // known command
	{
		if (AskParamStatus == 1)	// received from MC 1
		{
			AskParamStatus = 2;		// waits RX from MC 2
			ASK_PARAM_FLAG=1;		// re-enables parameters request
		}
		if (AskParamStatus == 2)	// received from MC 2 
		{
			AskParamStatus = 0;		// end of cycle
			ASK_PARAM_FLAG=0;		// it will be set again by ISR 1ms
			TX_EN2 = 0;
			if (SPACE_FLAG) ODO_FLAG=1;	// [21c]
			TX_EN1 = 0;
		}
	}
	
	UartRxStatus = 0;	
}

void Parser2 (void)	// [16b]
{
	int ParserCount;	// parser index
	unsigned int Ktmp;	// temp for PID coefficients
	DisableIntU2RX;
	
	switch (UART_RX2_CMD)
	{
		case 'H':		// immediate Halt without decelerating ramp
			CmdHalt();
		break;
		
		case 'W':		// setting reference speed (as mm/s) 
			// High Byte * 256 + Low Byte
			VelDes[IdRx2] = (UartRx2Buff[RX2_HEADER_LEN + 1] << 8) + 
							(UartRx2Buff[RX2_HEADER_LEN + 2]);
			CmdWriteVel(IdRx2,VelDes[IdRx2]); // sends VelDes to one MC
		break;
		
		case 'K':		// settings PID e Kvel coefficients
			for (ParserCount=0; ParserCount < 5; ParserCount+=2)
			{
				// High Byte * 256 + Low Byte
				Ktmp = (UartRx2Buff[RX_HEADER_LEN + ParserCount + 1] << 8) + 
							(UartRx2Buff[RX_HEADER_LEN + ParserCount + 2]);
				if (Ktmp > 999) Ktmp = 999; // range check
				Kpid[ParserCount/2][IdRx2] = Ktmp;
			}
			Kvel[IdRx2] = ((long)UartRx2Buff[RX2_HEADER_LEN + 6] << 24) +
						  ((long)UartRx2Buff[RX2_HEADER_LEN + 7] << 16) +
						  ((long)UartRx2Buff[RX2_HEADER_LEN + 8] << 8) +
						  ((long)UartRx2Buff[RX2_HEADER_LEN + 9]);
			CmdWritePar(IdRx2+1); // da 1 a 2
		break;
		
		case 'A':		// all parameters
				// VelDes = Int -> 2 byte
			 	UartTmp2Buff[0]=VelDes[IdRx2]>>8; 
				UartTmp2Buff[1]=VelDes[IdRx2];
				// Curr = int -> 2byte
			 	UartTmp2Buff[2]=Curr[IdRx2]>>8;
				UartTmp2Buff[3]=Curr[IdRx2];
				// SpTick = int -> 2byte
			 	UartTmp2Buff[4]=SpTick[IdRx2]>>8;
				UartTmp2Buff[5]=SpTick[IdRx2];
				Tx2Parameters('A',6);  
		break;
		
/*		case 'X':		// bot position coordinates request
//#########################??????????????############## CONTROLLARE 
				// X e Y
			 	UartTmp2Buff[0]=PosX>>8; 
				UartTmp2Buff[1]=PosX;
				UartTmp2Buff[2]=PosY>>8; 
				UartTmp2Buff[3]=PosY;
				Tx2Parameters('X',4);
		break;
*/		
		case 'V':		// speed value
				// VelInt = Int -> 2 byte
			 	UartTmp2Buff[0]=VelDes[IdRx2]>>8; 
				UartTmp2Buff[1]=VelDes[IdRx2];
				Tx2Parameters('V',2);
		break;
		
		case 'C':		// motor current
				// Curr = int -> 2byte
			 	UartTmp2Buff[0]=Curr[IdRx2]>>8;
				UartTmp2Buff[1]=Curr[IdRx2];
				Tx2Parameters('C',2);
		break;
		
		case 'P':		// position value
				// SpTick = int -> 2byte
			 	UartTmp2Buff[0]=SpTick[IdRx2]>>8;
				UartTmp2Buff[0]=SpTick[IdRx2];
				Tx2Parameters('P',2); 
		break;
		
		default:
			UartRx2Error(-7); //	error: not a known command
		break;
	}
	
	UartRx2Status = 0;
	EnableIntU2RX;
}

void MC_Setting(void)	// both motor controllers configuration [16a]
{
DelayN10us(2);			// waits for stable clock on MCs
CS1 = 1;				// starts MC 1 program	
DelayN10us(3);			// waits for MC 1 inizialization
CS1 = 0;
CmdWriteId(ID_I, 1);	// sets MC 1 ID changing it from initial ID
do // transmission sequence pending
{
	if (TX_FLAG)	UartTx();
} while (TX_BUFF_FULL);
CS2 = 1;				// starts MC 2 program	
DelayN10us(3);			// waits for MC 2 inizialization
CS2 = 0;
CmdWriteId(ID_I, 2);	// sets MC 2 ID changing it from initial ID
do // transmission sequence pending
{
	if (TX_FLAG)	UartTx();
} while (TX_BUFF_FULL);
DelayN10us(1);			// waits for command parsing
CmdWritePar(1);			// sets Kp, Ki, Kd, KVel on both MCs
do // transmission sequence pending
{
	if (TX_FLAG)	UartTx();
} while (TX_BUFF_FULL);
DelayN10us(20);			// waits for command parsing
CmdWritePar(2);			// sets Kp, Ki, Kd, KVel on both MCs
do // transmission sequence pending
{
	if (TX_FLAG)	UartTx();
} while (TX_BUFF_FULL);
DelayN10us(20);			// waits for command parsing
}

void DelayN10us(int n) // [22]
{
	int DelayCount;
	for (DelayCount = 0; DelayCount < (42 * n); DelayCount ++);	
}
/*---------------------------------------------------------------------------*/
/* Interrupt Service Routines                                                */
/*---------------------------------------------------------------------------*/
void _ISR_PSV _T1Interrupt(void)	// Timer 1 [13]
{
	_T1IF=0;   		// interrupt flag reset
	HRT_BT = 1;		// Hartbeat 
	Blink ++;		// index for heartbeat LED blinking (6 cycles)
	HRT_BT = 0;		// pulse is high for 6 cycles (200us) every 1ms
	ClrWdt();		// [1]
	if (AskParam)	// [20a]
	{
		AskParamTimer1 ++;
		if (AskParamTimer1 >= ASK_PARAM_TMO)
		{
			ASK_PARAM_FLAG = 1; // it's time to ask parameters
			if (AskParamStatus)
			{
				UartRxError(-10);	// MC timeout error [20c]
			}
			AskParamStatus = 1; 
			AskParamTimer2 ++;
			if (AskParamTimer2 >= ASK_PARAM_ALL_TMO)
			{
				AskParamTimer2 = 0;
				AskParam = 4; // requests all parameters every n cycles
			}
			else
			{
				AskParam = 1;
			}
			AskParamTimer1 = 0;
		}
	}
}

void _ISR_PSV _U1RXInterrupt(void)	// UART1 RX [6b]
{
	_U1RXIF = 0; 	// interrupt flag reset
	
	// UART errors, still parsing command or buffer overflow ?
	if (!OVERRUN_ERROR && !FRAME_ERROR && UartRxStatus!=99 && 
		UartRxCntr < MAX_RX_BUFF)	
	{
		UartRxBuff[UartRxCntr] = ReadUART1();	// fills RX buffer
		RX_FLAG = 1;		// a new character has came on UART register
		UartRxTmr = UART_RX_TIME_OUT;	// timeout reset
	}
	else
	{
		// indicates the error kind [6b]
		if (OVERRUN_ERROR) UartRxStatus = -4;
		if (FRAME_ERROR) UartRxStatus = -3;
		if (UartRxCntr >= MAX_RX_BUFF) UartRxStatus = -8;
		if (UartRxStatus!=99) UartRxStatus = -9;
		OVERRUN_ERROR = 0;	// error reset
		RX_FLAG = 1;
		UartRxTmr = UART_RX_TIME_OUT;	// timeout reset
	}
}

void _ISR_PSV _U2RXInterrupt(void)	// UART2 RX [6d]
{
	_U2RXIF = 0; 	// interrupt flag reset
	
	// UART errors, still parsing command or buffer overflow ?
	if (!OVERRUN_ERROR2 && !FRAME_ERROR2 && UartRx2Status!=99 && 
		UartRx2Cntr < MAX_RX_BUFF)	
	{
		UartRx2Buff[UartRx2Cntr] = ReadUART2();	// fills RX buffer
		RX2_FLAG = 1;		// a new character has came on UART register
		UartRx2Tmr = UART_RX2_TIME_OUT;	// timeout reset
	}
	else
	{
		OVERRUN_ERROR2 = 0;	// error reset
		RX2_FLAG = 1;
		UartRx2Tmr = UART_RX2_TIME_OUT;	// timeout reset
		UartRx2Status = -3;	// indicates the error kind
	}
}

void _ISR_PSV _U1TXInterrupt(void)	// UART1 TX [6a]
{
	_U1TXIF = 0;	// interrupt flag reset
	if (UartTxCntr < UartTxBuffSize)
	{
		WriteUART1(UartTxBuff[UartTxCntr]);
		UartTxCntr++;
	}
	else
	{
		TX_BUFF_FULL=0;		
	}
}

void _ISR_PSV _U2TXInterrupt(void)	// UART2 TX [6d]
{
	_U2TXIF = 0;	// interrupt flag reset
	if (UartTx2Cntr < UartTx2BuffSize)
	{
		WriteUART2(UartTx2Buff[UartTx2Cntr]);
		UartTx2Cntr++;
	}
	else
	{// waits for transmission end to disable UART
//		TX2_FLAG = 2; //########################	
	}
}

/*****************************************************************************/
