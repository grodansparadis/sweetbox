/* //////////////////////////////////////////////////////////////////////////*/
/* Included	in "dsODO_definitions.h", it contains functions prototypes       */
/* //////////////////////////////////////////////////////////////////////////*/

void DeadReckoning(void);
void CmdWritePar(char Id);
void AskParamCall(void);
void CmdWriteId(char Id, char Id1);
void CmdWriteVel(char Id,int Vel);
void CmdHalt(void);
void TxParameters(char Id,char TxCmd,int TxCmdLen);
void Tx2Parameters(char TxCmd,int TxCmdLen);
void UartTx(void);
void UartTx2(void);
unsigned char UartChkSum (unsigned char *,unsigned int);
void UartRxError(int Err);
void UartRx2Error(int Err);
void Parser (void);
void Parser2 (void);
void UartRx(void);
void UartRx2(void);
void Settings(void);
void ISR_Settings(void);
void MC_Setting(void);
void DelayN10us(int n);
void _ISR_PSV _U1RXInterrupt(void);
void _ISR_PSV _U2RXInterrupt(void);
void _ISR_PSV _U1TXInterrupt(void);
void _ISR_PSV _U2TXInterrupt(void);
void _ISR_PSV _T1Interrupt(void);
