/* ////////////////////////////////////////////////////////////////////////////
** File:      dsPid.c
*/                                  
#define  Ver "dsPID ver 0.7\n\r 08-2007"
/*
** Description: PID motor control with dsPIC30F4012   
** Descrizione: controllo motori tramite PID con dsPIC30F4012   
**
** Detailed descriptions are on file "descrEng.txt" 
** numbers between brackets, eg.: [1] , are the references to the specific 
** decription into the file
**
** I commenti dettagliati sono sul file "descrIta.txt" 
** il numero fra parentesi quadre, es.: [1] , e' il riferimento al relativo 
** commento nel documento di descrizione        
/////////////////////////////////////////////////////////////////////////////*/

#include "dsPID_definitions.h"


int main (void)
{
Settings();

LED1 = 1;			// [1]
LED2 = 0;
MOTOR_ENABLE = 0;	// [1]
RX_FLAG = 0;
TxFlag = 0;
UartRxStatus = 0;
DISABLE_TX;
TX_CONT_FLAG = 0;
TMR2_OVFLW_FLAG = 0;
IC_FIRST = 0;
RAMP_FLAG = 0;
PID_REF = 0;	

KP=Q15(0.6);
KI=Q15(0.2);
KD=Q15(0.02);
InitPid();

#ifndef debug_SA	// [15g]
	while (!_RB3);	// waiting supervisor [14]
	ClrWdt();
#endif

UsartSetting();	// initializes Usart after supervisor abilitation
ISR_Settings();	// Configures and enables ISRs

/*===========================================================================*/
/* Main loop                                                                 */
/*===========================================================================*/
while (1)
{	
/* ------------------------------------------ one character coming from UART */	
if (RX_FLAG) UartRx();	

/* ---------------------------------- a command coming from serial interface */	 
if (UartRxStatus == 99) Parser();

#ifdef debug_SA
	/*--------------------- a string has to be sent on serial interface [6a] */
	if (TxFlag)	UartTx();
#else
	/* a string has to be sent on serial interface [6a]
							 	  it transmits ONLY if enabled by supervisor */
	if (TxFlag && _RD0)	UartTx();
#endif

/* ------------------------------------- PID and speed calculation every 1ms */	
if (PID_CALC_FLAG)	Pid();

/*------- continuos parameters transmission without request (just for debug) */		
// if (TX_CONT_FLAG && UartContTxTimer<=0) TxParameters();

	if (Blink == 200)
	{
		LED1 = 0;
		Blink ++;
	}
	if (Blink == 1001)
	{
		LED1 = 1;
		Blink = 0;
	}
}/*....Main loop*/

}/*.....................................................................Main */


/*===========================================================================*/
/* Functions                                                                  */
/*===========================================================================*/
void InitPid(void)
{
//Initialize the PID data structure: PIDstruct
//Set up pointer to derived coefficients
PIDstruct.abcCoefficients = &abcCoefficient[0];
//Set up pointer to controller history samples
PIDstruct.controlHistory = &controlHistory[0]; 
// Clear the controler history and the controller output
PIDInit(&PIDstruct); 
//Derive the a,b, & c coefficients from the Kp, Ki & Kd
PIDCoeffCalc(&kCoeffs[0], &PIDstruct); 
}

void Pid(void)	// [19]
{
	int IcPeriodTmp;
	int IcIndxTmp;
	int PWM;

	IcPeriodTmp=IcPeriod;	// [19a]
	IcIndxTmp=IcIndx;
	IcIndx = 0;	
	IcPeriod=0;	
	IC_FIRST=0;
	PID_CALC_FLAG = 0;
	Vel=0;
	
	if (IcIndxTmp)	//il motore non e' fermo [19c]
	{
		Vel = Kvel*IcIndxTmp/IcPeriodTmp;
	}

	Space += (int)POSCNT; // cast to signed to store direction [19]
	POSCNT=0;

	// calcolo PID
	if (RAMP_FLAG)	// the motor is acc/dec-elerating [19f]
	{
		PID_REF += Ramp;
		if (RAMP_T_FLAG)	
		{
			if (PID_REF >= VelFin) 
			{
				PID_REF = VelFin;
				RAMP_FLAG = 0;	// acceleration is over
			}
		}
		else
		{
			if (PID_REF <= VelFin) 
			{
				PID_REF = VelFin;
				RAMP_FLAG = 0;	// acceleration is over
			}
		}
	}
	
	PID_MES = (Vel);			// speed in m/s
	PID(&PIDstruct);
	PWM = (PID_OUT >> 4) + 2048 ;	// [19e]
	SetDCMCPWM(1, PWM, 0);
	MOTOR_ENABLE = 1;	// [1]
}

void TxParameters(char TxCmd,int TxCmdLen)	// [18]
{
	int TxCount;
	
	UartTxBuff[0] = '@';		// Header
	UartTxBuff[1] = Id;			// Id
	UartTxBuff[2] = TxCmd;		// Cmd
	UartTxBuff[3] = TxCmdLen +1;	// CmdLen
	for (TxCount = 0; TxCount < TxCmdLen; TxCount ++)
	{
		UartTxBuff[TxCount + 4] = UartTmpBuff[TxCount];
	}
	UartTxBuff[TxCount + 4] = UartChkSum(UartTxBuff,TxCount + 4);
	UartTxBuffSize = TxCount + 5;
	TxFlag =1;	// send buffer
	UartContTxTimer=UART_CONT_TIMEOUT;	// timer reset 
}

void UartTx(void)	// [6a]
{
	switch (TxFlag)
	{
		case 1:
			UartTxCntr = 0;	// initializes array to send
			TxFlag = 0;
			ENABLE_TX; // first INT occurs and everything is managed by ISR
		break;
			
		case 2:
			// if TX Buff and TX shift register are empty TX is disabled again
			if (TX_REG_EMPTY)
			{
				DISABLE_TX;
				TxFlag = 0;
			}	
		break;
		
		default:
			TxFlag = 0;
		break;
	}
}
void UartRx(void)	// [6b]
{	
	if (UartRxStatus < 0)	// if error, RX is terminated
	{
		UartRxError(UartRxStatus);		   	
	}
	else					// 	otherwise it analyzes status 
	{					
		switch (UartRxStatus)
		{     
   			case 0:	// idle
   	    		if (UartRxBuff[UartRxCntr] == HEADER)
   	    		{
	   	    		UartRxStatus = 1;	// next status
	   	    	}
	   	    	else					// out of command sequence -> error
	   	    	{
					UartRxError(-5);		   	
				}
			break;
		
			case 1:	// header received
			
   	    		if(UartRxBuff[UartRxCntr] == Id || UartRxBuff[UartRxCntr] == 0)
   	    		{// command addressed to this MC or broadcast
					// Id received and recognized
   	     	 		RX_ID_FLAG = 1;			// it has to decode the command
   	     	 		UartRxStatus = 2;		// next status 
	   	   		}
	   	   		else
	   	   		{
					// Id received but NOT recognized 
   	     	 		RX_ID_FLAG = 0;	// receives but does not decode the command
   	        		UartRxStatus = 2;	// stato successivo
		   		}
			break;
		
			case 2:	// command received
   	     	 	UartRxStatus = 3;		// next status
			break;
		
			case 3:	// command length received
				// length of whole command string
				UartRxBuffSize = UART_RX_CMD_LEN + RX_HEADER_LEN; 
   	     	 	UartRxStatus = 4;		// next status
			break;
			
			case 4:	// waiting for command end
   	      		if (UartRxCntr >= UartRxBuffSize)
   	      		{	
	   	      		if (UartChkSum(UartRxBuff,UartRxBuffSize)==
	   	      			UartRxBuff[UartRxCntr])// checksum OK?		   	    
	   	      		{
	   	      			if (RX_ID_FLAG)	// if right Id
	   	      			{
		   	      			UartRxStatus=99;// enables command parser 
		   	      		}
		   	      		else
		   	      		{
			   	      		UartRxStatus=0;	// end of command receive 
			   	      	}
		   	      	}
		   	      	else
		   	      	{
			   	    	UartRxError(-1); // checksum error	
			   	    }
			   		UartRxCntr=-1;	// next increase will reset index to 0	
   	      		}
			break;
		
			default:// error: not a known status
				UartRxError(-6);				   	
			break;
		} // switch end
	}	// if end
		
	RX_FLAG=0;			// comes back in a new character waiting
	UartRxCntr++;
}

unsigned char UartChkSum (unsigned char *Buff,unsigned int BuffSize)	// [17]
{
	unsigned char ChkSum=0;	// checksum
	int ChkIndx;
	for (ChkIndx = 0; ChkIndx < BuffSize; ChkIndx ++)
	{
		ChkSum = ChkSum + Buff[ChkIndx];
	}
   	
	return (ChkSum);      	
}	
	   	      	
void UartRxError(int Err)	// RX error occured
{
	LED2=1;				// turns on error LED
	UartRxCntr=0;
	UartRxStatus=0; 
}

void Parser (void)	// [16]
{
	int ParserCount;		// parser index
	int PwmValue = 2048;	// motor stopped in LAP mode
	// PWM F=14.392Hz counting UP 12bit resolution @ 7,3728MHz clock
	int PwmFreqValue = 2048; 
	int VelInt;	// speed in mm/s as an integer
	unsigned int Ktmp;	// temp for PID coefficients
	int Wtmp;			// temp for measured speed
	DisableIntU1RX;
	
	switch (UART_RX_CMD)
	{
		
		case 'H':	// immediate Halt without decelerating ramp.In this way it 
				PID_REF = 0; //  uses the brake effect of H bridge in LAP mode
		break;
		
		case 'W':		// setting reference speed (as mm/s) 
				// High Byte * 256 + Low Byte
				Wtmp = (UartRxBuff[RX_HEADER_LEN + 1] << 8) + 
							(UartRxBuff[RX_HEADER_LEN + 2]);
				if (Wtmp >  999) Wtmp =  999; // range check
				if (Wtmp < -999) Wtmp = -999; // range check
				VelFin = Q15((float)(Wtmp)/1000);
				if (VelFin != PID_REF)
				{
					if (PID_REF>=0 && VelFin > PID_REF)
					{
						Ramp = Q15( ACC);
						RAMP_T_FLAG = 1;
					}
					if (PID_REF>=0 && VelFin < PID_REF) 
					{
						Ramp = Q15(-DEC);
						RAMP_T_FLAG = 0;
					}
					if (PID_REF< 0 && VelFin > PID_REF) 
					{
						Ramp = Q15( DEC);
						RAMP_T_FLAG = 1;
					}
					if (PID_REF< 0 && VelFin < PID_REF) 
					{
						Ramp = Q15(-ACC);
						RAMP_T_FLAG = 0;
					}
					RAMP_FLAG = 1; // acceleration ramp start
				}
		break;
		
		case 'A':		// all parameters request
				// VelInt = Int -> 2 byte
				VelInt=(long)(Vel * 1000)>>15;
			 	UartTmpBuff[0]=VelInt>>8; 
				UartTmpBuff[1]=VelInt;
				// ADCValue = int -> 2byte
			 	UartTmpBuff[2]=ADCValue>>8;
				UartTmpBuff[3]=ADCValue;
				// Space = int -> 2byte
			 	UartTmpBuff[4]=Space>>8;
				UartTmpBuff[5]=Space;
				Space = 0; // [19]
				TxParameters('A',6);  
		break;
		
		case 'V':		// measured speed value request
				// VelInt = Int -> 2 byte
				VelInt=(long)(Vel * 1000)>>15;
			 	UartTmpBuff[0]=VelInt>>8; 
				UartTmpBuff[1]=VelInt;
				TxParameters('V',2);
		break;
		
		case 'C':		// motor current request
				// ADCValue = int -> 2byte
			 	UartTmpBuff[0]=ADCValue>>8;
				UartTmpBuff[1]=ADCValue;
				TxParameters('C',2);
		break;
		
		case 'P':		// position value request
			 	// Space = int -> 2byte
			 	UartTmpBuff[0]=Space>>8;
				UartTmpBuff[1]=Space;
				Space = 0; // [19]
				TxParameters('P',2); 
		break;
		
		case 'I':		// Id designation
			Id=UartRxBuff[RX_HEADER_LEN+1];// first parameter of command string
		break;
		
		case 'K':		// PID coefficients setting
			for (ParserCount=0; ParserCount < 5; ParserCount+=2)
			{
				// High Byte * 256 + Low Byte
				Ktmp = (UartRxBuff[RX_HEADER_LEN + ParserCount + 1] << 8) + 
							(UartRxBuff[RX_HEADER_LEN + ParserCount + 2]);
				if (Ktmp > 999) Ktmp = 999; // range check
				kCoeffs[ParserCount/2] = Q15((float)(Ktmp)/1000);
			}
			Kvel =	((long)UartRxBuff[RX_HEADER_LEN + 7] << 24) +
					((long)UartRxBuff[RX_HEADER_LEN + 8] << 16) +
					((long)UartRxBuff[RX_HEADER_LEN + 9] << 8) +
					((long)UartRxBuff[RX_HEADER_LEN + 10]);
					
			Nop();
			InitPid();
		break;
				
		
		// ....................................Commands used just for debugging
		case 'p':		// PWM duty cycle
			// High Byte * 256 + Low Byte
			PwmValue = (UartRxBuff[RX_HEADER_LEN + 1] << 8) + 
						(UartRxBuff[RX_HEADER_LEN + 2]);
			SetDCMCPWM(1, PwmValue, 0);
			MOTOR_ENABLE = 1;	// [1]
		break;

		case 'e':		// received characters echo
			UartTxBuffSize = UartRxBuffSize + 1;
			for (ParserCount=0; ParserCount < UartTxBuffSize; ParserCount++)
			{	
				UartTxBuff[ParserCount] = UartRxBuff[ParserCount];
			}
			TxFlag =1;	// send buffer
		break;
		
		case 'f':		// PWM frequency
			// High Byte * 256 + Low Byte
			PwmFreqValue = (UartRxBuff[RX_HEADER_LEN + 1] << 8) + 
							(UartRxBuff[RX_HEADER_LEN + 2]);
			PTPER = PwmFreqValue;
		break;
		
		case 'c':		// Continuos send mode
			if (UartRxBuff[RX_HEADER_LEN + 1])
			{
				TX_CONT_FLAG = 1;
				UartContTxTimer=UART_CONT_TIMEOUT;	// timer reset
			}
			else
			{
				TX_CONT_FLAG = 0;
			}
		break;
		
		default:
			UartRxError(-7); //	error: not a known command
		break;
	}
	
	UartRxStatus = 0;
	EnableIntU1RX;
}

/*---------------------------------------------------------------------------*/
/* Interrupt Service Routines                                                */
/*---------------------------------------------------------------------------*/
#ifdef CLOCK_INT
	void _ISR_PSV _T1Interrupt(void)	// Timer 1 [13]
	{
		_T1IF=0;   		// interrupt flag reset
#else 
	void _ISR_PSV _INT0Interrupt(void)	// External Interrupt INT0 [9]
	{
		_INT0IF = 0;    			// interrupt flag reset
		#ifndef debug_SA
			if ( UartRxStatus > 0 && UartRxStatus < 99) 
			{// not idle & not parsing command
				UartRxTmr--;
				if (UartRxTmr <= 0)		// timeout Rx [6b]
				{
					RX_FLAG=1; // enables RX routine to analyze error
					UartRxTmr = UART_RX_TIME_OUT;	// timeout reset
					UartRxStatus = -2;	// RX timeout error
				}
			}
		#endif
#endif

		UartContTxTimer --;	// timer for continuos send mode
		Blink ++;			// heartbeat LED blink
		PID_CALC_FLAG = 1;	// PID and speed calculation enabled	
	}

void _ISR_PSV _INT1Interrupt(void)	// External Interrupt INT1 [8]
{
	_INT1IF = 0;    // interrupt flag reset
	ClrWdt();		// [1]
	LED1=0;			// [1]
}

void _ISR_PSV _ADCInterrupt(void)	// ADC [2]
{ 
	int AdcCount = 0;
	int ADCValueTmp = 0;	// to store intermediate ADC calculations 
	volatile unsigned int *ADC16Ptr;
	
	_ADIF = 0;	    // interrupt flag reset
	ADC16Ptr = &ADCBUF0; // initialize ADCBUF pointer
    for (AdcCount=0;AdcCount<16;AdcCount++)	// averages the 16 ADC values
    {
		ADCValueTmp += *ADC16Ptr++;
    }
    ADCValue = ADCValueTmp >> 4; // [2a]
}

void _ISR_PSV _U1RXInterrupt(void)	// UART RX [6b]
{
	_U1RXIF = 0; 	// interrupt flag reset
	
	// UART errors, still parsing command or buffer overflow ?
	if (!OVERRUN_ERROR && !FRAME_ERROR && UartRxStatus!=99 && 
		UartRxCntr < MAX_RX_BUFF)	
	{
		UartRxBuff[UartRxCntr] = ReadUART1();	// fills RX buffer
		RX_FLAG = 1;		// a new character has came on UART register
		UartRxTmr = UART_RX_TIME_OUT;	// timeout reset
	}
	else
	{
		// indicates the error kind [6b]
		if (OVERRUN_ERROR) UartRxStatus = -4;
		if (FRAME_ERROR) UartRxStatus = -3;
		if (UartRxCntr >= MAX_RX_BUFF) UartRxStatus = -8;
		if (UartRxStatus!=99) UartRxStatus = -9;
		OVERRUN_ERROR = 0;	// error reset
		RX_FLAG = 1;
		UartRxTmr = UART_RX_TIME_OUT;	// timeout reset
	}
}

void _ISR_PSV _U1TXInterrupt(void)	// UART TX [6a]
{
	_U1TXIF = 0;	// interrupt flag reset
	if (UartTxCntr < UartTxBuffSize)
	{
		WriteUART1(UartTxBuff[UartTxCntr]);
		UartTxCntr++;
	}
	else
	{// waits for UART sending complete to disable the peripheral
		TxFlag = 2;	
	}
}

void _ISR_PSV _QEIInterrupt(void)	// QEI [4]
{
	_QEIIF = 0;		// interrupt flag reset
	
}

void _ISR_PSV _IC2Interrupt(void)	// Input Capture 2 [7]
{
	_IC2IF = 0;					// interrupt flag reset
	if (IC_FIRST)// first sample, stores TMR2 starting value [19b]
	{
		ReadCapture2(&IcCurrPeriod);
		if (!TMR2_OVFLW_FLAG)
		{
			IcPeriod += (IcCurrPeriod - IcPrevPeriod);
		}
		else
		{
			TMR2_OVFLW_FLAG = 0;	
			IcPeriod += (IcCurrPeriod + (0xFFFF - IcPrevPeriod)); // [7a]
		}
		IcPrevPeriod = IcCurrPeriod;
		if (_UPDN)	// [7b]
		{
			IcIndx ++;
		}
		else
		{
			IcIndx --;
		}
	}
	else
	{
		ReadCapture2(&IcPrevPeriod);
		IC_FIRST=1;
	}
}

void _ISR_PSV _T2Interrupt(void)	// Timer 2 [12]
{
	_T2IF = 0;					// interrupt flag reset
	TMR2_OVFLW_FLAG = 1;		// TMR2 overflow as occurred
}

void _ISR_PSV _CNInterrupt(void)	// change Notification [3]
{
	_CNIF = 0;		// interrupt flag reset
	
}
/*****************************************************************************/


