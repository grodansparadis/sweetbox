/* ////////////////////////////////////////////////////////////////////////////
** It contains dsPIC settings and initializations
**
** Detailed description are on file "descrEng.txt" 
** numbers between brackets, eg.: [1] , are the references to the specific 
** decription into the file
**
** I commenti dettagliati sono sul file "descrIta.txt" 
** il numero fra parentesi quadre, es.: [1] , e' il riferimento al relativo 
** commento nel documento di descrizione        
/////////////////////////////////////////////////////////////////////////////*/

// standard includes
#include "dsPID_common.h"

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/* ports and peripherals registers setting an initialization                 */
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
void UsartSetting(void)
{
/*---------------------------------------------------------------------------*/
/* USART	[6]     			    									     */
/*---------------------------------------------------------------------------*/
long BaudRate;
// Baud Rate = Fcy / ( 16 * (UxBRG + 1) )
#ifdef debug_SA		// [15b]
	BaudRate = 230400; // desired baud rate 
	// 230.400 is MAX connecting to a PC for debug. 
#else
 	BaudRate = 921600; // desired baud rate 
	// MAX for dsPIC to dsPIC is 921.600 or 1.843.200
#endif

#define BRG (FCY/(16*((long)BaudRate)))-1//value to place in the U1BRG register
// Holds the value of uart config reg
unsigned int U1MODEvalue;
// Holds the information regarding uart TX & RX interrupt modes
unsigned int U1STAvalue;

// Configure UART1 module to transmit 8 bit data with one stopbit.
U1MODEvalue= UART_EN & UART_IDLE_STOP & UART_DIS_WAKE & UART_ALTRX_ALTTX & 
			UART_DIS_ABAUD & UART_NO_PAR_8BIT & UART_2STOPBITS & 
			UART_DIS_LOOPBACK;
U1STAvalue= UART_INT_TX & UART_TX_PIN_NORMAL & UART_TX_DISABLE &
			UART_INT_RX_CHAR & UART_ADR_DETECT_DIS & UART_RX_OVERRUN_CLEAR;
OpenUART1(U1MODEvalue, U1STAvalue, BRG);
/*.....................................................................USART */
}

void Settings(void)
{
/*---------------------------------------------------------------------------*/
/* Port	E   			    											     */
/*---------------------------------------------------------------------------*/
TRISE = 0b0000000100000000;
/*
RE0	26	PWM1L	PWM
RE1	25	PWM1H	PWM
RE2	24	RE2		H bridge enable	[11]
RE3	23	RE3		Led 1
RE4	22	RE4		Led 2			
RE5
-
-
RE8	16	INT0   Timer 1ms from supervisor (common between two motor controllers)
*/


/*---------------------------------------------------------------------------*/
/* A/D converter [2]  			    									     */
/*---------------------------------------------------------------------------*/
unsigned int PinConfig, Scanselect, Adcon3_reg, Adcon2_reg,Adcon1_reg;

SetChanADC10(ADC_CH0_POS_SAMPLEA_AN1 & 
			ADC_CH0_NEG_SAMPLEA_NVREF);

PinConfig 	= ENABLE_ALL_DIG & ENABLE_AN1_ANA;
Scanselect 	= SCAN_NONE;
Adcon3_reg 	= 	ADC_SAMPLE_TIME_31 & 
				ADC_CONV_CLK_SYSTEM & 
				ADC_CONV_CLK_32Tcy;
Adcon2_reg 	= 	ADC_VREF_EXT_AVSS & 
				ADC_SCAN_OFF & 
				ADC_ALT_BUF_OFF &
				ADC_ALT_INPUT_OFF & 
				ADC_CONVERT_CH0 & 
				ADC_SAMPLES_PER_INT_16;
Adcon1_reg 	= 	ADC_MODULE_ON & 
				ADC_IDLE_STOP & 
				ADC_FORMAT_INTG &
			 	ADC_CLK_AUTO & 
			 	ADC_SAMPLE_INDIVIDUAL & 
			 	ADC_AUTO_SAMPLING_ON;
OpenADC10(Adcon1_reg, Adcon2_reg, Adcon3_reg,PinConfig, Scanselect);

/*.............................................................A/D converter */


/*---------------------------------------------------------------------------*/
/* PWM	[11]        			    									     */
/*---------------------------------------------------------------------------*/
// Holds the value to be loaded into dutycycle register
unsigned int period;
// Holds the value to be loaded into special event compare register
unsigned int sptime;
// Holds PWM configuration value
unsigned int config1;
// Holds the value be loaded into PWMCON1 register
unsigned int config2;
// Holds the value to config the special event trigger postscale and dutycycle
unsigned int config3;

// Config PWM
period = 2048;// PWM F=14.392Hz counting UP 12bit resolution @ 7,3728MHz clock 
sptime = 0x0;
// 1:1 postscaler, 1:1 prescale, free running mode
// PWM time base ON, count up
config1 = 	PWM_EN & PWM_IDLE_CON & PWM_OP_SCALE1 & PWM_IPCLK_SCALE1 & 
			PWM_MOD_FREE;
			
// PWM1H e PWM1L enabled in complementar mode
// dsPICs with 3 pairs of PWM pins have one timer only (A)		
config2 = 	PWM_MOD1_COMP & PWM_PEN1L & PWM_PEN1H & PWM_PDIS3H & PWM_PDIS2H &
			PWM_PDIS3L & PWM_PDIS2L;
			
config3 = 	PWM_SEVOPS1 & PWM_OSYNC_PWM & PWM_UEN;
OpenMCPWM(period, sptime, config1, config2, config3);

// Dead time 500ns 
SetMCPWMDeadTimeGeneration(PWM_DTA15 & PWM_DTAPS1);

// dutycyclereg=1, dutycycle=50% (motore fermo in LAP mode , updatedisable=0
SetDCMCPWM(1, 2048, 0);
/*.......................................................................PWM */


/*---------------------------------------------------------------------------*/
/* QEI	[4]           			    									     */
/*---------------------------------------------------------------------------*/
OpenQEI(QEI_MODE_x4_MATCH & QEI_INPUTS_NOSWAP & QEI_IDLE_STOP
		& QEI_NORMAL_IO & QEI_INDEX_RESET_DISABLE,
		QEI_QE_CLK_DIVIDE_1_128 & QEI_QE_OUT_ENABLE & POS_CNT_ERR_INT_DISABLE);
				
MAXCNT = 0xFFFF;
POSCNT = 0;
/*.......................................................................QEI */


/*---------------------------------------------------------------------------*/
/* Input Capture [7]   			    									     */
/*---------------------------------------------------------------------------*/
OpenCapture2(IC_EVERY_EDGE&IC_INT_1CAPTURE&IC_IDLE_STOP&IC_TIMER2_SRC);
/*.............................................................Input Capture */


/*---------------------------------------------------------------------------*/
/* Timer 2	[12]    			    									     */
/*---------------------------------------------------------------------------*/
#define TMR2_VALUE 0xFFFF
OpenTimer2(	T2_ON & 
			T2_GATE_OFF & 
			T2_PS_1_1 &
			T1_SYNC_EXT_OFF &
			T2_SOURCE_INT, 
			TMR2_VALUE);
/*...................................................................Timer 2 */


/*---------------------------------------------------------------------------*/
/* Timer 1	1ms [13]    			    									 */
/*---------------------------------------------------------------------------*/
#define TMR1_VALUE 29491
#ifdef CLOCK_INT
	OpenTimer1(	T1_ON & 
			T1_GATE_OFF & 
			T1_PS_1_1 & 
			T1_SYNC_EXT_OFF &
			T1_SOURCE_INT, 
			TMR1_VALUE);
#endif 
/*................................................................ ..Timer 1 */
}


/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/* Interrupts setting                                                        */
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
void ISR_Settings(void)
{
//-------A/D converter	[2]
SetPriorityIntADC(4);
EnableIntADC;

//-------USART	[6]
ConfigIntUART1(UART_RX_INT_EN & UART_RX_INT_PR4 & UART_TX_INT_EN & 
				UART_TX_INT_PR4);

//-------PWM	[11]
ConfigIntMCPWM(PWM_INT_DIS);

//-------QEI	[4]
// ConfigIntQEI(QEI_INT_ENABLE & QEI_INT_PRI_4);

//-------Input Capture [7]
ConfigIntCapture2(IC_INT_ON & IC_INT_PRIOR_4);

//-------Timer 2	[12]
ConfigIntTimer2(T2_INT_PRIOR_4 & T2_INT_ON);
PR2 = TMR2_VALUE;
#ifdef CLOCK_INT
	//-------Timer 1	[13]
	ConfigIntTimer1(T1_INT_PRIOR_4 & T1_INT_ON);
	PR1 = TMR1_VALUE;
#else 
	// -------External INT [9]
	ConfigINT0(RISING_EDGE_INT & EXT_INT_PRI_4 & EXT_INT_ENABLE);
#endif

// -------External INT [8]
// ConfigINT1(RISING_EDGE_INT & EXT_INT_PRI_4 & EXT_INT_ENABLE);

// -------Change Notification CN5	[3]
// ConfigIntCN(CHANGE_INT_OFF & CHANGE_INT_PRI_4 & 0b0000000000100000);
	
}

