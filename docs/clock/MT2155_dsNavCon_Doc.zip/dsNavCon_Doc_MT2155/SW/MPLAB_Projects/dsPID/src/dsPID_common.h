/* //////////////////////////////////////////////////////////////////////////*/
/*Commons includes and definitions                                           */
/* //////////////////////////////////////////////////////////////////////////*/

// standard include 
#include <p30f4012.h>
#include <dsp.h>
#include <pwm.h>
#include <uart.h>
#include <qei.h>
#include <adc10.h>
#include <timer.h>
#include <InCap.h>
#include <ports.h>

#define CLOCK_FREQ 7372800 					//7.3728 MHz
#define PLL 16 		 						//x16 mode
#define FCY (CLOCK_FREQ*PLL)/4				//29,4912 MHz period = 33,90842ns
#define TCY 1/((float)(CLOCK_FREQ*PLL/4))

#define _ISR_PSV __attribute__((interrupt, auto_psv))

// #define debug_SA	// [15]
// #define CLOCK_INT	// [15a]
