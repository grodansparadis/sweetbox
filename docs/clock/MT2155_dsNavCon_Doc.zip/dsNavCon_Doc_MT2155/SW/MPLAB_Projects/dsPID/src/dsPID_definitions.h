/* ////////////////////////////////////////////////////////////////////////////
** Included in "dsPID.c", it contains definitions and variables initialization
/////////////////////////////////////////////////////////////////////////////*/

/*---------------------------------------------------------------------------*/
/* standard include														     */
/*---------------------------------------------------------------------------*/
#include "dsPID_common.h"

/*---------------------------------------------------------------------------*/
/* Status bits			    											     */
/*---------------------------------------------------------------------------*/
#ifdef debug_SA	// [15c]
	//Turn off the Watch-Dog Timer.	 [1]		
	_FWDT(WDT_OFF);	
	/* Run this project using an external crystal routed via the PLL in 
	16x multiplier mode 
	For the 7.3728 MHz crystal we will derive a throughput of 
	7.3728e+6*16/4 = 29.5s MIPS(Fcy) ~33.9 nanoseconds instruction 
	cycle time(Tcy).*/
#else
	// WDT Period = 2 ms � Prescale A � Prescale B	-> 2 x 8 x 5 = 80ms
	_FWDT(WDT_ON & WDTPSA_8 & WDTPSB_5);
#endif

#ifdef CLOCK_INT
	_FOSC(CSW_FSCM_OFF & XT_PLL16); // [5]
#else
	_FOSC(CSW_FSCM_OFF & EC_PLL16); // [5]
#endif	

/*Enable MCLR reset pin and turn on the power-up timers with 64ms delay.
PIN managed by PWM at reset*/           			 
_FBORPOR(MCLR_EN & PWRT_64 & RST_PWMPIN & PWMxH_ACT_HI & PWMxL_ACT_HI);				
//Disable Code Protection											
_FGS(CODE_PROT_OFF);            			 

/*---------------------------------------------------------------------------*/
/* include       														     */
/*---------------------------------------------------------------------------*/
#include "dsPID_prototypes.h"


/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/* Global defininitions                                                      */
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/

struct Bits{
	unsigned bit0:1;
	unsigned bit1:1;
	unsigned bit2:1;
	unsigned bit3:1;
	unsigned bit4:1;
	unsigned bit5:1;
	unsigned bit6:1;
	unsigned bit7:1;
};

struct Bits VARbits1;

//----- Flags

#define RC6Tick(x) (Delay1KTCYx(4*x),Delay100TCYx(4*x),Delay10TCYx(3*x))
#define	DELAY100MS Delay10KTCYx(100)	// 100ms

#define LED1 _LATE3
#define LED2 _LATE4
#define MOTOR_ENABLE _LATE2
#define MAX_TX_BUFF 32
#define MAX_RX_BUFF 32
#define DISABLE_TX U1STAbits.UTXEN = 0
#define ENABLE_TX U1STAbits.UTXEN = 1

const long Tcy = 1000000/(float)(FCY)* 100000000;

//----- Variabili
int i = 0; 		// generic index
int j = 0; 		// generic index
long Blink = 0; // heartbeat blink index


// UART
unsigned char Id = 9;			// Motor Controller Id [14]
unsigned char UartRxBuff[MAX_RX_BUFF];	// serial communication buffer
unsigned char UartTxBuff[MAX_TX_BUFF];
unsigned char UartTmpBuff[MAX_TX_BUFF-4];// temp buffer to compose TX buffer 
unsigned char TxFlag = 0;		// transmission status
int UartRxCntr=0;				// buffer index
unsigned int UartTxCntr=0;
unsigned int UartRxBuffSize=0;	// buffer size
unsigned int UartTxBuffSize=0;
#define UART_CONT_TIMEOUT 100			// continuos parameters TX in ms(debug) 
int UartContTxTimer=UART_CONT_TIMEOUT;	// timer for continuos parameters TX
#define UART_RX_TIME_OUT 5				// RX timeout timer in ms
int UartRxTmr = UART_RX_TIME_OUT;		// 
int UartRxStatus =0;					// index for command decoding status
#define RX_FLAG VARbits1.bit0			// new character coming flag
#define OVERRUN_ERROR U1STAbits.OERR	// RX overrun error flag
#define TX_REG_EMPTY  U1STAbits.TRMT	// TX shift register empty
#define FRAME_ERROR U1STAbits.FERR		// RX frame error flag
#define HEADER '@'						// command string header
#define UART_RX_CMD UartRxBuff[2]		// command code
#define UART_RX_CMD_LEN UartRxBuff[3]	// command length
#define RX_ID_FLAG VARbits1.bit1		// command decode flag
#define RX_HEADER_LEN 3					// command string header length (byte)
#define TX_CONT_FLAG VARbits1.bit2		// continuos parameters TX flag (debug)

// ADC
int ADCValue = 0;		// 16 sample average ADC reading

// Interrupt Capture (speed measurement)
int IcIndx = 0;			// samples buffer index 
unsigned int IcPrevPeriod;	// previous sample 
int IcPeriod = 0;			// n samples average value
unsigned int IcCurrPeriod;	// present value 
#define TMR2_OVFLW_FLAG VARbits1.bit3 // timer 2 overflow
#define PID_CALC_FLAG VARbits1.bit4	  // PID and speed elaboration flag
#define IC_FIRST VARbits1.bit5		  // first encoder pulse
/*
-> [4] [7] [19]
Encoder = 300 cpr 
Gear reduction ratio = 30:1
Wheel speed = 200 rpm
Encoder pulses for each wheel turn = 9.000
Wheel diameter = 58mm -> circumference = 182,2123739mm
Space for each encoder pulse 1x mode Delta S = 0,020245819mm
Space for each encoder pulse 2x mode Delta S = 0,01012291mm
Space for each encoder pulse 4x mode Delta S = 0,005061455mm
Speed calculation K in micron/second = 298536736 -> [19]
*/
#define CPR 300
#define GEAR_RATIO 30
#define CPR_WHEEL CPR*GEAR_RATIO				// 9000
#define DIAMETER  0.058
#define CIRC  DIAMETER*PI						// 0,182212374
#define SPACE_ENC_1X (CIRC / (CPR_WHEEL))
#define SPACE_ENC_2X (CIRC / (CPR_WHEEL * 2))	// 1,012291E-05
#define SPACE_ENC_4X (CIRC / (CPR_WHEEL * 4))
#define K_VEL ((SPACE_ENC_2X) / (TCY))			// TCY = 3,390842E-08
// Speed calculation K in m/s
long Kvel = 9782453; // K_VEL << 15
long Vel;	// speed in m/s  << 15 (long)

// QEI, covered space measurement 
int Space;	// covered space in encoder pulses

// PID [19d]
tPID PIDstruct;
fractional abcCoefficient[3] __attribute__ ((section (".xbss, bss, xmemory")));
fractional controlHistory[3] __attribute__ ((section (".ybss, bss, ymemory")));
fractional kCoeffs[] = {0,0,0};
#define KP kCoeffs[0]
#define KI kCoeffs[1]
#define KD kCoeffs[2]
#define PID_OUT PIDstruct.controlOutput
#define PID_MES PIDstruct.measuredOutput
#define PID_REF PIDstruct.controlReference

#define RAMP_FLAG VARbits1.bit6		// acc/dec-eleration flag
#define RAMP_T_FLAG VARbits1.bit7	// acc/dec-eleration direction
fractional VelFin;					// temp for speed during acceleration	
#define ACC 0.00025					// acceleration
#define DEC 0.0005					// deceleration
fractional Ramp;					// acc/dec-eleration ramp slope
/* Definitions end ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
