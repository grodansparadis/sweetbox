/* //////////////////////////////////////////////////////////////////////////*/
/* Included	in "dsPid_definitions.h", it contains functions prototypes       */
/* //////////////////////////////////////////////////////////////////////////*/

void InitPid(void);
void Pid(void);
void TxParameters(char TxCmd,int TxCmdLen);
void UartTx(void);
unsigned char UartChkSum (unsigned char *,unsigned int);
void UartRxError(int Err);
void Parser (void);
void UartRx(void);
void Settings(void);
void ISR_Settings(void);
void UsartSetting(void);
void _ISR _INT1Interrupt(void);
void _ISR _ADCInterrupt(void);
void _ISR _U1RXInterrupt(void);
void _ISR _U1TXInterrupt(void);
void _ISR _QEIInterrupt(void);
void _ISR _IC1Interrupt(void);
#ifdef debug_SA
	void _ISR _T1Interrupt(void);
#else
	void _ISR _INT0Interrupt(void);
#endif
void _ISR _CNInterrupt(void);

