dsNavCon project Registration Number MT2155

In the folders below there are full MPLAB project of both programs.

Motor Controllers program is dsPID
Supervisor program is dsODO

The same dsPID program is loaded in both motor controllers dsPIC30F4012, the Supervisor dsPIC30F3013 assigns them a different ID after the initialization.

The overall philosophy of both programs is similar, allowing "recycling" of many portion of the code.

Detailed descriptions are on files "descrEng.txt" in each code folder.
Numbers between brackets, eg.: [1] , are the references to the specific decription into those files.

They are developed using MPLAB 7.61 and C30 v3.01 Student Edition.
