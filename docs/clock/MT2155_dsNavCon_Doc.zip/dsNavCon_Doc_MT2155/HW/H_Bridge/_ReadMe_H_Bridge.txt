dsNavCon project Registration Number MT2155

The circuit of this H bridge is a classic application of L298 IC.
Optimization in a 30 x 40 mm PCB is a work of a friend of mine.
I'll be glad to send his name if necessary.

