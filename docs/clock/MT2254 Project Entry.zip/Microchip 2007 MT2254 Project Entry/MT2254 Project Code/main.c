//Microchip 16-bit Embedded Design Contest
//Determining Surface Roughness By Laser Light Backscatter
//Registration Number - MT2254
//October 16, 2007

//"main.c"


#include <p30fxxxx.h>
#include <stdio.h>
#include "main.h"
#include "linearFit.h"

float xVal[] = {1.0,2.0,3.0,4.0,5.0,6.0};
int xMap[] = {0,2,4,8,16,32,63,99};
float yVal[] = {0.0,0.0,0.0,0.0,0.0,0.0};
int lastMeasurementVal = 0;
float mVal = 0.0; //m as in "y = mx + b" for the linear fit equation
float bVal = 0.0; //b as in "y = mx + b" for the linear fit equation
float rSquaredVal = 0.0; //quantitative measure of the "goodness of fit"

int main(void)
{
	char temp[21];
	int keyPress = 0;

	init();
	calibrateSensors(); //calibration is needed for every reset
	calculateFit();
	lcdClear();
	while(1)
	{
		sprintf(temp,"(1)  MEASURE");
		lcdPrint(0,0,temp);
		sprintf(temp,"(2)  CALIBRATE");
		lcdPrint(1,0,temp);
		sprintf(temp,"Y=%.2fX+%.2f R2=%.2f",mVal,bVal,rSquaredVal);
		lcdPrint(2,0,temp);
		sprintf(temp,"MEASUREMENT = %d uin",lastMeasurementVal);
		lcdPrint(3,0,temp);
		
		keyPress = getKeypadValue();
		
		switch(keyPress)
		{
			case KEY_1:
				{
					lastMeasurementVal = getMeasurement();
					lcdClear();
				}
				break;
			case KEY_2:
				{
					calibrateSensors();
					calculateFit();
					lcdClear();
				}
				break;
		}
	}
	return 0;
}

void init()
{
	delay100ms(10); //allow LCD to initialize
	
	//set up UART to drive LCD Display
	U1BRG = (FCY / (16 * BAUD_RATE)) - 1; //formula given in family reference manual
	U1MODEbits.LPBACK = 1; //enable loop-back mode to free up RX pin for keypad	
	U1MODEbits.UARTEN = 1; //enable UART
	U1STAbits.UTXEN = 1; //enable TX
	putchar(17);  //turn on back light
	lcdClear();   //clear lcd contents
	
	//set up digital IO registers for keypad
	TRISBbits.TRISB4 = 1; //Key 1 - Input
	ADPCFGbits.PCFG4 = 1; //as digital
	TRISBbits.TRISB5 = 1; //Key 8 - Input
	ADPCFGbits.PCFG5 = 1; //as digital
	TRISBbits.TRISB6 = 1; //Key * - Input
	ADPCFGbits.PCFG6 = 1; //as digital
	TRISBbits.TRISB7 = 1; //Key 7 - Input
	ADPCFGbits.PCFG7 = 1; //as digital
	TRISBbits.TRISB8 = 1; //Key 4 - Input
	ADPCFGbits.PCFG8 = 1; //as digital
	TRISBbits.TRISB9 = 1; //Key 0 - Input
	ADPCFGbits.PCFG9 = 1; //as digital
	TRISDbits.TRISD8 = 1; //Key 3 - Input
	TRISDbits.TRISD9 = 1; //Key 6 - Input
	TRISFbits.TRISF2 = 1; //Key # - Input
	TRISFbits.TRISF4 = 1; //Key 5 - Input
	TRISFbits.TRISF5 = 1; //Key 2 - Input
	TRISFbits.TRISF6 = 1; //Key 9 - Input
	
	//set up ADC converters to read sensors
	TRISBbits.TRISB0 = 1; //Sensor 1 - Input
	ADPCFGbits.PCFG0 = 0; //as analog
	TRISBbits.TRISB1 = 1; //Sensor 2 - Input
	ADPCFGbits.PCFG1 = 0; //as analog
	TRISBbits.TRISB2 = 1; //Sensor 3 - Input
	ADPCFGbits.PCFG2 = 0; //as analog
	TRISBbits.TRISB3 = 1; //Sensor 4 - Input
	ADPCFGbits.PCFG3 = 0; //as analog
	ADCON1 = 0x00E0; // SSRC bit = 111 implies internal
			// counter ends sampling and starts
			// converting.
	ADCON3 = 0x1F02; // Sample time = 31Tad, Tad = internal 2 Tcy
	ADCON1bits.ADON = 1; // turn ADC ON

}

void lcdPrint(int row, int column, char *text)
{
	int cursorPosition;
	cursorPosition = 128 + (row * 20) + column; //cursor is sequential starting at 128
												//there are 4 rows by 20 columns
	putchar(cursorPosition);
	printf(text);
}

void lcdClear()
{
	int cursorPosition = 128; //start of display
	int i; //count variable
	
	putchar(cursorPosition); //set cursor to start of display
	for(i = 0; i < 80; i++) //loop till last position
	{
		putchar(' ');  //print a space
	}
	
	putchar(cursorPosition);  //set cursor to start of display
}

void delay100ms(int count)
{
	//value found by experiment using simulator
	//fcy = 20MHz 
	//compiler uses no optimizations
	unsigned int i, j;
	count = count<<2; //multiply by 4
	for(i = 0; i < (count); i++) 
	{
		for(j = 0; j < 55553; j++) //approx 25ms
		{
			//do nothing
		}
	}
}

int currentKeypadValue()
{
	//key presses are inverted so that a press = 1
	//each key is given a position provided in the defines
	//this method allows for key combinations as well
	int i;
	int keyValue = 0;
	int eachKey[12];
	
	eachKey[0] = 1 * !PORTBbits.RB4; //key 1
	eachKey[1] = 2 * !PORTFbits.RF5; //key 2
	eachKey[2] = 4 * !PORTDbits.RD8; //key 3
	eachKey[3] = 8 * !PORTBbits.RB8; //key 4
	eachKey[4] = 16 * !PORTFbits.RF4; //key 5
	eachKey[5] = 32 * !PORTDbits.RD9; //key 6
	eachKey[6] = 64 * !PORTBbits.RB7; //key 7
	eachKey[7] = 128 * !PORTBbits.RB5; //key 8
	eachKey[8] = 256 * !PORTFbits.RF6; //key 9
	eachKey[9] = 512 * !PORTBbits.RB9; //key 0
	eachKey[10] = 1024 * !PORTBbits.RB6; //key *
	eachKey[11] = 2048 * !PORTFbits.RF2; //key #
	
	//add all the positions to give a final key value
	for(i = 0; i < 12; i++)
	{
		keyValue += eachKey[i];
	}
	
	return keyValue;
}

int getKeypadValue()
{
	//This routine will provide debounce for the entire keypad at once.
	//This routine looks for a key press or key combination to be
	//valid for more than 100ms and then returns the value.
	//100ms should be enough for a key combination to work
	//It is recommended that your routine does not look for 
	//key combinations and the individual keys that make up the
	//combination at the same time.
	int keyValue1 = 0; //ensure values are different to start with
	int keyValue2 = 1;
	
	while(keyValue1 != keyValue2) 
	{
		keyValue1 = currentKeypadValue();
		delay100ms(1);
		keyValue2 = currentKeypadValue();
	}
	
	return keyValue1;
}

int getSensor1Val()
{
	//this routine will return an average of 16 readings
	int i;
	unsigned int adcValue = 0;
	ADCHS = 0x0000; // Connect RB0/AN0 as CH0 input.

	for(i = 0; i < 16; i++) //collect values to be averaged
	{	
		ADCON1bits.SAMP = 1; // start sampling then ...
			// after 31Tad go to conversion
		while (!ADCON1bits.DONE);// conversion done?
		adcValue += ADCBUF0; // yes then get ADC value and accumulate
	}
	
	return adcValue/16; //return the average value
}

int getSensor2Val()
{
	//this routine will return an average of 16 readings
	int i;
	unsigned int adcValue = 0;
	ADCHS = 0x0001; // Connect RB1/AN1 as CH0 input.

	for(i = 0; i < 16; i++) //collect values to be averaged
	{	
		ADCON1bits.SAMP = 1; // start sampling then ...
			// after 31Tad go to conversion
		while (!ADCON1bits.DONE);// conversion done?
		adcValue += ADCBUF0; // yes then get ADC value and accumulate
	}
	
	return adcValue/16; //return the average value
}

int getSensor3Val()
{
	//this routine will return an average of 16 readings
	int i;
	unsigned int adcValue = 0;
	ADCHS = 0x0002; // Connect RB2/AN2 as CH0 input.

	for(i = 0; i < 16; i++) //collect values to be averaged
	{	
		ADCON1bits.SAMP = 1; // start sampling then ...
			// after 31Tad go to conversion
		while (!ADCON1bits.DONE);// conversion done?
		adcValue += ADCBUF0; // yes then get ADC value and accumulate
	}
	
	return adcValue/16; //return the average value
}

int getSensor4Val()
{
	//this routine will return an average of 16 readings
	int i;
	unsigned int adcValue = 0;
	ADCHS = 0x0003; // Connect RB3/AN3 as CH0 input.

	for(i = 0; i < 16; i++) //collect values to be averaged
	{	
		ADCON1bits.SAMP = 1; // start sampling then ...
			// after 31Tad go to conversion
		while (!ADCON1bits.DONE);// conversion done?
		adcValue += ADCBUF0; // yes then get ADC value and accumulate
	}
	
	return adcValue/16; //return the average value
}
int getSensorSumTotalVal()
{
	int sumTotalVal;
	sumTotalVal = getSensor1Val();
	sumTotalVal += getSensor2Val();
	sumTotalVal += getSensor3Val();
	sumTotalVal += getSensor4Val();
	
	return sumTotalVal;
}

void calibrateSensors()
{
	char temp[21];
	int keyPress = 0;

	lcdClear();

	while(getKeypadValue() != 0); //sit and wait for button to be released
	do
	{
		sprintf(temp,"1) 2=%.2f 4) 16=%.2f",yVal[0],yVal[3]);
		lcdPrint(0,0,temp);
		sprintf(temp,"2) 4=%.2f 5) 32=%.2f",yVal[1],yVal[4]);
		lcdPrint(1,0,temp);
		sprintf(temp,"3) 8=%.2f 6) 63=%.2f",yVal[2],yVal[5]);
		lcdPrint(2,0,temp);
		lcdPrint(3,0,"1 to 6, 0 WHEN DONE");
		
		keyPress = getKeypadValue();
		
		switch(keyPress)
		{
			case KEY_1:
				{
					yVal[0] = getSensorSumTotalVoltage();
					lcdClear();
				}
				break;
			case KEY_2:
				{
					yVal[1] = getSensorSumTotalVoltage();
					lcdClear();
				}
				break;
			case KEY_3:
				{
					yVal[2] = getSensorSumTotalVoltage();
					lcdClear();
				}
				break;
			case KEY_4:
				{
					yVal[3] = getSensorSumTotalVoltage();
					lcdClear();
				}
				break;
			case KEY_5:
				{
					yVal[4] = getSensorSumTotalVoltage();
					lcdClear();
				}
				break;
			case KEY_6:
				{
					yVal[5] = getSensorSumTotalVoltage();
					lcdClear();
				}
				break;
		}
			
	}while(keyPress != KEY_0);	
}

float getSensorSumTotalVoltage()
{
	char temp[21];
	float voltage[] = {0.0,0.0,0.0};
	float averageVoltage;
	int keyPress = 0;

	while(getKeypadValue() != 0); //sit and wait for button to be released
	
	lcdClear();

	do
	{
		sprintf(temp,"POS(1)= %.2f VOLTS",voltage[0]);
		lcdPrint(0,0,temp);
		sprintf(temp,"POS(2)= %.2f VOLTS",voltage[1]);
		lcdPrint(1,0,temp);
		sprintf(temp,"POS(3)= %.2f VOLTS",voltage[2]);
		lcdPrint(2,0,temp);
		lcdPrint(3,0,"1 to 3, # WHEN DONE");
		
		keyPress = getKeypadValue();
		
		switch(keyPress)
		{
			case KEY_1:
				{
					voltage[0] = sumTotalToVoltage(getSensorSumTotalVal());
					lcdClear();
				}
				break;
			case KEY_2:
				{
					voltage[1] = sumTotalToVoltage(getSensorSumTotalVal());
					lcdClear();
				}
				break;
			case KEY_3:
				{
					voltage[2] = sumTotalToVoltage(getSensorSumTotalVal());
					lcdClear();
				}
				break;
		}
			
	}while(keyPress != KEY_POUND);
	
	averageVoltage = voltage[0];
	averageVoltage += voltage[1];
	averageVoltage += voltage[2];
	averageVoltage /= 3;
	
	return averageVoltage;
}

float sumTotalToVoltage(int sumTotal)
{
	float sumTotalVoltage;
	
	sumTotalVoltage = ((float)sumTotal * 20) / 16384.0; //16384 is 4 times 4096 (sum of 4 12-bit readings)
														//reference = 5 volts per sensor, 20 volts total
	return sumTotalVoltage;
}

int getMeasurement()
{
	int measurement;
	float sumTotalVoltageVal;
	float xFloatVal; //find the x value, given the Y value
	int xIntVal; //use to map position, given x index
	
	sumTotalVoltageVal = getSensorSumTotalVoltage();
	xFloatVal = (sumTotalVoltageVal - bVal) / mVal;
	
	//round to nearest x value (1 to 6)
	xIntVal = (int)(xFloatVal + 0.5); 
	
	//avoid out of bounds condition for array index
	if(xIntVal < 0) xIntVal = 0;
	if(xIntVal > 7) xIntVal = 7;
	
	//map x position value from x index
	measurement = xMap[xIntVal];
	
	return measurement;
}

void calculateFit()
{
	rSquaredVal = rSquared(xVal, yVal, 6);
	mVal = slope(xVal, yVal, 6);
	bVal = offset(xVal, yVal, 6);
}
