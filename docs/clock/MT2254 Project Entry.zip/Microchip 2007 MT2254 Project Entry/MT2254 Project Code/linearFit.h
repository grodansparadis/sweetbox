//Microchip 16-bit Embedded Design Contest
//Determining Surface Roughness By Laser Light Backscatter
//Registration Number - MT2254
//October 16, 2007

//"linearFit.h"

//functions to provide linear regression paramters

#ifndef _LINEAR_FIT_
#define _LINEAR_FIT_

//function prototypes
float average(float arrayData[], int arrayLength);
float standardDeviation(float arrayData[], int arrayLength);
float correlation(float xArrayData[], float yArrayData[], int arrayLength);
float rSquared(float xArrayData[], float yArrayData[], int arrayLength);
float slope(float xArrayData[], float yArrayData[], int arrayLength);
float offset(float xArrayData[], float yArrayData[], int arrayLength);

#endif //_LINEAR_FIT_

