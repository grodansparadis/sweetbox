//Microchip 16-bit Embedded Design Contest
//Determining Surface Roughness By Laser Light Backscatter
//Registration Number - MT2254
//October 16, 2007

//"linearFit.c"

//functions to provide linear regression paramters

#include "linearFit.h"
#include <stdio.h>
#include <math.h>

float average(float arrayData[], int arrayLength)
{
	float average;
	int i; //counter variable

	average = 0.0;
	for(i = 0; i < arrayLength; i++)
	{
		average += arrayData[i];
	}
	average /= arrayLength;

	return average;
}
float standardDeviation(float arrayData[], int arrayLength)
{
	//estimate the population standard deviation based on a sample
	float average1;
	int i; //counter variable
	float stDev = 0.0;

	//get average of array
	average1 = average(arrayData, arrayLength);

	//calculate standard deviation of y axis accelerometer array
	stDev = 0.0;
	for(i = 0; i < arrayLength; i++)
	{
		//stDev += powf((average1 - arrayData[i]),2); //square the delta
		stDev += (average1 - arrayData[i]) * (average1 - arrayData[i]);
	}
	stDev /= (arrayLength - 1);
	stDev = sqrt(stDev);

	return stDev;
}

float correlation(float xArrayData[], float yArrayData[], int arrayLength)
{
	float xAverage, yAverage, xStDev, yStDev, r;
	int i; //counter variable

	xAverage = average(xArrayData, arrayLength);
	yAverage = average(yArrayData, arrayLength);
	xStDev = standardDeviation(xArrayData, arrayLength);
	yStDev = standardDeviation(yArrayData, arrayLength);

	r = 0.0;
	for(i = 0; i < arrayLength; i++)
	{
		r += (xArrayData[i] - xAverage) * (yArrayData[i] - yAverage);
	}

	r = r / ((arrayLength - 1)* xStDev * yStDev);

	return r;
}

float rSquared(float xArrayData[], float yArrayData[], int arrayLength)
{
	float rSquared;

	rSquared = correlation(xArrayData, yArrayData, arrayLength);
	rSquared *= rSquared;

	return rSquared;
}

float slope(float xArrayData[], float yArrayData[], int arrayLength)
{
	float b1, r, xStDev, yStDev;

	r = correlation(xArrayData, yArrayData, arrayLength);
	xStDev = standardDeviation(xArrayData, arrayLength);
	yStDev = standardDeviation(yArrayData, arrayLength);

	b1 = r * (yStDev / xStDev);

	return b1;
}

float offset(float xArrayData[], float yArrayData[], int arrayLength)
{
	float b1, b0, xAverage, yAverage;

	b1 = slope(xArrayData, yArrayData, arrayLength);
	xAverage = average(xArrayData, arrayLength);
	yAverage = average(yArrayData, arrayLength);

	b0 = yAverage - (xAverage * b1);

	return b0;
}

