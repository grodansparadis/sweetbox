//Microchip 16-bit Embedded Design Contest
//Determining Surface Roughness By Laser Light Backscatter
//Registration Number - MT2254
//October 16, 2007

//"main.h"

//definitions
#define FCY 20000000.0 	//crystal = 20MHz, configuration set to HS2 with PLL 8x
#define BAUD_RATE 19200.0 //19.2Kbps

//Key values are based on bit positions within an integer
//This method also allows for valic key combinations
#define KEY_1 1
#define KEY_2 2
#define KEY_3 4
#define KEY_4 8
#define KEY_5 16
#define KEY_6 32
#define KEY_7 64
#define KEY_8 128
#define KEY_9 256
#define KEY_0 512
#define KEY_STAR 1024
#define KEY_POUND 2048

//function prototypes
void init();
void lcdPrint(int row, int column, char *text);
void lcdClear();
void delay100ms(int count);
int getKeypadValue();
int currentKeypadValue();
int getSensor1Val();
int getSensor2Val();
int getSensor3Val();
int getSensor4Val();
int getSensorSumTotalVal();
void calibrateSensors();
float getSensorSumTotalVoltage();
float sumTotalToVoltage(int sumTotal);
int getMeasurement();
void calculateFit();
