Microchip 16-bit Embedded Control Design Contest

Entry # MT1415

Eligible Part:		PIC24FJ64GA002-I/SP

Bonus Parts Used:	ENC28J60/SP
			24LC512

---------- Abstract ----------

abstract.txt
	short description

block-diagram.eps
	block diagram

schematics/*.eps
	schematics, four pages

photo-board.jpg
photo-complete-front.jpg
	photographs - board.jpg and done-front.jpg are the best
	"overview" photos, board.jpg has my name blurred out (sorry).
	Unblurred photo available on request.

snippet1.c - main()
snippet2.c - adc_task()
snippet3.c - configure_pic_io()
	code samples

---------- Complete Documentation ----------

documentation.doc
	full documentation

block-diagram.eps
block-diagram-bw.eps
	block diagram (color fills, bw = white fills)

schematics/*.eps
	schematics

photo-board.jpg
photo-complete-front.jpg
photo-complete-back.jpg
photo-complete-inside.jpg
photo-inside-cover.jpg
	photographs

Note: BOM and board layout files available on request.

---------- Code ----------

code/*
	Source code for the PIC's flash

utils/*
	Source code for the remote configuration utility.
