/**********************************************************************************
*	MT2239 Lin-Touch-LCD Circuit Cellar PIC design contest
* 	LIN Master, used for testing the LIN-TOUCH-DISPLAY module.
* Every 250ms this program blinks one LED  by using timer 1, and it sends an ID and two bytes
* of data to a slave node using a subset of the LIN protocol. The bytes, treated as an int, 
* take on the values 0 to 9999, incremented after each transmission.
* This program runs on the Microchip PIC24 starter kit, and is used to test the project
* board (a custom design).
*
* This board is the LIN master.
*
*************************************************************************************/

#include "p24fj64ga002.h"


#define XTFREQ          7372800         		//On-board Crystal frequency
#define PLLMODE         2               		//On-chip PLL setting
#define FCY             XTFREQ*PLLMODE        	//Instruction Cycle Frequency
#define BAUDRATE         9600
#define BRGVAL          ((FCY/BAUDRATE)/16)-1

//////// GLOBALS ////////////

unsigned int secTicks;							// increments once each second
unsigned int ledBits,temp55,temp1,clearOut; 	// global for testing
unsigned int indx;
unsigned int data[6];

////////// END OF GLOBALS ////////////////

void sendChar(unsigned char ch) {	// send a char over the LIN bus
	while(!U1STAbits.TRMT);			// wait till xmtr is free
	U2TXREG = ch;
}

int main(void)
{
	CLKDIVbits.RCDIV = 0;
	PADCFG1 = 0xFF;			// Make analog pins digital
	LATB = 0xF000;			// turn off the LEDs
	TRISB = 0x0FFF;			// LEDs as outputs
	TMR1 = 0;				// Clear timer 1
	PR1 = 0x3D09;			// Interrupt every 250ms // 15625

// set up uart2 to send a count to the LIN slave 4 times per second

	RPINR19bits.U2RXR = 11;	// Make RP11 (pin 22) U2RX
	RPOR5bits.RP10R = 5;	// map uart2 U2TX to RP10 (pin 21)

	U2BRG = BRGVAL;			// 9600 baud
	U2MODEbits.UARTEN = 1;	//0x8000;		// 8-n-1, alt pins, enable UART
	U2STAbits.UTXEN	= 1;	// Enable TX
	
	IFS0bits.T1IF = 0;		// Clear interrupt flag
	IEC0bits.T1IE = 1;		// Set interrupt enable bit
	T1CON = 0x8030;			// Fosc/4, 1:256 prescale, start TMR1

	while(1)	{
	}
	return 0;
}

void __attribute__((interrupt, no_auto_psv)) _T1Interrupt(void)
{
	IFS0bits.T1IF = 0;			// clear interrupt flag
	LATB ^= 0x1000;				// Toggle one LED
	secTicks += 1;
	if (secTicks > 9999) secTicks = 0;

	U2STAbits.UTXBRK = 1;		// next char will be a break
	sendChar(0x06);				// send dummy char for break
	sendChar(0x55);				// send sync byte
	sendChar(2);				// ID, message = master sends ticks
	sendChar(secTicks >> 8);	// send MSB of ticks
	sendChar(secTicks & 0xFF);	// send LSB of ticks

	// checksum omitted for the test board
}

// END




