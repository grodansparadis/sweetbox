/**********************************************************************************

MT2239  Microchip/Circuit Cellar PIC24 Contest
LIN-TOUCH-LCD module

*******************************************************************************************/

#define doADC
//#define doCalibrate

#define fj16

#ifdef fj16
	#include "p24fj16ga002.h"
#endif

#ifdef fj64
	#include "p24fj64ga002.h"
#endif

// segment definitions for 4 character 7 segment (8 including DP) LED display
#define segA 2
#define segB 0x10
#define segC 8
#define segD 4
#define segE 1
#define segF 0x80
#define segG 0x40
#define segDP 0x20


//////////// Global Variables ////////////////////
 

const unsigned int powers[3] = {1000,100,10};
const unsigned char bits2seg[10] = {
segA|segB|segC|segD|segE|segF, 		// 0
segF|segE,							// 1
segA|segF|segG|segC|segD,			// 2
segA|segF|segG|segE|segD,			// 3
segB|segG|segF|segE,				// 4
segA|segB|segG|segE|segD,			// 5
segA|segB|segC|segD|segE|segG,		// 6
segA|segF|segE,						// 7
segA|segF|segE|segD|segC|segB|segG,	// 8
segA|segB|segG|segF|segE,			// 9
};

unsigned char data[4];				// the bits to write to the segment drivers
unsigned char doDisplay;			// 1 if it is time to update the display
unsigned char decimalBits;			// bits 0..3 for decimal points; 3 is for touch
unsigned char nSegs;				// the number of segs that are on, not including DP
unsigned char state;				// touch state, 1 = high, 0 = low
unsigned char doSendBits;			// 1 if need to send decimalBits over LIN
unsigned char indx;					// the index into the data array
unsigned int delta;	// temp

unsigned int adcValue;				// the most recent adc reading
unsigned int turnOn[33];			// zero-terminated list of segments to turn on 
unsigned int lowThresh;
unsigned int highThresh = 10000;	// must wait 8 secs before touch is active
unsigned int intToDisplay;			// the value to display
unsigned int lastValue = 32123;		// last value displayed
unsigned int bytes[16];				// the data (temp, for testing)


/////////////end of globals /////////////////////////////

void doDecimal() { 	// turn on the decimal points
	unsigned char temp,tempBits;
	unsigned char index = nSegs;

	tempBits = decimalBits;
	for (temp=0; temp <4; temp ++) { 			// do the decimal points
		if (tempBits & (1 << temp)) {			// turn this one on
			turnOn[index] = 1 << (6 + temp);	// turn on the digit
			turnOn[index] |= 0x08;				// turn on the segment
			turnOn[index] = ~turnOn[index];
			index += 1;
		}
	}
	while (index < 19) {
		index += 1;
	}
	turnOn[index] = 0;	// marks the last one
	nSegs = index;
}

void int2segs(unsigned int n) {			// digit 0 is the one on the left
	unsigned char i,count,dig,seg,temp;
	unsigned char segBit;
	unsigned int subtract;

	if (n == lastValue) return;	// don't need to do it again.
	lastValue = n;
	for (i = 0; i < 3; i++) {
		count = 0;
		subtract = powers[i];
		while (n >= subtract) {
			n -= subtract;
			count += 1;
		}
		data[i] = bits2seg[count];
	}
	data[3] = bits2seg[n];
	for (i=0; i<32; i++) turnOn[i] = 0xFF;	// blank the display. turnOn[32] is always zero.

	// now build the turnon array.
	// the bits are zero for a seg or digit to turn on, 1 otherwise.
	// bits RB6..9 give the digit to turn on.
	// bits RB2..5 control 4 of the segments.
	// bits RA0..3 control the other 4 segments.
	// only one digit and one segment are turned on at a time.
	// a zero value indicates the end of the list (no more segs to turn on).
	// If there are less than 20 segs to turn on, fill the array (up to the 20th) with
	//	all bits high, so no seg is turned on in the corresponding time slot.
	// This keeps the brightness constant. If there are more than 20 segments to
	//  turn on, the display will dim slightly and if nearly 32 segments must be
	//  turned on there may be some flicker. 

	i = 0;									// the index into the turnOn array
	for (dig = 0; dig < 4; dig++) {
		segBit = 0x01;
		temp = data[dig]; 					// the segments to turn on
		for (seg = 0; seg < 8; seg++) {
			if (temp & segBit) {			// this segment needs to be on
				turnOn[i] = (1 << (dig+6));	// set the digit bit

				if (seg < 4) turnOn[i] |= segBit << 12;
				else turnOn[i] |= (segBit >> 2);

				turnOn[i] = ~turnOn[i];		// because high = off, low = on
				i += 1;
			}
		segBit <<= 1;
		}
	}
	turnOn[i] = 0;
	nSegs = i;								// the number of non-DP segments
	doDecimal();							// add the decimals to the seg list
} 

/* void sendToLin(unsigned char ch) {			// send ch over LIN
	while (!U1STAbits.RIDLE);				// wait till stop bit has finished		
	U1TXREG = ch;							// send the char 
	//U1TXREG = 210;						// dummy because LIN requires 2 bytes of data
} */

int main(void) {
	
	//count = segment = digit = 0;			// keeps track of the state of the display
	// digit drivers RB6..RB9
	// segment drivers RA12..15 and RB2..5

	int temp;

	TRISA	= ~0x001F;			// seg drivers RA0..3 and CS/WAKE LIN driver (RA4) are outputs
	TRISB	= ~0xF7FC;			// RB2..5 seg drivers, RB6..9 dig drivers, RB10 TXD, RB12..15 touch are outputs
	ODCB	= 0x07C0;			// dig drivers MUST BE OC, TXD also?
	AD1PCFG	= 0x1FFF;			// make all analog ports digital

	LATB	= 0x7FC;			// Digit drivers high (off), 4 segment drivers high (off), uart xmit high
	LATA	= 0x0F;				// The other 4 segment drivers off, LIN CS low

////////// UART STUFF ///////////

	RPOR5bits.RP10R	= 3;		// map uart1 txd to RB10 (pin 21)
	RPINR18 = 11;				// uart1 rxd to RB11 (pin 22)
	U1BRG	= 25;				// 9600 baud

	U1STA = 0;
	U1MODE = 0x8000;			// enable UART
	U1STAbits.UTXEN = 1;		// enable uart transmit
	
	U1TXREG = 0x33;				// send a dummy byte - gives LIN xcvr time to get ready
	while (!U1STAbits.TRMT);	// wait for xmtr to finish
	LATA |= 0x10;				// set LIN CS high to make it ready to go

	while (!U1STAbits.RIDLE);	// wait till stop bit has finished
	while (U1STAbits.URXDA) {
		temp = U1RXREG; 		// clear out the UART receiver buffer
	}
	U1MODEbits.WAKE = 1;		// rcvr  break detect
	U1MODEbits.ABAUD = 1;		// rcvr autobaud
	U1STAbits.ADDEN = 1;		// should not be needed
	IFS0bits.U1RXIF = 0;		// clear interrupt flag
	IEC0bits.U1RXIE = 1;		// enable receive interrupt
	
/////////// END OF UART SETUP /////////////

	turnOn[32] = 0; 			// make sure there is always a sentinel

#ifdef doADC
	AD1CON1	|= 0x00E0;			// set sample/convert sequence to auto-convert
	AD1CHS	= 11;				// AN11 is the ADC input
	AD1CON3	|= 0x300;			// set sample time to 7 
	AD1CON1	|= 0x8000;			// turn on the ADC module
	AD1PCFG |= 0x1FFF;			// set all analog pins to digital function
	IFS0bits.T1IF = 0;			// clear interrupt flag (shouldn't be necessary)
	IEC0bits.AD1IE = 1;			// enable ADC conversion interrupt
#endif

	TMR1 = 0;					// Clear timer 1
	T1CON = 0x8010;				//  1:8 prescale, start TMR1, clocks every 1 uS
	PR1 = 500;					// Interrupt every 1 MS
	intToDisplay = 123;			// the initial value
	doDisplay = 1;				// flag indicating that display needs service
	
	IFS0bits.T1IF = 0;			// Clear timer1 interrupt flag
	IEC0bits.T1IE = 1;			// Set timer1 interrupt enable bit
	
	while(1) {
		if (doDisplay) {
			doDisplay = 0;
			int2segs(intToDisplay);
		}
/*		if (doSendBits) {		// send decimalBits over LIN
			doSendBits = 0;
			sendToLin(decimalBits);
		} */
	}
}

void __attribute__((interrupt, no_auto_psv)) _U1RXInterrupt(void) {
	static unsigned char state;			// 0 = waiting for break/sync
										// 1 = received sync, waiting for 1st char
										// 2..n = waiting for n-2 more chars 
	
	unsigned int theChar;
	static unsigned int temp;
	unsigned int theStatus;	

	theStatus = U1STA;					// get the status
	IFS0bits.U1RXIF = 0;				// clear interrupt flag
	IFS4bits.U1ERIF = 0;				// clear error interrupt flag
	if(U1STAbits.URXDA == 0) {
		return; // nothing avail
	}
	
	
	while (U1STAbits.URXDA) {
		theChar = U1RXREG & 0xFF;
	}

	switch (state) {
		case 0: { 	// waiting for break
			if (theChar == 0x55) { 	//break char received
				state = 1;
			}
		else {							// expected break, got something else
			temp = 125; 				// for testing
			//while(!U1STAbits.TRMT);		// wait till xmtr is free
			U1MODEbits.WAKE = 1;		// rcvr  break detect
			U1MODEbits.ABAUD = 1;		// rcvr autobaud
			U1STAbits.ADDEN = 1;
			}
			break;
		}
		case 1: {						// received message id
			if (theChar == 2) {			// message id = master is sending ticks
				state = 2;
			} else {					// we are responding with the LED bits data
				//sendToLin(decimalBits);
			//	doSendBits = 1;			// send decimalBits

		//	while(!U1STAbits.TRMT);		// wait till xmtr is free
			//while (!U1STAbits.RIDLE);		// wait till stop bit has finished	
			U1MODEbits.WAKE = 1;		// rcvr  break detect
			U1MODEbits.ABAUD = 1;		// rcvr autobaud
			U1STAbits.ADDEN = 1;
			state = 0;
			}
			break;
		}
		case 2:	{	// received 1st char of ticks
			temp = theChar; // save it for later
			state = 3;
			break;
		}
		case 3: {	// received 2nd char of ticks
			intToDisplay = (temp << 8) | theChar;
			//intToDisplay = theChar; // for testing	
			bytes[indx++] = temp << 8 | theChar;
			if (indx > 15) indx = 0;
			//while (!U1STAbits.RIDLE);		// wait till stop bit has finished	
			doDisplay = 1;
		//	while(!U1STAbits.TRMT);		// wait till xmtr is free
			U1MODEbits.WAKE = 1;		// rcvr  break detect
			U1MODEbits.ABAUD = 1;		// rcvr autobaud
			U1STAbits.ADDEN = 1;
			//while(!U1STAbits.TRMT);		// wait till xmtr is free
			state = 0;
			break;
		}
/*		case 4: {	// we have received the bits we were sending
			while(!U1STAbits.TRMT);		// wait till xmtr is free
			while (!U1STAbits.RIDLE);		// wait till stop bit has finished	
			U1MODEbits.WAKE = 1;		// rcvr  break detect
			U1MODEbits.ABAUD = 1;		// rcvr autobaud
			state = 0;
			break;
		} */
	}			
}

void __attribute__((interrupt, no_auto_psv)) _ADC1Interrupt(void) {
	static unsigned int avgValue, maxValue;
	static unsigned char nValues,nCal;

	IFS0bits.AD1IF = 0;					// clear ADC interrupt flag
	adcValue = ADC1BUF0;				// store result 
	AD1PCFG |= 0x0800;					// set an11 pin to digital mode
	nValues += 1;

// do the calibration stuff
	if (nValues > 7) { 					// add a value every second
		nValues = 0;
		avgValue += adcValue;
		if (adcValue > maxValue) maxValue = adcValue;
		nCal += 1;
		if (nCal > 8)	{				// calculate and store the thresholds
			nCal = 0;
			avgValue -= maxValue;		// omit the largest value
			
			avgValue >>= 3;				// the actual average value
			lowThresh = avgValue + (avgValue >> 5);
			highThresh = avgValue + (avgValue >> 4);
			avgValue = 0;
			maxValue = 0;				// ready for next time
		}
	}

// see if the switch needs to be toggled
// state meaning:
//	0 = when adcValue goes above high, toggle DP and go to state 1
//	1 = when adcValue goes below low, go to state 0

	switch (state) {
		case 0: {	
			if (adcValue > highThresh) {
				decimalBits ^= 8;		// toggle rightmost DP
				doDecimal();			// display 
				state = 1;
			}
			break;
		}
		case 1: {	
			if (adcValue < lowThresh) {
				state = 0;
			}
			break;
		}
	}
}

void __attribute__((interrupt, no_auto_psv)) _T1Interrupt(void) {
	static unsigned int timerCount;
	static unsigned char nextSeg = 0;
	int temp;
	IFS0bits.T1IF = 0;					// clear interrupt flag

	timerCount += 1;
	if (timerCount > 127) { 
		timerCount = 0;
	}

// service the 4 digit LED display
// digit drivers RB6..RB9
// segment drivers RA0..3 and RB2..5

	temp = turnOn[nextSeg++];
	if ((temp == 0) || (nextSeg > 31)) {		// reset
		nextSeg = 0;
		temp = turnOn[nextSeg++];
	}
	LATA |= 0x0F;						// turn off 4 segments - high is off
	LATB |= 0x03FC;						// turn off 4 digits and the other 4 segments

	LATA &= (0xFFF0 | (temp >> 12)); 	// set segs 0..3
	LATB &= (0xFC03 | (temp	& 0x03FC));	// set segs 4..7 and dig	
	

/////////// TOUCH CODE ///////////////

	if (timerCount == 0) {				// do touch detect 8 times per second

// RB13 (pin 24) is the sense capacitor
// RB12 (pin 23) is the accumulator capacitor
	
	TRISB |= 0x2000;					// make bit13 an input
	LATB  |= 0x2000;					// bit13 = 1 when it is an output

	asm("push W0");						// save w0
	asm("mov #0x3000,W0");				// the values to toggle between charge Cs and transfer to Ca


#ifdef doCalibrate
	
	count = 0; ?? //this can't be here 
	asm("loop:");	
	asm("inc _count");					// number of times through the loop
	asm("xor TRISB");					// bit 12 input, bit 13 output - charge Cs
	asm("xor TRISB");					// bit 12 output, bit13 input - transfer charge to Ca
	asm("nop");							// docs say this is necessary before a read
	asm("btss PORTB,#13");				// skip the goto if bit 12 is high
	asm("goto loop");

#endif

#ifdef doADC
	asm("repeat #21");			// adjust the repeat number as necessary
	asm("xor TRISB");			// perform charge & transfer

	asm("bclr AD1PCFG,#11");	// set an11 pin to analog mode		
	asm("bset AD1CON1,#1");		// start the conversion	
#endif

	asm("pop W0");			// restore W0 to make c happy
	LATB &= 0xCFFF;			// latch a zero on bit 12 and bit13
	TRISB &= 0xCFFF;		// make them both outputs - discharge Ca and Cs
#ifdef doCalibrate
	displayBits = 1;
#endif
}

}

// END




