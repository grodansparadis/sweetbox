//
// Registration # MT2157.
//
#ifndef DSPIC_SCI_H
#define DSPIC_SCI_H

#include	"dspic_environ.h"

extern volatile utiny sci_byte;
extern utiny getptr; // bank1
extern utiny putptr; // bank1
extern utiny sci_buffer[]; // bank1

void            init_UART1(ulong);
void 		    putch_UART1(utiny);
//unsigned char	getch(void);

#endif
