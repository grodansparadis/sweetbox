#ifndef DSPIC_DELAY_C
#define DSPIC_DELAY_C
//
// dspic_delay.c -- 
//
// Registration # MT2157.
//
// This module provides simple time-delay routines. The delays are not precise, just
// approximations. No interrupts are used, so these delays are good for routine
// non-critical things.
//

#include	"dspic_delay.h"

volatile utiny	Osc_Freq_Mhz;

void Delay10Us(utiny cnt)
// Delay from 1 to 255 uS. It's a very rough estimate...
// The DelayMs() routine does a scaling based on the MPU's clock frequency.
{
	utiny kk, jj;
	
	for (jj=0; jj<cnt; jj++)
	{
		for (kk=0; kk<1; kk++)
		{
			continue;
		}
	}
}


void DelayMs(utiny cnt)
// Delay from 1 to 255 mS. 
// The global Osc_Freq_Mhz is used to scale the delay based on the MPU's
// actual clock frequency.
{
	utiny i;
	if (cnt < 1) cnt = 1;
	do {
		i = Osc_Freq_Mhz;
		do {
			Delay10Us(11);
			ClrWdt();
		} while(--i);
	} while(--cnt);
}


void DelayBigMs(ushort cnt)
// For longer delays up to about 65 seconds, in increments of 250 mS.
{
    if (cnt < 250) cnt = 250;
	cnt = cnt / 250;
	do {
		DelayMs(250);
		ClrWdt();
	} while(--cnt);
}

#endif
