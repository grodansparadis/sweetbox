#ifndef DSPIC_I2C_H
#define DSPIC_I2C_H

//
//  dspic_i2c.h
//
// Registration # MT2157.
//

#include	"dspic_environ.h"

#define DSPIC_I2C_BASE_ADDRESS       0xC0

#define I2C_BUFFER_SIZE 40

extern utiny slave_address;

typedef struct _dspic_i2c_buffer
{
    utiny   num_bytes;
    utiny   data[I2C_BUFFER_SIZE];
} dspic_i2c_buffer;

void setup_i2c(void);
void send_I2C_byte(utiny data);

#endif
