//
// dspic_main.c -- This is code for the dsPIC30F3013.
//
// Registration # MT2157.
//

#include <stdio.h>
#include <stdlib.h>
#include "p30fxxxx.h"
#include "dspic_main.h"
#include "dspic_delay.h"
#include "dspic_i2c.h"

// --------------------------------------------------
// Setup configuration bits
//
// Set the 'Primary Oscillator' to run at the highest possible speed. With a 7.3728 Mhz xtal,
// the freq is 117.965 Mhz, which is very close to the chip's rated max of 120 Mhz.
_FOSC(XT_PLL16)
_FWDT(WDT_OFF) // Watch-Dog timer is off

// --------------------------------------------------
// Declare interrupt ISRs
//
// INT0 interrupt:
void __attribute__((__interrupt__, no_auto_psv)) _INT0Interrupt(void);

// Timer2 interrupt:
void __attribute__((__interrupt__, no_auto_psv)) _T2Interrupt(void);

// --------------------------------------------------
// Declare global vars.
//
ulong               ticks;
utiny               seconds, minutes, hours;
bool			    heartbeat, data_ready;
timing_structure    timing;
ushort			    second_ticks;
utiny               atod_channel;
ushort              voltage;
// I2C vars:
volatile dspic_i2c_buffer	i2c_in_buffer, i2c_out_buffer;
utiny               slave_address, sent_count, sending_count, receive_count;

// --------------------------------------------------
// Define values for the crystal oven 'thermostat'.
//
#define HEATER_MAX          6000    // max power in any case
#define HEATER_LOOP_GAIN    50      // feedback loop param

// --------------------------------------------------
// Functions.
//

ushort get_voltage (utiny sel)
// Do a general-purpose A/D reading on the indicated channel (0-8). Return a value 
// between 0 and 4095.
{
    ushort val;
    
    // Configure A/D Module
    ADCHS = (sel & 0x000F);     // select the channel
    ADCON1bits.SAMP = 1;        // start sampling
    DelayMs(1);                 // acquisition time
    ADCON1bits.SAMP = 0;        // start conversion
    while (!ADCON1bits.DONE)    // wait for conversion to complete
    {
        ClrWdt();    
    }
    val = ADCBUF0;              // get the value
    return(val);
} // get_voltage()


void dspic_init(void)
// Configure the dsPIC.
{
	//-------------------------------------
    // Setup I/O ports.
	// 
    TRISB = 0b1111110111000111;
	LATB  = 0b0000000000111000;

	// 
    TRISC = 0b1111111111111111;
	LATC  = 0b0000000000000000;

    // 
    TRISD = 0b1111110111111111;
	LATD  = 0b0000000000000000;

	// RF5 - heartbeat LED
    TRISF = 0b1111111111011111;
	LATF  = 0b0000000000000000;
	
	//-------------------------------------
	// Setup Timers and timer vars.
	//
    timing.second_tick = 0;
    timing.seconds = 0;
    second_ticks = 100;
    T2CON  = 0b1000000000010000;    // Timer2 on, prescale 1:8

	//-------------------------------------
    // Setup A/D conversion.
    //
    ADCON1 = 0b1000000000000000; // turn on the A/D module
    // b15:13=000 for internal Vref
    ADCON2 = 0b0000000000000000; // 
    // Tcy is 33.9 nS.
    ADCON3 = 0b0000000000000100; // 4 is good, 3 is a bit over-clocked. Ideal is 3.9.
    ADCHS  = 0b0000000000000000; // select AN0
    ADPCFG = 0b1111111111111110; // enable AN0 as an analog input
    ADCSSL = 0b0000000000000000;
    
    //-------------------------------------
	// Setup Timer2, which is used for general time-keeping. Timer2 is NOT the time base
	// for the clock's displayed time.
	//
	PR2    = 0x9000;				// Timer2 period for 10ms ints with 118 Mhz clock.
	TMR2   = 0;
	IFS0bits.T2IF = 0;	// clear the interrupt flag
	// For the dspic_delay module - record about how fast our clock is.
	Osc_Freq_Mhz = 118;
	
	//-------------------------------------
	// Setup PWM on pin RB9, which drives the HEATER bulb.
	//
	OC2CON = 0x0006;
	OC2RS  = 0x0A00; // initial duty cycle, a dull orange glow
	
    //-------------------------------------
    // Setup the serial ports. Choices are 38400, 19200, 9600, 4800, 2400.
    // At 118 Mhz, the *only* valid choice is 38400.
    //init_UART1(38400);
    //init_UART2(38400);

    ClrWdt();
    
    //-------------------------------------
    // Setup interrupts.
    INTCON2 = 0b0000000000000000; // INT0 positive edge
	// Set the priority levels for ints we are using.
	// All peripherals default to level 4.
	IPC0  = 0b0000000000000110; // INT0 priority 6
	//IPC1  = 0b0000000000000000;
	//IPC2  = 0b0000000000000000;
	//IPC3  = 0b0000000000000000;
	//IPC4  = 0b0100010001000101;
	// Enable int-on-change bits.
	//CNEN1 = 0b0000000001100000;
	// Clear the flags for all interrupts.
	IFS0  = 0b0000000000000000;
	IFS1  = 0b0000000000000000;
	IFS2  = 0b0000000000000000;
    // Enable the interrupts we are using.
    IEC0  = 0b0000000001000001; // b15:PortChange, b13:Slave I2C, b6:Timer2, b0:INT0
	IEC1  = 0b0000000000000000; // b0:INT1
	IEC2  = 0b0000000000000000;
} // dspic_init()


void pot_setting(enum digital_pots pot, utiny setting)
// Set a position for one of the two digital pots. These pots provide a voltage
// level that is used to drive two of the meters.
// Since we don't know the starting position, first move the wiper all the way
// to the bottom, then move it back up to the right spot.
// The two pots are HOURS_POT and MINUTES_POT.
{
    utiny kk;
    
    // Move wiper to the bottom.
    UP_DOWN = 0; // decrement
    Delay10Us(1);
    if (pot == HOURS_POT)
        CS2 = 0;
    else // MINUTES_POT
        CS3 = 0;
    Delay10Us(1);
    for (kk=0; kk<64; kk++)
        {
        Delay10Us(1);
  		UP_DOWN = 0;
  		Delay10Us(1);
  		UP_DOWN = 1;
        }
    Delay10Us(1);
    CS2 = 1;
    CS3 = 1;
    Delay10Us(1);
    
    // Move wiper up to the desired spot.
    UP_DOWN = 1; // increment
    Delay10Us(1);
    if (pot == HOURS_POT)
        CS2 = 0;
    else // MINUTES_POT
        CS3 = 0;
    Delay10Us(1);
    for (kk=0; kk<setting; kk++)
        {
        Delay10Us(1);
  		UP_DOWN = 0;
  		Delay10Us(1);
  		UP_DOWN = 1;
        }
    Delay10Us(1);
    CS2 = 1;
    CS3 = 1;
    Delay10Us(1);
} // pot_setting()


//--------------------------------------
// Main program.

int main(void)
{
    ushort voltage, heater_feedback;
    
	// Init the PIC, its ports, and peripherals.
    dspic_init();
    
    // Default the time to 12:00:00.
    hours   = 12;
    minutes = 0;
    seconds = 0;
    
    // Set the meters full-scale for a few seconds, to see if the calibration
    // looks right.
    pot_setting(MINUTES_POT, 4);
    pot_setting(HOURS_POT, 0);
    DelayBigMs(7000);

	// Main program loop. Stay here forever.
	while(1)
	    {
		// Update the time display, and blink the heartbeat LED.
		// We do this once per second.
		if (heartbeat)
		    {
    		// Update the minutes display.
    		pot_setting(MINUTES_POT, (63-minutes));
    		
    		// Update the hours display.
            pot_setting(HOURS_POT, (utiny)((12-hours)*5.25));
    		
    		// Update the heater setting. Get the current temperature from the MCP9700A.
    		voltage = get_voltage(0);
    		// Force a minimum measurement of 25 degrees C. In case we're cold, we don't
    		// want to go to a really high brightness. A reading of '614' indicates a
    		// temperature of 25 degrees.
    		if (voltage < 614) voltage = 614;
    		// Set a new PWM duty cycle for the lamp/heater. The higher the temperature,
    		// the lower the PWM will be.
    		heater_feedback = (voltage-614) * HEATER_LOOP_GAIN;
    		// Don't allow the feedback to become 'positive feedback'.
    		if (heater_feedback > HEATER_MAX) heater_feedback = HEATER_MAX;
    		// Assign a new PWM value.
    	    OC2RS  = HEATER_MAX - heater_feedback;
    		
    		// Blink the heartbeat LED.
			HEARTBEAT_LED = 1; // LED on
			DelayMs(20);
			HEARTBEAT_LED = 0; // LED off
			heartbeat = FALSE;
			
			// Update the pendulum.
			if (PENDULUM)
                PENDULUM = 0;
            else
                PENDULUM = 1;
		    }
		
		//
		// Check the time-setting buttons.
		//
		
		if (!FORWARD) // is 'Forward' button pushed?
    	    {
        	// Move the time forward quickly.
        	minutes++;
        	if (minutes > 59)
        	    {
            	minutes = 0;
            	hours++;
                if (hours > 12) hours = 1;   
                }
            DelayMs(150);
            heartbeat = TRUE;
            }
            
        if (!BACK) // is 'Backward' button pushed?
    	    {
        	// Move the time backward quickly.
        	minutes--;
        	if (minutes > 59) // wrapped around to 255
        	    {
            	minutes = 59;
            	hours--;
                if (hours < 1) hours = 12;   
                }
            DelayMs(150);
            heartbeat = TRUE;
            }
	    }
} // main()


void __attribute__((__interrupt__, no_auto_psv)) _INT0Interrupt(void)
// INT0 interrupt handler.
// This interrupt occurs at 100 Khz, from the crystal oscillator. It is the
// time reference for the Clock.
{
    ticks++;
    // Every second, update the HH:MM:SS counters.
    if (ticks > 100000)
        {
        ticks = 0;
        seconds++;
        if (seconds > 59)
            {
            seconds = 0;
            minutes++;
            if (minutes > 59)
                {
                minutes = 0;
                hours++;
                if (hours > 12)
                    hours = 1;
                }    
            }    
        }
	IFS0bits.INT0IF = 0;	// clear the interrupt flag
} // INT0Interrupt()


void __attribute__((__interrupt__, no_auto_psv)) _T2Interrupt(void)
// Timer2 interrupt handler.
// Interrupts from Timer2 are used for general time-keeping. The interrupt occurs
// every 10 mS, so we can use it to generate longer intervals easily.
{
	// Count the # of 10mS intervals.
    timing.tenMilSeconds++;
    timing.second_tick++;
    
    if (timing.second_tick > second_ticks)
    {
        // Do this stuff every second. Since the 'second_ticks' var is set according to the
        // current clock speed, stuff in this block can be made to happen every 1 second
        // even if we change clock speeds.
        
        // Count the # of seconds that have elapsed.
        timing.seconds++;
		// Reset our tick counter to start the next 1-second interval.
        timing.second_tick = 0;
        
        // Set a flag that will cause the heartbeat LED to blink. This will also cause
        // us to update the time display.
        heartbeat = TRUE;
    }
    
	IFS0bits.T2IF = 0;	// clear the interrupt flag
} // T2Interrupt()
