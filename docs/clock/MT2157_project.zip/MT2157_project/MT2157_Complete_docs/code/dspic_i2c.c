//
// dsipc_i2c.c - I2C Slave routines.
//
// Registration # MT2157.
//

#include <p30fxxxx.h>
#include "dspic_i2c.h"
#include "dspic_delay.h"

utiny checksum;


void setup_i2c(void)
{
    utiny kk;
    
    // Setup I2C.
    IEC0bits.SI2CIE = 0;
    I2CCONbits.I2CEN = 0;	// disable I2C
    TRISF = (TRISF & 0b1111111111110011); // set I2C pins as outputs
    LATFbits.LATF2 = 0; // clr the LAT bits
    LATFbits.LATF3 = 0;
    TRISF = (TRISF | 0b0000000000001100); // set I2C pins as inputs
    I2CSTAT = 0b0000000000000000;
    // Set the I2C address.
    I2CADD = slave_address;
    // Do a dummy read to clear the BF flag.
    kk = I2CRCV;
    I2CSTATbits.I2COV = 0; // clear overflow flag
    IFS0bits.SI2CIF = 0; // clear interrupt flag
    IEC0bits.SI2CIE = 1; // enable I2C interrupts
    I2CCON  = 0b1001001000000000; // enable I2C
} // setup_i2c()


void send_I2C_byte(utiny data)
{
    bool collision = TRUE;
    ushort kk;
    
    // Wait for BF to clear, but don't wait forever.
    kk = 0;
    while(I2CSTATbits.TBF)
    {
        ClrWdt();
        Delay10Us(15); // plm 1
        kk++;
        if (kk > 50000) break;
    }

	kk = 0;
    while(collision)
    {
        I2CSTATbits.IWCOL = 0;
        I2CTRN = data;
        if (I2CSTATbits.IWCOL == 0) collision = FALSE;
        Delay10Us(15); // plm 1
        kk++;
        if (kk > 50000) break;
    }
    // Release the clock, which allows our data to be sent to the Master.
    I2CCONbits.SCLREL = 1; // release the clock
    checksum += data;
} // send_I2C_byte()
