//
// Registration # MT2157.
//
#ifndef ENVIRON_H
#define ENVIRON_H

#include "p30f3013.h"

// basic types
#ifndef tiny
    typedef signed char     tiny;
#endif

#ifndef utiny
    typedef unsigned char   utiny;
#endif

#ifndef uchar
    typedef unsigned char   uchar;
#endif

#ifndef bool
    typedef unsigned char   bool;
#endif

#ifndef ushort
    typedef unsigned short  ushort;
#endif

#ifndef ulong
    typedef unsigned long   ulong;
#endif

// Boolean values
#define TRUE                    1
#define FALSE                   0

#define MHZ                     *1000L      // number of kHz in a MHz

// Timing vars.
typedef struct _timing_structure
{
    utiny   tenMilSeconds;
    ushort  second_tick;
    utiny	seconds;
} timing_structure;

#endif //ENVIRON_H
