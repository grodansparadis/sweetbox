//
// Registration # MT2157.
//
#ifndef DSPIC_MAIN_H
#define DSPIC_MAIN_H

#include "dspic_environ.h"
#include "dspic_sci.h"
#include "dspic_i2c.h"

extern volatile utiny	Osc_Freq_Mhz;
extern char			    sci_data_buffer[];
extern utiny		    sci_data_count;
extern utiny		    tmr2_expire_cnt;
extern utiny		    checksum;

// Define individual bits.
#define HEARTBEAT_LED           LATFbits.LATF5
#define HEATER                  LATBbits.LATB9
#define PENDULUM                LATDbits.LATD9
#define CS2                     LATBbits.LATB3  // Hours pot CS
#define CS3                     LATBbits.LATB4  // Minutes pot CS
#define UP_DOWN                 LATBbits.LATB5  // Pot up/down control
#define FORWARD                 PORTBbits.RB8   // Forward-setting button
#define BACK                    PORTFbits.RF4   // Backward-setting button
#define INT0                    PORTFbits.RF6
#define SCL                     PORTFbits.RF3
#define SDA                     PORTFbits.RF2

// Define names for the digital pots.
enum digital_pots {
    HOURS_POT, 
    MINUTES_POT };

#endif
