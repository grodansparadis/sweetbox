
/**********************************************************************
*
* FileName:       			 main.c
* Dependencies:   			 Header (.h) files if applicable, see below
* Processor:				 dsPIC30F2023
* Compiler:     	  		 MPLAB� C30 v3.01
* IDE:           			 MPLAB� IDE v7.62
* Hardware Dependencies:	 MiniTron Controller Board
*
* 
* REVISION HISTORY:
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* Author            Date      Comments on this revision
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*
* XXXXX			09/13/07	Initial Release
* XXXXX			09/14/07	rewrote SPI routines to reduce code size
* XXXXX			09/16/07	Added and debugged single channel SMPS code
* XXXXX			09/17/07	Added second channel to SMPS code (untested)
* XXXXX			09/18/07	Added simple high voltage control
*
*~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
* ADDITIONAL NOTES: 
*
* Some code segments are lifted from the programming examples on the Microchip web site
*
**********************************************************************/

#include "p30F2023.h"

/* Configuration Bit Settings */
_FOSCSEL(FRC_PLL)									// Fast RC w/PLL
_FOSC(CSW_FSCM_OFF & FRC_HI_RANGE & OSC2_CLKO)		// High range with clk out on CLKO
_FPOR(PWRT_128)										// POR timer = 128
_FGS(CODE_PROT_OFF)									// no code protect
_FBS(BSS_NO_FLASH)									// no BSS flash
_FWDT(FWDTEN_OFF) 			            			// Watchdog Timer Enabled/disabled by user software



//**************************************  FUNCTIONS  ***************************************

void delay(void)
{	
	short temp;	
	for (temp=0;temp<255;temp++)
		;
}	

void Init_SPI(void) 								// setup the SPI peripheral
{	
	SPI1STAT = 0x0000;  							// disable the SPI module (just in case)
	SPI1CON1 = 0x0422;								// unused = 0b000, DISSCK = 0, DISSDO = 0, MODE16 = 1; SMP = 0;  CKE = 0; SSEN = 0; CKP = 0; MSTEN = 1; SPRE = 0b000, PPRE = 0b10
	SPI1STAT = 0x8000; 								// enable the SPI module
}

void write_RT_OPT_Bias_A(long spi_word_a)
{	
	long temp,tempword,outword;	

	PORTAbits.RA8 = 0;								// lower the chip select line
	temp = SPI1BUF;									// dummy read of the SPI1BUF register to clear the SPIRBF flag
	tempword = spi_word_a & 0x0FFF;					// mask upper 4 bits
	outword = tempword | 0x5000;					// include config in upper 4 bits								
	SPI1BUF = outword;								// write the data out to the DAC 1A
    while (!SPI1STATbits.SPIRBF)					// wait for the data to be sent out
		;
	PORTAbits.RA8 = 1;								// raise the chip select line
	delay();
}

void write_RT_OPT_Bias_B(long spi_word_b)
{
	long temp,tempword,outword;	

	PORTAbits.RA8 = 0;								// lower the chip select line
	temp = SPI1BUF;									// dummy read of the SPI1BUF register to clear the SPIRBF flag
	tempword = spi_word_b & 0x0FFF;					// mask upper 4 bits
	outword = tempword | 0xD000;					// include config in upper 4 bits								
	SPI1BUF = outword;								// write the data out to the DAC 1B
    while (!SPI1STATbits.SPIRBF)					// wait for the data to be sent out
		;
	PORTAbits.RA8 = 1;								// raise the chip select line
	delay();
}

void write_LT_OPT_Bias_B(long spi_word_a)
{	
	long temp,tempword,outword;	

	PORTAbits.RA9 = 0;								// lower the chip select line
	temp = SPI1BUF;									// dummy read of the SPI1BUF register to clear the SPIRBF flag
	tempword = spi_word_a & 0x0FFF;					// mask upper 4 bits
	outword = tempword | 0x5000;					// include config in upper 4 bits								
	SPI1BUF = outword;								// write the data out to the DAC 2A
    while (!SPI1STATbits.SPIRBF)					// wait for the data to be sent out
		;
	PORTAbits.RA9 = 1;								// raise the chip select line
	delay();
}

void write_RT_DRV_Bias(long spi_word_b)
{
	long temp,tempword,outword;	

	PORTAbits.RA9 = 0;								// lower the chip select line
	temp = SPI1BUF;									// dummy read of the SPI1BUF register to clear the SPIRBF flag
	tempword = spi_word_b & 0x0FFF;					// mask upper 4 bits
	outword = tempword | 0xD000;					// include config in upper 4 bits								
	SPI1BUF = outword ;								// write the data out to the DAC 2B
    while (!SPI1STATbits.SPIRBF)					// wait for the data to be sent out
		;
	PORTAbits.RA9 = 1;								// raise the chip select line
	delay();
}

void write_LT_DRV_Bias(long spi_word_a)
{	
	long temp,tempword,outword;	

	PORTAbits.RA10 = 0;								// lower the chip select line
	temp = SPI1BUF;									// dummy read of the SPI1BUF register to clear the SPIRBF flag
	tempword = spi_word_a & 0x0FFF;					// mask upper 4 bits
	outword = tempword | 0x5000;					// include config in upper 4 bits								
	SPI1BUF = outword ;								// write the data out to the DAC 3A
    while (!SPI1STATbits.SPIRBF)					// wait for the data to be sent out
		;
	PORTAbits.RA10 = 1;								// raise the chip select line
	delay();
}

void write_LT_OPT_Bias_A(long spi_word_b)
{	
	long temp,tempword,outword;	

	PORTAbits.RA10 = 0;								// lower the chip select line
	temp = SPI1BUF;									// dummy read of the SPI1BUF register to clear the SPIRBF flag
	tempword = spi_word_b & 0x0FFF;					// mask upper 4 bits
	outword = tempword | 0xD000;					// include config in upper 4 bits								
	SPI1BUF = outword;								// write the data out to the DAC 3B
    while (!SPI1STATbits.SPIRBF)					// wait for the data to be sent out
		;
	PORTAbits.RA10 = 1;								// raise the chip select line
	delay();
}

void Set_PGA_Channel(long channel)
{	
	long temp,tempword,outword;	

	PORTAbits.RA11 = 0;								// lower the chip select line
	temp = SPI1BUF;									// dummy read of the SPI1BUF register to clear the SPIRBF flag
	tempword = channel & 0x0007;					// mask upper 13 bits
	outword = tempword | 0x4100;					// include channel set config in upper 13 bits
	SPI1BUF = outword;								// write the data out to the SPI peripheral
    while (!SPI1STATbits.SPIRBF)					// wait for the data to be sent out
		;
	PORTAbits.RA11 = 1;								// raise the chip select line
	delay();
}

void Set_PGA_Gain(long gain)
{	
	long temp,tempword,outword;	

	PORTAbits.RA11 = 0;								// lower the chip select line
	temp = SPI1BUF;									// dummy read of the SPI1BUF register to clear the SPIRBF flag
	tempword = gain & 0x0007;						// mask upper 13 bits
	outword = tempword | 0x4000;					// include gain set config in upper 13 bits
	SPI1BUF = outword;								// write the data out to the SPI peripheral
    while (!SPI1STATbits.SPIRBF)					// wait for the data to be sent out
		;
	PORTAbits.RA11 = 1;								// raise the chip select line
	delay();
}

void Write_Bias(long L_DRV, long R_DRV, long L_OPT_A, long L_OPT_B, long R_OPT_A, long R_OPT_B)
{
write_RT_OPT_Bias_A(R_OPT_A);
write_RT_OPT_Bias_B(R_OPT_B);
write_LT_OPT_Bias_B(L_OPT_B);
write_RT_DRV_Bias(R_DRV);
write_LT_DRV_Bias(L_DRV);
write_LT_OPT_Bias_A(L_OPT_A);
}

void HV_ON(void)
{
PORTEbits.RE4 = 1;								// turn on the high voltage power supply
}

void HV_OFF(void)
{
PORTEbits.RE4 = 0;								// turn off the high voltage power supply
}

void __attribute__((__interrupt__)) _ADCInterrupt()

// interrupt service routine. Reads ADC when result is ready and transfers result to PWM 1 and PWM 2
{
	int channel0Result,channel1Result;
	
	IFS0bits.ADIF = 0;              /* Clear ADC Interrupt Flag */
	ADSTATbits.P0RDY = 0;           /* Clear the ADSTAT bits */
	channel0Result = ADCBUF0;       /* Get the conversion result */
	channel1Result = ADCBUF1;       /* Get the conversion result */
	
	/* Update the Duty cycle 1 with value read from AN0 
	   PDC1 value will be such that 7F >= PDC1 >= 3F0 */
	
	PDC1 = (channel0Result >= 0x03F0) ? 0x03F0 :
			 ((channel0Result <= 0x007F) ? 0x007F : channel0Result);

	/* Update the Duty cycle 2 with value read from AN1 
	   PDC2 value will be such that 7F >= PDC1 >= 3F0 */

	PDC2 = (channel1Result >= 0x03F0) ? 0x03F0 :
			 ((channel1Result <= 0x007F) ? 0x007F : channel1Result);
}

//**************************************  FUNCTIONS END  ***************************************




//************************************** MAIN STARTS HERE ***************************************


int main(void)
{
// initial values for bias variables determined by testing. Auto bias to be added later
	long L_DRV=754,R_DRV=722,L_OPT_A=987,L_OPT_B=990,R_OPT_A=943,R_OPT_B=918;

	
	RCONbits.SWDTEN=0;          					// Disable Watch Dog Timer
	while(OSCCONbits.LOCK!=1) {}; 					// Wait for PLL to lock

	TRISA = 0xF0FF;								   	// RA8 RA9 RA10 RA11  are CS output
	PORTA = 0x0F00;									// Set them

	TRISB = 0xFFFF;									// Port B is input

	TRISD = 0xFFFE;									// RD0 is output
	PORTD = 0x0000;									// clear port D

	TRISE = 0x00E0;									// RE0 through RE4 is output
	PORTE = 0x0000;									// clear port E

	TRISF = 0x0080;									// set PORTF to output except for SDI1, RF2 is CS for EEPROM
	PORTF = 0x0040;									// set RF2

	TRISG = 0xFFFF;									// RGx is input
	PORTG = 0x0000;									// clear port D
	
	Init_SPI();

	PTPER = 2048;                   				// PWM Period = 2.199 usec @ 29.1 MIPS 





//********************************** Initialize PWM Generator 1 **************************************
	
	IOCON1bits.PENH		= 1;        /* PWM Module controls High output */
	IOCON1bits.PENL		= 1;        /* PWM Module controls Low output */
	IOCON1bits.POLH		= 0;        /* High Output Polarity is active High */
	IOCON1bits.POLL		= 0;        /* Low Output Polarity is active High */
	IOCON1bits.PMOD		= 1;        /* Independant output mode */
	IOCON1bits.OVRENH 	= 0;        /* High Output Override disabled */
	IOCON1bits.OVRENL 	= 0;        /* Low Output Override disabled */
	
	TRGCON1bits.TRGDIV = 0;         /* Trigger on every event */
	TRGCON1bits.TRGSTRT	= 0;        /* Start the counting at the start */
	
	TRIG1 = 50;                    /* Trigger event at  0.214 usec from
	                                   start of the PWM cycle */
										
	PWMCON1bits.FLTSTAT = 0;        /* Clear Fault Interrupt flag */
	PWMCON1bits.CLSTAT = 0;         /* Clear Current Limit Interrupt flag */
	PWMCON1bits.TRGSTAT = 0;        /* Clear PWM Trigger Interrupt flag */
	PWMCON1bits.FLTIEN = 0;         /* Disable Fault Interrupt */
	PWMCON1bits.CLIEN = 0;          /* Disable Current Limit Interrupt */
	PWMCON1bits.TRGIEN = 0;         /* Disable Trigger Interrupt */
	PWMCON1bits.ITB	= 0;            /* Time base is read from PTMR */
	PWMCON1bits.MDCS = 0;           /* Duty cycle is read from PDC */
	PWMCON1bits.DTC	= 2;            /* No Dead Time */
	PWMCON1bits.XPRES = 0;          /* No extenal reset for PTMR */
	PWMCON1bits.IUE = 0;            /* Immediate update to PDC */
										
	PDC1 = 128;                     /* Start with a Ton value of 0.137usec */
	PHASE1 = 0;                     /* No staggering */
		
//*********************************** Initialize PWM Generator 2 *****************************************
	
	IOCON2bits.PENH		= 1;        /* PWM Module controls High output */
	IOCON2bits.PENL		= 1;        /* PWM Module controls Low output */
	IOCON2bits.POLH		= 0;        /* High Output Polarity is active High */
	IOCON2bits.POLL		= 0;        /* Low Output Polarity is active High */
	IOCON2bits.PMOD		= 1;        /* Independant output mode */
	IOCON2bits.OVRENH 	= 0;        /* High Output Override disabled */
	IOCON2bits.OVRENL 	= 0;        /* Low Output Override disabled */
	
	//TRGCON2bits.TRGDIV = 0;         /* Trigger on every event */
	//TRGCON2bits.TRGSTRT	= 0;        /* Start the counting at the start */
								
	PWMCON2bits.FLTSTAT = 0;        /* Clear Fault Interrupt flag */
	PWMCON2bits.CLSTAT = 0;         /* Clear Current Limit Interrupt flag */
	PWMCON2bits.TRGSTAT = 0;        /* Clear PWM Trigger Interrupt flag */
	PWMCON2bits.FLTIEN = 0;         /* Disable Fault Interrupt */
	PWMCON2bits.CLIEN = 0;          /* Disable Current Limit Interrupt */
	PWMCON2bits.TRGIEN = 0;         /* Disable Trigger Interrupt */
	PWMCON2bits.ITB	= 0;            /* Time base is read from PTMR */
	PWMCON2bits.MDCS = 0;           /* Duty cycle is read from PDC */
	PWMCON2bits.DTC	= 2;            /* No Dead Time */
	PWMCON2bits.XPRES = 0;          /* No extenal reset for PTMR */
	PWMCON2bits.IUE = 0;            /* Immediate update to PDC */
										
	PDC2 = 128;                     /* Start with a Ton value of 0.137usec */
	PHASE2 = 0;                     /* No staggering */
		

//*********************************** Intialize the ADC *****************************************************
	
	ADCONbits.ADSIDL = 0;           /* Operate in Idle Mode */
	ADCONbits.FORM = 0;             /* Output in Integer Format */
	ADCONbits.EIE = 0;              /* Disable Early Interrupt  ---------  Test the affect of this bit on system accuracy  */
	ADCONbits.ORDER = 0;            /* Even channel first */
	ADCONbits.SEQSAMP = 1;          /* Sequential Sampling Enabled */
	ADCONbits.ADCS = 5;             /* Clock Divider is set up for Fadc/14 */
	
	ADPCFG = 0xFF00;                /* AN0 through AN7 are analog inputs */
	ADSTAT = 0;                     /* Clear the ADSTAT register */
	ADCPC0bits.TRGSRC0 = 0x4;       /* Trigger conversion on PWM#1 Trigger */
	ADCPC0bits.IRQEN0 = 1;          /* Enable the interrupt */
	
	ADCONbits.ADON = 1;             /* Start the ADC module */	
				
	/* Set up the Interrupts */
	
	IFS0bits.ADIF = 0;              /* Clear AD Interrupt Flag */	
	IPC2bits.ADIP = 4;              /* Set ADC Interrupt Priority */
	IEC0bits.ADIE = 1;              /* Enable the ADC Interrupt */
	
	PTCON = 0x8000;                 /* Enable PWM Module */



	//delay();

	Write_Bias(L_DRV,R_DRV,L_OPT_A,L_OPT_B,R_OPT_A,R_OPT_B); 	// set up initial bias voltages
	Set_PGA_Channel(0);											// set pga to monitor bias power supply
	Set_PGA_Gain(0);											// set pga to unity gain
	delay();
	HV_ON();													// turn on the high voltage
while(1)
{

	// main loop code goes here (house keeping, new features etc)
	// ADC --> PWM functions are interrupt driven

}





	
}
//************************************** THE END ***************************************


