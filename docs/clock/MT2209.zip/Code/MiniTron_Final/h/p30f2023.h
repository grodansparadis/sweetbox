/*-------------------------------------------------------------------------
 *
 * MPLAB-C30  dsPIC30F2023 processor header
 *
 * (c) Copyright 2005-2006 Microchip Technology, All rights reserved
 *
 * File Description / Notes:
 * =========================
 * 1] This header file defines special function registers (SFR), and useful
 *    macros for the dsPIC30Fxxxx Family of Digital Signal
 *    Controllers (also referred to as the dsPIC).
 * 2] The register and bit names used in this file match the
 *    dsPIC30Fxxxx data sheets as closely as possible.
 * 3] The memory locations of the registers defined in this header file are
 *    specified in the respective linker scripts.
 * 4] SFR definitions are listed in the ascending order of memory addresses
 *    and are grouped based on the module they belong to. For e.g., WREG10
 *    is listed before ACCAL, and the Core SFRs are grouped separately
 *    from the Interrupt Controller SFRs or the General Purpose Timer SFRs.
 *
 * Revision History:
 * =================
 * --------------------------------------------------------------------------
 * Rev:   Date:        Details:                                     Who:
 * --------------------------------------------------------------------------
 * 1.0    04 Jun 2006  New file                             S Fernandes
 * 1.1    29 Sept 2006 Corrections to bit names and         S Khare
                       register names and addresses
 * 1.5    17 Oct 2006  Corrections to SPI registers         S Khare
 * 1.6    13 Nov 2006  Corrections to security settings     S Khare
 *                     Corrections to WDT settings          S Khare
 * v3.00  02 Feb 2007  Added processor check                S. Curtis
 *                      (Rev reflects compiler version)
 * ------------------------------------------------------------------------*/

#ifndef __dsPIC30F2023__
#error "Include file does not match processor setting"
#endif

#ifndef __30F2023_H
#define __30F2023_H

/* ------------------------- */
/* Core Register Definitions */
/* ------------------------- */

/* W registers W0-W15 */
extern volatile unsigned int WREG0 __attribute__((__near__,__deprecated__,__unsafe__));
extern volatile unsigned int WREG1 __attribute__((__near__,__deprecated__,__unsafe__));
extern volatile unsigned int WREG2 __attribute__((__near__,__deprecated__,__unsafe__));
extern volatile unsigned int WREG3 __attribute__((__near__,__deprecated__,__unsafe__));
extern volatile unsigned int WREG4 __attribute__((__near__,__deprecated__,__unsafe__));
extern volatile unsigned int WREG5 __attribute__((__near__,__deprecated__,__unsafe__));
extern volatile unsigned int WREG6 __attribute__((__near__,__deprecated__,__unsafe__));
extern volatile unsigned int WREG7 __attribute__((__near__,__deprecated__,__unsafe__));
extern volatile unsigned int WREG8 __attribute__((__near__,__deprecated__,__unsafe__));
extern volatile unsigned int WREG9 __attribute__((__near__,__deprecated__,__unsafe__));
extern volatile unsigned int WREG10 __attribute__((__near__,__deprecated__,__unsafe__));
extern volatile unsigned int WREG11 __attribute__((__near__,__deprecated__,__unsafe__));
extern volatile unsigned int WREG12 __attribute__((__near__,__deprecated__,__unsafe__));
extern volatile unsigned int WREG13 __attribute__((__near__,__deprecated__,__unsafe__));
extern volatile unsigned int WREG14 __attribute__((__near__,__deprecated__,__unsafe__));
extern volatile unsigned int WREG15 __attribute__((__near__,__deprecated__,__unsafe__));

/* SPLIM: Stack Pointer Limit */
extern volatile unsigned int SPLIM __attribute__((__near__));

/* Alternative access structure for the 40-bit accumulators */
typedef struct tagACC {
    unsigned int L;
    unsigned int H;
    unsigned char U;
} ACC;

/* Acc A<15:0> */
extern volatile unsigned int ACCAL __attribute__((__near__));

/* Acc A<31:16> */
extern volatile unsigned int ACCAH __attribute__((__near__));

/* Acc A<39:32> */
extern volatile unsigned char ACCAU __attribute__((__near__));

/* Acc A defined as a structure consisting of the 3 parts */
extern volatile ACC ACCA __attribute__((__near__));

/* Acc B<15:0> */
extern volatile unsigned int ACCBL __attribute__((__near__));

/* Acc B<31:16> */
extern volatile unsigned int ACCBH __attribute__((__near__));

/* Acc B<39:32> */
extern volatile unsigned char ACCBU __attribute__((__near__));

/* Acc B defined as a structure consisting of the 3 parts */
extern volatile ACC ACCB __attribute__((__near__));

/* PCL: Program Counter low word */
extern volatile unsigned int PCL __attribute__((__near__));

/* PCH: Program Counter high byte */
extern volatile unsigned char PCH __attribute__((__near__));

/* TBLPAG: Table Page Register */
extern volatile unsigned char TBLPAG __attribute__((__near__));

/* PSVPAG: Program Space Visibility Page Register */
extern volatile unsigned char PSVPAG __attribute__((__near__));

/* RCOUNT: REPEAT loop count */
extern volatile unsigned int RCOUNT __attribute__((__near__));

/* DCOUNT: DO loop count */
extern volatile unsigned int DCOUNT __attribute__((__near__));

/* DOSTARTL: DO loop start address bits <15:0> */
extern volatile unsigned int DOSTARTL __attribute__((__near__));

/* DOSTARTH: DO loop start address bits <23:16> */
extern volatile unsigned int DOSTARTH __attribute__((__near__));

/* DOENDL: DO loop end address bits <15:0> */
extern volatile unsigned int DOENDL __attribute__((__near__));

/* DOENDH: DO loop end address bits <23:16> */
extern volatile unsigned int DOENDH __attribute__((__near__));

/* SR: Status Register */
extern volatile unsigned int SR __attribute__((__near__));
typedef struct tagSRBITS {
        unsigned C      :1;     /* Carry flag                           */
        unsigned Z      :1;     /* Sticky Zero flag                     */
        unsigned OV     :1;     /* Overflow flag                        */
        unsigned N      :1;     /* Negative flag                        */
        unsigned RA     :1;     /* REPEAT loop active flag              */
        unsigned IPL    :3;     /* CPU Interrupt Priority Level         */
        unsigned DC     :1;     /* Digit Carry flag                     */
        unsigned DA     :1;     /* DO loop active flag                  */
        unsigned SAB    :1;     /* Combined A/B saturation flag         */
        unsigned OAB    :1;     /* Combined A/B overflow flag           */
        unsigned SB     :1;     /* Acc B saturation flag                */
        unsigned SA     :1;     /* Acc A saturation flag                */
        unsigned OB     :1;     /* Acc B overflow flag                  */
        unsigned OA     :1;     /* Acc A overflow flag                  */
} SRBITS;
extern volatile SRBITS SRbits __attribute__((__near__));

/* CORCON: CPU Mode control Register */
extern volatile unsigned int CORCON __attribute__((__near__));
typedef struct tagCORCONBITS {
        unsigned IF     :1;     /* Integer/Fractional mode              */
        unsigned RND    :1;     /* Rounding mode                        */
        unsigned PSV    :1;     /* Program Space Visibility enable      */
        unsigned IPL3   :1;     /* MS bit of CPU priority nibble        */
        unsigned ACCSAT :1;     /* Acc saturation mode                  */
        unsigned SATDW  :1;     /* Data space write saturation enable   */
        unsigned SATB   :1;     /* Acc B saturation enable              */
        unsigned SATA   :1;     /* Acc A saturation enable              */
        unsigned DL     :3;     /* DO loop nesting level status         */
        unsigned EDT    :1;     /* Early DO loop termination control    */
        unsigned US	:1;		/* Signed or UnSigned DSP multiply	*/
	unsigned 	:3;
} CORCONBITS;
extern volatile CORCONBITS CORCONbits __attribute__((__near__));

/* MODCON: Modulo Addressing Control Register */
extern volatile unsigned int MODCON __attribute__((__near__));
typedef struct tagMODCONBITS {
        unsigned XWM    :4;     /* X-RAGU/X-WAGU modulo addressing register select  */
        unsigned YWM    :4;     /* Y-RAGU modulo addressing register select         */
        unsigned BWM    :4;     /* Bit-reversed addressing register select          */
        unsigned        :2;
        unsigned YMODEN :1;     /* Y-RAGU modulo addressing enable                  */
        unsigned XMODEN :1;     /* X-RAGU/X-WAGU modulo addressing enable           */
} MODCONBITS;
extern volatile MODCONBITS MODCONbits __attribute__((__near__));

/* XMODSRT: X-RAGU/X-WAGU modulo buffer start address */
extern volatile unsigned int XMODSRT __attribute__((__near__));

/* XMODEND: X-RAGU/X-WAGU modulo buffer end address */
extern volatile unsigned int XMODEND __attribute__((__near__));

/* YMODSRT: Y-RAGU modulo buffer start address */
extern volatile unsigned int YMODSRT __attribute__((__near__));

/* YMODEND: Y-RAGU modulo buffer end address */
extern volatile unsigned int YMODEND __attribute__((__near__));

/* XBREV: X-WAGU Bit-reversed Addressing Control Register */
extern volatile unsigned int XBREV __attribute__((__near__));
typedef struct tagXBREVBITS {
        unsigned XB     :15;    /* Bit-reversed addressing register select  */
        unsigned BREN   :1;     /* Bit-reversed addressing enable           */
} XBREVBITS;
extern volatile XBREVBITS XBREVbits __attribute__((__near__));

/* DISICNT: Disable Interrupt Cycle Count */
extern volatile unsigned int DISICNT __attribute__((__near__));
typedef struct tagDISICNTBITS {
        unsigned DISICNT:14;
        unsigned        :2;
} DISICNTBITS;
extern volatile DISICNTBITS DISICNTbits __attribute__((__near__));

/* ---------------------------------------------- */
/* Input Change Notification register definitions */
/* ---------------------------------------------- */

/* CNEN1: Input Change Notification Interrupt Enable Register 1 */
extern volatile unsigned int CNEN1 __attribute__((__sfr__));
typedef struct tagCNEN1BITS {
        unsigned CN0IE  :1;
        unsigned CN1IE  :1;
        unsigned CN2IE  :1;
        unsigned CN3IE  :1;
        unsigned CN4IE  :1;
        unsigned CN5IE  :1;
        unsigned CN6IE  :1;
        unsigned CN7IE  :1;
        unsigned        :8;
} CNEN1BITS;
extern volatile CNEN1BITS CNEN1bits __attribute__((__sfr__));

/* CNPU1: Input Change Notification Pullup Enable Register 1 */
extern volatile unsigned int CNPU1 __attribute__((__sfr__));
typedef struct tagCNPU1BITS {
        unsigned CN0PUE :1;
        unsigned CN1PUE :1;
        unsigned CN2PUE :1;
        unsigned CN3PUE :1;
        unsigned CN4PUE :1;
        unsigned CN5PUE :1;
        unsigned CN6PUE :1;
        unsigned CN7PUE :1;
        unsigned        :8;
} CNPU1BITS;
extern volatile CNPU1BITS CNPU1bits __attribute__((__sfr__));


/* ----------------------------------------- */
/* Interrupt Controller register definitions */
/* ----------------------------------------- */

/* INTCON1: Interrupt Control Register 1 */
extern volatile unsigned int INTCON1 __attribute__((__near__));
typedef struct tagINTCON1BITS {
        unsigned                :1;
        unsigned OSCFAIL        :1;
        unsigned STKERR         :1;
        unsigned ADDRERR        :1;
        unsigned MATHERR        :1;
        unsigned                :1;
        unsigned DIV0ERR        :1;
        unsigned SFTACERR       :1;
        unsigned COVTE          :1;
        unsigned OVBTE          :1;
        unsigned OVATE          :1;
        unsigned COVBERR        :1;
        unsigned COVAERR        :1;
        unsigned OVBERR         :1;
        unsigned OVAERR         :1;
        unsigned NSTDIS         :1;
} INTCON1BITS;

extern volatile INTCON1BITS INTCON1bits __attribute__((__near__));

/* INTCON2: Interrupt Control Register 2 */
extern volatile unsigned int INTCON2 __attribute__((__near__));
typedef struct tagINTCON2BITS {
        unsigned INT0EP         :1;
        unsigned INT1EP         :1;
        unsigned INT2EP         :1;
        unsigned                :11;
        unsigned DISI           :1;
        unsigned ALTIVT         :1;
} INTCON2BITS;
extern volatile INTCON2BITS INTCON2bits __attribute__((__near__));

/* IFS0: Interrupt Flag Status Register 0 */
extern volatile unsigned int IFS0 __attribute__((__near__));
typedef struct tagIFS0BITS {
        unsigned INT0IF  :1; /* External Interrupt 0            */
        unsigned IC1IF   :1; /* Input Compare 1                 */
        unsigned OC1IF   :1; /* Output Compare 1                */
        unsigned T1IF    :1; /* Timer 1                         */
        unsigned         :1; /* */
        unsigned OC2IF   :1; /* Output Compare 2                */
        unsigned T2IF    :1; /* Timer 2                         */
        unsigned T3IF    :1; /* Timer 3                         */
        unsigned SPI1IF  :1; /* SPI 1                           */
        unsigned U1RXIF  :1; /* UART 1 Reciever                 */
        unsigned U1TXIF  :1; /* UART 1 Transmitter              */
        unsigned ADIF    :1; /* ADC Conversion Complete         */
        unsigned NVMIF   :1; /* NVM Write Complete              */
        unsigned SI2CIF  :1; /* I2C Transfer Complete           */
        unsigned MI2CIF  :1; /* I2C Bus Collision               */
        unsigned         :1; /* */
} IFS0BITS;
extern volatile IFS0BITS IFS0bits __attribute__((__near__));

/* IFS1: Interrupt Flag Status Register 1 */
extern volatile unsigned int IFS1 __attribute__((__near__));
typedef struct tagIFS1BITS {
        unsigned INT1IF  :1; /* External Interrupt 1            */
        unsigned INT2IF  :1; /* External Interrupt 2            */
        unsigned PSEMIF  :1; /* PWM-Special Event Match         */
        unsigned PWM1IF  :1; /* PWM Generator #1                */
        unsigned PWM2IF  :1; /* PWM Generator #2                */
        unsigned PWM3IF  :1; /* PWM Generator #3                */
        unsigned PWM4IF  :1; /* PWM Generator #4                */
        unsigned         :4; /*                                 */
	  unsigned CNIF    :1; /* Input Change Notification       */
        unsigned         :1; /*                                 */
        unsigned AC1IF	 :1; /* Analog Comparator 1             */
        unsigned AC2IF   :1; /* Analog Comparator 2             */
        unsigned AC3IF   :1; /* Analog Comparator 3             */
} IFS1BITS;
extern volatile IFS1BITS IFS1bits __attribute__((__near__));

/* IFS2: Interrupt Flag Status Register 2 */
extern volatile unsigned int IFS2 __attribute__((__near__));
typedef struct tagIFS2BITS {
        unsigned AC4IF   :1; /* Analog Comparator 4          */
        unsigned         :4;
        unsigned ADCP0IF :1; /* ADC Pair 0			 */
        unsigned ADCP1IF :1; /* ADC Pair 1			 */
        unsigned ADCP2IF :1; /* ADC Pair 2			 */
        unsigned ADCP3IF :1; /* ADC Pair 3			 */
        unsigned ADCP4IF :1; /* ADC Pair 4			 */
        unsigned ADCP5IF :1; /* ADC Pair 5			 */

        unsigned         :5;
} IFS2BITS;
extern volatile IFS2BITS IFS2bits __attribute__((__near__));

/* IEC0: Interrupt Enable Control Register 0 */
extern volatile unsigned int IEC0 __attribute__((__near__));
typedef struct tagIEC0BITS {
        unsigned INT0IE  :1; /* External Interrupt 0            */
        unsigned IC1IE   :1; /* Input Capture 1                 */
        unsigned OC1IE   :1; /* Output Compare 1                */
        unsigned T1IE    :1; /* Timer 1                         */
        unsigned         :1; /*                                 */
        unsigned OC2IE   :1; /* Output Compare 2                */
        unsigned T2IE    :1; /* Timer 2                         */
        unsigned T3IE    :1; /* Timer 3                         */
        unsigned SPI1IE  :1; /* SPI 1                           */
        unsigned U1RXIE  :1; /* UART 1 Reciever                 */
        unsigned U1TXIE  :1; /* UART 1 Transmitter              */
        unsigned ADIE    :1; /* ADC Conversion Complete         */
        unsigned NVMIE   :1; /* NVM Write Complete              */
        unsigned SI2CIE  :1; /* I2C Transfer Complete           */
        unsigned MI2CIE  :1; /* I2C Bus Collision               */
        unsigned         :1; /* */
} IEC0BITS;
extern volatile IEC0BITS IEC0bits __attribute__((__near__));

/* IEC1: Interrupt Enable Control Register 1 */
extern volatile unsigned int IEC1 __attribute__((__near__));
typedef struct tagIEC1BITS {
        unsigned INT1IE  :1; /* External Interrupt 1            */
        unsigned INT2IE  :1; /* External Interrupt 2            */
        unsigned PSEMIE  :1;  /* PWM-Special Event Match        */
        unsigned PWM1IE  :1; /* PWM Generator #1                */
        unsigned PWM2IE  :1; /* PWM Generator #2                */
        unsigned PWM3IE  :1; /* PWM Generator #3                */
        unsigned PWM4IE  :1; /* PWM Generator #4                */
        unsigned         :4; /*                                 */
        unsigned CNIE    :1; /* Input Change Notification       */
        unsigned         :1; /*                                 */
        unsigned AC1IE   :1; /* Analog Comparator 1             */
        unsigned AC2IE   :1; /* Analog Comparator 2             */
        unsigned AC3IE   :1; /* Analog Comparator 3             */
} IEC1BITS;
extern volatile IEC1BITS IEC1bits __attribute__((__near__));

/* IEC2: Interrupt Enable Control Register 2 */
extern volatile unsigned int IEC2 __attribute__((__near__));
typedef struct tagIEC2BITS {
        unsigned AC4IE   :1; /* Analog Comparator 4          */
        unsigned         :4;
        unsigned ADCP0IE :1; /* ADC Pair 0			 */
        unsigned ADCP1IE :1; /* ADC Pair 1			 */
        unsigned ADCP2IE :1; /* ADC Pair 2			 */
        unsigned ADCP3IE :1; /* ADC Pair 3			 */
        unsigned ADCP4IE :1; /* ADC Pair 4			 */
        unsigned ADCP5IE :1; /* ADC Pair 5			 */
        unsigned	       :5; 
} IEC2BITS;
extern volatile IEC2BITS IEC2bits __attribute__((__near__));

/* IPC0: Interrupt Priority Control Register 0 */
extern volatile unsigned int IPC0 __attribute__((__near__));
typedef struct tagIPC0BITS {
        unsigned INT0IP :3; /* External Interrupt 0             */
        unsigned        :1;
        unsigned IC1IP  :3; /* Input Compare 1                  */
        unsigned        :1;
        unsigned OC1IP  :3; /* Output Compare 1                 */
        unsigned        :1;
        unsigned T1IP   :3; /* Timer 1                          */
        unsigned        :1;
} IPC0BITS;
extern volatile IPC0BITS IPC0bits __attribute__((__near__));

/* IPC1: Interrupt Priority Control Register 1 */
extern volatile unsigned int IPC1 __attribute__((__near__));
typedef struct tagIPC1BITS {
        unsigned        :3;
        unsigned        :1;
        unsigned OC2IP  :3; /* Output Compare 2                 */
        unsigned        :1;
        unsigned T2IP   :3; /* Timer 2                          */
        unsigned        :1;
        unsigned T3IP   :3; /* Timer 3                          */
        unsigned        :1;
} IPC1BITS;
extern volatile IPC1BITS IPC1bits __attribute__((__near__));

/* IPC2: Interrupt Priority Control Register 2 */
extern volatile unsigned int IPC2 __attribute__((__near__));
typedef struct tagIPC2BITS {
        unsigned SPI1IP :3; /* SPI 1                            */
        unsigned        :1;
        unsigned U1RXIP :3; /* UART 1 Reciever                  */
        unsigned        :1;
        unsigned U1TXIP :3; /* UART 1 Transmitter               */
        unsigned        :1;
        unsigned ADIP   :3; /* ADC Conversion Complete          */
        unsigned        :1;
} IPC2BITS;
extern volatile IPC2BITS IPC2bits __attribute__((__near__));

/* IPC3: Interrupt Priority Control Register 3 */
extern volatile unsigned int IPC3 __attribute__((__near__));
typedef struct tagIPC3BITS {
        unsigned NVMIP  :3; /* NVM Write Complete               */
        unsigned        :1;
        unsigned SI2CIP :3; /* I2C Transfer Complete            */
        unsigned        :1;
        unsigned MI2CIP :3; /* I2C Bus Collision                */
        unsigned        :1;
        unsigned        :3;
        unsigned        :1;
} IPC3BITS;
extern volatile IPC3BITS IPC3bits __attribute__((__near__));

/* IPC4: Interrupt Priority Control Register 4 */
extern volatile unsigned int IPC4 __attribute__((__near__));
typedef struct tagIPC4BITS {
        unsigned INT1IP  :3; /* External Interrupt 1           */
        unsigned         :1;
        unsigned INT2IP  :3; /* External Interrupt 2           */
        unsigned         :1;
        unsigned PSEMIP :3; /* PWM-Special Event Match        */
        unsigned         :1;
        unsigned PWM1IP  :3; /* PWM Generator #1               */
        unsigned         :1;
} IPC4BITS;
extern volatile IPC4BITS IPC4bits __attribute__((__near__));

/* IPC5: Interrupt Priority Control Register 5 */
extern volatile unsigned int IPC5 __attribute__((__near__));
typedef struct tagIPC5BITS {
        unsigned PWM2IP :3; /* PWM Generator #2               */
        unsigned        :1;
        unsigned PWM3IP :3; /* PWM Generator #3               */
        unsigned        :1;
        unsigned PWM4IP :3; /* PWM Generator #4               */
        unsigned        :1;
        unsigned        :3;
        unsigned        :1;

} IPC5BITS;
extern volatile IPC5BITS IPC5bits __attribute__((__near__));

/* IPC6: Interrupt Priority Control Register 6 */
extern volatile unsigned int IPC6 __attribute__((__near__));
typedef struct tagIPC6BITS {
        unsigned        :12;
		unsigned CNIP   :3; /* Change Notification            */
        unsigned        :1;
} IPC6BITS;
extern volatile IPC6BITS IPC6bits __attribute__((__near__));

/* IPC7: Interrupt Priority Control Register 7 */
extern volatile unsigned int IPC7 __attribute__((__near__));
typedef struct tagIPC7BITS {
        unsigned        :3;
        unsigned        :1;
        unsigned AC1IP  :3; /* Analog Comparator 1              */
        unsigned        :1;
        unsigned AC2IP  :3; /* Analog Comparator 2              */
        unsigned        :1;
        unsigned AC3IP  :3; /* Analog Comparator 3              */
        unsigned        :1;
} IPC7BITS;
extern volatile IPC7BITS IPC7bits __attribute__((__near__));

/* IPC8: Interrupt Priority Control Register 8 */
extern volatile unsigned int IPC8 __attribute__((__near__));
typedef struct tagIPC8BITS {
        unsigned AC4IP  :3; /* Analog Comparator 4              */
        unsigned        :13;
} IPC8BITS;
extern volatile IPC8BITS IPC8bits __attribute__((__near__));

/* IPC9: Interrupt Priority Control Register 9 */
extern volatile unsigned int IPC9 __attribute__((__near__));
typedef struct tagIPC9BITS {
        unsigned        :4;
		unsigned ADCP0IP:3; /* ADC Pair 0 			*/
		unsigned 		:1;
		unsigned ADCP1IP:3; /* ADC Pair 1 			*/
		unsigned 		:1;
		unsigned ADCP2IP:3; /* ADC Pair 2 			*/
		unsigned 		:1;
} IPC9BITS;
extern volatile IPC9BITS IPC9bits __attribute__((__near__));

/* IPC10: Interrupt Priority Control Register 10 */
extern volatile unsigned int IPC10 __attribute__((__near__));
typedef struct tagIPC10BITS {
	unsigned ADCP3IP:3; /* ADC Pair 3 			*/
		unsigned 		:1;
		unsigned ADCP4IP:3; /* ADC Pair 4			*/
		unsigned		:1;
		unsigned ADCP5IP:3; /* ADC Pair 5			*/
		unsigned 		:5;
} IPC10BITS;
extern volatile IPC10BITS IPC10bits __attribute__((__near__));

/* INTTREG: Interrupt Control and Status Register */
extern volatile unsigned int INTTREG __attribute__((__near__));
typedef struct tagINTTREGBITS {
		unsigned VECNUM:7; /*Vector # of Pending Interrupt bits */
		unsigned       :1;
		unsigned ILR   :4; /* New Interrupt priority level bits */
		unsigned       :4;
} INTTREGBITS;
extern volatile INTTREGBITS INTTREGbits __attribute__((__near__));



/* --------------------------- */
/* Timer1 register definitions */
/* --------------------------- */

/* Generic structure for Timer 1 Control Register */

/* TMR1: Timer 1 Count Register */
extern volatile unsigned int TMR1 __attribute__((__near__));

/* PR1: Timer 1 Period Register */
extern volatile unsigned int PR1 __attribute__((__near__));

/* T1CON: Timer 1 Control Register */
extern volatile unsigned int T1CON __attribute__((__near__));

typedef struct tagTCON_16BIT {
        unsigned        :1;
        unsigned TCS    :1;
        unsigned TSYNC  :1;
        unsigned        :1;
        unsigned TCKPS  :2;
        unsigned TGATE  :1;
        unsigned        :6;
        unsigned TSIDL  :1;
        unsigned        :1;
        unsigned TON    :1;
} TCON_16BIT;

extern volatile TCON_16BIT T1CONbits __attribute__((__near__));

/* TMR2: Timer 2 Count Register */
extern volatile unsigned int TMR2 __attribute__((__near__));

/* TMR3HLD: Timer 3 Holding Register */
extern volatile unsigned int TMR3HLD __attribute__((__near__));

/* TMR3: Timer 3 Count Register */
extern volatile unsigned int TMR3 __attribute__((__near__));

/* PR2: Timer 2 Period Register */
extern volatile unsigned int PR2 __attribute__((__near__));

/* PR3: Timer 3 Period Register */
extern volatile unsigned int PR3 __attribute__((__near__));

/* ----------------------------- */
/* Timer2/3 register definitions */
/* ----------------------------- */

/* T2CON: Timer 2 Control Register */
extern volatile unsigned int T2CON __attribute__((__near__));
/* Generic structure for Timer 2 and Timer 4 Control Registers */
typedef struct tagTCON_EVEN {
        unsigned        :1;
        unsigned TCS    :1;
        unsigned        :1;
        unsigned T32    :1;
        unsigned TCKPS  :2;
        unsigned TGATE  :1;
        unsigned        :6;
        unsigned TSIDL  :1;
        unsigned        :1;
        unsigned TON    :1;
} TCON_EVEN;

extern volatile TCON_EVEN T2CONbits __attribute__((__near__));


/* T3CON: Timer 3 Control Register */
extern volatile unsigned int T3CON __attribute__((__near__));
/* Generic structure for Timer 3 and Timer 5 Control Registers */
typedef struct tagTCON_ODD {
        unsigned        :1;
        unsigned TCS    :1;
        unsigned        :1;
        unsigned        :1;
        unsigned TCKPS  :2;
        unsigned TGATE  :1;
        unsigned        :6;
        unsigned TSIDL  :1;
        unsigned        :1;
        unsigned TON    :1;
} TCON_ODD;

extern volatile TCON_ODD T3CONbits __attribute__((__near__));


/* ---------------------------------- */
/* Input Capture register definitions */
/* ---------------------------------- */

/* IC1BUF: Input Capture 1 Buffer */
extern volatile unsigned int IC1BUF __attribute__((__near__));

/* Generic structure of entire SFR area for each Input Capture module */
typedef struct tagIC {
        unsigned int icxbuf;
        unsigned int icxcon;
} IC, *PIC;

/* SFR blocks for each Input Capture module */
extern volatile IC IC1 __attribute__((__near__));

/* IC1CON: Input Capture 1 Control Register */
extern volatile unsigned int IC1CON __attribute__((__near__));

/* Generic structure for Input Capture Control Registers */
typedef struct tagICxCONBITS {
        unsigned ICM    :3;
        unsigned ICBNE  :1;
        unsigned ICOV   :1;
        unsigned ICI    :2;
        unsigned ICTMR  :1;
        unsigned        :5;
        unsigned ICSIDL :1;
        unsigned        :1;
        unsigned        :1;
} ICxCONBITS;

extern volatile ICxCONBITS IC1CONbits __attribute__((__near__));


/* --------------------------------------- */
/* Output Compare/PWM register definitions */
/* --------------------------------------- */

/* Generic structure of entire SFR area for each Output Compare module */
typedef struct tagOC {
        unsigned int ocxrs;
        unsigned int ocxr;
        unsigned int ocxcon;
} OC, *POC;

/* SFR blocks for each Output Compare module */
extern volatile OC OC1 __attribute__((__near__));
extern volatile OC OC2 __attribute__((__near__));

/* OC1RS: Output Compare 1 Secondary Register */
extern volatile unsigned int OC1RS __attribute__((__near__));

/* OC1R: Output Compare 1 Main Register */
extern volatile unsigned int OC1R __attribute__((__near__));

/* Generic structure for Output Compare Control Registers */
typedef struct tagOCxCONBITS {
        unsigned OCM    :3;
        unsigned OCTSEL :1;
        unsigned OCFLT  :1;
        unsigned        :8;
        unsigned OCSIDL :1;
        unsigned        :1;
        unsigned        :1;
} OCxCONBITS;

/* OC1CON: Output Compare 1 Control Register */
extern volatile unsigned int OC1CON __attribute__((__near__));
extern volatile OCxCONBITS OC1CONbits __attribute__((__near__));

/* OC2RS: Output Compare 2 Secondary Register */
extern volatile unsigned int OC2RS __attribute__((__near__));

/* OC2R: Output Compare 2 Main Register */
extern volatile unsigned int OC2R __attribute__((__near__));

/* OC2CON: Output Compare 2 Control Register */
extern volatile unsigned int OC2CON __attribute__((__near__));
extern volatile OCxCONBITS OC2CONbits __attribute__((__near__));


/* ------------------------ */
/* I2C register definitions */
/* ------------------------ */

/* I2CRCV: I2C Receive Register */
extern volatile unsigned char I2CRCV __attribute__((__near__));
typedef struct tagI2CRCVBITS {
        unsigned I2CRCV :8;
        unsigned        :8;
} I2CRCVBITS;
extern volatile I2CRCVBITS I2CRCVbits __attribute__((__near__));


/* I2CTRN: I2C Transmit Register */
extern volatile unsigned char I2CTRN __attribute__((__near__));
typedef struct tagI2CTRNBITS {
        unsigned I2CTRN :8;
        unsigned        :8;
} I2CTRNBITS;
extern volatile I2CTRNBITS I2CTRNbits __attribute__((__near__));

/* I2CBRG: I2C Baud Rate Generator Register */
extern volatile unsigned int I2CBRG __attribute__((__near__));
typedef struct tagI2CBRGBITS {
        unsigned I2CBRG :9;
        unsigned        :7;
} I2CBRGBITS;
extern volatile I2CBRGBITS I2CBRGbits __attribute__((__near__));

/* I2CCON: I2C Control Register */
extern volatile unsigned int I2CCON __attribute__((__near__));
typedef struct tagI2CCONBITS {
        unsigned SEN    :1;
        unsigned RSEN   :1;
        unsigned PEN    :1;
        unsigned RCEN   :1;
        unsigned ACKEN  :1;
        unsigned ACKDT  :1;
        unsigned STREN  :1;
        unsigned GCEN   :1;
        unsigned SMEN   :1;
        unsigned DISSLW :1;
        unsigned A10M   :1;
        unsigned IPMIEN :1;
        unsigned SCLREL :1;
        unsigned I2CSIDL:1;
        unsigned        :1;
        unsigned I2CEN  :1;
} I2CCONBITS;
extern volatile I2CCONBITS I2CCONbits __attribute__((__near__));

/* I2CSTAT: I2C Status Register */
extern volatile unsigned int I2CSTAT __attribute__((__near__));
typedef struct tagI2CSTATBITS {
        unsigned TBF    :1;
        unsigned RBF    :1;
        unsigned R_W    :1;
        unsigned S      :1;
        unsigned P      :1;
        unsigned D_A    :1;
        unsigned I2COV  :1;
        unsigned IWCOL  :1;
        unsigned ADD10  :1;
        unsigned GCSTAT :1;
        unsigned BCL    :1;
        unsigned        :3;
        unsigned TRSTAT :1;
        unsigned ACKSTAT:1;
} I2CSTATBITS;
extern volatile I2CSTATBITS I2CSTATbits __attribute__((__near__));

/* I2CADD: I2C Address Register */
extern volatile unsigned int I2CADD __attribute__((__near__));
typedef struct tagI2CADDBITS {
        unsigned I2CADD :10;
        unsigned        :6;
} I2CADDBITS;
extern volatile I2CADDBITS I2CADDbits __attribute__((__near__));

/* I2CAMSK: I2C Slave Address Mask Register */
extern volatile unsigned int I2CAMSK __attribute__((__near__));
typedef struct tagI2CAMSKBITS {
        unsigned I2CAMSK:10;
        unsigned        :6;
} I2CAMSKBITS;
extern volatile I2CAMSKBITS I2CAMSKbits __attribute__((__near__));


/* -------------------------- */
/* UART1 register definitions */
/* -------------------------- */

/* Generic structure of entire SFR area for each UART module */
typedef struct tagUART {
        unsigned int uxmode;
        unsigned int uxsta;
        unsigned int uxtxreg;
        unsigned int uxrxreg;
        unsigned int uxbrg;
} UART, *PUART;

/* SFR blocks for each UART module */
extern volatile UART UART1 __attribute__((__near__));

/* Generic structure for UART Mode Registers */
typedef struct tagUxMODEBITS {
        unsigned STSEL  :1;
        unsigned PDSEL  :2;
        unsigned BRGH   :1;
	unsigned RXINV  :1;
        unsigned ABAUD  :1;
        unsigned LPBACK :1;
        unsigned WAKE   :1;
        unsigned        :2;
        unsigned ALTIO  :1;
        unsigned 	:1;
        unsigned IREN   :1;
        unsigned USIDL  :1;
        unsigned        :1;
        unsigned UARTEN :1;
} UxMODEBITS;

/* Generic structure for UART Status and Control Registers */
typedef struct tagUxSTABITS {
        unsigned URXDA          :1;
        unsigned OERR           :1;
        unsigned FERR           :1;
        unsigned PERR           :1;
        unsigned RIDLE          :1;
        unsigned ADDEN          :1;
        unsigned URXISEL        :2;
        unsigned TRMT           :1;
        unsigned UTXBF          :1;
        unsigned UTXEN          :1;
        unsigned UTXBRK         :1;
        unsigned                :1;
	unsigned UTXISEL0	:1;
        unsigned UTXINV         :1;
        unsigned UTXISEL1       :1;
} UxSTABITS;

/* Generic structure for UART Transmit Registers */
typedef struct tagUxTXREGBITS {
        unsigned UTXREG0:1;
        unsigned UTXREG1:1;
        unsigned UTXREG2:1;
        unsigned UTXREG3:1;
        unsigned UTXREG4:1;
        unsigned UTXREG5:1;
        unsigned UTXREG6:1;
        unsigned UTXREG7:1;
        unsigned UTX8   :1;
        unsigned        :7;
} UxTXREGBITS;

/* Generic structure for UART Receive Registers */
typedef struct tagUxRXREGBITS {
        unsigned URXREG0:1;
        unsigned URXREG1:1;
        unsigned URXREG2:1;
        unsigned URXREG3:1;
        unsigned URXREG4:1;
        unsigned URXREG5:1;
        unsigned URXREG6:1;
        unsigned URXREG7:1;
        unsigned URX8   :1;
        unsigned        :7;
} UxRXREGBITS;

/* U1MODE: UART1 Mode Regsiter */
extern volatile unsigned int U1MODE __attribute__((__near__));
extern volatile UxMODEBITS U1MODEbits __attribute__((__near__));

/* U1STA: UART1 Status and Control Register */
extern volatile unsigned int U1STA __attribute__((__near__));
extern volatile UxSTABITS U1STAbits __attribute__((__near__));

/* U1TXREG: UART1 Transmit Register */
extern volatile unsigned int U1TXREG __attribute__((__near__));
extern volatile UxTXREGBITS U1TXREGbits __attribute__((__near__));

/* U1RXREG: UART1 Receive Register */
extern volatile unsigned int U1RXREG __attribute__((__near__));
extern volatile UxRXREGBITS U1RXREGbits __attribute__((__near__));

/* U1BRG: UART1 Baud Rate Generator Register */
extern volatile unsigned int U1BRG __attribute__((__near__));


/* ------------------------- */
/* SPI1 register definitions */
/* ------------------------- */

/* Generic structure of entire SFR area for each SPI module */
typedef struct tagSPI {
        unsigned int spixstat;
        unsigned int spixcon1;
        unsigned int spixcon2;
        unsigned int spixbuf;
} SPI, *PSPI;

/* SFR blocks for each SPI module */
extern volatile SPI SPI1 __attribute__((__near__));

/* Generic structure for SPI Status Registers */
typedef struct tagSPIxSTATBITS {
        unsigned SPIRBF :1;
        unsigned SPITBF	:1;
	unsigned        :4;
        unsigned SPIROV :1;
        unsigned        :6;
        unsigned SPISIDL:1;
        unsigned        :1;
        unsigned SPIEN  :1;
} SPIxSTATBITS;

/* Generic structure for SPI Control Register 1 */
typedef struct tagSPIxCON1BITS {
    unsigned PPRE    :2;
    unsigned SPRE    :3;
    unsigned MSTEN   :1;
    unsigned CKP     :1;
    unsigned SSEN    :1;
    unsigned CKE     :1;
    unsigned SMP     :1;
    unsigned MODE16  :1;
    unsigned DISSDO  :1;
    unsigned DISSCK  :1;
} SPIxCON1BITS;

/* Generic structure for SPI Control Register 2 */
typedef struct tagSPIxCON2BITS {
  unsigned ENHBUF    :1;
  unsigned FRMDLY    :1;
  unsigned           :11;
  unsigned FRMPOL    :1;
  unsigned SPIFSD    :1;
  unsigned FRMEN     :1;
}  SPIxCON2BITS;

/* SPI1STAT: SPI1 Status Register */
extern volatile unsigned int SPI1STAT __attribute__((__near__));
extern volatile SPIxSTATBITS SPI1STATbits __attribute__((__near__));

/* SPI1CON1: SPI1 Control Register 1 */
extern volatile unsigned int SPI1CON1 __attribute__((__near__));
extern volatile SPIxCON1BITS SPI1CON1bits __attribute__((__near__));

/* SPI1CON2: SPI1 Control Register 2 */
extern volatile unsigned int SPI1CON2 __attribute__((__near__));
extern volatile SPIxCON2BITS SPI1CON2bits __attribute__((__near__));

/* SPI1BUF: SPI1 Buffer */
extern volatile unsigned int SPI1BUF __attribute__((__near__));


/* ------------------------------- */
/* I/O Ports register definitions  */
/* ------------------------------- */

/* TRISA: Port A Direction Control Register */
extern volatile unsigned int TRISA __attribute__((__near__));
typedef struct tagTRISABITS {
        unsigned                :8;
        unsigned TRISA8         :1;
        unsigned TRISA9         :1;
        unsigned TRISA10        :1;
        unsigned TRISA11        :1;
        unsigned                :4;
} TRISABITS;
extern volatile TRISABITS TRISAbits __attribute__((__near__));

/* PORTA: Port A Pin Register */
extern volatile unsigned int PORTA __attribute__((__near__));
typedef struct tagPORTABITS {
        unsigned                :8;
        unsigned RA8            :1;
        unsigned RA9            :1;
        unsigned RA10           :1;
        unsigned RA11           :1;
        unsigned                :4;
} PORTABITS;
extern volatile PORTABITS PORTAbits __attribute__((__near__));

/* LATA: Port A Latch Register */
extern volatile unsigned int LATA __attribute__((__near__));
typedef struct tagLATAABITS {
        unsigned                :8;
        unsigned LATA8         :1;
        unsigned LATA9          :1;
        unsigned LATA10        :1;
        unsigned LATA11        :1;
        unsigned                :4;
} LATAABITS;
extern volatile LATAABITS LATAbits __attribute__((__near__));

/* TRISB: Port B Direction Control Register */
extern volatile unsigned int TRISB __attribute__((__near__));
typedef struct tagTRISBBITS {
        unsigned TRISB0         :1;
        unsigned TRISB1         :1;
        unsigned TRISB2         :1;
        unsigned TRISB3         :1;
        unsigned TRISB4         :1;
        unsigned TRISB5         :1;
        unsigned TRISB6         :1;
        unsigned TRISB7         :1;
        unsigned TRISB8         :1;
        unsigned TRISB9         :1;
        unsigned TRISB10        :1;
        unsigned TRISB11        :1;
        unsigned                :4;
} TRISBBITS;
extern volatile TRISBBITS TRISBbits __attribute__((__near__));

/* PORTB: Port B Pin Register */
extern volatile unsigned int PORTB __attribute__((__near__));
typedef struct tagPORTBBITS {
        unsigned RB0    :1;
        unsigned RB1    :1;
        unsigned RB2    :1;
        unsigned RB3    :1;
        unsigned RB4    :1;
        unsigned RB5    :1;
        unsigned RB6    :1;
        unsigned RB7    :1;
        unsigned RB8    :1;
        unsigned RB9    :1;
        unsigned RB10   :1;
        unsigned RB11   :1;
        unsigned        :4;
} PORTBBITS;
extern volatile PORTBBITS PORTBbits __attribute__((__near__));

/* LATB: Port B Latch Register */
extern volatile unsigned int LATB __attribute__((__near__));
typedef struct tagLATBBITS {
        unsigned LATB0  :1;
        unsigned LATB1  :1;
        unsigned LATB2  :1;
        unsigned LATB3  :1;
        unsigned LATB4  :1;
        unsigned LATB5  :1;
        unsigned LATB6  :1;
        unsigned LATB7  :1;
        unsigned LATB8  :1;
        unsigned LATB9  :1;
        unsigned LATB10 :1;
        unsigned LATB11 :1;
        unsigned        :4;
} LATBBITS;
extern volatile LATBBITS LATBbits __attribute__((__near__));

/* TRISD: Port D Direction Control Register */
extern volatile unsigned int TRISD __attribute__((__near__));
typedef struct tagTRISDBITS {
        unsigned TRISD0 :1;
        unsigned TRISD1 :1;
        unsigned        :14;
} TRISDBITS;
extern volatile TRISDBITS TRISDbits __attribute__((__near__));

/* PORTD: Port D Pin Register */
extern volatile unsigned int PORTD __attribute__((__near__));
typedef struct tagPORTDBITS {
        unsigned RD0    :1;
        unsigned RD1    :1;
        unsigned        :14;
} PORTDBITS;
extern volatile PORTDBITS PORTDbits __attribute__((__near__));

/* LATD: Port D Latch Register */
extern volatile unsigned int LATD __attribute__((__near__));
typedef struct tagLATDBITS {
        unsigned LATD0  :1;
        unsigned LATD1  :1;
        unsigned        :15;
} LATDBITS;
extern volatile LATDBITS LATDbits __attribute__((__near__));

/* TRISE: Port E Direction Control Register */
extern volatile unsigned int TRISE __attribute__((__near__));
typedef struct tagTRISEBITS {
        unsigned TRISE0 :1;
        unsigned TRISE1 :1;
        unsigned TRISE2 :1;
        unsigned TRISE3 :1;
        unsigned TRISE4 :1;
        unsigned TRISE5 :1;
        unsigned TRISE6 :1;
        unsigned TRISE7 :1;
        unsigned        :8;
} TRISEBITS;
extern volatile TRISEBITS TRISEbits __attribute__((__near__));

/* PORTE: Port E Pin Register */
extern volatile unsigned int PORTE __attribute__((__near__));
typedef struct tagPORTEBITS {
        unsigned RE0    :1;
        unsigned RE1    :1;
        unsigned RE2    :1;
        unsigned RE3    :1;
        unsigned RE4    :1;
        unsigned RE5    :1;
        unsigned RE6    :1;
        unsigned RE7    :1;
        unsigned        :8;
} PORTEBITS;
extern volatile PORTEBITS PORTEbits __attribute__((__near__));

/* LATE: Port E Latch Register */
extern volatile unsigned int LATE __attribute__((__near__));
typedef struct tagLATEBITS {
        unsigned LATE0  :1;
        unsigned LATE1  :1;
        unsigned LATE2  :1;
        unsigned LATE3  :1;
        unsigned LATE4  :1;
        unsigned LATE5  :1;
        unsigned LATE6  :1;
        unsigned LATE7  :1;
        unsigned        :8;
} LATEBITS;
extern volatile LATEBITS LATEbits __attribute__((__near__));

/* TRISF: Port F Direction Control Register */
extern volatile unsigned int TRISF __attribute__((__near__));
typedef struct tagTRISFBITS {
        unsigned                :2;
        unsigned TRISF2         :1;
        unsigned TRISF3         :1;
        unsigned                :2;
        unsigned TRISF6         :1;
        unsigned TRISF7         :1;
        unsigned TRISF8         :1;
        unsigned                :5;
        unsigned TRISF14        :1;
        unsigned TRISF15        :1;
} TRISFBITS;
extern volatile TRISFBITS TRISFbits __attribute__((__near__));

/* PORTF: Port F Pin Register */
extern volatile unsigned int PORTF __attribute__((__near__));
typedef struct tagPORTFBITS {
        unsigned                :2;
        unsigned RF2            :1;
        unsigned RF3            :1;
        unsigned                :2;
        unsigned RF6            :1;
        unsigned RF7            :1;
        unsigned RF8            :1;
        unsigned                :5;
        unsigned RF14           :1;
        unsigned RF15           :1;

} PORTFBITS;
extern volatile PORTFBITS PORTFbits __attribute__((__near__));

/* LATF: Port F Latch Register */
extern volatile unsigned int LATF __attribute__((__near__));
typedef struct tagLATFBITS {
        unsigned                :2;
        unsigned LATF2          :1;
        unsigned LATF3          :1;
        unsigned                :2;
        unsigned LATF6          :1;
        unsigned LATF7          :1;
        unsigned LATF8          :1;
        unsigned                :5;
        unsigned LATF14         :1;
        unsigned LATF15         :1;
} LATFBITS;
extern volatile LATFBITS LATFbits __attribute__((__near__));

/* TRISG: Port G Direction Control Register */
extern volatile unsigned int TRISG __attribute__((__near__));
typedef struct tagTRISGBITS {
        unsigned                :2;
        unsigned TRISG2         :1;
        unsigned TRISG3         :1;
        unsigned                :12;
} TRISGBITS;
extern volatile TRISGBITS TRISGbits __attribute__((__near__));

/* PORTG: Port G Pin Register */
extern volatile unsigned int PORTG __attribute__((__near__));
typedef struct tagPORTGBITS {
        unsigned                :2;
        unsigned RG2            :1;
        unsigned RG3            :1;
        unsigned                :12;
} PORTGBITS;
extern volatile PORTGBITS PORTGbits __attribute__((__near__));

/* LATG: Port G Latch Register */
extern volatile unsigned int LATG __attribute__((__near__));
typedef struct tagLATGBITS {
        unsigned                :2;
        unsigned LATG2          :1;
        unsigned LATG3          :1;
        unsigned                :12;
} LATGBITS;
extern volatile LATGBITS LATGbits __attribute__((__near__));

/* ------------------------------------------------------ */
/* Analog-to-Digital (A/D) Converter register definitions */
/* ------------------------------------------------------ */
/* ADC Buffers 0-F */
extern volatile unsigned int ADCBUF0 __attribute__((__near__));
extern volatile unsigned int ADCBUF1 __attribute__((__near__));
extern volatile unsigned int ADCBUF2 __attribute__((__near__));
extern volatile unsigned int ADCBUF3 __attribute__((__near__));
extern volatile unsigned int ADCBUF4 __attribute__((__near__));
extern volatile unsigned int ADCBUF5 __attribute__((__near__));
extern volatile unsigned int ADCBUF6 __attribute__((__near__));
extern volatile unsigned int ADCBUF7 __attribute__((__near__));
extern volatile unsigned int ADCBUF8 __attribute__((__near__));
extern volatile unsigned int ADCBUF9 __attribute__((__near__));
extern volatile unsigned int ADCBUFA __attribute__((__near__));
extern volatile unsigned int ADCBUFB __attribute__((__near__));
extern volatile unsigned int ADCBUF10 __attribute__((__near__));
extern volatile unsigned int ADCBUF11 __attribute__((__near__));

/* ADCON: ADC Control Register 1 */
extern volatile unsigned int ADCON __attribute__((__near__));
typedef struct tagADCONBITS {
        unsigned ADCS   :3;
        unsigned        :2;
        unsigned SEQSAMP:1;
        unsigned ORDER  :1;
        unsigned EIE    :1;
        unsigned FORM   :1;
        unsigned        :1;
        unsigned GSWTRG :1;
        unsigned        :2;
        unsigned ADSIDL :1;
        unsigned        :1;
        unsigned ADON   :1;
} ADCONBITS;
extern volatile ADCONBITS ADCONbits __attribute__((__near__));

/* ADPCFG: ADC Port Configuration Register */
extern volatile unsigned int ADPCFG __attribute__((__near__));
typedef struct tagADPCFGBITS {
        unsigned PCFG0  :1;
        unsigned PCFG1  :1;
        unsigned PCFG2  :1;
        unsigned PCFG3  :1;
        unsigned PCFG4  :1;
        unsigned PCFG5  :1;
        unsigned PCFG6  :1;
        unsigned PCFG7  :1;
        unsigned PCFG8  :1;
        unsigned PCFG9  :1;
        unsigned PCFG10 :1;
        unsigned PCFG11 :1;
        unsigned        :8;
} ADPCFGBITS;
extern volatile ADPCFGBITS ADPCFGbits __attribute__((__near__));

/* ADSTAT: ADSTAT  Register */
extern volatile unsigned int ADSTAT __attribute__((__near__));
typedef struct tagADSTATBITS {
        unsigned P0RDY   :1;
        unsigned P1RDY   :1;
        unsigned P2RDY   :1;
        unsigned P3RDY   :1;
        unsigned P4RDY	 :1;
        unsigned P5RDY	 :1;
        unsigned    	 :10;
} ADSTATBITS;
extern volatile ADSTATBITS ADSTATbits __attribute__((__near__));

extern volatile unsigned int ADBASE __attribute__((__near__));
typedef struct tagADBASEBITS {
        unsigned                :1;
    unsigned ADBASE :15;
} ADBASEBITS;
extern volatile ADBASEBITS ADBASEbits __attribute__((__near__));

typedef struct tagADCPC0BITS {
        unsigned TRGSRC0        :5;
        unsigned SWTRG0         :1;
        unsigned PEND0          :1;
        unsigned IRQEN0         :1;
        unsigned TRGSRC1        :5;
        unsigned SWTRG1         :1;
        unsigned PEND1          :1;
        unsigned IRQEN1         :1;
} ADCPC0BITS;
extern volatile unsigned int ADCPC0 __attribute__((__near__));
extern volatile ADCPC0BITS ADCPC0bits __attribute__((__near__));

typedef struct tagADCPC1BITS {
        unsigned TRGSRC2        :5;
        unsigned SWTRG2         :1;
        unsigned PEND2          :1;
        unsigned IRQEN2         :1;
        unsigned TRGSRC3        :5;
        unsigned SWTRG3         :1;
        unsigned PEND3          :1;
        unsigned IRQEN3         :1;
} ADCPC1BITS;
extern volatile unsigned int ADCPC1 __attribute__((__near__));
extern volatile ADCPC1BITS ADCPC1bits __attribute__((__near__));

typedef struct tagADCPC2BITS {
        unsigned TRGSRC4        :5;
        unsigned SWTRG4         :1;
        unsigned PEND4          :1;
        unsigned IRQEN4         :1;
        unsigned TRGSRC5        :5;
        unsigned SWTRG5         :1;
        unsigned PEND5          :1;
        unsigned IRQEN5         :1;
} ADCPC2BITS;
extern volatile unsigned int ADCPC2 __attribute__((__near__));
extern volatile ADCPC2BITS ADCPC2bits __attribute__((__near__));


/* ------------------------------------------------------------------ */
/* ---------END OF A/D CONVERTER (A/D) REGISTER MAP------------------ */

/* ------------------------------------------------------------------ */
/*      SMPS Register definitions 				      */
/* ------------------------------------------------------------------ */

/* PTCON Register */
extern volatile unsigned int PTCON __attribute__((__near__));
typedef struct tagPTCONBITS {
        unsigned SEVTPS         :4;
        unsigned SYNCSRC        :3;
        unsigned SYNCEN         :1;
        unsigned SYNCOEN        :1;
        unsigned SYNCPOL        :1;
        unsigned EIPU           :1;
        unsigned SEIEN          :1;
        unsigned SESTAT         :1;
        unsigned PTSIDL         :1;
        unsigned                :1;
        unsigned PTEN           :1;
} PTCONBITS;
extern volatile PTCONBITS PTCONbits __attribute__((__near__));

/* PWM Timebase Period register */
extern volatile unsigned int PTPER __attribute__((__near__));

/* Master Duty Cycle (MDC) Register */
extern volatile unsigned int MDC __attribute__((__near__));

/* Special Event Compare Register SEVTCMP */
extern volatile unsigned int SEVTCMP __attribute__((__near__));

extern volatile unsigned int PWMCON1 __attribute__((__near__));
extern volatile unsigned int PWMCON2 __attribute__((__near__));
extern volatile unsigned int PWMCON3 __attribute__((__near__));
extern volatile unsigned int PWMCON4 __attribute__((__near__));
typedef struct tagPWMCONBITS {
        unsigned IUE            :1;
        unsigned XPRES          :1;
        unsigned 	        :4;
        unsigned DTC            :2;
        unsigned MDCS           :1;
        unsigned ITB            :1;
        unsigned TRGIEN         :1;
        unsigned CLIEN          :1;
        unsigned FLTIEN         :1;
        unsigned TRGSTAT        :1;
        unsigned CLSTAT         :1;
        unsigned FLTSTAT        :1;
} PWMCONBITS;
extern volatile PWMCONBITS PWMCON1bits __attribute__((__near__));
extern volatile PWMCONBITS PWMCON2bits __attribute__((__near__));
extern volatile PWMCONBITS PWMCON3bits __attribute__((__near__));
extern volatile PWMCONBITS PWMCON4bits __attribute__((__near__));

extern volatile unsigned int IOCON1 __attribute__((__near__));
extern volatile unsigned int IOCON2 __attribute__((__near__));
extern volatile unsigned int IOCON3 __attribute__((__near__));
extern volatile unsigned int IOCON4 __attribute__((__near__));
typedef struct tagIOCONBITS {
        unsigned OSYNC          :1;
        unsigned                :1;
        unsigned CLDAT          :2;
        unsigned FLTDAT         :2;
        unsigned OVRDAT         :2;
        unsigned OVRENL         :1;
        unsigned OVRENH         :1;
        unsigned PMOD           :2;
        unsigned POLL           :1;
        unsigned POLH           :1;
        unsigned PENL           :1;
        unsigned PENH           :1;
} IOCONBITS;
extern volatile IOCONBITS IOCON1bits __attribute__((__near__));
extern volatile IOCONBITS IOCON2bits __attribute__((__near__));
extern volatile IOCONBITS IOCON3bits __attribute__((__near__));
extern volatile IOCONBITS IOCON4bits __attribute__((__near__));

extern volatile unsigned int FCLCON1 __attribute__((__near__));
extern volatile unsigned int FCLCON2 __attribute__((__near__));
extern volatile unsigned int FCLCON3 __attribute__((__near__));
extern volatile unsigned int FCLCON4 __attribute__((__near__));
typedef struct tagFCLCONBITS {
        unsigned FLTMOD         :2;
        unsigned FLTPOL         :1;
        unsigned FLTSRC         :4;
        unsigned CLMODE         :1;
        unsigned CLPOL          :1;
        unsigned CLSRC          :4;
	unsigned 		:3;
} FCLCONBITS;
extern volatile FCLCONBITS FCLCON1bits __attribute__((__near__));
extern volatile FCLCONBITS FCLCON2bits __attribute__((__near__));
extern volatile FCLCONBITS FCLCON3bits __attribute__((__near__));
extern volatile FCLCONBITS FCLCON4bits __attribute__((__near__));

extern volatile unsigned int PDC1 __attribute__((__near__));
extern volatile unsigned int PDC2 __attribute__((__near__));
extern volatile unsigned int PDC3 __attribute__((__near__));
extern volatile unsigned int PDC4 __attribute__((__near__));

extern volatile unsigned int PHASE1 __attribute__((__near__));
extern volatile unsigned int PHASE2 __attribute__((__near__));
extern volatile unsigned int PHASE3 __attribute__((__near__));
extern volatile unsigned int PHASE4 __attribute__((__near__));

extern volatile unsigned int DTR1 __attribute__((__near__));
extern volatile unsigned int DTR2 __attribute__((__near__));
extern volatile unsigned int DTR3 __attribute__((__near__));
extern volatile unsigned int DTR4 __attribute__((__near__));

extern volatile unsigned int ALTDTR1 __attribute__((__near__));
extern volatile unsigned int ALTDTR2 __attribute__((__near__));
extern volatile unsigned int ALTDTR3 __attribute__((__near__));
extern volatile unsigned int ALTDTR4 __attribute__((__near__));

extern volatile unsigned int TRIG1 __attribute__((__near__));
extern volatile unsigned int TRIG2 __attribute__((__near__));
extern volatile unsigned int TRIG3 __attribute__((__near__));
extern volatile unsigned int TRIG4 __attribute__((__near__));
typedef struct tagTRIGBITS {
        unsigned                :4;
        unsigned TRIG           :12;
} TRIGBITS;
extern volatile TRIGBITS TRIG1bits __attribute__((__near__));
extern volatile TRIGBITS TRIG2bits __attribute__((__near__));
extern volatile TRIGBITS TRIG3bits __attribute__((__near__));
extern volatile TRIGBITS TRIG4bits __attribute__((__near__));

extern volatile unsigned int TRGCON1 __attribute__((__near__));
extern volatile unsigned int TRGCON2 __attribute__((__near__));
extern volatile unsigned int TRGCON3 __attribute__((__near__));
extern volatile unsigned int TRGCON4 __attribute__((__near__));
typedef struct TRGCONBITS {
        unsigned TRGSTRT        :6;
        unsigned                :7;
        unsigned TRGDIV         :3;
} TRGCONBITS;
extern volatile TRGCONBITS TRGCON1bits __attribute__((__near__));
extern volatile TRGCONBITS TRGCON2bits __attribute__((__near__));
extern volatile TRGCONBITS TRGCON3bits __attribute__((__near__));
extern volatile TRGCONBITS TRGCON4bits __attribute__((__near__));

extern volatile unsigned int LEBCON1 __attribute__((__near__));
extern volatile unsigned int LEBCON2 __attribute__((__near__));
extern volatile unsigned int LEBCON3 __attribute__((__near__));
extern volatile unsigned int LEBCON4 __attribute__((__near__));
typedef struct tagLEBCONBITS {
        unsigned          	:3;
 	unsigned LEB		:7;
	unsigned CLLEBEN        :1;
        unsigned FLTLEBEN       :1;
        unsigned PLF         	:1;
        unsigned PLR          	:1;
        unsigned PHF          	:1;
        unsigned PHR            :1;
} LEBCONBITS;
extern volatile LEBCONBITS LEBCON1bits __attribute__((__near__));
extern volatile LEBCONBITS LEBCON2bits __attribute__((__near__));
extern volatile LEBCONBITS LEBCON3bits __attribute__((__near__));
extern volatile LEBCONBITS LEBCON4bits __attribute__((__near__));

/* --------------------------------------- */
/*      Analog Comparator Control Register Map */
/* --------------------------------------- */
typedef struct CMPCONBITS {
        unsigned RANGE          :1;
        unsigned CMPPOL         :1;
        unsigned                :1;
        unsigned CMPSTAT        :1;
        unsigned                :1;
        unsigned EXTREF         :1;
        unsigned INSEL          :2;
        unsigned 	            :1;
        unsigned                :4;
        unsigned CMPSIDL        :1;
        unsigned                :1;
        unsigned CMPON          :1;
} CMPCONBITS;

typedef struct CMPDACBITS {
        unsigned CMREF         :10;
        unsigned                :6;
} CMPDACBITS;


extern volatile unsigned int CMPCON1 __attribute__((__near__));
extern volatile CMPCONBITS CMPCON1bits __attribute__((__near__));

extern volatile unsigned int CMPDAC1 __attribute__((__near__));
extern volatile CMPDACBITS CMPDAC1bits __attribute__((__near__));

extern volatile unsigned int CMPCON2 __attribute__((__near__));
extern volatile CMPCONBITS CMPCON2bits __attribute__((__near__));

extern volatile unsigned int CMPDAC2 __attribute__((__near__));
extern volatile CMPDACBITS CMPDAC2bits __attribute__((__near__));

extern volatile unsigned int CMPCON3 __attribute__((__near__));
extern volatile CMPCONBITS CMPCON3bits __attribute__((__near__));

extern volatile unsigned int CMPDAC3 __attribute__((__near__));
extern volatile CMPDACBITS CMPDAC3bits __attribute__((__near__));

extern volatile unsigned int CMPCON4 __attribute__((__near__));
extern volatile CMPCONBITS CMPCON4bits __attribute__((__near__));

extern volatile unsigned int CMPDAC4 __attribute__((__near__));
extern volatile CMPDACBITS CMPDAC4bits __attribute__((__near__));



/* --------------------------------------------- */
/* System Integration register (SIB) definitions */
/* --------------------------------------------- */

/* RCON: Reset Control Register */
extern volatile unsigned int RCON __attribute__((__near__));
typedef struct tagRCONBITS {
        unsigned POR    :1;
        unsigned        :1;
        unsigned IDLE   :1;
        unsigned SLEEP  :1;
        unsigned WDTO   :1;
        unsigned SWDTEN :1;
        unsigned SWR    :1;
        unsigned EXTR   :1;
        unsigned        :5;
        unsigned        :1;
        unsigned IOPUWR :1;
        unsigned TRAPR  :1;
} RCONBITS;
extern volatile RCONBITS RCONbits __attribute__((__near__));

/* OSCCON: Oscillator Control Register */
extern volatile unsigned int OSCCON __attribute__((__near__));
typedef struct tagOSCCONBITS {
        unsigned OSWEN  :1;
        unsigned        :1;
        unsigned TSEQEN :1;
        unsigned CF     :1;
        unsigned PRCDEN :1;
        unsigned LOCK   :1;
        unsigned        :1;
        unsigned CLKLOCK:1;
        unsigned NOSC   :3;
        unsigned        :1;
        unsigned COSC   :3;
        unsigned        :1;
} OSCCONBITS;
extern volatile OSCCONBITS OSCCONbits __attribute__((__near__));

/*extern volatile unsigned int CLKDIV __attribute__((__near__));
typedef struct tagCLKDIVBITS {
        unsigned        :11;
        unsigned DOZEN  :1;
        unsigned DOZE   :3;
        unsigned ROI    :1;
} CLKDIVBITS;
extern volatile CLKDIVBITS CLKDIVbits __attribute__((__near__));*/

/* OSCTUN: Oscillator Control Register */
extern volatile unsigned int OSCTUN __attribute__((__near__));
typedef struct tagOSCTUNBITS {
        unsigned TUN    :4;
        unsigned TSEQ1  :4;
        unsigned TSEQ2  :4;
        unsigned TSEQ3  :4;
} OSCTUNBITS;
extern volatile OSCTUNBITS OSCTUNbits __attribute__((__near__));

extern volatile unsigned int OSCTUN2 __attribute__((__near__));
typedef struct tagOSCTUN2BITS {
        unsigned TSEQ4  :4;
        unsigned TSEQ5  :4;
        unsigned TSEQ6  :4;
        unsigned TSEQ7  :4;
} OSCTUN2BITS;
extern volatile OSCTUN2BITS OSCTUN2bits __attribute__((__near__));

/* ----------------------------- */
/* NVM Register Map definitions  */
/* ----------------------------- */
extern volatile unsigned int NVMCON __attribute__((__near__));
typedef struct tagNVMCONBITS {
        unsigned PROGOP         :7;
        unsigned                :1;
        unsigned TWRI           :1;
        unsigned                :4;
        unsigned WRERR          :1;
        unsigned WREN           :1;
        unsigned WR             :1;
} NVMCONBITS;
extern volatile NVMCONBITS NVMCONbits __attribute__((__near__));

extern volatile unsigned int NVMADR __attribute__((__near__));

extern volatile unsigned int NVMADRU __attribute__((__near__));
typedef struct tagNVMADRUBITS {
        unsigned NVMADR         :8;
        unsigned                :8;
} NVMADRUBITS;
extern volatile NVMADRUBITS NVMADRUbits __attribute__((__near__));

extern volatile unsigned int NVMKEY __attribute__((__near__));
typedef struct tagNVMKEYBITS {
        unsigned NVMKEY         :8;
        unsigned                :8;
} NVMKEYBITS;
extern volatile NVMKEYBITS NVMKEYbits __attribute__((__near__));

/* ---------------------------------------------------- */
/* Peripheral Module Disable (PMD) register definitions */
/* ---------------------------------------------------- */

/* PMD1: Peripheral Module Disable Register 1 */
extern volatile unsigned int PMD1 __attribute__((__near__));
typedef struct tagPMD1BITS {
        unsigned ADCMD  :1;
        unsigned        :2;
        unsigned SPI1MD :1;
        unsigned        :1;
        unsigned U1MD   :1;
        unsigned        :1;
        unsigned I2CMD  :1;
        unsigned        :1;
        unsigned PWMMD  :1;
        unsigned        :1;
        unsigned T1MD   :1;
        unsigned T2MD   :1;
        unsigned T3MD   :1;
        unsigned        :2;
} PMD1BITS;
extern volatile PMD1BITS PMD1bits __attribute__((__near__));

/* PMD2: Peripheral Module Disable Register 2 */
extern volatile unsigned int PMD2 __attribute__((__near__));
typedef struct tagPMD2BITS {
        unsigned OC1MD  :1;
        unsigned OC2MD  :1;
        unsigned        :6;
        unsigned IC1MD  :1;
        unsigned        :7;
} PMD2BITS;
extern volatile PMD2BITS PMD2bits __attribute__((__near__));

/* PMD3: Peripheral Module Disable Register 3 */
extern volatile unsigned int PMD3 __attribute__((__near__));
typedef struct tagPMD3BITS {
        unsigned                :11;
        unsigned CMP_PSMD       :1;
        unsigned                :4;
} PMD3BITS;
extern volatile PMD3BITS PMD3bits __attribute__((__near__));

/* LFSR: LINEAR FEEDBACK SHIFT REGISTER */
extern volatile unsigned int LFSR __attribute__((near));

/* --------------------------------- */
/* Defines for unique SFR bit names  */
/* --------------------------------- */

/* SR */
#define _C SRbits.C
#define _Z SRbits.Z
#define _OV SRbits.OV
#define _N SRbits.N
#define _RA SRbits.RA
#define _IPL SRbits.IPL
#define _DC SRbits.DC
#define _DA SRbits.DA
#define _SAB SRbits.SAB
#define _OAB SRbits.OAB
#define _SB SRbits.SB
#define _SA SRbits.SA
#define _OB SRbits.OB
#define _OA SRbits.OA

/* CORCON */
#define _IF CORCONbits.IF
#define _RND CORCONbits.RND
#define _PSV CORCONbits.PSV
#define _IPL3 CORCONbits.IPL3
#define _ACCSAT CORCONbits.ACCSAT
#define _SATDW CORCONbits.SATDW
#define _SATB CORCONbits.SATB
#define _SATA CORCONbits.SATA
#define _DL CORCONbits.DL
#define _EDT CORCONbits.EDT
#define _US CORCONbits.US 

/* MODCON */
#define _YMODEN MODCONbits.YMODEN
#define _XMODEN MODCONbits.XMODEN

/* XBREV */
#define _XB XBREVbits.XB
#define _BREN XBREVbits.BREN

/* CNEN1 */

#define _CN0IE CNEN1bits.CN0IE
#define _CN1IE CNEN1bits.CN1IE
#define _CN2IE CNEN1bits.CN2IE
#define _CN3IE CNEN1bits.CN3IE
#define _CN4IE CNEN1bits.CN4IE
#define _CN5IE CNEN1bits.CN5IE
#define _CN6IE CNEN1bits.CN6IE
#define _CN7IE CNEN1bits.CN7IE

/* CNPU1 */

#define _CN0PUE CNPU1bits.CN0PUE
#define _CN1PUE CNPU1bits.CN1PUE
#define _CN2PUE CNPU1bits.CN2PUE
#define _CN3PUE CNPU1bits.CN3PUE
#define _CN4PUE CNPU1bits.CN4PUE
#define _CN5PUE CNPU1bits.CN5PUE
#define _CN6PUE CNPU1bits.CN6PUE
#define _CN7PUE CNPU1bits.CN7PUE

/* INTCON1 */
#define _OSCFAIL INTCON1bits.OSCFAIL
#define _STKERR INTCON1bits.STKERR
#define _ADDRERR INTCON1bits.ADDRERR
#define _MATHERR INTCON1bits.MATHERR
#define _DIV0ERR INTCON1bits.DIV0ERR
#define _SFTACERR INTCON1bits.SFTACERR
#define _COVTE INTCON1bits.COVTE
#define _OVBTE INTCON1bits.OVBTE
#define _OVATE INTCON1bits.OVATE
#define _COVBERR INTCON1bits.COVBERR
#define _COVAERR INTCON1bits.COVAERR
#define _OVBERR INTCON1bits.OVBERR	
#define _OVAERR INTCON1bits.OVAERR
#define _NSTDIS INTCON1bits.NSTDIS

/* INTCON2 */
#define _INT0EP INTCON2bits.INT0EP
#define _INT1EP INTCON2bits.INT1EP
#define _INT2EP INTCON2bits.INT2EP
#define _DISI INTCON2bits.DISI
#define _ALTIVT INTCON2bits.ALTIVT

/* IFS0 */
#define _INT0IF IFS0bits.INT0IF
#define _IC1IF IFS0bits.IC1IF
#define _OC1IF IFS0bits.OC1IF
#define _T1IF IFS0bits.T1IF
#define _OC2IF IFS0bits.OC2IF
#define _T2IF IFS0bits.T2IF
#define _T3IF IFS0bits.T3IF
#define _SPI1IF IFS0bits.SPI1IF
#define _U1RXIF IFS0bits.U1RXIF
#define _U1TXIF IFS0bits.U1TXIF
#define _ADIF IFS0bits.ADIF
#define _NVMIF IFS0bits.NVMIF
#define _SI2CIF IFS0bits.SI2CIF
#define _MI2CIF IFS0bits.MI2CIF

/* IFS1 */
#define _INT1IF IFS1bits.INT1IF
#define _INT2IF IFS1bits.INT2IF
#define _PSEMIF IFS1bits.PSEMIF
#define _PWM1IF IFS1bits.PWM1IF
#define _PWM2IF IFS1bits.PWM2IF
#define _PWM3IF IFS1bits.PWM3IF
#define _PWM4IF IFS1bits.PWM4IF
#define _CNIF	IFS1bits.CNIF
#define _AC1IF IFS1bits.AC1IF
#define _AC2IF IFS1bits.AC2IF
#define _AC3IF IFS1bits.AC3IF

/* IFS2 */
#define _AC4IF IFS2bits.AC4IF
#define _ADCP0IF IFS2bits.ADCP0IF
#define _ADCP1IF IFS2bits.ADCP1IF
#define _ADCP2IF IFS2bits.ADCP2IF
#define _ADCP3IF IFS2bits.ADCP3IF
#define _ADCP4IF IFS2bits.ADCP4IF
#define _ADCP5IF IFS2bits.ADCP5IF

/* IEC0 */
#define _INT0IE IEC0bits.INT0IE
#define _IC1IE IEC0bits.IC1IE
#define _OC1IE IEC0bits.OC1IE
#define _T1IE IEC0bits.T1IE
#define _OC2IE IEC0bits.OC2IE
#define _T2IE IEC0bits.T2IE
#define _T3IE IEC0bits.T3IE
#define _SPI1IE IEC0bits.SPI1IE
#define _U1RXIE IEC0bits.U1RXIE
#define _U1TXIE IEC0bits.U1TXIE
#define _ADIE IEC0bits.ADIE
#define _NVMIE IEC0bits.NVMIE
#define _SI2CIE IEC0bits.SI2CIE
#define _MI2CIE IEC0bits.MI2CIE

/* IEC1 */
#define _INT1IE IEC1bits.INT1IE
#define _INT2IE IEC1bits.INT2IE
#define _PSEMIE IEC1bits.PSEMIE
#define _PWM1IE IEC1bits.PWM1IE
#define _PWM2IE IEC1bits.PWM2IE
#define _PWM3IE IEC1bits.PWM3IE
#define _PWM4IE IEC1bits.PWM4IE
#define _CNIE	IEC1bits.CNIE
#define _AC1IE IEC1bits.AC1IE
#define _AC2IE IEC1bits.AC2IE
#define _AC3IE IEC1bits.AC3IE

/* IEC2 */
#define _AC4IE IEC2bits.AC4IE
#define _ADCP0IE IEC2bits.ADCP0IE
#define _ADCP1IE IEC2bits.ADCP1IE
#define _ADCP2IE IEC2bits.ADCP2IE
#define _ADCP3IE IEC2bits.ADCP3IE
#define _ADCP4IE IEC2bits.ADCP4IE
#define _ADCP5IE IEC2bits.ADCP5IE

/* IPC0 */
#define _INT0IP IPC0bits.INT0IP
#define _IC1IP IPC0bits.IC1IP
#define _OC1IP IPC0bits.OC1IP
#define _T1IP IPC0bits.T1IP

/* IPC1 */
#define _OC2IP IPC1bits.OC2IP
#define _T2IP IPC1bits.T2IP
#define _T3IP IPC1bits.T3IP

/* IPC2 */
#define _SPI1IP IPC2bits.SPI1IP
#define _U1RXIP IPC2bits.U1RXIP
#define _U1TXIP IPC2bits.U1TXIP
#define _ADIP IPC2bits.ADIP

/* IPC3 */
#define _NVMIP IPC3bits.NVMIP
#define _SI2CIP IPC3bits.SI2CIP
#define _MI2CIP IPC3bits.MI2CIP

/* IPC4 */
#define _INT1IP IPC4bits.INT1IP
#define _INT2IP IPC4bits.INT2IP
#define _PSEMIP IPC4bits.PSEMIP
#define _PWM1IP IPC4bits.PWM1IP

/* IPC5 */
#define _PWM2IP IPC5bits.PWM2IP
#define _PWM3IP IPC5bits.PWM3IP
#define _PWM4IP IPC5bits.PWM4IP

/* IPC6 */
#define _CNIP IPC6bits.CNIP

/* IPC7 */
#define _AC1IP IPC7bits.AC1IP
#define _AC2IP IPC7bits.AC2IP
#define _AC3IP IPC7bits.AC3IP

/* IPC8 */
#define _AC4IP IPC8bits.AC4IP

/* IPC9 */
#define _ADCP0IP IPC9bits.ADCP0IP
#define _ADCP1IP IPC9bits.ADCP1IP
#define _ADCP2IP IPC9bits.ADCP2IP

/* IPC10 */
#define _ADCP3IP IPC10bits.ADCP3IP
#define _ADCP4IP IPC10bits.ADCP4IP
#define _ADCP5IP IPC10bits.ADCP5IP

/* INTTREG */
#define _VECNUM INTTREGbits.VECNUM
#define _ILR    INTTREGbits.ILR

/* No unique SFR bit names for Timer Register Map */

/*IC1CON */
#define _ICBNE IC1CONbits.ICBNE
#define _ICOV IC1CONbits.ICOV
#define _ICTMR IC1CONbits.ICTMR
#define _ICSIDL IC1CONbits.ICSIDL

/* No unique SFR bit names for Output Compare Register Map */

/* I2CCON: I2C Control Register */
#define _SEN I2CCONbits.SEN
#define _RSEN I2CCONbits.RSEN
#define _PEN I2CCONbits.PEN
#define _RCEN I2CCONbits.RCEN
#define _ACKEN I2CCONbits.ACKEN
#define _ACKDT I2CCONbits.ACKDT
#define _STREN I2CCONbits.STREN
#define _GCEN I2CCONbits.GCEN
#define _SMEN I2CCONbits.SMEN
#define _DISSLW I2CCONbits.DISSLW
#define _IPMIEN I2CCONbits.IPMIEN
#define _SCLREL I2CCONbits.SCLREL
#define _I2CSIDL I2CCONbits.I2CSIDL
#define _I2CEN I2CCONbits.I2CEN

/* I2CSTAT Register*/
#define _TBF I2CSTATbits.TBF
#define _RBF I2CSTATbits.RBF
#define _R_W I2CSTATbits.R_W
#define _S I2CSTATbits.S
#define _P I2CSTATbits.P
#define _D_A I2CSTATbits.D_A
#define _I2COV I2CSTATbits.I2COV
#define _IWCOL I2CSTATbits.IWCOL
#define _ADD10 I2CSTATbits.ADD10
#define _GCSTAT I2CSTATbits.GCSTAT
#define _TRSTAT I2CSTATbits.TRSTAT
#define _ACKSTAT I2CSTATbits.ACKSTAT

/* No unique SFR bit names for UART1  Register Map */

/* SPI1 Register */
#define _SPIRBF SPI1STAT.SPIRBF
#define _SPITBF SPISTAT.SPITBF
#define _SPIROV SPI1STAT.SPIROV
#define _SPISIDL SPI1STAT.SPISIDL
#define _SPIEN SPI1STAT.SPIEN

/* TRISA */
#define _TRISA8 TRISAbits.TRISA8
#define _TRISA9 TRISAbits.TRISA9
#define _TRISA10 TRISAbits.TRISA10
#define _TRISA11 TRISAbits.TRISA11

/* PORTA */
#define _RA8 PORTAbits.RA8
#define _RA9 PORTAbits.RA9
#define _RA10 PORTAbits.RA10
#define _RA11 PORTAbits.RA11

/* LATA */
#define _LATA8 LATAbits.LATA8
#define _LATA9 LATAbits.LATA9
#define _LATA10 LATAbits.LATA10
#define _LATA11 LATAbits.LATA11

/* TRISB */
#define _TRISB0 TRISBbits.TRISB0
#define _TRISB1 TRISBbits.TRISB1
#define _TRISB2 TRISBbits.TRISB2
#define _TRISB3 TRISBbits.TRISB3
#define _TRISB4 TRISBbits.TRISB4
#define _TRISB5 TRISBbits.TRISB5
#define _TRISB6 TRISBbits.TRISB6
#define _TRISB7 TRISBbits.TRISB7
#define _TRISB8 TRISBbits.TRISB8
#define _TRISB9 TRISBbits.TRISB9
#define _TRISB10 TRISBbits.TRISB10
#define _TRISB11 TRISBbits.TRISB11

/* PORTB */
#define _RB0 PORTBbits.RB0
#define _RB1 PORTBbits.RB1
#define _RB2 PORTBbits.RB2
#define _RB3 PORTBbits.RB3
#define _RB4 PORTBbits.RB4
#define _RB5 PORTBbits.RB5
#define _RB6 PORTBbits.RB6
#define _RB7 PORTBbits.RB7
#define _RB8 PORTBbits.RB8
#define _RB9 PORTBbits.RB9
#define _RB10 PORTBbits.RB10
#define _RB11 PORTBbits.RB11

/* LATB */
#define _LATB0 LATBbits.LATB0
#define _LATB1 LATBbits.LATB1
#define _LATB2 LATBbits.LATB2
#define _LATB3 LATBbits.LATB3
#define _LATB4 LATBbits.LATB4
#define _LATB5 LATBbits.LATB5
#define _LATB6 LATBbits.LATB6
#define _LATB7 LATBbits.LATB7
#define _LATB8 LATBbits.LATB8
#define _LATB9 LATBbits.LATB9
#define _LATB10 LATBbits.LATB10
#define _LATB11 LATBbits.LATB11

/* TRISD */
#define _TRISD0 TRISDbits.TRISD0
#define _TRISD1 TRISDbits.TRISD1

/* PORTD */
#define _RD0 PORTDbits.RD0
#define _RD1 PORTDbits.RD1

/* LATD */
#define _LATD0 LATDbits.LATD0
#define _LATD1 LATDbits.LATD1

/* TRISE */
#define _TRISE0 TRISEbits.TRISE0
#define _TRISE1 TRISEbits.TRISE1
#define _TRISE2 TRISEbits.TRISE2
#define _TRISE3 TRISEbits.TRISE3
#define _TRISE4 TRISEbits.TRISE4
#define _TRISE5 TRISEbits.TRISE5
#define _TRISE6 TRISEbits.TRISE6
#define _TRISE7 TRISEbits.TRISE7

/* PORTE */
#define _RE0 PORTEbits.RE0
#define _RE1 PORTEbits.RE1
#define _RE2 PORTEbits.RE2
#define _RE3 PORTEbits.RE3
#define _RE4 PORTEbits.RE4
#define _RE5 PORTEbits.RE5
#define _RE6 PORTEbits.RE6
#define _RE7 PORTEbits.RE7

/* LATE */
#define _LATE0 LATEbits.LATE0
#define _LATE1 LATEbits.LATE1
#define _LATE2 LATEbits.LATE2
#define _LATE3 LATEbits.LATE3
#define _LATE4 LATEbits.LATE4
#define _LATE5 LATEbits.LATE5
#define _LATE6 LATEbits.LATE6
#define _LATE7 LATEbits.LATE7

/* TRISF */
#define _TRISF2 TRISFbits.TRISF2
#define _TRISF3 TRISFbits.TRISF3
#define _TRISF6 TRISFbits.TRISF6
#define _TRISF7 TRISFbits.TRISF7
#define _TRISF8 TRISFbits.TRISF8
#define _TRISF14 TRISFbits.TRISF14
#define _TRISF15 TRISFbits.TRISF15

/* PORTF */
#define _RF2 PORTFbits.RF2
#define _RF3 PORTFbits.RF3
#define _RF6 PORTFbits.RF6
#define _RF7 PORTFbits.RF7
#define _RF8 PORTFbits.RF8
#define _RF14 PORTFbits.RF14
#define _RF15 PORTFbits.RF15

/* LATF */
#define _LATF2 LATFbits.LATF2
#define _LATF3 LATFbits.LATF3
#define _LATF6 LATFbits.LATF6
#define _LATF7 LATFbits.LATF7
#define _LATF8 LATFbits.LATF8
#define _LATF14 LATFbits.LATF14
#define _LATF15 LATFbits.LATF15

/* TRISG */
#define _TRISG2 TRISGbits.TRISG2
#define _TRISG3 TRISGbits.TRISG3

/* PORTG */
#define _RG2 PORTGbits.RG2
#define _RG3 PORTGbits.RG3

/* LATG */
#define _LATG2 LATGbits.LATG2
#define _LATG3 LATGbits.LATG3

/* ADCON */
#define _ADCS ADCONbits.ADCS
#define _SEQSAMP ADCONbits.SEQSAMP	
#define _ORDER ADCONbits.ORDER
#define _EIE ADCONbits.EIE
#define _FORM ADCONbits.FORM
#define _GSWTRG ADCONbits.GSWTRG
#define _ADSIDL ADCONbits.ADSIDL
#define _ADON ADCONbits.ADON

/* ADPCFG */
#define _PCFG0 ADPCFGbits.PCFG0
#define _PCFG1 ADPCFGbits.PCFG1
#define _PCFG2 ADPCFGbits.PCFG2
#define _PCFG3 ADPCFGbits.PCFG3
#define _PCFG4 ADPCFGbits.PCFG4
#define _PCFG5 ADPCFGbits.PCFG5
#define _PCFG6 ADPCFGbits.PCFG6
#define _PCFG7 ADPCFGbits.PCFG7
#define _PCFG8 ADPCFGbits.PCFG8
#define _PCFG9 ADPCFGbits.PCFG9
#define _PCFG10 ADPCFGbits.PCFG10
#define _PCFG11 ADPCFGbits.PCFG11


/* PTCON */
#define _SEVTPS PTCONbits.SEVTPS
#define _SYNCSRC PTCONbits.SYNCSRC
#define _SYNCEN PTCONbits.SYNCEN
#define _SYNCOEN PTCONbits.SYNCOEN
#define _SEIEN PTCONbits.SEIEN
#define _PTSIDL PTCONbits.PTSIDL
#define _PTEN PTCONbits.PTEN
#define _SESTAT PTCONbits.SESTAT
#define _SYNCPOL PTCONbits.SYNCPOL
#define _EIPU PTCONbits.EIPU

/* No unique SFR bit names for Analog Comparator Register Map */

/* RCON */
#define _POR RCONbits.POR
#define _IDLE RCONbits.IDLE
#define _SLEEP RCONbits.SLEEP
#define _WDTO RCONbits.WDTO
#define _SWDTEN RCONbits.SWDTEN
#define _SWR RCONbits.SWR
#define _EXTR RCONbits.EXTR
#define _BGST RCONbits.BGST
#define _IOPUWR RCONbits.IOPUWR
#define _TRAPR RCONbits.TRAPR

/* OSCCON */
#define _OSWEN OSCCONbits.OSWEN
#define _TSEQEN OSCCONbits.TSEQEN
#define _CF OSCCONbits.CF
#define _PRCDEN OSCCONbits.PRCDEN
#define _LOCK OSCCONbits.LOCK
#define _CLKLOCK OSCCONbits.CLKLOCK
#define _NOSC OSCCONbits.NOSC
#define _COSC OSCCONbits.COSC

/* CLKDIV 
#define _DOZEN CLKDIV.DOZEN
#define _DOZE CLKDIV.DOZE
#define _ROI CLKDIV.ROI */

/* NVMCON */
#define _SIZSEL NVMCONbits.SIZSEL
#define _MEMSEL NVMCONbits.MEMSEL
#define _SEGSEL NVMCONbits.SEGSEL
#define _ERASE NVMCONbits.ERASE
#define _TWRI NVMCONbits.TWRI
#define _WRERR NVMCONbits.WRERR
#define _WREN NVMCONbits.WREN
#define _WR NVMCONbits.WR

/* PMD1 */
#define _ADCMD PMD1bits.ADCMD
#define _SPI1MD PMD1bits.SPI1MD
#define _U1MD PMD1bits.U1MD
#define _I2CMD PMD1bits.I2CMD
#define _PWMMD PMD1bits.PWMMD
#define _T1MD PMD1bits.T1MD
#define _T2MD PMD1bits.T2MD
#define _T3MD PMD1bits.T3MD

/* PMD2 */
#define _OC1MD PMD2bits.OC1MD
#define _OC2MD PMD2bits.OC2MD
#define _IC1MD PMD2bits.IC1MD

/* PMD3 */
#define _CMP_PSMD PMD3bits.CMP_PSMD


/* ----------------------------------------- */
/* Macros for Device Configuration Registers */
/* ----------------------------------------- */

/* FOSC */
#define _FOSC(x) __attribute__((section("__FOSC.sec, code"))) int _FOSC = (x);

#define CSW_FSCM_OFF    0xFFFF
#define CSW_ON_FSCM_OFF 0xFF7F
#define CSW_FSCM_ON     0xFF3F
#define FRC_LO_RANGE    0xFFDF
#define FRC_HI_RANGE    0xFFFF
#define OSC2_IO         0xFFFB
#define OSC2_CLKO       0xFFFF
#define HS_EC_DIS       0xFFFF
#define EC              0xFFFC
#define HS              0xFFFE

/* FOSCSEL */
#define _FOSCSEL(x) __attribute__((section("__FOSCSEL.sec,code"))) int _FOSCSEL	= (x);

#define FRC		0xFFFC
#define FRC_PLL		0xFFFD
#define PRIOSC		0xFFFE
#define PRIOSC_PLL	0xFFFF

/* FWDT */
#define _FWDT(x) __attribute__((section("__FWDT.sec, code"))) int _FWDT = (x);

#define FWDTEN_OFF           0xFF7F
#define FWDTEN_ON            0xFFFF

#define WINDIS_ON            0xFFBF
#define WINDIS_OFF           0xFFFF

#define WDTPRE_PR32          0xFFEF
#define WDTPRE_PR128         0xFFFF

#define WDTPOST_PS1          0xFFF0
#define WDTPOST_PS2          0xFFF1
#define WDTPOST_PS4          0xFFF2
#define WDTPOST_PS8          0xFFF3
#define WDTPOST_PS16         0xFFF4
#define WDTPOST_PS32         0xFFF5
#define WDTPOST_PS64         0xFFF6
#define WDTPOST_PS128        0xFFF7
#define WDTPOST_PS256        0xFFF8
#define WDTPOST_PS512        0xFFF9
#define WDTPOST_PS1024       0xFFFA
#define WDTPOST_PS2048       0xFFFB
#define WDTPOST_PS4096       0xFFFC
#define WDTPOST_PS8192       0xFFFD
#define WDTPOST_PS16384      0xFFFE
#define WDTPOST_PS32768      0xFFFF

/* FPOR */
#define _FPOR(x) __attribute__((section("__FPOR.sec, code"))) int _FPOR = (x);

#define PWRT_OFF       0xFFF8
#define PWRT_2         0xFFF9
#define PWRT_4         0xFFFA
#define PWRT_8         0xFFFB
#define PWRT_16        0xFFFC
#define PWRT_32        0xFFFD
#define PWRT_64        0xFFFE
#define PWRT_128       0xFFFF


/* FGS */
#define _FGS(x) __attribute__((section("__FGS.sec, code"))) int _FGS = (x);

#define CODE_PROT_OFF  0xFFFF
#define CODE_PROT_ON   0xFFFD
#define GWRP_OFF  0xFFFF
#define GWRP_ON   0xFFFE

/* FBS */
#define _FBS(x) __attribute__((section("__FBS.sec, code"))) int _FBS = (x);

#define BSS_MEDIUM_FLASH_HIGH 0xFFF3
#define BSS_SMALL_FLASH_HIGH  0xFFF5
#define BSS_MEDIUM_FLASH_STD  0xFFFB
#define BSS_SMALL_FLASH_STD   0xFFFD
#define BSS_NO_FLASH          0xFFFF
#define BWRP_WRPROTECT_ON     0xFFFE
#define BWRP_WRPROTECT_OFF    0xFFFF


#define _FUID0(x) __attribute__((section("__FUID0.sec,code"))) int _FUID0 = (x);
#define _FUID1(x) __attribute__((section("__FUID1.sec,code"))) int _FUID1 = (x);
#define _FUID2(x) __attribute__((section("__FUID2.sec,code"))) int _FUID2 = (x);
#define _FUID3(x) __attribute__((section("__FUID3.sec,code"))) int _FUID3 = (x);

/* ---------------------------------------------------------------------------
 Setting configuration fuses using macros:
 ==========================================
 Macros are provided which can be used to set configuration fuses:
 For e.g., to set the FOSC fuse using a macro above, the following line of
 code can be pasted before the beginning of the C source code.

        _FOSC(CSW_FSCM_ON & FRC & FRC_LO_RANGE);

 This would enable the internal FRC oscillator to its lower range of operation,
 and further enable clock switching and failsafe clock monitoring.

 Similarly, to set the FPOR fuse, paste the following :

        _FPOR(PWRT_64 & MCLR_DIS);

 This would enable Brown-out Reset at 2.7 Volts and initialize the Power-up
 timer to 64 milliseconds and configure the use of the MCLR pin for I/O.
 Given below, is a list of settings valid to each of the fuses:
 (Paste the ones relevant to your application before the beginning of C
 source code.)

NOTE: Check for availablity of the selected fuse configuration in the device

	FOSC:
               ======
                _FOSC(CSW_FSCM_OFF & FRC_HI_RANGE);
                _FOSC(CSW_FSCM_OFF & FRC_LO_RANGE);
                _FOSC(CSW_FSCM_OFF & OSC2_IO & HS_EC_DIS);
                _FOSC(CSW_FSCM_OFF & OSC2_IO & EC);
                _FOSC(CSW_FSCM_OFF & OSC2_IO & HS);
                _FOSC(CSW_FSCM_OFF & OSC2_CLKO & HS_EC_DIS);
                _FOSC(CSW_FSCM_OFF & OSC2_CLKO & EC);
                _FOSC(CSW_FSCM_OFF & OSC2_CLKO & HS);
                _FOSC(CSW_ON_FSCM_OFF & FRC_HI_RANGE);
                _FOSC(CSW_ON_FSCM_OFF & FRC_LO_RANGE);
                _FOSC(CSW_ON_FSCM_OFF & OSC2_IO & HS_EC_DIS);
                _FOSC(CSW_ON_FSCM_OFF & OSC2_IO & EC);
                _FOSC(CSW_ON_FSCM_OFF & OSC2_IO & HS);
                _FOSC(CSW_ON_FSCM_OFF & OSC2_CLKO & HS_EC_DIS);
                _FOSC(CSW_ON_FSCM_OFF & OSC2_CLKO & EC);
                _FOSC(CSW_ON_FSCM_OFF & OSC2_CLKO & HS);
                _FOSC(CSW_FSCM_ON & FRC_HI_RANGE);
                _FOSC(CSW_FSCM_ON & FRC_LO_RANGE);
                _FOSC(CSW_FSCM_ON & OSC2_IO & HS_EC_DIS);
                _FOSC(CSW_FSCM_ON & OSC2_IO & EC);
                _FOSC(CSW_FSCM_ON & OSC2_IO & HS);
                _FOSC(CSW_FSCM_ON & OSC2_CLKO & HS_EC_DIS);
                _FOSC(CSW_FSCM_ON & OSC2_CLKO & EC);
                _FOSC(CSW_FSCM_ON & OSC2_CLKO & HS);
	
		FOSCSEL
		=======

		_FOSCSEL(FRC);
		_FOSCSEL(FRC_PLL);
		_FOSCSEL(PRIOSC);
		_FOSCSEL(PRIOSC_PLL);

 
		FWDT
               =====
               _FWDT(WDT_OFF);
               _FWDT(WDT_ON & WDTPSA_1 & WDTPSB_1);
               _FWDT(WDT_ON & WDTPSA_1 & WDTPSB_2);
               _FWDT(WDT_ON & WDTPSA_1 & WDTPSB_3);
               _FWDT(WDT_ON & WDTPSA_1 & WDTPSB_4);
               _FWDT(WDT_ON & WDTPSA_1 & WDTPSB_5);
               _FWDT(WDT_ON & WDTPSA_1 & WDTPSB_6);
               _FWDT(WDT_ON & WDTPSA_1 & WDTPSB_7);
               _FWDT(WDT_ON & WDTPSA_1 & WDTPSB_8);
               _FWDT(WDT_ON & WDTPSA_1 & WDTPSB_9);
               _FWDT(WDT_ON & WDTPSA_1 & WDTPSB_10);
               _FWDT(WDT_ON & WDTPSA_1 & WDTPSB_11);
               _FWDT(WDT_ON & WDTPSA_1 & WDTPSB_12);
               _FWDT(WDT_ON & WDTPSA_1 & WDTPSB_13);
               _FWDT(WDT_ON & WDTPSA_1 & WDTPSB_14);
               _FWDT(WDT_ON & WDTPSA_1 & WDTPSB_15);
               _FWDT(WDT_ON & WDTPSA_1 & WDTPSB_16);
               _FWDT(WDT_ON & WDTPSA_4 & WDTPSB_1);
               _FWDT(WDT_ON & WDTPSA_4 & WDTPSB_2);
               _FWDT(WDT_ON & WDTPSA_4 & WDTPSB_3);
               _FWDT(WDT_ON & WDTPSA_4 & WDTPSB_4);
               _FWDT(WDT_ON & WDTPSA_4 & WDTPSB_5);
               _FWDT(WDT_ON & WDTPSA_4 & WDTPSB_6);
               _FWDT(WDT_ON & WDTPSA_4 & WDTPSB_7);
               _FWDT(WDT_ON & WDTPSA_4 & WDTPSB_8);
               _FWDT(WDT_ON & WDTPSA_4 & WDTPSB_9);
               _FWDT(WDT_ON & WDTPSA_4 & WDTPSB_10);
               _FWDT(WDT_ON & WDTPSA_4 & WDTPSB_11);
               _FWDT(WDT_ON & WDTPSA_4 & WDTPSB_12);
               _FWDT(WDT_ON & WDTPSA_4 & WDTPSB_13);
               _FWDT(WDT_ON & WDTPSA_4 & WDTPSB_14);
               _FWDT(WDT_ON & WDTPSA_4 & WDTPSB_15);
               _FWDT(WDT_ON & WDTPSA_4 & WDTPSB_16);
               

               FPOR
               ========
               _FPOR( PWRT_OFF );
               _FPOR( PWRT_2 );
               _FPOR( PWRT_4 );
               _FPOR( PWRT_8 );
               _FPOR( PWRT_16 );
               _FPOR( PWRT_32 );
               _FPOR( PWRT_64 );
               _FPOR( PWRT_128 );

               FGS
               ====
               _FGS(CODE_PROT_OFF);
               _FGS(CODE_PROT_ON);

               FBS
               ====
               _FBS(BSS_MEDIUM_FLASH_HIGH & BWRP_WRPROTECT_ON);
               _FBS(BSS_MEDIUM_FLASH_HIGH & BWRP_WRPROTECT_OFF);
               _FBS(BSS_SMALL_FLASH_HIGH & BWRP_WRPROTECT_ON);
               _FBS(BSS_SMALL_FLASH_HIGH & BWRP_WRPROTECT_OFF);
               _FBS(BSS_MEDIUM_FLASH_STD & BWRP_WRPROTECT_ON);
               _FBS(BSS_MEDIUM_FLASH_STD & BWRP_WRPROTECT_OFF);
               _FBS(BSS_SMALL_FLASH_STD & BWRP_WRPROTECT_ON);
               _FBS(BSS_SMALL_FLASH_STD & BWRP_WRPROTECT_OFF);
               _FBS(BSS_NO_FLASH);
               
 ---------------------------------------------------------------------------- */


/* -------------------------------------------- */
/* Some useful macros for inline assembly stuff */
/* -------------------------------------------- */

#define Nop()    {__asm__ volatile ("nop");}
#define ClrWdt() {__asm__ volatile ("clrwdt");}
#define Sleep()  {__asm__ volatile ("pwrsav #0");}
#define Idle()   {__asm__ volatile ("pwrsav #1");}

/* ---------------------------------------------------------- */
/* Some useful macros for allocating data memory              */
/* ---------------------------------------------------------- */

/* The following macros require an argument N that specifies  */
/* alignment. N must a power of two, minimum value = 2.       */
/* For example, to declare an uninitialized array in X memory */
/* that is aligned to a 32 byte address:                      */
/*                                                            */
/* int _XBSS(32) xbuf[16];                                    */
/*                                                            */
#define _XBSS(N)    __attribute__((space(xmemory),aligned(N)))
#define _XDATA(N)   __attribute__((space(xmemory),aligned(N)))
#define _YBSS(N)    __attribute__((space(ymemory),aligned(N)))
#define _YDATA(N)   __attribute__((space(ymemory),aligned(N)))

/* The following macros do not require an argument. They can  */
/* be used to locate a variable in persistent data memory or  */
/* in near data memory. For example, to declare two variables */
/* that retain their values across a device reset:            */
/*                                                            */
/* int _PERSISTENT var1,var2;                                 */
/*                                                            */
#define _PERSISTENT __attribute__((persistent))
#define _NEAR       __attribute__((near))

/* ---------------------------------------------------------- */
/* Some useful macros for declaring functions                 */
/* ---------------------------------------------------------- */

/* The following macros can be used to declare interrupt      */
/* service routines (ISRs). For example, to declare an ISR    */
/* for the timer1 interrupt:                                  */
/*                                                            */
/* void _ISR _T1Interrupt(void);                              */
/*                                                            */
/* To declare an ISR for the SPI1 interrupt with fast         */
/* context save:                                              */
/*                                                            */
/* void _ISRFAST _SPI1Interrupt(void);                        */
/*                                                            */
/* Note: ISRs will be installed into the interrupt vector     */
/* tables automatically if the reserved names listed in the   */
/* MPLAB C30 Compiler User's Guide (DS51284) are used.        */
/*                                                            */
#define _ISR __attribute__((interrupt))
#define _ISRFAST __attribute__((interrupt, shadow))

/* ---------------------------------------------------------- */
/* Some useful macros for changing the CPU IPL                */
/* ---------------------------------------------------------- */

/* The following macros can be used to modify the current CPU */
/* IPL. The definition of the macro may vary from device to   */
/* device.                                                    */
/*                                                            */
/* To safely set the CPU IPL, use SET_CPU_IPL(ipl); the       */
/* valid range of ipl is 0-7, it may be any expression.       */
/*                                                            */
/* SET_CPU_IPL(7);                                            */
/*                                                            */
/* To preserve the current IPL and save it use                */
/* SET_AND_SAVE_CPU_IPL(save_to, ipl); the valid range of ipl */
/* is 0-7 and may be any expression, save_to should denote    */
/* some temporary storage.                                    */
/*                                                            */
/* int old_ipl;                                               */
/*                                                            */
/* SET_AND_SAVE_CPU_IPL(old_ipl, 7);                          */
/*                                                            */
/* The IPL can be restored with RESTORE_CPU_IPL(saved_to)     */
/*                                                            */
/* RESTORE_CPU_IPL(old_ipl);                                  */

#define SET_CPU_IPL(ipl) {       \
  int DISI_save;                 \
                                 \
  DISI_save = DISICNT;           \
  asm volatile ("disi #0x3FFF"); \
  SRbits.IPL = ipl;              \
  DISICNT = DISI_save; } (void) 0;

#define SET_AND_SAVE_CPU_IPL(save_to, ipl) { \
  save_to = SRbits.IPL; \
  SET_CPU_IPL(ipl); } (void) 0;

#define RESTORE_CPU_IPL(saved_to) SET_CPU_IPL(saved_to)

#endif

