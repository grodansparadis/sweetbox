2007 Microchip 16bit Design Competion Entry.

Registration Number: MT1769
Title: dsPIC LCR Meter

Folders & Files included with submission:


MT1769_Documentation.ZIP
	MT1769_Abstract.DOC
	MT1769_Full_Documentation.DOC


MT1769_Schematics.ZIP
	MT1769_Schematic_Pg1.GIF
	MT1769_Schematic_Pg2.GIF	
	MT1769_Schematic_Pg3.GIF
	MT1769_Schematic_Pg4.GIF
	MT1769_Schematic_Pg5.GIF

MT1769_Images.ZIP
	MT1769_AC_Waveform.GIF
	MT1769_Block_Diagram.GIF
	MT1769_Circuit_1.JPEG
	MT1769_Circuit_2.JPEG
	MT1769_Circuit_3.JPEG
	MT1769_Circuit_4.JPEG
	MT1769_Circuit_Diagram.GIF
	MT1769_Data_Aquisition.GIF
	MT1769_LCD_1.JPEG
	MT1769_LCD_2.JPEG
	MT1769_LCD_3.JPEG
	MT1769_LCD_4.JPEG
	MT1769_Program_Flow.GIF
	MT1769_System.JPEG
	MT1769_Zero_Crossing.GIF


MT1769_Source_Code.ZIP
	CustomDSP_Functions.c
	CustomDSP_Functions.h
	dsPIC_LCR_Meter.mcp
	dsPIC_LCR_Meter.mcs
	dsPIC_LCR_Meter.mcw
	dsPIC_LCR_Meter.mptags
	dsPIC_LCR_Meter.tagsrc
	Graphic LCD.c
	Graphic LCD.h
	HexFile.Hex
	IIR_BP_1K.s
	IIR_BP_10K.s
	IIR_BP_100.s
	LCR METER FUNCS.c
	LCR METER FUNCS.h
	LCR METER INIT.c
	LCR METER INIT.h
	Main.c
	SPI DDS.c
	SPI DDS.h
	SPI GPIO.C
	SPI GPIO.h
	SPI MCP PGA.c
	SPI MCP PGA.h
	SPI POT.c
	SPI POT.h
	V1KFIR_DEC_V.s
	V100FIR_DEC_V.s

	
END FILE.
