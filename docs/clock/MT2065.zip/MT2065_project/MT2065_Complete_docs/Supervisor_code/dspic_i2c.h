#ifndef DSPIC_I2C_H
#define DSPIC_I2C_H

//
//  dspic_i2c.h
//
// Registration # MT2065.
//

#include	"dspic_environ.h"

#define DSPIC_I2C_BASE_ADDRESS  0xC0

// sspcon commands
#define START_EN            0x01
#define REP_START_EN        0x02
#define STOP_EN             0x04
#define RECV_EN             0x08
#define ACK_EN              0x10

#define I2C_BUFFER_SIZE     255

void reset_i2c_bus(void);
void set_i2ccon(ushort data);
void send_i2c_byte(utiny data);
void i2c_start(void);
void i2c_start_read(utiny device, utiny send_count, bool send_checksum);
void i2c_read_bytes(utiny *data, utiny num_bytes, bool send_ack);
void i2c_finish(void);
utiny i2c_packet(utiny address, utiny send_count, utiny read_count);
void i2c_init(void);

#endif
