#ifndef DSPIC_DELAY_C
#define DSPIC_DELAY_C
//
// dspic_delay.c -- 
//
// Registration # MT2065.
//
// This module provides simple time-delay routines. The delays are not precise, just
// approximations. No interrupts are used, so these delays are good for routine
// non-critical things.
//

#include	"dspic_delay.h"


void Delay10Us(utiny cnt)
// Delay from 1 to 255 uS. It's a very rough estimate...
// The DelayMs() routine does a scaling based on the
// MPU's clock frequency.
{
	utiny kk, jj;
	
	for (jj=0; jj<cnt; jj++)
	{
		for (kk=0; kk<1; kk++)
		{
			continue;
		}
	}
}


void DelayShort(ushort cnt)
{
    utiny i;
    
    if (cnt < 1) cnt = 1;
  	do {
  		i = 7;
  		do {
  			Delay10Us(11);
  			ClrWdt();
  		} while(--i);
  	} while(--cnt);
}    


void DelayMs(ushort cnt)
// Delay from 1 to about 65000 mS. 
{
	if (cnt <= 255)
    	{
    	DelayShort(cnt);
    	}
    else
        {
        cnt = cnt / 250;
	    do {
		    DelayShort(250);
		    ClrWdt();
	    } while(--cnt);
        }    
}

#endif
