//
// dspic_main.c -- This is the code that runs on a dsPIC30F6014A on the 
// "dsPICDEM 1.1 Plus Development Board".
//
// Registration # MT2065.
//

#include <stdio.h>
#include <stdlib.h>
#include "p30fxxxx.h"
#include "dspic_main.h"
#include "dspic_delay.h"
#include "dspic_i2c.h"

// --------------------------------------------------
// Setup configuration bits
//
//_FOSC(XT)
// The PICDEM board's crystal osc became unreliable - use FRC instead.
_FOSC(FRC)
_FWDT(WDT_OFF) // Watch-Dog timer is off

// --------------------------------------------------
// Declare interrupt ISRs
/*
// INT0 interrupt:
void __attribute__((__interrupt__, no_auto_psv)) _INT0Interrupt(void);

// INT1 interrupt:
void __attribute__((__interrupt__, no_auto_psv)) _INT1Interrupt(void);
*/
// Timer2 interrupt:
void __attribute__((__interrupt__, no_auto_psv)) _T2Interrupt(void);

// Interrupt-On-Change pins:
void __attribute__((__interrupt__, no_auto_psv)) _CNInterrupt(void);

// --------------------------------------------------
// Declare global vars.

//unsigned char	    sci_count;
//volatile bool	    sci_ready;
//utiny             buff64[64];
bool			    heartbeat, send_UART1_flag, send_UART2_flag, read_atod, data_ready;
timing_structure    timing;
ushort			    second_ticks;
utiny               sent_count, sending_count, receive_count;
utiny               atod_channel, kk_INT1, menu_pos,
                    gain_val, channel_val, vref_val, trigger_val, delay_val, pulsewidth_val;
ushort              voltage;
utiny               bin_index;
#define             RAW_BIN_COUNT   126
ushort              raw_bins[RAW_BIN_COUNT];
#define             BIN_COUNT       128
utiny               bins[BIN_COUNT];
utiny               muon_bins[BIN_COUNT];
#define             LCD_COLUMN_COUNT    122
char                lcd_str[20];
GM_structure        GM_data, total_GM_data;

// How many top-level menu items there are.
#define MENU_SIZE   9

// --------------------------------------------------
// Functions.

ushort get_voltage (utiny sel)
// Do an A/D reading on the indicated channel (0-8). Return a value between 0
// and 1023.
{
    ushort val;
    
    // Configure A/D Module
    ADCHS = (sel & 0x000F);     // select the channel
    ADCON1bits.SAMP = 1;        // start sampling
    Delay10Us(2);               // acquisition time
    ADCON1bits.SAMP = 0;        // start conversion
    while (!ADCON1bits.DONE)    // wait for conversion to complete
    {
        ClrWdt();    
    }
    val = ADCBUF0;              // get the value
    return(val);
} // get_voltage()


void dspic_init(void)
// Init the dsPIC.
{
	//-------------------------------------
    // Setup I/O ports.
    
	// 
    TRISA = 0b1111111111111111;
	LATA  = 0b1111000000000000;
    
	// 
    TRISB = 0b1111111111011011; // b2:SS1
	LATB  = 0b0000000000100000;

	// 
    TRISC = 0b1111111111111111;
	LATC  = 0b0000000000000000;

    // 
    TRISD = 0b1110000001010000;
	LATD  = 0b0000111100001111;

	// 
    TRISF = 0b1111111111010111;
	LATF  = 0b0000000000000000;
	
	// 
    TRISG = 0b1111110010111111;
	LATG  = 0b0000000000000000;

	//-------------------------------------
	// Setup I2C Master communications.
	i2c_init();
	
	//-------------------------------------
	// Setup Timers.
    timing.second_tick = 0;
    timing.seconds = 0;
    
	// Setup Timer2, which is used for routine timekeeping:
	T2CON  = 0b1000000000010000;    // Timer2 on, prescale 1:8
    PR2    = 0x0900;				// Timer2 period for 10ms ints with 7.3728 Mhz clock.
	TMR2   = 0;
	IFS0bits.T2IF = 0;	// clear the interrupt flag

	//-------------------------------------
    // Setup A/D conversion.
    ADCON1 = 0b1000000000000000; // turn on the A/D module
    ADCON2 = 0b0000000000000000; // Internal Vref+, Vss; channel 0
    ADCON3 = 0b0000000000000100; // 
    ADCHS  = 0b0000000000000000; // select AN0
    ADPCFG = 0b1111111111111110; // enable AN0 as analog input
    ADCSSL = 0b0000000000000000;
    
    //-------------------------------------
	// Setup the oscillator.
	// Timer2 is set up to interrupt every 10 mS with a 7.3728 Mhz clock. So every
	// 100 ticks will be 1 second.
	T2CON  = 0b1000000000010000;    // Timer2 on, prescale 1:8
	second_ticks = 100;

    //-------------------------------------
    // Setup the serial ports. Choices are 38400, 19200, 9600, 4800, 2400.
    init_UART1(4800);
    //init_UART2(38400);
    
    //-------------------------------------
    // Setup SPI for talking to the PGAs and the LCD controller.
    SPI2CONbits.SMP     = 0;
    SPI2CONbits.CKE     = 0;
    SPI2CONbits.CKP     = 0;
    SPI2CONbits.MODE16  = 0;
    SPI2CONbits.MSTEN   = 1;
    SPI2STATbits.SPIEN  = 1;

    ClrWdt();
    
    //-------------------------------------
    // Setup interrupts.
    INTCON2 = 0b0000000000000011; // INT0 and INT1 negative edge
    // Set NSTDIS if nested ints are not wanted.
	// Set the priority levels for ints we are using.
	// All peripherals default to level 4.
	//IPC0  = 0b0000000000000101; // INT0 priority 5
	//IPC1  = 0b0000000000000000;
	//IPC2  = 0b0000000000000000;
	//IPC3  = 0b0000000000000000;
	//IPC4  = 0b0100010001000110; // INT1 priority 6
	// Enable int-on-change bits.
	CNEN1 = 0b0000000000000000;
	// Clear the flags for all interrupts.
	IFS0  = 0b0000000000000000;
	IFS1  = 0b0000000000000000;
	IFS2  = 0b0000000000000000;
    // Enable the interrupts we are using.
    IEC0  = 0b0000000001000000; // b15:PortChange, b13:Slave I2C, b6:Timer2, b0:INT0
	IEC1  = 0b0000000000000000; // b0:INT1
	IEC2  = 0b0000000000000000;
} // dspic_init()


void send_SPI2(utiny dat)
// Send a byte on SPI2.
    {
    ushort kk;
    
    kk = SPI2BUF;
    SPI2BUF = dat;
    while( SPI2STATbits.SPITBF )
        ClrWdt();
    }
    
    
void put_pixel(utiny X, utiny Y)
// Draw a pixel on the LCD at the specified location.
    {
    send_SPI2( 0xD8 );
    send_SPI2( X );
    send_SPI2( Y );
    }
    
    
void put_char(char ch, utiny X, utiny Y)
// Put a char on the LCD at the specified location.
    {
    send_SPI2( 0xE6 );
	send_SPI2( ch );
	send_SPI2( X );
	send_SPI2( Y );
    }
    
    
void put_string(utiny X, utiny Y)
// Write a string on the LCD at the specified location.
    {
    utiny kk;
    
    for (kk=0; kk<20; kk++)
        {
        if (lcd_str[kk])
            put_char(lcd_str[kk], (X+kk), Y);
        else
            break;
        }
    }
    
    
void clear_display(void)
// Clear the LCD display.
    {
    send_SPI2( 0x82 );       // clear home
	DelayMs(50);
    }
    
    
void set_PGA_gain(utiny gain)
// Send commands to the PGAs to set the specified gain. The 2 PGAs are
// daisy-chained. When there's a choice, give the first PGA the higher
// gain setting, to improve the noise figure.
    {
    LATBbits.LATB2 = 0;
    DelayMs(20);
    
    // Select the gain.
    if (gain == 0)
        {
        send_SPI2( 0b00100000 ); // shutdown
        send_SPI2( 0b00100000 ); // shutdown
        }
    
    if (gain == 1)
        {
        send_SPI2( 0b01000000 ); // register write
        send_SPI2( 0b00000000 ); // gain 1X
        send_SPI2( 0b01000000 ); // register write
        send_SPI2( 0b00000000 ); // gain 1X
        }
        
    if (gain == 2)
        {
        send_SPI2( 0b01000000 ); // register write
        send_SPI2( 0b00000000 ); // gain 1X
        send_SPI2( 0b01000000 ); // register write
        send_SPI2( 0b00000001 ); // gain 2X
        }
        
    if (gain == 4)
        {
        send_SPI2( 0b01000000 ); // register write
        send_SPI2( 0b00000000 ); // gain 1X
        send_SPI2( 0b01000000 ); // register write
        send_SPI2( 0b00000010 ); // gain 4X
        }
        
    if (gain == 5)
        {
        send_SPI2( 0b01000000 ); // register write
        send_SPI2( 0b00000000 ); // gain 1X
        send_SPI2( 0b01000000 ); // register write
        send_SPI2( 0b00000011 ); // gain 5X
        }
        
    if (gain == 8)
        {
        send_SPI2( 0b01000000 ); // register write
        send_SPI2( 0b00000000 ); // gain 1X
        send_SPI2( 0b01000000 ); // register write
        send_SPI2( 0b00000100 ); // gain 8X
        }
        
    if (gain == 10)
        {
        send_SPI2( 0b01000000 ); // register write
        send_SPI2( 0b00000000 ); // gain 1X
        send_SPI2( 0b01000000 ); // register write
        send_SPI2( 0b00000101 ); // gain 10X
        }
        
    if (gain == 16)
        {
        send_SPI2( 0b01000000 ); // register write
        send_SPI2( 0b00000000 ); // gain 1X
        send_SPI2( 0b01000000 ); // register write
        send_SPI2( 0b00000110 ); // gain 16X
        }
        
    if (gain == 32)
        {
        send_SPI2( 0b01000000 ); // register write
        send_SPI2( 0b00000000 ); // gain 1X
        send_SPI2( 0b01000000 ); // register write
        send_SPI2( 0b00000111 ); // gain 32X
        }
        
    if (gain == 64)
        {
        send_SPI2( 0b01000000 ); // register write
        send_SPI2( 0b00000001 ); // gain 2X
        send_SPI2( 0b01000000 ); // register write
        send_SPI2( 0b00000111 ); // gain 32X
        }
    
    DelayMs(20);
    LATBbits.LATB2 = 1;
    DelayMs(20);
    } // set_PGA_gain()
    
    
void set_PGA_channel(utiny channel)
// Select an input channel for the first PGA. The second PGA is always
// channel 0.
    {
    LATBbits.LATB2 = 0;
    DelayMs(20);
    
    // Select the input to use.
    send_SPI2( 0b01000001 ); // channel register write
    send_SPI2( 0b00000000 ); // always channel 0 for U4
    send_SPI2( 0b01000001 ); // channel register write
    send_SPI2( channel );    // channel # for U3
    
    DelayMs(20);
    LATBbits.LATB2 = 1;
    DelayMs(20);
    } // set_PGA_gain()
    
    
void pot_setting(enum digital_pots pot, utiny setting)
// Set a position for a digital pot. Since we don't know the starting
// position, first move the wiper all the way to the bottom, then move
// it back up to the right spot.
{
    utiny kk;
    
    // Move wiper to the bottom.
    UP_DOWN = 0; // decrement
    if (pot == VREF_POT)
        CS2 = 0;
    else // TRIGGER_LEVEL_POT
        CS3 = 0;
    for (kk=0; kk<64; kk++)
        {
  		UP_DOWN = 0;
  		UP_DOWN = 1;
        }
    CS2 = 1;
    CS3 = 1;
    
    // Move wiper up to the desired spot.
    UP_DOWN = 1; // increment
    if (pot == VREF_POT)
        CS2 = 0;
    else // TRIGGER_LEVEL_POT
        CS3 = 0;
    for (kk=0; kk<setting; kk++)
        {
  		UP_DOWN = 0;
  		UP_DOWN = 1;
        }
    CS2 = 1;
    CS3 = 1;
} // pot_setting()


enum buttons button_pressed(void)
// Is a button currently being pressed?
{
    enum buttons but = NO_BUTTON;
    ushort but_bits;
    
    but_bits = (utiny)(PORTA & 0xF000);
    if (but_bits != 0xF000) // a button is pressed
    {
        DelayMs(20); // debounce
        but_bits = (PORTA & 0xF000);
        
        if (but_bits == 0xE000) but = CHOOSE;
        if (but_bits == 0xD000) but = VAL_UP;
        if (but_bits == 0xB000) but = VAL_DN;
        if (but_bits == 0x7000) but = SELECT;
    }
    // Wait for button to be released.
    while (but_bits != 0xF000)
    {
        LED4 = 0; // LED on
        but_bits = (PORTA & 0xF000);
        DelayMs(20); // debounce
    }
    LED4 = 1; // LED off
    return(but);
} // button_pressed()


void show_menu_item(void)
// Display the current main menu item.
    {
    LATGbits.LATG9 = 0;
    DelayMs(20);
    clear_display();
    
    switch (menu_pos)
        {
        case 1:
            sprintf(lcd_str, "Scintillator Sample");
            put_string(0, 0);
            break;
        case 2:
            sprintf(lcd_str, "Geiger Sample");
            put_string(0, 0);
            break;
        case 3:
            sprintf(lcd_str, "Scint Defaults");
            put_string(0, 0);
            break;
        case 4:
            sprintf(lcd_str, "Gain");
            put_string(0, 0);
            sprintf(lcd_str, "%d", gain_val);
            put_string(0, 1);
            break;
        case 5:
            sprintf(lcd_str, "Channel");
            put_string(0, 0);
            sprintf(lcd_str, "%d", channel_val);
            put_string(0, 1);
            break;
        case 6:
            sprintf(lcd_str, "Vref");
            put_string(0, 0);
            sprintf(lcd_str, "%d", vref_val);
            put_string(0, 1);
            break;
        case 7:
            sprintf(lcd_str, "Trigger");
            put_string(0, 0);
            sprintf(lcd_str, "%d", trigger_val);
            put_string(0, 1);
            break;
        case 8:
            sprintf(lcd_str, "Delay Factor X .31uS");
            put_string(0, 0);
            sprintf(lcd_str, "%d", delay_val);
            put_string(0, 1);
            break;
        case 9:
            sprintf(lcd_str, "Cal. Pulse Width");
            put_string(0, 0);
            sprintf(lcd_str, "%d", pulsewidth_val);
            put_string(0, 1);
            break;
        default:
            break;
        }        
    
    // Delay a bit before de-selecting the display, otherwise it will lock up.
    DelayMs(20);
    LATGbits.LATG9 = 1;
    } // show_menu_item()
    
    
void set_delay_factor(ushort delay)
// Send a command to a processor to set its delay factor.
{
    utiny mm;
    
    for (mm=0; mm<3; mm++)
        {
        i2c_data[0] = 0x28;   // cmd to set the delay factor
        i2c_data[1] = (utiny)(delay & 0x00FF);
        i2c_data[2] = (utiny)(delay >> 8);
        i2c_packet((utiny)(DSPIC_I2C_BASE_ADDRESS+(mm*2)), 3, 4);
        DelayMs(50);
        }
} // set_delay_factor()
    

void do_button(enum buttons button)
// Do what's indicated by a button press.
    {
    utiny kk, mm, index;
    ushort bin_val;
    
    LATGbits.LATG9 = 0;
    
    // The user is moving through the menu options.
    if (button == CHOOSE)
        {
        if (menu_pos < MENU_SIZE)
            menu_pos++;
        else
            menu_pos = 1;
        show_menu_item();
        }
    
    // Increase the value of the current option.
    if (button == VAL_UP)
        {
        switch (menu_pos)
            {
            case 5:
                gain_val++;
                break;
            case 6:
                channel_val++;
                break;
            case 7:
                vref_val++;
                break;
            case 8:
                trigger_val++;
                break;
            case 9:
                delay_val++;
                break;
            case 10:
                pulsewidth_val++;
                break;
            default:
                break;
            }
        show_menu_item();
        }
    
    // Decrease the value of the current option.
    if (button == VAL_DN)
        {
        switch (menu_pos)
            {
            case 5:
                gain_val--;
                break;
            case 6:
                channel_val--;
                break;
            case 7:
                vref_val--;
                break;
            case 8:
                trigger_val--;
                break;
            case 9:
                delay_val--;
                break;
            case 10:
                pulsewidth_val--;
                break;
            default:
                break;
            }
        show_menu_item();
        }
    
    // Execute the currently-displayed option.
    if (button == SELECT)
        {
        switch (menu_pos)
            {
            case 1:
                //
                // Start a scint sampling session.
                //
                clear_display();
                sprintf(lcd_str, "Sampling");
                put_string(0, 0);
                
                set_PGA_gain(0);
                DelayMs(20);
            
    	        for (mm=0; mm<3; mm++)
                    {
                    i2c_data[0] = 0x26;   // cmd to start a scint sampling session
                  	i2c_data[1] = 0;
                    i2c_packet((utiny)(DSPIC_I2C_BASE_ADDRESS+(mm*2)), 2, 4);
                    DelayMs(20);
                    }
                    
                set_PGA_gain(gain_val);
                
                DelayMs(15000);
                
                // Stop a scint sampling session.
                for (mm=0; mm<3; mm++)
                    {
                    i2c_data[0] = 0x27;   // cmd to stop a scint sampling session
                  	i2c_data[1] = 0;
                    i2c_packet((utiny)(DSPIC_I2C_BASE_ADDRESS+(mm*2)), 2, 4);
                    DelayMs(20);
                    }
                    
                // Zero the data bins.
                for (kk=0; kk<RAW_BIN_COUNT; kk++)
                    raw_bins[kk] = 0xFFFF;      // pulses are negative
                for (kk=0; kk<BIN_COUNT; kk++)
                    bins[kk] = 0;
                    
                for (mm=0; mm<3; mm++)
                    {
                    // Read the captured data.
                    i2c_data[0] = 0x24;   // cmd to read the data
                  	i2c_data[1] = 0;      // 
                    i2c_packet((utiny)(DSPIC_I2C_BASE_ADDRESS+(mm*2)), 2, ((RAW_BIN_COUNT*2)+2));
                    
                    for (kk=0; kk<RAW_BIN_COUNT; kk++)
                        {
                        bin_val = (ushort)(i2c_data[(kk*2)+1] + (i2c_data[(kk*2)+2] * 256));
                        if (bin_val < raw_bins[kk])
                            raw_bins[kk] = bin_val;
                        }  
                    
                    // Display the data.
                    //sprintf(lcd_str, "%02x%02x %02x%02x %02x%02x %02x%02x", 
                    //    bins[1], bins[0], bins[3], bins[2], bins[5], bins[4], bins[7], bins[6] );
                    //put_string(0, (mm+1));
                    }
                    
                // Sort the data into the bins.
                for (kk=0; kk<RAW_BIN_COUNT; kk++)
                    {
                    index = (utiny)((ushort)(0x03FF - raw_bins[kk]) >> 3);
                    if (index > 121) index = 121;
                    bins[index]++;
                    }
                    
                // Display the bins.
                LATGbits.LATG9 = 0;
                DelayMs(50);
                clear_display();
                for (kk=0; kk<BIN_COUNT; kk++)
                    {
                    for (mm=0; mm<bins[kk]; mm++)
                        {
                        if (mm < 32)
                            put_pixel(kk, mm);
                        }    
                    }
                DelayMs(50);
                LATGbits.LATG9 = 1;
                break;
            case 2:
                //
                // Start a Geiger sampling session.
                //
                clear_display();
                sprintf(lcd_str, "Sampling");
                put_string(0, 0);
                
                // The Geiger mode only uses one processor. Tell the other two to
                // slow down, to conserve power.
                i2c_data[0] = 0x21;   // cmd to run at 7 Mhz
              	i2c_data[1] = 0;
                i2c_packet((DSPIC_I2C_BASE_ADDRESS+2), 2, 4);
                DelayMs(20);
                i2c_data[0] = 0x21;   // cmd to run at 7 Mhz
              	i2c_data[1] = 0;
                i2c_packet((DSPIC_I2C_BASE_ADDRESS+4), 2, 4);
                DelayMs(20);
                
                // Zero the data bins.
                for (kk=0; kk<LCD_COLUMN_COUNT; kk++)
                {
                    bins[kk] = 0;
                    muon_bins[kk] = 0;   
                }    
                total_GM_data.count_1           = 0;
                total_GM_data.count_2           = 0;
                total_GM_data.coincidence_count = 0;
                    
                while(TRUE)
                    {
                    //
                    // Read the captured data.
                    //
                    i2c_data[0] = 0x2B;   // cmd to read the data
                  	i2c_data[1] = 0;      // 
                    i2c_packet(DSPIC_I2C_BASE_ADDRESS, 2, (6+2));
                    GM_data.count_1 = (ushort)(i2c_data[1] + (i2c_data[2] * 256));
                    GM_data.count_2 = (ushort)(i2c_data[3] + (i2c_data[4] * 256));
                    GM_data.coincidence_count = (ushort)(i2c_data[5] + (i2c_data[6] * 256));
                    total_GM_data.count_1           += GM_data.count_1;
                    total_GM_data.count_2           += GM_data.count_2;
                    total_GM_data.coincidence_count += GM_data.coincidence_count;
                    DelayMs(20);
                    
                    //
                    // Start a new Geiger sampling session.
                    //
                    i2c_data[0] = 0x29;   // cmd to start a Geiger sampling session
                  	i2c_data[1] = 0;
                    i2c_packet(DSPIC_I2C_BASE_ADDRESS, 2, 4);
                    DelayMs(20);
                    
                    //
                    // Display the latest data.
                    //
                    LATGbits.LATG9 = 0;
                    DelayMs(15);
                    clear_display();
                    // Shift the bins.
                    for (kk=0; kk<(LCD_COLUMN_COUNT-1); kk++)
                        {
                        bins[kk] = bins[kk+1];
                        muon_bins[kk] = muon_bins[kk+1];
                        }    
                    bins[LCD_COLUMN_COUNT-1]      = GM_data.count_1 + GM_data.count_2;
                    muon_bins[LCD_COLUMN_COUNT-1] = GM_data.coincidence_count;
                    // Display the bins in graphical form.
                    DelayMs(15);
                    for (kk=0; kk<LCD_COLUMN_COUNT; kk++)
                        {
                        for (mm=0; mm<bins[kk]; mm++)
                            {
                            if (mm < 22)
                                put_pixel(kk, mm);
                            }
                        for (mm=0; mm<muon_bins[kk]; mm++)
                            {
                            if (mm < 10)
                                put_pixel(kk, (mm+22));
                            }
                        }
                    // Delay a bit before showing the text values.
                    DelayMs(1500);
                    // Show the totals in text format.
                    sprintf(lcd_str, "%d %d %d", 
                        total_GM_data.count_1, total_GM_data.count_2, total_GM_data.coincidence_count );
                    put_string(0, 0);
                    // Finish writing to the LCD.
                    DelayMs(50);
                    LATGbits.LATG9 = 1;
                    
                    // Sampling time. 7 seconds is a useful value for monitoring background rads.
                    DelayMs(7000);
                    
                    //
                    // Stop a Geiger sampling session.
                    //
                    i2c_data[0] = 0x2A;   // cmd to stop a Geiger sampling session
                  	i2c_data[1] = 0;
                    i2c_packet(DSPIC_I2C_BASE_ADDRESS, 2, 4);
                    DelayMs(20);
                    
                    // If a button is pushed, exit the loop.
                    if (button_pressed() != NO_BUTTON) break;
                    } // while(TRUE)
                
                // Tell the 2nd and 3rd processors to go back to full speed.
                i2c_data[0] = 0x22;   // cmd to run at 118 Mhz
              	i2c_data[1] = 0;
                i2c_packet((DSPIC_I2C_BASE_ADDRESS+2), 2, 4);
                DelayMs(20);
                i2c_data[0] = 0x22;   // cmd to run at 118 Mhz
              	i2c_data[1] = 0;
                i2c_packet((DSPIC_I2C_BASE_ADDRESS+4), 2, 4);
                DelayMs(20);
                break;
            case 3:     // scint defaults
                channel_val = 0;
                set_PGA_channel(channel_val);
                DelayMs(50);
                gain_val = 1;
                set_PGA_gain(gain_val);                         // gain of X1
                DelayMs(50);
                vref_val = 0;
                pot_setting(VREF_POT, vref_val);                // Vref = 5V
                DelayMs(50);
                trigger_val = 5;
                pot_setting(TRIGGER_LEVEL_POT, trigger_val);    // Trigger < 5V
                DelayMs(50);
                delay_val = 6;
                set_delay_factor(delay_val);
                pulsewidth_val = 3;
                break;
            case 4:
                set_PGA_gain(gain_val);
                break;
            case 5:
                set_PGA_channel(channel_val);
                break;
            case 6:
                pot_setting(VREF_POT, vref_val);
                break;
            case 7:
                pot_setting(TRIGGER_LEVEL_POT, trigger_val);
                break;
            case 8:
                set_delay_factor(delay_val);
                break;
            case 9:
                break;
            default:
                break;
            }
        sprintf(lcd_str, "Z");
        put_string(19, 3);
        }
    
    button = NO_BUTTON;
    DelayMs(100);
    LATGbits.LATG9 = 1;
    } // do_button()

//--------------------------------------
// Main program.

int main(void)
{
    utiny kk, jj; //, max_bin, max_bin_value;
    enum buttons button;
    ushort voltage;
    
	ClrWdt();
	
	// Init the PIC, its ports, and peripherals.
    dspic_init();
    
    send_UART1_flag = FALSE;
    send_UART2_flag = FALSE;
    read_atod       = FALSE;
    
    HEARTBEAT_LED = 0; // LED on
	DelayMs(500);
	HEARTBEAT_LED = 1; // LED off
	DelayMs(100);
	
	printf("\nRad Supervisor");
	
	// Display something on the LCD.
    LATGbits.LATG9 = 0;
    DelayMs(50);
    clear_display();
    sprintf(lcd_str, "Rad");
    put_string(0, 3);
	for (kk=0; kk<32; kk++)
    	{
        put_pixel( kk, kk );
    	}
    // Delay a bit before de-selecting the display, otherwise it will lock up.
    DelayMs(50);
    LATGbits.LATG9 = 1;
    
    // Send a loopback message to the dsPIC slaves, to verify that we can talk to them.
    // We are sending 80 55 00 2B, and we expect to receive 80 2B 55.
    for (jj=0; jj<3; jj++)
        {
        i2c_data[0] = 0x80;
    	i2c_data[1] = 0x55;
    	i2c_data[2] = 0;
        i2c_packet((utiny)(DSPIC_I2C_BASE_ADDRESS+(jj*2)), 3, 3);
        printf("\ndsPIC %d, %02x %02x %02x, I2C ", jj, i2c_data[0], i2c_data[1], i2c_data[2]);
        if ((i2c_data[1] == 0x2B) && (i2c_data[2] == 0x55))
            {
            // Signal success.
            printf("OK");
            I2C_LED = 0; // on
            DelayMs(500);
            I2C_LED = 1; // off
            }
        else
            {
            // Signal failure.
            printf("Failed");
            for (kk=0; kk<5; kk++)
                {
                I2C_LED = 0; // on
                DelayMs(60);
                I2C_LED = 1; // off
                DelayMs(60);
                }    
            }
        }    
   
    // Set some defaults.
    channel_val = 0;
    set_PGA_channel(channel_val);
    DelayMs(100);
    // The SPI or the PGA seems to ignore the very first attempt, so
    // repeat it:
    set_PGA_channel(channel_val);
    DelayMs(100);
    
    gain_val = 1;
    set_PGA_gain(gain_val);                         // gain of X1
    DelayMs(100);
    
    vref_val = 0;
    pot_setting(VREF_POT, vref_val);                // Vref = 5V
    DelayMs(100);
    
    trigger_val = 5;
    pot_setting(TRIGGER_LEVEL_POT, trigger_val);    // Trigger < 5V
    DelayMs(100);
    
    delay_val = 6;
    set_delay_factor(delay_val);
    
    pulsewidth_val = 3;
    
	// Main program loop. Stay here forever.
	while(1)
	    {
		// Clear the Watchdog Timer (in case it's enabled).
		ClrWdt();
		
		// Was a button pressed?
        button = button_pressed();
        if (button != NO_BUTTON)
            do_button(button);
		
		// See if we've been asked to do any work.
		
		if (heartbeat)
		    {
		    HEARTBEAT_LED = 0; // LED on
	        DelayMs(10);
	        HEARTBEAT_LED = 1; // LED off
	        heartbeat = FALSE;
	        
	        // Get the current voltage, and display it.
	        voltage = (ushort)(get_voltage(0) * 0.404);
	        LATGbits.LATG9 = 0;
            DelayMs(15);
            sprintf(lcd_str, "%04d", (ushort)voltage);
            put_string(16, 0);
            DelayMs(15);
            LATGbits.LATG9 = 1;
	        }
	    }
} // main()

/*
void __attribute__((__interrupt__, no_auto_psv)) _INT0Interrupt(void)
// INT0 interrupt handler.
{
	IFS0bits.INT0IF = 0;	// clear the interrupt flag
} // INT0Interrupt()


void __attribute__((__interrupt__, no_auto_psv)) _INT1Interrupt(void)
// INT1 interrupt handler.
{
	IFS1bits.INT1IF = 0;	// clear the interrupt flag
} // INT1Interrupt()
*/

void __attribute__((__interrupt__, no_auto_psv)) _CNInterrupt(void)
// Port Change interrupts
{
    IFS0bits.CNIF = 0; // clear the flag
} // Port Change interrupt


void __attribute__((__interrupt__, no_auto_psv)) _T2Interrupt(void)
// Timer2 interrupt handler.
// Interrupts from Timer2 are used for general time-keeping. The interrupt occurs exactly
// every 10 mS (when the clock is 7.3728 Mhz), so we can use it to generate longer intervals easily.
{
    utiny kk;
    
	// Count the # of 10mS intervals.
    timing.tenMilSeconds++;
    timing.second_tick++;
    
    if (timing.second_tick > second_ticks)
    {
        // Do this stuff every second. Since the 'second_ticks' var is set according to the
        // current clock speed, stuff in this block can be made to happen every 1 second
        // even if we change clock speeds.
        
        // Count the # of seconds that have elapsed.
        timing.seconds++;
        // Count toward a 10-second interval.
        timing.ten_second_tick++;
		// Reset our tick counter to start the next 1-second interval.
        timing.second_tick = 0;
        // Set a flag that will cause the heartbeat LED to blink.
        heartbeat = TRUE;
    }
    
    // Here is where we generate the pulses for the Test Signal Generator.
    timing.calibrate_tick++;
    if (timing.calibrate_tick > CALIBRATE_TICKS)
        {
        timing.calibrate_tick = 0;
        CALIBRATE_OUT = 1;
        for (kk=0; kk<pulsewidth_val; kk++) Nop();
        CALIBRATE_OUT = 0;
        }
    
    if (timing.ten_second_tick > 9)
    {
        // Do this stuff every ten seconds.
        timing.ten_second_tick = 0;
        timing.tenSeconds++;
    }

	IFS0bits.T2IF = 0;	// clear the interrupt flag
} // T2Interrupt()
