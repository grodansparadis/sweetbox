//
// Registration # MT2065.
//
#ifndef DSPIC_DELAY_H
#define DSPIC_DELAY_H

#include	"dspic_environ.h"

// function prototypes
void Delay10Us(utiny cnt);
void DelayMs(ushort cnt);

#endif
