//
// dsipc_i2c.c - I2C Master routines.
//
// Registration # MT2065.
//

#include <stdio.h>
#include <p30fxxxx.h>
#include "dspic_i2c.h"
#include "dspic_delay.h"

utiny           	i2c_data[I2C_BUFFER_SIZE];
utiny           	i2c_checksum;

void reset_i2c_bus(void)
{
    TRISG  = 0b1111110010110011;
	TRISG  = 0b1111110010111111;
	LATG  |= 0b0000000000001100;
	
	I2CCONbits.PEN = 1;	// STOP
    Delay10Us(10);
    I2CCONbits.RCEN = 0;
    // reset I2C
    I2CCONbits.I2CEN = 0;	// Disable I2C Mode
    IFS0bits.MI2CIF = 0;	// Clear Interrupt
    I2CSTATbits.IWCOL = 0;
    I2CSTATbits.BCL = 0;
    I2CCONbits.I2CEN = 1;	// re-enable I2C
    IFS0bits.MI2CIF = 0;	// Clear Interrupt
    Nop();
	I2CCONbits.PEN = 1;	// STOP
    Delay10Us(8);
} // reset_i2c_bus()


void set_i2ccon(ushort data)
{
    utiny kk = 0;
    
    I2CCON |= data;  // Set I2CCON bit
    Nop();

    // wait for hardware clear
    while (data == (I2CCON & data))
    {
        DelayMs(1);
        kk++;
        if (kk > 20) break;
    }
} // set_i2ccon()


void send_i2c_byte(utiny data)
{
    ushort i;

	while (I2CSTATbits.TBF) { }
    IFS0bits.MI2CIF = 0;	// Clear Interrupt
    I2CTRN = data;			// load the outgoing data byte

    // wait for transmission
    for (i = 0; i < 500; i++)
    {
        // Poll for the interrupt flag.
		if (!I2CSTATbits.TRSTAT) break; // plm - is this OK?
        //if (IFS1bits.MI2CIF == 1) break;
        Delay10Us(1);
    }
    if (i == 500)
    {
        // Failed.
        printf("\nsend_i2c_byte tmo");
    }

    // Check for NO_ACK from slave
    if (I2CSTATbits.ACKSTAT == 1)
    {
        // Failed.
        printf("\nsend_i2c_byte NO_ACK");
        reset_i2c_bus();
    }
    DelayMs(5); // plm - shorten this?
} // send_i2c_byte()


void i2c_start(void)
{
    I2CCONbits.ACKDT = 0; // ack
    DelayMs(3);
    set_i2ccon(START_EN);
    if (I2CCONbits.SEN)
    {
        // Failed.   
    }
    DelayMs(2);
} // i2c_start()


void i2c_start_read(utiny device, utiny send_count, bool send_checksum)
{
    utiny kk;
    
    i2c_checksum = 0;
    i2c_start();
    send_i2c_byte( device ); // mode is WRITE
    for (kk=0; kk<send_count; kk++)
        {
        send_i2c_byte( i2c_data[kk] );
        i2c_checksum += i2c_data[kk];
        }
    if (send_checksum)
        {
        send_i2c_byte( (utiny)(256 - i2c_checksum) ); // send checksum
        }
    set_i2ccon(REP_START_EN); // Repeated Start, to change from WRITE to READ
    DelayMs(2);
    send_i2c_byte(0x01 | device);   // mode is READ
    DelayMs(20); // plm
    set_i2ccon(RECV_EN);   // enable receive mode (wait for RCEN to clear)
    i2c_checksum = 0;
} // i2c_start_read()


void i2c_read_bytes(utiny *data, utiny num_bytes, bool send_ack)
{
    while(num_bytes > 0)
    {
        *data = I2CRCV;
        i2c_checksum += *data;
        data++;
        IFS0bits.MI2CIF = 0;	// Clear Interrupt
        num_bytes--;
        if ((num_bytes > 0) || send_ack)
        {
            set_i2ccon(ACK_EN);      //send ack
            DelayMs(2);
            set_i2ccon(RECV_EN);
            Nop();
        }
    }
} // i2c_read_bytes()


void i2c_finish(void)
{
    I2CCONbits.ACKDT = 1;	// Set NACK cause we're done
    set_i2ccon(ACK_EN);	// Acknowledge
    DelayMs(2);
    set_i2ccon(STOP_EN);	// Stop
    IFS0bits.MI2CIF = 0;	// Clear Interrupt
} // i2c_finish()


utiny i2c_packet(utiny address, utiny send_count, utiny read_count)
{
    utiny status = 0;
    
    i2c_start_read(address, send_count, TRUE); // include checksum byte
    i2c_read_bytes( (utiny *)&i2c_data[0], read_count, FALSE);
    i2c_finish();
    
    return(status);
} // i2c_packet()


void i2c_init(void)
{
    utiny temp;
    	
	I2CBRG = 50;				// baud rate is ?
	I2CCONbits.I2CEN = 0;      // Disable I2C Mode
	I2CCONbits.DISSLW = 1;		// Disable slew rate control
    IFS0bits.MI2CIF = 0;       // Clear Interrupt
    I2CCONbits.I2CEN = 1;      // Enable I2C Mode
    temp = I2CRCV;          	// read buffer to clear buffer full
    reset_i2c_bus();
} // i2c_init()
