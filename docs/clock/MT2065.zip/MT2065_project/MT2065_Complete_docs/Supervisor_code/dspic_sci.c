//
// dspic_main.c -- 
// 
// Registration # MT2065.
//
// This module does some serial port (UART) stuff.
//

#include <p30fxxxx.h>
#include "dspic_sci.h"

volatile utiny sci_byte;


void init_UART1(ulong baud)
// Init UART1. Assume the oscillator is 7.3728 Mhz.
{
    switch (baud)
    {
        case 38400:
        {
            U1BRG = 2;
            break;   
        }
        case 19200:
        {
            U1BRG = 5;
            break;   
        }
        case 9600:
        {
            U1BRG = 11;
            break;   
        }
        case 4800:
        {
            U1BRG = 23;
            break;   
        }
        default: // 2400 baud
        {
            U1BRG = 47;
        }
    }
    
    U1TXREG = 0;
    U1MODE = 0b1000010000000000;
    U1STA  = 0b0000010000000000;
} // init_UART1()


void init_UART2(ulong baud)
// Init UART2. Assume the oscillator is 7.3728 Mhz.
{
    switch (baud)
    {
        case 38400:
        {
            U2BRG = 2;
            break;   
        }
        case 19200:
        {
            U2BRG = 5;
            break;   
        }
        case 9600:
        {
            U2BRG = 11;
            break;   
        }
        case 4800:
        {
            U2BRG = 23;
            break;   
        }
        default: // 2400 baud
        {
            U2BRG = 47;
        }
    }
    
    U2TXREG = 0;
    U2MODE = 0b1000000000000000;
    U2STA  = 0b0000010000000000;
} // init_UART2()


void putch_UART1(utiny byte)
// Output a byte on UART1.
// Wait for the buffer to be empty.
{
    while(U1STAbits.UTXBF)
    {
        ClrWdt();
    }
    U1TXREG = byte;
    return;
} // putch_UART1()


void putch_UART2(utiny byte)
// Output a byte on UART2.
// Wait for the buffer to be empty.
{
    while(U2STAbits.UTXBF)
    {
        ClrWdt();
    }
    U2TXREG = byte;
    return;
} // putch_UART2()


/*
unsigned char getch(void)
{
    while(!RC1IF)   // set when register is not empty
    {
        continue;
    }

    return RCREG1;  // RXD9 and FERR are gone now
}
*/
