//
// Registration # MT2065.
//
#ifndef ENVIRON_H
#define ENVIRON_H

#include "p30fxxxx.h"

// basic types
#ifndef tiny
    typedef signed char     tiny;
#endif

#ifndef utiny
    typedef unsigned char   utiny;
#endif

#ifndef uchar
    typedef unsigned char   uchar;
#endif

#ifndef bool
    typedef unsigned char   bool;
#endif

#ifndef ushort
    typedef unsigned short  ushort;
#endif

#ifndef ulong
    typedef unsigned long   ulong;
#endif

// Boolean values
#define TRUE                    1
#define FALSE                   0

#define MHZ                     *1000L      // number of kHz in a MHz

#define SEC_IN_MIN              60          // number of seconds in a min (duh)
#define SEC_IN_HOUR             3600        // number of seconds in 1 hour
#define SEC_IN_DAY              86400       // number of seconds in 1 day
#define SEC_IN_HLF_HR           1800        // number of seconds in a half hour
#define SEC_IN_QTR_HR           900         // number of seconds in 15 minutes
#define CALIBRATE_TICKS         2

// Timing vars.
typedef struct _timing_structure
{
    utiny   tenMilSeconds;
    ushort  second_tick;
    utiny	seconds;
    utiny   calibrate_tick;
    utiny	ten_second_tick;
    utiny   tenSeconds;
    utiny	monitor_seconds;
    ushort  ee_update_seconds;
} timing_structure;

#endif //ENVIRON_H
