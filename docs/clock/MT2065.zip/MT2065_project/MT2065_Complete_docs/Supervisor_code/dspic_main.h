//
// Registration # MT2065.
//
#ifndef DSPIC_MAIN_H
#define DSPIC_MAIN_H

#include "dspic_environ.h"
#include "dspic_sci.h"
#include "dspic_i2c.h"

extern char			    sci_data_buffer[];
extern utiny		    sci_data_count;
extern utiny		    tmr2_expire_cnt;
extern utiny           	i2c_data[I2C_BUFFER_SIZE];
extern utiny		    checksum;

// Define individual bits.
#define HEARTBEAT_LED           LATDbits.LATD0
#define I2C_LED                 LATDbits.LATD1
#define LED3                    LATDbits.LATD2
#define LED4                    LATDbits.LATD3
#define GM1                     PORTBbits.RB4
#define GM2                     PORTBbits.RB5
#define CS1                     LATBbits.LATB2      // PGA CS
#define CS2                     LATDbits.LATD9      // Vref CS
#define CS3                     LATDbits.LATD10     // Trigger Lvl CS
#define UP_DOWN                 LATDbits.LATD11     // Pot up/down
#define CALIBRATE_OUT           LATDbits.LATD12     // 10 Hz out
#define SO                      LATFbits.LATF8      // SPI SDO
#define SCK                     LATFbits.LATF6      // SPI SCK
#define SCL                     PORTGbits.RG2       // I2C SCL
#define SDA                     PORTGbits.RG3       // I2C SDA

// Define names for the digital pots.
enum digital_pots {
    VREF_POT, 
    TRIGGER_LEVEL_POT };
    
// Define names for the 4 buttons.
enum buttons { NO_BUTTON, CHOOSE, VAL_UP, VAL_DN, SELECT };
    
// A struct for storing Geiger counts.
typedef struct _GM_structure
    {
    ushort  count_1;
    ushort  count_2;
    ushort  coincidence_count; // for Muons
    } GM_structure;

#endif
