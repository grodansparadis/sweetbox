//
// Registration # MT2065.
//
#ifndef DSPIC_MAIN_H
#define DSPIC_MAIN_H

#include "dspic_environ.h"
#include "dspic_sci.h"
#include "dspic_i2c.h"

extern volatile utiny	Osc_Freq_Mhz;
extern char			    sci_data_buffer[];
extern utiny		    sci_data_count;
extern utiny		    tmr2_expire_cnt;
extern utiny		    checksum;

// Define individual bits.
#define HEARTBEAT_LED           LATEbits.LATE5
#define I2C_ADDR_1              PORTEbits.RE0
#define I2C_ADDR_2              PORTEbits.RE1
#define I2C_ADDR_3              PORTEbits.RE2
#define VREF                    PORTBbits.RB0
#define AN2                     PORTBbits.RB2
#define AN3                     PORTBbits.RB3
#define AN4                     PORTBbits.RB4
#define INT0                    PORTEbits.RE8
#define INT1                    PORTDbits.RD0
#define INT2                    PORTDbits.RD1
#define SCL                     PORTFbits.RF3
#define SDA                     PORTFbits.RF2

typedef struct _GM_structure
{
    ushort  count_1;
    ushort  count_2;
    ushort  coincidence_count;
} GM_structure;

#endif
