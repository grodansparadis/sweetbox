//
// dspic_main.c -- This is code for the dsPIC30F4012 on a "Data Acquisition
// Processor".
//
// Registration # MT2065.
//

#include <stdio.h>
#include <stdlib.h>
#include "p30fxxxx.h"
#include "OscillatorSystemCodes.h"
#include "dspic_main.h"
#include "dspic_delay.h"
#include "dspic_i2c.h"

int clockSwitch (unsigned int);

// --------------------------------------------------
// Setup configuration bits
//
// Set the 'Primary Oscillator' to run at the highest possible speed. With a 7.3728 Mhz xtal,
// the freq is 117.965 Mhz, which is very close to the chip's rated max of 120 Mhz.
// Also enable 'clock-switching', so that we can change speeds on-the-fly.
_FOSC(XT_PLL16 & CSW_ON_FSCM_OFF)
_FWDT(WDT_OFF) // Watch-Dog timer is off
_FBORPOR(RST_IOPIN)

// --------------------------------------------------
// Declare interrupt ISRs

// INT0 interrupt:
void __attribute__((__interrupt__, no_auto_psv)) _INT0Interrupt(void);

// INT1 interrupt:
void __attribute__((__interrupt__, no_auto_psv)) _INT1Interrupt(void);

// Timer2 interrupt:
void __attribute__((__interrupt__, no_auto_psv)) _T2Interrupt(void);

// I2C Slave interrupt:
void __attribute__((__interrupt__, no_auto_psv)) _SI2CInterrupt(void);

// Interrupt-On-Change pins:
void __attribute__((__interrupt__, no_auto_psv)) _CNInterrupt(void);

// --------------------------------------------------
// Declare global vars.
//
bool			    heartbeat, send_UART1_flag, send_UART2_flag, read_atod, data_ready,
					read_scint_data,  scint_sample_session,
					read_geiger_data, geiger_sample_session,
					clock_7mhz, clock_118mhz;
timing_structure    timing;
ushort			    second_ticks;
utiny               atod_channel, kk_CN;
ushort              voltage, sample_count, portb, sample_delay, jj_INT0;
GM_structure        GM_data;
utiny               bin_index;
#define             BIN_COUNT   252  // must be a multiple of 2
utiny               bins[BIN_COUNT];
// I2C vars:
volatile dspic_i2c_buffer	i2c_in_buffer, i2c_out_buffer;
utiny               slave_address, sent_count, sending_count, receive_count;

// --------------------------------------------------
// Functions.
//

void set_clock_7mhz(void)
// Make the PIC clock run at 7.3728 Mhz, using the internal "Fast RC Oscillator"
// in the PIC. This slower speed saves a lot of power, and is good enough for
// most routine tasks.
{
	clockSwitch( NOSC_FRC ); // perform a clock switch to "FRC".
	// For the dspic_delay module - record about how fast our clock is.
	Osc_Freq_Mhz = 7;
	
    PR2    = 0x0900;				// Timer2 period for 10ms ints with 7.3728 Mhz clock.
	TMR2   = 0;
	IFS0bits.T2IF = 0;	// clear the interrupt flag
	
	// Set A/D conversion clk.
	ADCON3 = 0b0000000000000001;
} // set_clock_7mhz()


void set_clock_118mhz(void)
// Make the PIC clock run at 118 Mhz (actually 7.3728 X 16 = 117.965. This lets us 
// run pretty fast, but it uses a fair bit of current (110 mA or so).
{
    PR2    = 0x9000;				// Timer2 period for 10ms ints with 118 Mhz clock.
	TMR2   = 0;
	IFS0bits.T2IF = 0;	// clear the interrupt flag
	
	clockSwitch( NOSC_PRIOSC ); // perform a clock switch to "Primary Osc".
	// For the dspic_delay module - record about how fast our clock is.
	Osc_Freq_Mhz = 118;
	
	// Set A/D conversion clk.
	ADCON3 = 0b0000000000000100;
} // set_clock_118mhz()


ushort get_voltage (utiny sel)
// Do a general-purpose A/D reading on the indicated channel (0-8). Return a value 
// between 0 and 1023.
{
    ushort val;
    
    // Configure A/D Module
    ADCHS = (sel & 0x000F);     // select the channel
    ADCON1bits.SAMP = 1;        // start sampling
    Delay10Us(1);               // acquisition time
    ADCON1bits.SAMP = 0;        // start conversion
    while (!ADCON1bits.DONE)    // wait for conversion to complete
    {
        ClrWdt();    
    }
    val = ADCBUF0;              // get the value
    return(val);
} // get_voltage()


void dspic_init(void)
// Configure the dsPIC.
{
	//-------------------------------------
    // Setup I/O ports.
    
	// 
    TRISB = 0b1111111111111111;
	LATB  = 0b0000000000000000;

	// 
    TRISC = 0b1111111111111111;
	LATC  = 0b0000000000000000;

    // 
    TRISD = 0b1111111111111111;
	LATD  = 0b0000000000000000;

	// RE5 - heartbeat LED
	// RE3 - timing marker output
    TRISE = 0b1111111111010111;
	LATE  = 0b0000000000000000;
	
	// 
    TRISF = 0b1111111111111111;
	LATF  = 0b0000000000000000;
	
	// Disable PWM to enable I/O on PORTE.
	PWMCON1 = 0;
	
	//-------------------------------------
	// Setup Timers.
    timing.second_tick = 0;
    timing.seconds = 0;
    second_ticks = 100;
    T2CON  = 0b1000000000010000;    // Timer2 on, prescale 1:8

	//-------------------------------------
    // Setup A/D conversion.
    ADCON1 = 0b1000000000000000; // turn on the A/D module
    // b15:13=011 for external Vref
    ADCON2 = 0b0110000000000000; // 
    // Tcy is 33.9 nS.
    ADCON3 = 0b0000000000000100; // 4 is good, 3 is a bit over-clocked. Ideal is 3.9.
    ADCHS  = 0b0000000000000010; // select AN2
    ADPCFG = 0b1111111111111000; // enable AN0-AN2 as analog inputs
    ADCSSL = 0b0000000000000000;
    
    //-------------------------------------
	// Setup I2C Slave communications.
	slave_address = (utiny)(DSPIC_I2C_BASE_ADDRESS + (PORTE & 0x0007));
	setup_i2c();
    
    //-------------------------------------
	// Setup the oscillator to our default speed (fast). On request, we will
	// go to a slower speed.
	set_clock_118mhz();

    //-------------------------------------
    // Setup the serial ports. Choices are 38400, 19200, 9600, 4800, 2400.
    // At 118 Mhz, the *only* valid choice is 38400.
    //init_UART1(38400);
    //init_UART2(38400);

    ClrWdt();
    
    //-------------------------------------
    // Setup interrupts.
    INTCON2 = 0b0000000000000000; // INT0 and INT1 positive edge
    // Set NSTDIS if nested ints are not wanted.
	// Set the priority levels for ints we are using.
	// All peripherals default to level 4.
	IPC0  = 0b0000000000000110; // INT0 priority 6
	//IPC1  = 0b0000000000000000;
	//IPC2  = 0b0000000000000000;
	//IPC3  = 0b0000000000000000;
	IPC4  = 0b0100010001000101; // INT1 priority 5
	// Enable int-on-change bits.
	CNEN1 = 0b0000000001100000;
	// Clear the flags for all interrupts.
	IFS0  = 0b0000000000000000;
	IFS1  = 0b0000000000000000;
	IFS2  = 0b0000000000000000;
    // Enable the interrupts we are using.
    IEC0  = 0b0010000001000000; // b15:PortChange, b13:Slave I2C, b6:Timer2, b0:INT0
	IEC1  = 0b0000000000000000; // b0:INT1
	IEC2  = 0b0000000000000000;
} // dspic_init()


//--------------------------------------
// Main program.

int main(void)
{
    utiny kk, rcv_cnt;
    
	ClrWdt();
	
	// Init the PIC, its ports, and peripherals.
    dspic_init();
    
    send_UART1_flag		= FALSE;
    read_atod			= FALSE;
	read_scint_data	    = FALSE;
	read_geiger_data    = FALSE;
    
    // Blink the heartbeat LED to show that we're alive.
    HEARTBEAT_LED = 1; // LED on
	DelayBigMs(500);
	HEARTBEAT_LED = 0; // LED off
	DelayMs(100);

	scint_sample_session    = FALSE;
	sample_count = 0;
	ADCON1bits.SAMP = 1;        // start sampling
	// Default to the shortest delay factor until told otherwise.
	sample_delay = (ushort)(PORTE & 0x0007);

	// Main program loop. Stay here forever.
	while(1)
	{
		// Clear the Watchdog Timer (in case it's enabled).
		ClrWdt();
		
		// See if we've been asked to do any work.
		
		if (scint_sample_session)
		    {
    		//
    		// Perform a sampling session with the scintillation probe.
    		//
    		
    		// Blink the LED to show we got the command.
			HEARTBEAT_LED = 1; // LED on
			DelayMs(100);
			HEARTBEAT_LED = 0; // LED off
			
    		// Init the data area.
    		for (kk=0; kk<BIN_COUNT; kk++)
    		    bins[kk] = 0;
    		sample_count = 0;

    	    IFS0bits.INT0IF = 0;	// clear the interrupt flag
    	    
    	    // Enable INT0, disable Timer2.
    	    IEC0  = 0b0010000000000001;     // b15:PortChange, b13:Slave I2C, b6:Timer2, b0:INT0
    		
    		// Stay here until the session is done. An I2C command (interrupt) will get
    		// us out of this loop.
    		while (scint_sample_session)
    		    {
        		Nop();
        		}
        		
            // The session is over. Restore normal interrupts.
            IEC0  = 0b0010000001000000;     // b15:PortChange, b13:Slave I2C, b6:Timer2, b0:INT0

            // Blink the LED to show that we're done.
            HEARTBEAT_LED = 1; // LED on
            DelayMs(100);
            HEARTBEAT_LED = 0; // LED off
            
            heartbeat = FALSE;
            timing.second_tick = 0;
            TMR2   = 0;
    		}
    		
    	if (geiger_sample_session)
		    {
    		//
    		// Perform a sampling session with the Geiger tubes.
    		//
    		
    		// Blink the LED to show we got the command.
			HEARTBEAT_LED = 1; // LED on
			DelayMs(100);
			HEARTBEAT_LED = 0; // LED off
			
    		// Init the data area.
    		GM_data.count_1             = 0;
    		GM_data.count_2             = 0;
    		GM_data.coincidence_count   = 0;

    	    IFS0bits.CNIF = 0; // clear the interrupt flag
    	    
    	    // Enable PortChange interrupts, disable Timer2.
    	    IEC0  = 0b1010000000000000;     // b15:PortChange, b13:Slave I2C, b6:Timer2, b0:INT0
    		
    		// Stay here until the session is done. An I2C command (interrupt) will get
    		// us out of this loop.
    		while (geiger_sample_session)
    		    {
        		Nop();
        		}
        		
            // Restore normal interrupts.
            IEC0  = 0b0010000001000000;     // b15:PortChange, b13:Slave I2C, b6:Timer2, b0:INT0

            // Blink the LED to show that we're done.
            HEARTBEAT_LED = 1; // LED on
            DelayMs(100);
            HEARTBEAT_LED = 0; // LED off
            
            heartbeat = FALSE;
            timing.second_tick = 0;
            TMR2   = 0;
    		}
    		
    	if (read_scint_data)
		{
    		//
    		// The supervisor is reading our scintillation probe measurements. Send the contents of
    		// the bins[] array.
    		//
    		
    		read_scint_data = FALSE;
    		
    		for (kk=0; kk<BIN_COUNT; kk++)
    		    send_I2C_byte( bins[kk] );
        	
        	send_I2C_byte( (utiny)(256-checksum) ); // send checksum
    	}
    	
    	if (read_geiger_data)
		{
    		//
    		// The supervisor is reading our Geiger counts. Send the contents of
    		// the related vars.
    		//
    		
    		read_geiger_data = FALSE;
    		
    		// Send the count for tube #1.
    		send_I2C_byte( (utiny)(GM_data.count_1 & 0x00FF) );
    		send_I2C_byte( (utiny)(GM_data.count_1 >> 8) );
    		// Send the count for tube #2.
    		send_I2C_byte( (utiny)(GM_data.count_2 & 0x00FF) );
    		send_I2C_byte( (utiny)(GM_data.count_2 >> 8) );
    		// Send the coincidence count (Muons!!).
    		send_I2C_byte( (utiny)(GM_data.coincidence_count & 0x00FF) );
    		send_I2C_byte( (utiny)(GM_data.coincidence_count >> 8) );
        	
        	send_I2C_byte( (utiny)(256-checksum) ); // send checksum
    	}
    	
    	if (clock_7mhz)
    	    {
        	//
        	// The Supervisor wants us to run at 7.3 Mhz.
        	//
        	
        	clock_7mhz = FALSE;
        	set_clock_7mhz();
            }
            
        if (clock_118mhz)
    	    {
        	//
        	// The Supervisor wants us to run at 118 Mhz (our top speed).
        	//
        	
        	clock_118mhz = FALSE;
        	set_clock_118mhz();
            }
		
		if (send_UART1_flag)
		{
    		//
        	// The Supervisor wants us to send a char on our UART.
        	//
        	
    		send_UART1_flag = FALSE;
    		// Allow other stuff to be received.
    		rcv_cnt = receive_count-1; // don't include the checksum
		    for (kk=1; kk<rcv_cnt; kk++)
		    {
			    putch_UART1( i2c_in_buffer.data[kk] );
			}
		}

		// See if it's time to blink the heartbeat LED. When nothing more important
		// is happening, we do this once per second.
		if (heartbeat)
		{
			HEARTBEAT_LED = 1; // LED on
			DelayMs(10);
			HEARTBEAT_LED = 0; // LED off
			heartbeat = FALSE;
		}
	}
} // main()


void __attribute__((__interrupt__, no_auto_psv)) _INT0Interrupt(void)
// INT0 interrupt handler. This comes from the 'Trigger' output of the Analog Module.
// Use the 'jj_INT0' var for indexes and such. It's declared globally
// to avoid adding interrupt overhead.
{
    // Apply the delay factor, which is based on the lower 3 bits of our I2C address.
	// The sample_delay variable was assigned in main(), based on the I2C address that
	// was read from the switch pack.
    // When sample_delay is 0, this for-loop takes about 0.25 uS.
    // Every iteration of the loop adds about 0.31 uS.
    for (jj_INT0=0; jj_INT0<sample_delay; jj_INT0++) Nop();

    ADCON1bits.SAMP = 0;        // end sampling, start A/D conversion

    // Conversion time is about 1.6 uS (33.9nS * 4 * 12). [ADCS=4, conversion takes 12 cycles].
    while (!ADCON1bits.DONE);   // wait for conversion

    voltage = ADCBUF0;          // get the sampled value

    // Record the sample in the next open spot in the bins[] array. If we've used up all the
	// available space, then discard the sample.
    if (sample_count < BIN_COUNT)
        {
        bins[sample_count]   = (utiny)(voltage & 0x00FF);	// lo byte
        bins[sample_count+1] = (utiny)(voltage >> 8);		// hi byte
        sample_count = sample_count + 2;					// goto next open position
        }
        
    ADCON1bits.SAMP = 1;        // start sampling for next time
    
	IFS0bits.INT0IF = 0;	// clear the interrupt flag
} // INT0Interrupt()


void __attribute__((__interrupt__, no_auto_psv)) _INT1Interrupt(void)
// INT1 interrupt handler.
{
    IFS1bits.INT1IF = 0;	// clear the interrupt flag
} // INT1Interrupt()


void __attribute__((__interrupt__, no_auto_psv)) _CNInterrupt(void)
// Port Change interrupts. This is where we detect pulses from the Geiger tubes.
{
    // Capture the state of the pins.
    portb = PORTB;
    
    // Was there a pulse from tube #1?
    if (!(portb & 0x0008))                // RB3  - CN5
        {
        GM_data.count_1++;

        HEARTBEAT_LED = 1; // LED on
	    for (kk_CN=0; kk_CN<40; kk_CN++)
    	    Nop();
	    HEARTBEAT_LED = 0; // LED off
        }
        
    // Was there a pulse from tube #2?
    if (!(portb & 0x0010))              // RB4  - CN6
        {
        GM_data.count_2++;

        HEARTBEAT_LED = 1; // LED on
	    for (kk_CN=0; kk_CN<40; kk_CN++)
    	    Nop();
	    HEARTBEAT_LED = 0; // LED off
        }
        
    // Was there a pulse from both tubes at the same time?
    if (!(portb & 0x0018))
        {
        // Coincidence! Muon!!
        GM_data.coincidence_count++;
        }
    
    IFS0bits.CNIF = 0; // clear the flag
} // Port Change interrupt


void __attribute__((__interrupt__, no_auto_psv)) _T2Interrupt(void)
// Timer2 interrupt handler.
// Interrupts from Timer2 are used for general time-keeping. The interrupt occurs exactly
// every 10 mS, so we can use it to generate longer intervals easily.
{
	// Count the # of 10mS intervals.
    timing.tenMilSeconds++;
    timing.second_tick++;
    
    if (timing.second_tick > second_ticks)
    {
        // Do this stuff every second. Since the 'second_ticks' var is set according to the
        // current clock speed, stuff in this block can be made to happen every 1 second
        // even if we change clock speeds.
        
        // Count the # of seconds that have elapsed.
        timing.seconds++;
        // Count toward a 10-second interval.
        timing.ten_second_tick++;
		// Reset our tick counter to start the next 1-second interval.
        timing.second_tick = 0;
        // Set a flag that will cause the heartbeat LED to blink.
        heartbeat = TRUE;
    }
    
    if (timing.ten_second_tick > 9)
    {
        // Do this stuff every ten seconds.
        timing.ten_second_tick = 0;
        timing.tenSeconds++;
    }

	IFS0bits.T2IF = 0;	// clear the interrupt flag
} // T2Interrupt()


void __attribute__((__interrupt__, no_auto_psv)) _SI2CInterrupt(void)
// I2C Slave interrupt handler.
{
	ushort ssp_stat;
	bool checksum_error;
	
	IFS0bits.SI2CIF = 0;	// clear the interrupt flag

	// Bits: | ACKSTAT | TRSTAT | BCL | GCSTAT | ADD10 | IWCOL | I2C0V | D/A | Pstop | Sstart | R/W | RBF | TBF |
	ssp_stat = (I2CSTAT & 0b0000000000101110);
	    
	if (ssp_stat == 0b0000000000001010) // state 1 - master write, last byte address, START or RESTART
	{
    	//
		// We have been addressed by the Master.
		//
		
	    i2c_in_buffer.data[0] = I2CRCV; // clear BF
	    i2c_in_buffer.num_bytes = 0;    // our buffer is empty
	    I2CCONbits.SCLREL = 1;
	    checksum = 0;
	    receive_count = 0;
	}
	else if (ssp_stat == 0b0000000000101010) // state 2 - master write, last byte data
	{
    	//
		// The Master is sending us data.
		//
		
	    i2c_in_buffer.data[i2c_in_buffer.num_bytes] = I2CRCV; // get data
	    if (i2c_in_buffer.num_bytes < I2C_BUFFER_SIZE) // don't overflow the buffer
	    {
    	    // Track how many bytes we receive.
    	    receive_count++;
		    // Calculate a checksum.
		    checksum += i2c_in_buffer.data[i2c_in_buffer.num_bytes];
	        i2c_in_buffer.num_bytes++;
	    }
	    I2CCONbits.SCLREL = 1; // release the clock
	    sent_count = 0;
	}
	else if ((ssp_stat == 0b0000000000001100) || // state 3 - master read,  last byte address, START or RESTART
			 (ssp_stat == 0b0000000000101100) || // last byte data
	         (ssp_stat == 0b0000000000001110))
	{
    	//
		// The Master is reading from us, and is expecting us to send some data back.
		//
		
	    if (ssp_stat == 0b0000000000001110)
	    {
	        // Do a dummy read to clear the BF flag.
	        i2c_in_buffer.data[i2c_in_buffer.num_bytes] = I2CRCV;
	    }

		// The master sent us some bytes (including checksum) while in 'write mode'.
		// Now we are in 'read mode', so its time to process the command.
		// data[0] is always a command byte; the last byte is always a checksum.
		if (sent_count == 0)
		{
			// Check the checksum.
			checksum_error = FALSE;
			if (checksum)
			{
			    checksum_error = TRUE;
			    i2c_in_buffer.data[0] = 0; // the cmd is no longer valid
			}
			
			// For all I2C cmds, we return the command byte first.
			i2c_out_buffer.data[0] = i2c_in_buffer.data[0];
			
			// Process a command byte.
			// Commands can be either foreground or background. Foreground cmds are
			// handled immediately here in the ISR. Background cmds are handled by
			// the main program loop, because they may require time to complete.
			
			sending_count = 1;
			// For 'foreground' commands, data is ready by default.
			data_ready = TRUE;
			switch (i2c_in_buffer.data[0])
			{
				//
				// Commands related to scintillation probe measurements.
				//

				case 0x24:
				{
					// Background. Read analog (scintillation) sample data.
					// Main will get the data and send it when ready.
					read_scint_data = TRUE;
					data_ready = FALSE;
					break;	
				}
				
				case 0x26:
				{
					// Background. Do a scint pulse sampling session. Main will set
					// things up and then do nothing until the session is over.
					scint_sample_session = TRUE;
					break;	
				}
				
				case 0x27:
				{
					// Background. End a scint pulse sampling session.
					scint_sample_session = FALSE;
					break;	
				}
				
				case 0x28:
				{
					// Foreground. Set the sampling delay factor. The Supervisor sent us a
					// value that we multiply by the lower 3 bits of our I2C address, to determine
					// our delay factor. The delay will be applied in the ISR.
					sample_delay = (ushort)((PORTE & 0x0007) * (ushort)(i2c_in_buffer.data[1] + (i2c_in_buffer.data[2] * 256)));
					break;	
				}
				
				//
				// Commands related to Geiger-Mueller pulse counting.
				//
				
				case 0x29:
				{
					// Background. Do a Geiger pulse sampling session. Main will set
					// things up and then do nothing until the session is over.
					geiger_sample_session = TRUE;
					break;	
				}
				
				case 0x2A:
				{
					// Background. End a Geiger pulse sampling session.
					geiger_sample_session = FALSE;
					break;	
				}
				
				case 0x2B:
				{
					// Background. Read Geiger count data.
					// Main will get the data and send it when ready.
					read_geiger_data = TRUE;
					data_ready = FALSE;
					break;	
				}
				
				//
				// Miscellaneous commands.
				//
				
			    case 0x80:
			    {
			        // Foreground. I2C loopback test, to verify that the interface is working.
			        // The Master sent us: 80 55 00 2B.
			        // Return the received checksum byte. We will send: 80 2B 55.
			        i2c_out_buffer.data[1] = i2c_in_buffer.data[3];
			        sending_count = 2; // does not include the checksum
			        break;
			    }
			    
			    case 0x20:
				{
					// Foreground. Send the received data to UART1.
					send_UART1_flag = TRUE;
					sending_count = 1;
					break;	
				}
				
				case 0x21:
				{
					// Foreground. Set our clock to 7 Mhz.
					clock_7mhz = TRUE;
					sending_count = 1;
					break;	
				}
				
				case 0x22:
				{
					// Foreground. Set our clock to 118 Mhz.
					clock_118mhz = TRUE;
					sending_count = 1;
					break;	
				}
				
				case 0x23:
				{
					// Background. Read voltage from an A/D channel. This is for slow, general-
					// purpose readings.
					atod_channel = i2c_in_buffer.data[1];
					sending_count = 3;
					// Main will get the data and send it when ready.
					read_atod = TRUE;
					data_ready = FALSE;
					break;	
				}
				
			    default:
			    {
			    }
			}
			
			// If there was a problem in communications, replace the 1st 2 bytes with 0xEE.
			if (checksum_error)
			{
			    i2c_out_buffer.data[0] = 0xEE;
			    i2c_out_buffer.data[1] = 0xEE;
			}
			
			// Send the first response byte, which is nearly always the command byte.
			send_I2C_byte( i2c_out_buffer.data[0] );
			sent_count++;
		} // send the 1st response byte
		else
	    {
    	    // If it is a 'foreground' command, send the next byte (other than the very first byte).
    	    if (data_ready)
    	    {
    		    // If we've sent everything for the current command, then
    	        // send the checksum byte.
    	        if (sent_count >= sending_count)
    		        send_I2C_byte( (utiny)(256-checksum) ); // send checksum
    		    else
    		    	// Send the next response byte.
    	        	send_I2C_byte( i2c_out_buffer.data[sent_count] );
    	        sent_count++;
	        }
	    }
	}
	else if (ssp_stat == 0b0000000000101000) // state 5 - master NACK
	{
    	//
		// The Master is finished talking to us.
		//
		
	    if (I2CSTATbits.IWCOL) I2CSTATbits.IWCOL = 0;
	    if (I2CSTATbits.I2COV) I2CSTATbits.I2COV = 0;
	    // Do a dummy read to clear the BF flag.
	    i2c_in_buffer.data[i2c_in_buffer.num_bytes] = I2CRCV;
	}
} // SI2CInterrupt()
