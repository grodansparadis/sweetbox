//
// dspic_sci.c -- This module does some serial port (UART) stuff.
//
// Registration # MT2065.
//

#include <p30fxxxx.h>
#include "dspic_sci.h"

extern volatile utiny Osc_Freq_Mhz;
volatile utiny sci_byte;


void init_UART1(ulong baud)
// Init UART1. Assume the oscillator is 7.3728 Mhz, or 16X that.
{
    if (Osc_Freq_Mhz == 118)
        baud = (baud >> 4); // divide baud by 16
    
    switch (baud)
    {
        case 38400:
        {
            U1BRG = 2;
            break;   
        }
        case 19200:
        {
            U1BRG = 5;
            break;   
        }
        case 9600:
        {
            U1BRG = 11;
            break;   
        }
        case 4800:
        {
            U1BRG = 23;
            break;   
        }
        default: // 2400 baud
        {
            U1BRG = 47;
        }
    }
    
    U1TXREG = 0;
    U1MODE = 0b1000010000000000;
    U1STA  = 0b0000010000000000;
} // init_UART1()


void putch_UART1(utiny byte)
// Output a byte on UART1.
// Wait for the buffer to be empty.
{
    while(U1STAbits.UTXBF)
    {
        ClrWdt();
    }
    U1TXREG = byte;
    return;
} // putch_UART1()


/*
unsigned char getch(void)
{
    while(!RC1IF)   // set when register is not empty
    {
        continue;
    }

    return RCREG1;  // RXD9 and FERR are gone now
}
*/
